
WIZ550web.hex : Bootloader+Application hex file (for production)

WIZ550web_App.bin : Application binary for WIZnet configuration tool

WIZ550web_Boot.bin : Bootloader binary