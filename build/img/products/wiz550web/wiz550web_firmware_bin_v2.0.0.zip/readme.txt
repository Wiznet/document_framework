--------------------------
** H/W Revision 1.1
** Firmware Version 2.0.0
--------------------------

WIZ550web.hex : Bootloader+Application hex file (for production)

WIZ550web_App.bin : Application binary for WIZnet configuration tool

WIZ550web_Boot.bin : Bootloader binary