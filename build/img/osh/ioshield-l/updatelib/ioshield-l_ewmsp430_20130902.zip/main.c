/*
 * MSP430 LaunchPad - W5500 Ethernet BoosterPack
 *
 * WIZnet Co., Ltd
 */

#include "io430.h"
#include <stdio.h>

#include "src\config.h"
#include "src\w5500.h"
#include "src\usci.h"
#include "src\socket.h"
#include "src\util.h"
   
#include "src\loopback.h"

/*
 * Network Information
 */
uint8 mac[6] = {0x00, 0x08, 0xDC, 0x11, 0x22, 0x92};    // MAC Address
uint8 ip[4] = {192, 168, 1, 119};                       // IP Address
uint8 gw[4] = {192, 168, 1, 1};                         // Gateway Address
uint8 sn[4] = {255, 255, 255, 0};                       // SubnetMask Address
uint8 dns[4] = {168, 126, 63, 1};                       // DNS Server Address

uint8 destip[4] = {192, 168, 1, 214};           // Destination IP Address for HTTP Client
uint16 destport = 80;                           // Destination Port number for HTTP Client

//TX MEM SIZE- SOCKET 0-7:2KB
//RX MEM SIZE- SOCKET 0-7:2KB
uint8 txsize[MAX_SOCK_NUM] = {2,2,2,2,2,2,2,2};
uint8 rxsize[MAX_SOCK_NUM] = {2,2,2,2,2,2,2,2};

uint8 TX_BUF[TX_RX_MAX_BUF_SIZE];
uint8 RX_BUF[TX_RX_MAX_BUF_SIZE];

/*
 * Etc.
 */
uint8 getMAC[6];
uint8 getIP[4];
uint8 getGateway[4];
uint8 getSubnet[4];

void Init_MSP430(void)
{    
    BCSCTL1 = CALBC1_16MHZ;            // Set DCO to 16 MHz clock
    DCOCTL = CALDCO_16MHZ;
    
    Init_UART();       
    Init_SPI(); 
}

void Init_W5500(void)
{  
    wiz_NetInfo netinfo;        
    device_init(txsize, rxsize); // Socket Tx, Rx memory size init function
       
#ifndef __WIZ550IO__
    uint8 i;    
    for(i=0; i<4; i++){
        netinfo.mac[i] = mac[i];
        netinfo.ip[i] = ip[i];
        netinfo.sn[i] = sn[i];
        netinfo.gw[i] = gw[i];
        netinfo.dns[i] = dns[i];
    }
    netinfo.mac[i] = mac[i];
    i++;
    netinfo.mac[i] = mac[i];
    
    SetNetInfo(&netinfo);     
    printf("\r\nMSP430 LaunchPad - W5500 TestBoard\r\n");
#else
    printf("\r\nMSP430 LaunchPad - WIZ550io BoosterPack\r\n");
#endif 
    
    GetNetInfo(&netinfo);
	
    printf("\r\nMAC : %X:%X:%X:%X:%X:%X", netinfo.mac[0],netinfo.mac[1],netinfo.mac[2],netinfo.mac[3],netinfo.mac[4],netinfo.mac[5]);
	printf("\r\nIP : %d.%d.%d.%d", netinfo.ip[0],netinfo.ip[1],netinfo.ip[2],netinfo.ip[3]);    
}

void Init_LED(void)
{
    P1DIR |= LED1_PIN;
    P1OUT |= LED1_PIN;
}

// LED1 : Red LED Control
void LED1(uint8 control)
{
    if(control == ON) {       
        LED1_PORT |= LED1_PIN;
    } else {                
        LED1_PORT &= ~LED1_PIN;
    }
}

/**
@brief  This function gets PHY Status register in common register.
 */
uint8 getPHY(void)
{
    //return IINCHIP_READ(PHY);
	return IINCHIP_READ_COMMON(WIZC_PHYCFG);
}

void Check_link(void)
{
    uint8 link_status;
    static uint8 count = 0;
    // Link check
	do
	{		
        Reset_W5500(); // W5500 Hardware Reset

		Delay_ms(2000 + (100 * count));		
		count++;
        
		link_status = (uint8)((getPHY() >> 5) & 0x01); // or PHYSTATUS & 0x20, PHY register defined (COMMON_BASE + 0x0035)		
	} while(link_status != 0x01);
}

/**
@brief  Main function
*/
void main( void )
{
    // Stop watchdog timer to prevent time out reset
    WDTCTL = WDTPW + WDTHOLD;
       
    uint8 ledcontrol = 0;        
      
    Init_LED();    
    LED1(ON);    
    
    Init_MSP430();      // MSP430 Configuration          
    Init_W5500();       // W5500 (WIZ550io) Configuration
    Delay_ms(50);
       
    while(1) {    
      /* Loopback Test */
      loopback_tcps(1, 5000);
      loopback_tcps(2, 5001);
      loopback_udp(3, 3000);
      
      ledcontrol ? LED1(ON):LED1(OFF);      
      ledcontrol = ~ledcontrol;            
    }
}
