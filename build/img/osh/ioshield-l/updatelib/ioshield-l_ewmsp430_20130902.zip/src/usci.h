#include "types.h"

#define RXD        BIT1 
#define TXD        BIT2

#define SPI_MODE_0 (UCCKPH)			    /* CPOL=0 CPHA=0 */
#define SPI_MODE_1 (0)                 	/* CPOL=0 CPHA=1 */
#define SPI_MODE_2 (UCCKPL | UCCKPH)    /* CPOL=1 CPHA=0 */
#define SPI_MODE_3 (UCCKPL)			    /* CPOL=1 CPHA=1 */

#define SPI_CLOCK_DIV1   1
#define SPI_CLOCK_DIV2   2
#define SPI_CLOCK_DIV4   4
#define SPI_CLOCK_DIV8   8
#define SPI_CLOCK_DIV16  16
#define SPI_CLOCK_DIV32  32
#define SPI_CLOCK_DIV64  64
#define SPI_CLOCK_DIV128 128

//tmp : SPI Clock Setting
#define SPI_CLOCK           SPI_CLOCK_8MHZ

#define SPI_CLOCK_16MHZ     SPI_CLOCK_DIV1
#define SPI_CLOCK_8MHZ      SPI_CLOCK_DIV2  
#define SPI_CLOCK_4MHZ      SPI_CLOCK_DIV4
#define SPI_CLOCK_2MHZ      SPI_CLOCK_DIV8
#define SPI_CLOCK_1MHZ      SPI_CLOCK_DIV16


/*
 *  WIZ820io(W5200)
 */
   // SCS -  P2.0
   // SCLK - P1.5     
   // MISO - P1.6
   // MOSI - P1.7
   
#define WIZ_SCLK_PIN			BIT5
#define WIZ_MISO_PIN			BIT6
#define WIZ_MOSI_PIN			BIT7
#define WIZ_SPI_OUT_PORT		P1OUT
#define WIZ_SPI_IN_PORT			P1IN
#define WIZ_SPI_SCLK_PORT		P1OUT
#define WIZ_SCS_PIN			    BIT0 
#define WIZ_SCS_PORT			P2OUT

#define WIZ_INT_PIN				BIT7 // JP2
#define WIZ_INT_PORT			P2IE
#define WIZ_PWDN_PIN			BIT0 // JP3
#define WIZ_PWDN_PORT			P2OUT
#define WIZ_RESET_PIN			BIT4 // JP5
#define WIZ_RESET_PORT			P1OUT

#define LED1_PIN                BIT0
#define LED1_PORT               P1OUT

// port masks, used to prevent accidental configuration changes
#define P1MASK					WIZ_SCLK_PIN + WIZ_MISO_PIN + WIZ_MOSI_PIN + WIZ_RESET_PIN // add all P1 pins
#define P2MASK                  WIZ_PWDN_PIN + WIZ_INT_PIN + WIZ_SCS_PIN // add all P2 pins
#define P3MASK					0 // add all P3 pins
//


#define P1DIR_SETUP P1DIR |= WIZ_SCLK_PIN + WIZ_MOSI_PIN + WIZ_RESET_PIN               
#define P1OUT_SETUP P1OUT &= ~WIZ_SCLK_PIN; P1OUT |= WIZ_MOSI_PIN + WIZ_RESET_PIN       
//#define P1OUT_SETUP P1OUT |= WIZ_SCLK_PIN + WIZ_MOSI_PIN + WIZ_RESET_PIN
   
#define P1SEL_SETUP P1SEL |= WIZ_SCLK_PIN + WIZ_MOSI_PIN + WIZ_MISO_PIN
#define P1SEL2_SETUP P1SEL2 |= WIZ_SCLK_PIN + WIZ_MOSI_PIN + WIZ_MISO_PIN
   
#define P2DIR_SETUP P2DIR |= WIZ_SCS_PIN
#define P2OUT_SETUP P2OUT |= WIZ_SCS_PIN

//#define P2DIR_SETUP P2DIR |= WIZ_PWDN_PIN
//#define P2OUT_SETUP P2OUT |= WIZ_PWDN_PIN

/*
 * End board specific
 */
#define WIZ_RESET_0				WIZ_RESET_PORT &= ~WIZ_RESET_PIN
#define WIZ_RESET_1				WIZ_RESET_PORT |= WIZ_RESET_PIN
#define WIZ_POWER_UP			WIZ_PWDN_PORT &= ~WIZ_PWDN_PIN
#define WIZ_POWER_DOWN			WIZ_PWDN_PORT |= WIZ_PWDN_PIN
#define WIZ_SELECT				WIZ_SCS_PORT &= ~WIZ_SCS_PIN
#define WIZ_DESELECT			WIZ_SCS_PORT |= WIZ_SCS_PIN
#define WIZ_IE_ENABLE			WIZ_INT_PORT |= WIZ_INT_PIN
#define WIZ_IE_DISABLE			WIZ_INT_PORT &= ~WIZ_INT_PIN
//
#define wizPowerUp()			WIZ_POWER_UP
#define wizPowerDown()			WIZ_POWER_DOWN
#define wizSelect()				WIZ_SELECT
#define wizDeselect()			WIZ_DESELECT
#define wizEnableInterrupt()	WIZ_IE_ENABLE
#define wizDisableInterrupt()	WIZ_IE_DISABLE


void Init_UART(void);
void Init_SPI(void);
uint8 MSP430_SpiSendData(u_char byte);

void initTimer(void);