#include "io430.h"
#include <stdio.h>
#include "usci.h"
#include "util.h"

extern void IINCHIP_CSon();
extern void IINCHIP_CSoff();

int (putchar)(int c)
{   
    // **** BEGIN SPECIFIC CODE FOR ANSI TERMINAL ***** //
    //
    // For I/O with ANSI terminal (or equivalent), convert C
    // line end (\n) to carriage-return + linefeed combo (\r\n).
    //
    if (c == '\n') putchar('\r');
    //
    // (**** END SPECIFIC CODE FOR ANSI TERMINAL ***** //

    if (c != EOF)
    {          
        while (!(IFG2&UCA0TXIFG));			// USCI_A0 TX buffer ready?
        UCA0TXBUF = c;					    // TX -> RXed character
    }   
    return (c);
}

/**
 * Initializes the UART for 9600 baud, 16MHz 
 **/
void Init_UART(void) {    
    // USCI A0 UART  
    UCA0CTL1 |= UCSWRST;    
    UCA0CTL1 |= UCSSEL_2;             // Have USCI use System Master Clock: AKA core clk 16MHz
    
    UCA0BR0 = 0x82;                    // 16MHz 9600, see user manual, 1666, 0x682
    UCA0BR1 = 0x06;                    //    
    
    UCA0MCTL = UCBRS_6;                // Modulation UCBRSx = 1
    
    P1SEL |= RXD + TXD ;                // Select TX and RX functionality for P1.1 & P1.2
    P1SEL2 |= RXD + TXD ;              //
    
    UCA0CTL1 &= ~UCSWRST;             // Start USCI state machine
}

void Init_SPI(void) {
    // USCI B0 SPI    
    UCB0CTL1 = UCSWRST; 
    UCB0CTL1 |= UCSSEL_2;      // Put USCI in reset mode, source USCI clock from SMCLK	        
    UCB0CTL0 = SPI_MODE_0 | UCMSB | UCSYNC | UCMST;  // Use SPI MODE 0 - CPOL=0 CPHA=0          
  
    switch(SPI_CLOCK)
    {
        case SPI_CLOCK_16MHZ:
            UCB0BR0 = SPI_CLOCK_DIV1 & 0xFF;    // Set Initial speed to 16MHz (16MHz / 1)
            UCB0BR1 = (SPI_CLOCK_DIV1 >> 8 ) & 0xFF;
            break;
        case SPI_CLOCK_8MHZ:
            UCB0BR0 = SPI_CLOCK_DIV2 & 0xFF;    // Set Initial speed to 8MHz (16MHz / 2)
            UCB0BR1 = (SPI_CLOCK_DIV2 >> 8 ) & 0xFF;
            break;
        case SPI_CLOCK_4MHZ:
            UCB0BR0 = SPI_CLOCK_DIV4 & 0xFF;    // Set Initial speed to 4MHz (16MHz / 4)
            UCB0BR1 = (SPI_CLOCK_DIV16 >> 8 ) & 0xFF;
            break;
        case SPI_CLOCK_2MHZ:
            UCB0BR0 = SPI_CLOCK_DIV8 & 0xFF;    // Set Initial speed to 2MHz (16MHz / 8)
            UCB0BR1 = (SPI_CLOCK_DIV16 >> 8 ) & 0xFF;
            break;
        case SPI_CLOCK_1MHZ:
        default:
            UCB0BR0 = SPI_CLOCK_DIV16 & 0xFF;    // Set Initial speed to 1MHz (16MHz / 16)
            UCB0BR1 = (SPI_CLOCK_DIV16 >> 8 ) & 0xFF;
            break;
    }
        
    P1DIR_SETUP;	   
    P1OUT_SETUP;
    P1SEL_SETUP;
    P1SEL2_SETUP;    
    P2DIR_SETUP;
	P2OUT_SETUP;
    
    UCB0CTL1 &= ~UCSWRST;			    // release USCI for operation
}

uint8 MSP430_SpiSendData(u_char byte)
{   
    // USCI_B0  SPI Mode
    while (!(UC0IFG & UCB0TXIFG))
		; // wait for previous tx to complete
	UCB0TXBUF = byte; // setting TXBUF clears the TXIFG flag
	while (!(UC0IFG & UCB0RXIFG))
		; // wait for an rx character?    
	return UCB0RXBUF; // reading clears RXIFG flag    
}