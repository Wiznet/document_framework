#include <stdio.h>
#include <stdarg.h>
#include "config.h"
#include "util.h"
#include "w5500.h"

#include "usci.h" // for MSP430 Pin configuration, temp
#include "io430.h"

#ifdef __GNUC__
  /* With GCC/RAISONANCE, small printf (option LD Linker->Libraries->Small printf
     set to 'Yes') calls __io_putchar() */
  #define PUTCHAR_PROTOTYPE int __io_putchar(int ch)
#else
  #define PUTCHAR_PROTOTYPE int fputc(int ch, FILE *f)
#endif /* __GNUC__ */

/*
 * W5200 hardware reset
 */
//void Reset_W5200(void) {
void Reset_W5500(void) {
	WIZ_RESET_0;
	Delay_us(20);
	WIZ_RESET_1;
	Delay_ms(200);
	wizPowerUp();
	Delay_ms(200);
}

/*******************************************************************************
* Function Name  : Delay_us
* Description    : Delay per micro second.
* Input          : time_us
* Output         : None
* Return         : None
*******************************************************************************/

void Delay_us(u_char time_us) {
	u_char c = 0;
	while (c++ < time_us) {
		__delay_cycles(16);
	}
}


/*******************************************************************************
* Function Name  : Delay_ms
* Description    : Delay per mili second.
* Input          : time_ms
* Output         : None
* Return         : None
*******************************************************************************/

void Delay_ms(u_int time_ms) {
	u_int c = 0;
	while (c++ < time_ms) {
		__delay_cycles(16000);
	}
}



