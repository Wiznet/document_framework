Imports System
Imports System.Net
Imports System.Net.Sockets
Imports System.Text
Imports System.Text.RegularExpressions

Public Class frmMain

#Region "global parameters"
    Friend isSchOk As Boolean = False
    Friend SchPwd As String = ""
    Friend isBroadcast As Boolean = False
    Friend directIP As String = ""
    Friend directPort As Integer = 0

#End Region
#Region "private parameters"
    'root node of treeview
    Private rNode As Windows.Forms.TreeNode
    'selected child index of rnode; 2010. 06. 29
    Private sIndex As UInt16 = 0

    'currently selected node
    Private sNode As TreeNode

    'sockets
    Private WithEvents sckUDP As New clsSckUDP 'udp searching & setting
    Private WithEvents sckTCP As New clsSckTCP 'direct searching & setting
    Private WithEvents sckTcpUp As New clsSckTCP 'Firmware updating
    'ports
    Private bPort As Integer = 50001 '60001 '50001 'udp broadcast port
    Private uPort As Integer = 50002 '60002 '50002 'firmware upload port

    Private udpRep As IPEndPoint 'udp ip end point
    Private tcpRep As IPEndPoint 'tcp ip end point

    '
    Private Sec As New clsSEC

    'MA command in the prefix
    Private MACMD(9) As Byte
    'store the calculate setting msg in bytes
    Private bSetMsg() As Byte
    'stop watch
    Dim sw As New Stopwatch
    'if the value of found device displayed
    Dim isValDisplayed As Boolean = False
    'firmware upload command sent flag
    Dim isUploadCmd As Boolean = False
    'firmware upload status
    Dim isUploading As Boolean = False
    'firmware length
    Dim fLen As Long = 0
    'file stream
    Dim fStrm As IO.FileStream
    Dim bufLen As Int16 = 1024
    Dim fDat(bufLen - 1) As Byte
    Dim sOffset As Long = 0

    Dim rxLen As Long = 0

    'command states
    Private Const S_NULL As Int16 = 0
    Private Const S_SEARCH As Int16 = 1
    Private Const S_SET As Int16 = 2
    Private Const S_RESET As Int16 = 3
    Private Const S_UPLOAD As Int16 = 4
    Private Const S_FACTORY As Int16 = 5

    Private cmdState As Int16 = 0

    '20120808
    Private new_module_ver() As Integer = {3, 4, 5, 7}
    Private Const NEW_MODULE_FW_SIZE As Integer = 65536 ' 64K bytes
    'end of new module check

    Friend Function prefix_MA(ByVal mac As String) As Byte()
        Dim ret(9) As Byte
        ret(0) = &H4DS
        ret(1) = &H41

        Dim s() As String = Split(mac, ":")
        If s.Length = 6 Then
            For i As Int16 = 0 To 5
                ret(2 + i) = CInt("&H" & s(i))
            Next
        Else
            For i As Int16 = 0 To 5
                ret(2 + i) = &HFF
            Next
        End If
        ret(8) = &HD
        ret(9) = &HA

        Return ret
    End Function

    Private Structure myDataItem
        Dim Name As String
        Dim rVal As Byte
        Public Sub New(ByVal _name As String, ByVal _value As Byte)
            Name = _name
            rVal = _value

        End Sub
        Public Overrides Function ToString() As String
            Return Me.Name
        End Function
    End Structure

#End Region
#Region "Delegate function"
    Private Delegate Sub SetVsBarCallback(ByVal vs As ToolStripProgressBar, ByVal value As Integer)
    Private Sub setVsBarVal(ByVal vs As ToolStripProgressBar, ByVal value As Integer)
        If vs.ProgressBar.InvokeRequired Then
            Dim d As New SetVsBarCallback(AddressOf setVsBarVal)
            Me.Invoke(d, New Object() {[vs], [value]})
        Else
            vs.Value = value
        End If
    End Sub
    Private Delegate Sub InitVsBarCallback(ByVal vs As ToolStripProgressBar, ByVal maxVal As Integer)
    Private Sub InitVsBar(ByVal vs As ToolStripProgressBar, ByVal maxVal As Integer)
        If vs.ProgressBar.InvokeRequired Then
            Dim d As New InitVsBarCallback(AddressOf InitVsBar)
            Me.Invoke(d, New Object() {[vs], [maxVal]})
        Else
            vs.ProgressBar.Maximum = maxVal
      
        End If
    End Sub
    Private Delegate Sub SetTextCallback(ByVal ctrl As Control, ByVal [text] As String)
    Private Sub SetText(ByVal ctrl As Control, ByVal text As String)
        If ctrl.InvokeRequired Then
            Dim d As New SetTextCallback(AddressOf SetText)
            Me.Invoke(d, New Object() {[ctrl], [text]})
        Else
            ctrl.Text = text
        End If
    End Sub
    Private Delegate Sub SetProgressBarStyleCallBack(ByVal pb As ToolStripProgressBar, ByVal isMarquee As Boolean)
    Private Sub SetProgressBarStyle(ByVal pb As ToolStripProgressBar, ByVal isMarquee As Boolean)

    End Sub
    Private Delegate Sub tvAddNodeCallback(ByVal tView As TreeView, ByVal pNode As Windows.Forms.TreeNode, ByVal nSec As clsSEC)
    Private Sub tvAddNode(ByVal tView As TreeView, ByVal pNode As Windows.Forms.TreeNode, ByVal nSec As clsSEC)

        If tView.InvokeRequired Then
            Dim d As New tvAddNodeCallback(AddressOf tvAddNode)
            Me.Invoke(d, New Object() {[tView], [pNode], [nSec]})
        Else
            Dim nd As Windows.Forms.TreeNode
            Dim idx As Integer = 0
            Dim isExist As Boolean = False
            For Each nd In pNode.Nodes
                If nd.Text = nSec.MC.data Then
                    isExist = True
                    idx += 1
                    pNode.Nodes.Remove(nd)
                    Exit For
                End If
            Next

            Dim cNode As Windows.Forms.TreeNode = pNode.Nodes.Add(nSec.MC.data)
            cNode.Nodes.Add("Model name: " & nSec.MN.data)
            cNode.Nodes.Add("UART: " & nSec.UN.data)
            cNode.Nodes.Add("Firmware version: " & nSec.VR.data)
            cNode.Nodes.Add("Status: " & nSec.ST.data)
            cNode.Nodes.Add("Debug message: " & IIf(nSec.DG.data = "0", "Disabled", "Enabled"))
            'host name
            'cNode.Nodes.Add("Host name: " & nSec.DW.data)

            cNode.Tag = nSec
            If pNode.Nodes.Count > 0 Then
                pNode.Expand()
            End If
        End If

    End Sub
    Private Delegate Sub SetRtbTxtCallback(ByVal rtb As RichTextBox, ByVal [text] As String, ByVal isAppend As Boolean)
    Private Sub SetRtbTxt(ByVal rtb As RichTextBox, ByVal text As String, ByVal isAppend As Boolean)
        If rtb.InvokeRequired Then
            Dim d As New SetRtbTxtCallback(AddressOf SetRtbTxt)
            Me.Invoke(d, New Object() {[rtb], [text], [isAppend]})
        Else
            If isAppend Then
                rtb.AppendText(text)
                'rtb.Select(rtb.TextLength, 0)
                rtb.ScrollToCaret()
            Else
                rtb.Text = text
            End If
        End If
    End Sub
    Private Delegate Sub SetCtrlStateCallback(ByVal ctrl As Control, ByVal enabled As Boolean)
    Private Sub setCtrlState(ByVal ctrl As Control, ByVal enabled As Boolean)
        If ctrl.InvokeRequired Then
            Dim d As New SetCtrlStateCallback(AddressOf setCtrlState)
            Me.Invoke(d, New Object() {[ctrl], [enabled]})
        Else
            ctrl.Enabled = enabled

        End If
    End Sub
#End Region

#Region "parsing functions"
    Private Function parsingMsg(ByVal msg As String) As clsSEC
        Dim ret As clsSEC = New clsSEC
        If msg.Length > 0 Then
            Dim s() As String = Split(msg, vbCrLf)
            For i As Integer = 0 To s.Length - 1
                If s(i).Length > 2 Then
                    Dim sData As String = s(i).Substring(2, s(i).Length - 2)
                    Select Case s(i).Substring(0, 2)
                       
                        Case "MC"
                            ret.MC.name = "MC"
                            ret.MC.data = sData
                        Case "VR"
                            ret.VR.name = "VR"
                            ret.VR.data = sData
                        Case "MN"
                            ret.MN.name = "MN"
                            ret.MN.data = sData
                        Case "ST"
                            ret.ST.name = "ST"
                            ret.ST.data = sData
                        Case "IM"
                            ret.IM.name = "IM"
                            ret.IM.data = sData
                        Case "OP"
                            ret.OP.name = "OP"
                            ret.OP.data = sData
                        Case "DD"
                            ret.DD.name = "DD"
                            ret.DD.data = sData
                        Case "CP"
                            ret.CP.name = "CP"
                            ret.CP.data = sData
                        Case "PO"
                            ret.PO.name = "PO"
                            ret.PO.data = sData
                        Case "DG"
                            ret.DG.name = "DG"
                            ret.DG.data = sData
                        Case "KA"
                            ret.KA.name = "KA"
                            ret.KA.data = sData
                        Case "KI"
                            ret.KI.name = "KI"
                            ret.KI.data = sData
                        Case "KE"
                            ret.KE.name = "KE"
                            ret.KE.data = sData
                        Case "RI"
                            ret.RI.name = "RI"
                            ret.RI.data = sData
                        Case "LI"
                            ret.LI.name = "LI"
                            ret.LI.data = sData
                        Case "SM"
                            ret.SM.name = "SM"
                            ret.SM.data = sData
                        Case "GW"
                            ret.GW.name = "GW"
                            ret.GW.data = sData
                        Case "DS"
                            ret.DS.name = "DS"
                            ret.DS.data = sData
                        Case "PI"
                            ret.PI.name = "PI"
                            ret.PI.data = sData
                        Case "PP"
                            ret.PP.name = "PP"
                            ret.PP.data = sData
                        Case "DP"
                            ret.DP.name = "DP"
                            ret.DP.data = sData
                        Case "DI"
                            ret.DI.name = "DI"
                            ret.DI.data = sData
                        Case "DW"
                            ret.DW.name = "DW"
                            ret.DW.data = sData
                        Case "DH"
                            ret.DH.name = "DH"
                            ret.DH.data = sData
                        Case "LP"
                            ret.LP.name = "LP"
                            ret.LP.data = sData
                        Case "RP"
                            ret.RP.name = "RP"
                            ret.RP.data = sData
                        Case "RH"
                            ret.RH.name = "RH"
                            ret.RH.data = sData
                        Case "BR"
                            ret.BR.name = "BR"
                            ret.BR.data = sData
                        Case "DB"
                            ret.DB.name = "DB"
                            ret.DB.data = sData
                        Case "PR"
                            ret.PR.name = "PR"
                            ret.PR.data = sData
                        Case "SB"
                            ret.SB.name = "SB"
                            ret.SB.data = sData
                        Case "FL"
                            ret.FL.name = "FL"
                            ret.FL.data = sData
                        Case "IT"
                            ret.IT.name = "IT"
                            ret.IT.data = sData
                        Case "PT"
                            ret.PT.name = "PT"
                            ret.PT.data = sData
                        Case "PS"
                            ret.PS.name = "PS"
                            ret.PS.data = sData
                        Case "PD"
                            ret.PD.name = "PD"
                            ret.PD.data = sData
                        Case "TE"
                            ret.TE.name = "TE"
                            ret.TE.data = sData
                        Case "SS"
                            ret.SS.name = "SS"
                            ret.SS.data = sData
                        Case "NP"
                            ret.NP.name = "NP"
                            ret.NP.data = sData
                        Case "SP"
                            ret.SP.name = "SP"
                            ret.SP.data = sData
                        Case "LG"
                            ret.LG.name = "LG"
                            ret.LG.data = sData
                        Case "ER"
                            ret.ER.name = "ER"
                            ret.ER.data = sData
                        Case "UN"
                            ret.UN.name = "UN"
                            ret.UN.data = sData
                    End Select
                End If
            Next
        End If
        Return ret

    End Function

    Private Sub DisplayValue(ByVal se As clsSEC)
        'obtain ip method
        Select Case se.IM.data
            Case 0
                rbStatic.Checked = True
                txtLIP.Text = se.LI.data
                txtLP.Text = se.LP.data
                txtLP.Enabled = True

                txtSubnet.Text = se.SM.data
                txtGw.Text = se.GW.data
                txtDNS.Text = se.DS.data
                txtPId.Enabled = False
                txtPPwd.Enabled = False
            Case 1
                rbDHCP.Checked = True
                txtLIP.Enabled = False
                'txtLP.Enabled = False
                txtLIP.Text = se.LI.data
                txtLP.Text = se.LP.data
                txtSubnet.Text = se.SM.data
                txtGw.Text = se.GW.data
                txtDNS.Text = se.DS.data
                txtSubnet.Enabled = False
                txtGw.Enabled = False
                txtDNS.Enabled = False
                txtPId.Enabled = False
                txtPPwd.Enabled = False

            Case 2
                rbPPP.Checked = True
                txtLIP.Enabled = False
                'txtLP.Enabled = False
                txtLIP.Text = se.LI.data
                txtLP.Text = se.LP.data
                txtSubnet.Text = se.SM.data
                txtGw.Text = se.GW.data
                txtDNS.Text = se.DS.data
                txtSubnet.Enabled = False
                txtGw.Enabled = False
                txtDNS.Enabled = False
                txtPId.Enabled = True
                txtPPwd.Enabled = True
                txtPId.Text = se.PI.data.Trim
                txtPPwd.Text = se.PP.data.Trim
        End Select
        'operation mode
        Select Case se.OP.data
            Case "0" 'client
                rbClient.Checked = True
                txtRIP.Enabled = True
                txtRIP.Text = se.RH.data
                txtRp.Enabled = True
                txtRp.Text = se.RP.data

            Case "1" 'server
                rbServer.Checked = True
                txtRIP.Enabled = False
                txtRIP.Text = se.RH.data
                txtRp.Enabled = False
                txtRp.Text = se.RP.data

            Case "2" 'mixed
                rbMixed.Checked = True
                txtRIP.Enabled = True
                txtRIP.Text = se.RH.data
                txtRp.Enabled = True
                txtRp.Text = se.RP.data

            Case "3" 'udp
                rbUdp.Checked = True
                txtRIP.Enabled = True
                txtRIP.Text = se.RH.data
                txtRp.Enabled = True
                txtRp.Text = se.RP.data

        End Select
        'ddns settings
        If se.DX.data.Length > 0 Then
            cboDdns.SelectedItem = CType(se.DX.data, Int16)
        End If

        txtDPort.Text = se.DP.data
        txtDID.Text = se.DI.data
        txtDPwd.Text = se.DW.data.Trim
        txtDHost.Text = "" 'se.DH.data
        'serial settings
        cboBaud.SelectedIndex = CType(se.BR.data, Integer)
        cboDataBit.SelectedIndex = CType(se.DB.data, Integer)
        cboParity.SelectedIndex = CType(se.PR.data, Integer)
        cboStopBit.SelectedIndex = CType(se.SB.data, Integer)
        cboFlow.SelectedIndex = CType(se.FL.data, Integer)
        'debug message
        If se.DG.data = "0" Then
            chkDebug.Checked = False
        ElseIf se.DG.data = "1" Then
            chkDebug.Checked = True
        End If
        'serial data packing settings
        txtTimer.Text = se.PT.data '0~65535ms
        txtSize.Text = se.PS.data '0~255
        txtChar.Text = se.PD.data '0~200
        'option settings
        txtInactiveTimer.Text = se.IT.data '0~65535ms
        'reconnection (for client mode only); A20110222
        txtReconn.Text = se.RI.data
        '
        If se.TE.data = "1" Then
            chkTrigger.Checked = True
            txtTrigger1.Enabled = True
            txtTrigger2.Enabled = True
            txtTrigger3.Enabled = True
            If se.SS.data.Length = 6 Then
                txtTrigger1.Text = se.SS.data.Substring(0, 2)
                txtTrigger2.Text = se.SS.data.Substring(2, 2)
                txtTrigger3.Text = se.SS.data.Substring(4, 2)
            Else
                'error
            End If
        ElseIf se.TE.data = "0" Then
            chkTrigger.Checked = False
            
            txtTrigger1.Enabled = False
            txtTrigger2.Enabled = False
            txtTrigger3.Enabled = False
            If se.SS.data.Length = 6 Then
                txtTrigger1.Text = se.SS.data.Substring(0, 2)
                txtTrigger2.Text = se.SS.data.Substring(2, 2)
                txtTrigger3.Text = se.SS.data.Substring(4, 2)
            Else
                'error
            End If
        End If
        txtSearchPwd.Text = se.SP.data.Trim
        If se.CP.data = "1" Then
            chkConnPwd.Checked = True
            txtConnPwd.Enabled = True
            txtConnPwd.Text = se.NP.data.Trim
        ElseIf se.CP.data = "0" Then
            chkConnPwd.Checked = False
            txtConnPwd.Enabled = False
            txtConnPwd.Text = ""
        End If
        'network prorocol
        If se.PO.data = "0" Then
            rbRaw.Checked = True
        ElseIf se.PO.data = "1" Then
            rbTelnet.Checked = True
        End If
        'Keep alive settings
        If se.KA.data = "1" Then
            chkKa.Checked = True
            txtKA.Enabled = True
            txtKaRep.Enabled = True
            txtKA.Text = se.KI.data
            txtKaRep.Text = se.KE.data
        ElseIf se.KA.data = "0" Then
            chkKa.Checked = False
            txtKA.Enabled = False
            txtKaRep.Enabled = False
            'txtKA.Text = "7000"
            'txtKaRep.Text = "1000"

        End If
    End Sub
    Private Function VerifyIpAddr(ByVal ip As String) As Boolean
        If ip.Length > 0 Then
            Dim s() As String = Split(ip, ".")
            If s.Length = 4 Then
                For i As Int16 = 0 To 3
                    Try
                        If CType(s(i), Int16) > 255 Or CType(s(i), Int16) < 0 Then
                            Return False
                            Exit For
                        End If
                    Catch ex As Exception
                        Return False
                        Exit For
                    End Try
                Next
                Return True
            Else
                Return False
            End If
        Else
            Return False
        End If

    End Function
    Private Function verifyNumber(ByVal num As String, ByVal minVal As Integer, ByVal maxVal As Integer) As Boolean
        Try
            If CType(num, Integer) >= minVal And CType(num, Integer) <= maxVal Then
                Return True
            Else
                Return False
            End If
        Catch ex As Exception
            Return False
        End Try
    End Function
    Private Function CalcSetMsg() As String
        Dim ret As String = ""
        'If txtSearchPwd.Text.Trim.Length > 0 Then
        'ret = "PW" & txtSearchPwd.Text.Trim & vbCrLf
        'Else
        'ret = "PW" & " " & vbCrLf
        'End If
        ret = "PW" & Sec.SP.data & vbCrLf
        'ret += "MC" & vbCrLf
        Dim im As String = ""
        If rbStatic.Checked Then
            im = "0"
            ret += "IM" & im & vbCrLf
            If VerifyIpAddr(txtLIP.Text.Trim) Then
                ret += "LI" & txtLIP.Text.Trim & vbCrLf
            Else
                MsgBox("Please input a valid IP address for the selected device.", MsgBoxStyle.Critical, "Error")
                txtLIP.Focus()
                Return ""
            End If
            If VerifyIpAddr(txtSubnet.Text.Trim) Then
                ret += "SM" & txtSubnet.Text.Trim & vbCrLf
            Else
                MsgBox("Please input a correct subnet mask for the selected device.", MsgBoxStyle.Critical, "Error")
                txtSubnet.Focus()
                Return ""
            End If
            If VerifyIpAddr(txtGw.Text.Trim) Then
                ret += "GW" & txtGw.Text.Trim & vbCrLf
            Else
                MsgBox("Please input a correct gateway IP address for the selected device.", MsgBoxStyle.Critical, "Error")
                txtGw.Focus()
                Return ""
            End If
            If VerifyIpAddr(txtDNS.Text.Trim) Then
                ret += "DS" & txtDNS.Text.Trim & vbCrLf
            Else
                MsgBox("Please input a valid DNS server IP address for the selected device.", MsgBoxStyle.Critical, "Error")
                txtDNS.Focus()
                Return ""
            End If

        ElseIf rbDHCP.Checked Then
            im = "1"
            ret += "IM" & im & vbCrLf
        ElseIf rbPPP.Checked Then
            im = "2"
            ret += "IM" & im & vbCrLf
            If txtPId.Text.Trim.Length > 0 Then
                ret += "PI" & txtPId.Text.Trim & vbCrLf
            Else
                MsgBox("Please input your PPPoE ID.", MsgBoxStyle.Critical, "Error")
                Return ""
            End If
            If txtPPwd.Text.Trim.Length > 0 Then
                ret += "PP" & txtPPwd.Text.Trim & vbCrLf
            Else
                MsgBox("Please input your PPPoE password.", MsgBoxStyle.Critical, "Error")
                Return ""
            End If
        End If
        If txtLP.Text.Trim.Length > 0 Then
            Try
                If CType(txtLP.Text.Trim, Integer) > 0 And CType(txtLP.Text.Trim, Integer) < 65536 Then
                    ret += "LP" & txtLP.Text.Trim & vbCrLf
                Else
                    MsgBox("Please input a valid port number (0~65535) for the device.", MsgBoxStyle.Critical, "Error")
                    txtLP.Focus()
                    Return ""
                End If
            Catch ex As Exception
                MsgBox("Please input a valid port number (0~65535) for the device.", MsgBoxStyle.Critical, "Error")
                txtLP.Focus()
                Return ""
            End Try
        End If

        'operation mode
        Dim op As String = ""
        If rbClient.Checked Then
            op = "0"
            ret += "OP" & op & vbCrLf
            If txtRIP.Text.Trim.Length > 0 Then
                ret += "RH" & txtRIP.Text.Trim & vbCrLf
            Else
                MsgBox("Please input remote host IP/domain name.", MsgBoxStyle.Critical, "Error")
                Return ""
            End If
            If txtRp.Text.Trim.Length > 0 Then
                If verifyNumber(txtRp.Text.Trim, 1, 65535) Then
                    ret += "RP" & txtRp.Text.Trim & vbCrLf
                Else
                    MsgBox("Please input a port number between 0 and 65535.", MsgBoxStyle.Critical, "Error")
                    Return ""
                End If

            Else
                MsgBox("Please input the port of remote host.", MsgBoxStyle.Critical, "Error")
                Return ""
            End If
            If txtReconn.Text.Trim.Length > 0 Then
                If verifyNumber(txtReconn.Text.Trim, 1, 65535) Then
                    ret += "RI" & txtReconn.Text.Trim & vbCrLf
                Else
                    MsgBox("The reconnection interval should be between 1 and 65535.", MsgBoxStyle.Critical, "Error")
                    Return ""
                End If

            Else
                ret += "RI" & "0" & vbCrLf
            End If
        ElseIf rbServer.Checked Then
            op = "1"
            ret += "OP" & op & vbCrLf
            If chkConnPwd.Checked Then
                ret += "CP" & "1" & vbCrLf
                'ret += "NP" & txtConnPwd.Text.Trim & vbCrLf
                If txtConnPwd.Text.Trim.Length > 0 Then
                    ret += "NP" & txtConnPwd.Text.Trim & vbCrLf
                Else
                    MsgBox("Please input the connection password or disable it.", MsgBoxStyle.Critical, "Error")
                    Return ""
                End If
            Else
                ret += "CP" & "0" & vbCrLf
            End If
        ElseIf rbMixed.Checked Then
            op = "2"
            ret += "OP" & op & vbCrLf
            If txtRIP.Text.Trim.Length > 0 Then
                ret += "RH" & txtRIP.Text.Trim & vbCrLf

            End If
            If txtRp.Text.Trim.Length > 0 Then
                ret += "RP" & txtRp.Text.Trim & vbCrLf

            End If
            If txtReconn.Text.Trim.Length > 0 Then
                If verifyNumber(txtReconn.Text.Trim, 0, 65535) Then
                    ret += "RI" & txtReconn.Text.Trim & vbCrLf
                Else
                    MsgBox("The reconnection interval should be between 0 and 65535.", MsgBoxStyle.Critical, "Error")
                    Return ""
                End If
            Else
                ret += "RI" & "0" & vbCrLf
            End If
            If chkConnPwd.Checked Then
                ret += "CP" & "1" & vbCrLf
                'ret += "NP" & txtConnPwd.Text.Trim & vbCrLf
                If txtConnPwd.Text.Trim.Length > 0 Then
                    ret += "NP" & txtConnPwd.Text.Trim & vbCrLf
                Else
                    MsgBox("Please input the connection password or disable it.", MsgBoxStyle.Critical, "Error")
                    Return ""
                End If
            Else
                ret += "CP" & "0" & vbCrLf
            End If
        ElseIf rbUdp.Checked Then
            op = "3"
            ret += "OP" & op & vbCrLf
            If txtRIP.Text.Trim.Length > 0 Then
                ret += "RH" & txtRIP.Text.Trim & vbCrLf
            Else
                MsgBox("Please input remote host IP/domain name.", MsgBoxStyle.Critical, "Error")
                Return ""
            End If
            If txtRp.Text.Trim.Length > 0 Then
                If verifyNumber(txtRp.Text.Trim, 1, 65535) Then
                    ret += "RP" & txtRp.Text.Trim & vbCrLf
                Else
                    MsgBox("Please input a port between 0 and 65535.", MsgBoxStyle.Critical, "Error")
                    Return ""
                End If
            Else
                MsgBox("Please input the port of remote host.", MsgBoxStyle.Critical, "Error")
                Return ""
            End If

        End If
        'DDNS settings
        If chkDD.Checked Then
            ret += "DD" & "1" & vbCrLf
            ret += "DX" & cboDdns.SelectedIndex.ToString & vbCrLf
            If txtDPort.Text.Trim.Length > 0 Then
                If verifyNumber(txtDPort.Text.Trim, 1, 65535) Then
                    ret += "DP" & txtDPort.Text.Trim & vbCrLf
                Else
                    MsgBox("The DDNS server port should be between 0 and 65535.", MsgBoxStyle.Critical, "Error")
                    Return ""
                End If

            Else
                MsgBox("Please input DDNS server port.", MsgBoxStyle.Critical, "Error")
                Return ""
            End If
            If txtDID.Text.Trim.Length > 0 Then
                ret += "DI" & txtDID.Text.Trim & vbCrLf
            Else
                MsgBox("Please input your DDNS ID.", MsgBoxStyle.Critical, "Error")
                Return ""
            End If
            If txtDPwd.Text.Trim.Length > 0 Then
                ret += "DW" & txtDPwd.Text.Trim & vbCrLf
            Else
                MsgBox("Please input your DDNS password.", MsgBoxStyle.Critical, "Error")
                Return ""
            End If
            If txtDHost.Text.Trim.Length > 0 Then
                ret += "DH" & txtDHost.Text.Trim & vbCrLf
            Else
                MsgBox("Please input your DDNS domain name.", MsgBoxStyle.Critical, "Error")
                Return ""
            End If

        Else
            ret += "DD" & "0" & vbCrLf
        End If
        'debug message
        If chkDebug.Checked Then
            ret += "DG" & "1" & vbCrLf
        Else
            ret += "DG" & "0" & vbCrLf
        End If
        'serial settings
        ret += "BR" & cboBaud.SelectedIndex.ToString & vbCrLf
        ret += "DB" & cboDataBit.SelectedIndex.ToString & vbCrLf
        ret += "PR" & cboParity.SelectedIndex.ToString & vbCrLf
        ret += "SB" & cboStopBit.SelectedIndex.ToString & vbCrLf
        ret += "FL" & cboFlow.SelectedIndex.ToString & vbCrLf
        'serial data packing settings
        If txtTimer.Text.Trim.Length > 0 Then
            If verifyNumber(txtTimer.Text.Trim, 0, 65535) Then
                ret += "PT" & txtTimer.Text.Trim & vbCrLf
            Else
                MsgBox("The serial data packing interval should be between 0 and 65535.", MsgBoxStyle.Critical, "Error")
                txtTimer.Focus()
                Return ""
            End If

        Else
            ret += "PT" & "0" & vbCrLf
        End If
        If txtSize.Text.Trim.Length > 0 Then
            If verifyNumber(txtSize.Text.Trim, 0, 255) Then
                ret += "PS" & txtSize.Text.Trim & vbCrLf
            Else
                MsgBox("The packing size of serial data should be between 0 and 255.", MsgBoxStyle.Critical, "Error")
                txtSize.Focus()
                Return ""
            End If
        Else
            ret += "PS" & "0" & vbCrLf
        End If
        If txtChar.Text.Trim.Length > 0 Then
            If CType("&H" & txtChar.Text.Trim, Int16) >= 0 And CType("&H" & txtChar.Text.Trim, Int16) < 256 Then
                ret += "PD" & txtChar.Text.Trim & vbCrLf
                Debug.Print("PD=" & txtChar.Text.Trim)

            Else
                MsgBox("Please input the packing character indicator of serial data in hexacode(0~255).", MsgBoxStyle.Critical, "Error")
                txtChar.Focus()
                Return ""
            End If

        Else
            ret += "PD" & "0" & vbCrLf
        End If
        'other options
        If txtInactiveTimer.Text.Trim.Length > 0 Then
            If verifyNumber(txtInactiveTimer.Text.Trim, 0, 65535) Then
                ret += "IT" & txtInactiveTimer.Text.Trim & vbCrLf
            Else
                MsgBox("The inactive timer should be between 0 and 65535.", MsgBoxStyle.Critical, "Error")
                txtInactiveTimer.Focus()
                Return ""
            End If

        Else
            ret += "IT" & "0" & vbCrLf
        End If
        If chkTrigger.Checked Then
            ret += "TE" & "1" & vbCrLf
            If txtTrigger1.Text.Trim.Length > 0 Then
                If txtTrigger1.Text.Trim.Length = 2 Then
                    ret += "SS" & txtTrigger1.Text.Trim
                Else
                    ret += "SS" & "0" & txtTrigger1.Text.Trim
                End If
            Else
                tpOption.Show()
                txtTrigger1.Focus()
                MsgBox("Please input software trigger code.", MsgBoxStyle.Critical, "Error")
                Return ""

            End If
            If txtTrigger2.Text.Trim.Length > 0 Then
                If txtTrigger2.Text.Trim.Length = 2 Then
                    ret += txtTrigger2.Text.Trim
                Else
                    ret += "0" & txtTrigger2.Text.Trim
                End If
            Else
                tpOption.Show()
                txtTrigger2.Focus()
                MsgBox("Please input software trigger code.", MsgBoxStyle.Critical, "Error")
                Return ""

            End If
            If txtTrigger3.Text.Trim.Length > 0 Then
                If txtTrigger3.Text.Trim.Length = 2 Then
                    ret += txtTrigger3.Text.Trim
                Else
                    ret += "0" & txtTrigger3.Text.Trim
                End If
            Else
                tpOption.Show()
                txtTrigger3.Focus()
                MsgBox("Please input software trigger code.", MsgBoxStyle.Critical, "Error")
                Return ""
            End If
            ret += vbCrLf
        Else
            ret += "TE" & "0" & vbCrLf
        End If
        'search password
        If txtSearchPwd.Text.Trim.Length > 0 Then
            ret += "SP" & txtSearchPwd.Text.Trim & vbCrLf
        Else
            ret += "SP" & " " & vbCrLf 'if user does not input any character, send a space
        End If
        'keep alive options
        If chkKa.Checked Then
            ret += "KA" & "1" & vbCrLf
            ret += "KI" & txtKA.Text.Trim & vbCrLf
            ret += "KE" & txtKaRep.Text.Trim & vbCrLf

        Else
            ret += "KA" & "0" & vbCrLf
            'ret += "KI" & "7000" & vbCrLf
            'ret += "KE" & "1000" & vbCrLf
        End If

        'append the GET commands to get the response from module
        ret += Sec.SearchMsg
        'save and reboot commands
        ret += "SV" & vbCrLf

        'reset
        ret += "RT" & vbCrLf
        Return ret
    End Function
    Private Function Reset(ByVal mac As String, ByVal pwd As String) As Byte()
        Dim ma() As Byte = prefix_MA(mac)
        Dim str As String = "PW" & pwd & vbCrLf & "RT" & vbCrLf
        Dim b() As Byte = Encoding.ASCII.GetBytes(str)
        Dim ret(ma.Length + b.Length - 1) As Byte
        Array.ConstrainedCopy(ma, 0, ret, 0, ma.Length)
        Array.ConstrainedCopy(b, 0, ret, ma.Length, b.Length)
        Return ret
    End Function
    Private Function FactoryReset(ByVal mac As String, ByVal pwd As String) As Byte()
        Dim ma() As Byte = prefix_MA(mac)
        Dim str As String = "PW" & pwd & vbCrLf & "FR" & vbCrLf & "RT" & vbCrLf
        Dim b() As Byte = Encoding.ASCII.GetBytes(str)
        Dim ret(ma.Length + b.Length - 1) As Byte
        Array.ConstrainedCopy(ma, 0, ret, 0, ma.Length)
        Array.ConstrainedCopy(b, 0, ret, ma.Length, b.Length)
        Return ret
    End Function

    Private Function SendOneCommandWithNoData(ByVal mac As String, ByVal pwd As String, ByVal cmd As String) As Byte()
        Dim ma() As Byte = prefix_MA(mac)
        Dim str As String = "PW" & pwd & vbCrLf & cmd & vbCrLf
        Dim b() As Byte = Encoding.ASCII.GetBytes(str)
        Dim ret(ma.Length + b.Length - 1) As Byte
        Array.ConstrainedCopy(ma, 0, ret, 0, ma.Length)
        Array.ConstrainedCopy(b, 0, ret, ma.Length, b.Length)
        Return ret
    End Function
#End Region
#Region "TreeView Operation"
    Private Function tvAddRootNode(ByVal tView As TreeView, ByVal sName As String) As TreeNode
        Dim nd As TreeNode

        If sName.Length > 0 Then
            nd = tView.Nodes.Add(sName)
        Else
            nd = tView.Nodes.Add("Invalid node name!")
        End If
        Return nd

    End Function
    Private Function RemoveOneNode(ByVal tView As TreeView, ByVal pNode As Windows.Forms.TreeNode, ByVal nd As Windows.Forms.TreeNode) As String
        Dim ret As String = ""
        pNode.Nodes.Remove(nd)
        ret = nd.Text & " removed from the search results."
        Return ret
    End Function
    Private Sub RemoveAllNodes(ByVal pNode As Windows.Forms.TreeNode)
        pNode.Nodes.Clear()
    End Sub

#End Region
#Region "Interface control"
    Private Sub EnableControls(ByVal isEnabled As Boolean)
        tsbSet.Enabled = isEnabled
        tsbUpload.Enabled = isEnabled
        tsbReset.Enabled = isEnabled
        tsbFactory.Enabled = isEnabled
        tc.Enabled = isEnabled
    End Sub
#End Region

    Private Sub frmMain_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing

        Dim ret As DialogResult = MessageBox.Show(Me, "Are you sure to close this program?", "Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Information)
        If ret = Windows.Forms.DialogResult.Yes Then
            'close
            End
        Else
            e.Cancel = True
        End If
    End Sub
    Private Sub frmMain_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.Text = "WIZ107SR / WIZ108SR Configuration Tool Ver" & Application.ProductVersion
        'initialize controls
        'add combobox data
        With cboBaud
            .Items.Add(New myDataItem("300", 0))
            .Items.Add(New myDataItem("600", 1))
            .Items.Add(New myDataItem("1200", 2))
            .Items.Add(New myDataItem("1800", 3))
            .Items.Add(New myDataItem("2400", 4))
            .Items.Add(New myDataItem("4800", 5))
            .Items.Add(New myDataItem("9600", 6))
            .Items.Add(New myDataItem("14400", 7))
            .Items.Add(New myDataItem("19200", 8))
            .Items.Add(New myDataItem("28800", 9))
            .Items.Add(New myDataItem("38400", 10))
            .Items.Add(New myDataItem("57600", 11))
            .Items.Add(New myDataItem("115200", 12))
            .Items.Add(New myDataItem("230400", 13))
        End With

        With cboDataBit
            .Items.Add(New myDataItem("7", 0))
            .Items.Add(New myDataItem("8", 1))
            .Items.Add(New myDataItem("9", 2))
        End With
        cboStopBit.Items.Add(New myDataItem("1", 0))
        cboStopBit.Items.Add(New myDataItem("2", 1))
        With cboParity
            .Items.Add(New myDataItem("NONE", 0))
            .Items.Add(New myDataItem("ODD", 1))
            .Items.Add(New myDataItem("EVEN", 2))

        End With
        With cboFlow
            .Items.Add(New myDataItem("NONE", 0))
            .Items.Add(New myDataItem("XON/XOFF", 1))
            .Items.Add(New myDataItem("CTS/RTS", 2))
        End With
        'tree view
        rNode = tvAddRootNode(tv, "Serial to Ethernet")
        'create ipendpoint and bind udp socket
        udpRep = New IPEndPoint(IPAddress.Broadcast, bPort)

        sckUDP.Bind(0)
        'hide progress bar
        tpb.Visible = False
    End Sub

    Private Sub tsbSrchAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsbSrchAll.Click
        frmPwd.ShowDialog(Me)
        If isSchOk Then
            If isBroadcast Then
                Dim b() As Byte = Sec.SeachMsgBytes(SchPwd)
                sckUDP.SendTo(b, udpRep)
            Else
                Debug.Print("direct ip: " & directIP)

                If sckTCP.isConnected Then
                    'Dim b() As Byte = Sec.SeachMsgBytes(SchPwd)
                    'sckTCP.Send(b.Length, b)
                    'isSchOk = False
                    sckTCP.Disconnect()
               

                    'Dim tRemEp As New IPEndPoint(Dns.GetHostEntry(directIP).AddressList(0), 50001)
                    
                End If
                'Dim tRemEp As New IPEndPoint(IPAddress.Parse(directIP), bPort)
                Dim tRemEp As New IPEndPoint(IPAddress.Parse(directIP), directPort)
                sckTCP.Connect(tRemEp)
                cmdState = S_SEARCH 'set command state

            End If
            'clear nodes of root node of tv
            RemoveAllNodes(rNode)
            EnableControls(False)
            'progressbar
            tpb.Visible = True
            tpb.Style = ProgressBarStyle.Marquee
            'status lable
            tLblState.Text = "Searching..."
            'timer and stop watch
            tmrPb.Start()
            sw.Start()
        End If
    End Sub

    Private Sub tsbSet_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsbSet.Click
        Dim msg As String = CalcSetMsg()
        If msg.Length > 0 Then
            Dim bMa() As Byte = prefix_MA(Sec.MC.data)
            Dim bMsg() As Byte = Encoding.ASCII.GetBytes(msg)
            ReDim bSetMsg(bMsg.Length + 10 - 1)
            Array.ConstrainedCopy(bMa, 0, bSetMsg, 0, 10)
            Array.ConstrainedCopy(bMsg, 0, bSetMsg, 10, bMsg.Length)
            If isBroadcast Then
                sckUDP.SendTo(bSetMsg, udpRep)
            Else
                If sckTCP.isConnected Then
                    sckTCP.Disconnect()

                End If
                'the direct Ip should be the select device's ip
                directIP = Sec.LI.data
                Dim tRemEp As New IPEndPoint(IPAddress.Parse(directIP), bPort)
                sckTCP.Connect(tRemEp)
                cmdState = S_SET 'set cmd state


            End If
            'progressbar
            tpb.Visible = True
            tpb.Style = ProgressBarStyle.Marquee
            'timer and stop watch
            tmrPb.Start()
            sw.Start()
        End If
    End Sub

    Private Sub tsbUpload_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsbUpload.Click
        'ping the module at first; 2010. 06. 29
        If My.Computer.Network.Ping(txtLIP.Text) = False Then
            'show error message
            MessageBox.Show(Me, "The destination: " & Trim(txtLIP.Text) & " is unreachable." & vbCrLf & _
                           "Please check if the device is in the same subnet with the PC!", "Firmware uploading error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Else
            'open file dialog
            Dim sFile As String = ""
            ofd.FileName = ""
            ofd.ShowDialog()
            sFile = ofd.FileName
            If sFile.Length > 0 Then
                fStrm = New IO.FileStream(sFile, IO.FileMode.Open, IO.FileAccess.Read)
                fLen = fStrm.Length
                rxLen = 0
                sOffset = 0


                '20120808
                'check if old or new module from f/w version
                'Dim mVer As Integer = Math.Truncate(CType(Sec.VR.data, Single))
                Dim isNew As Boolean = False
                Dim strVer As String() = Sec.VR.data.Split(New Char() {"."c})
                Dim mVer As Integer = Int(strVer(0))

                If Array.IndexOf(new_module_ver, mVer) >= 0 Then
                    'new module
                    isNew = True
                    If fLen < 64 * 1024 And fLen > 51 * 1024 Then
                        fLen = 51 * 1024

                    Else
                        MessageBox.Show("Firmware file error! Please check your version of file again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                        fStrm.Close()
                        Exit Sub
                    End If

                    'If fLen <> 65536 Then
                    'If fLen > 60 * 1024 Or fLen <= 50 * 1024 Then
                    '    'MessageBox.Show("Firmware file length error! Please check your file again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                    '    MessageBox.Show("Firmware file error! Please check your version of file again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                    '    fStrm.Close()
                    '    Exit Sub
                    'Else
                    '    'get the real file length
                    '    fLen = 51 * 1024
                    '    'fLen = 61440

                    'End If

                Else
                    'old module
                    isNew = False
                    If fLen > 51 * 1024 Then
                        'MessageBox.Show("The length of firmware file should be less than 50K bytes.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                        MessageBox.Show("Firmware file error! Please check your version of file again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                        fStrm.Close()
                        Exit Sub

                    End If
                End If


                
                ' If fLen < (50) * 1024 Then
                'set toolstripprogressbar
                tpb.Visible = True
                tpb.Value = 0
                tpb.Maximum = fLen
                'send firmware upload command
                isUploadCmd = True 'set flag
                If isBroadcast Then
                    Dim b() As Byte = Sec.UploadMsg(Sec.MC.data, Sec.SP.data, fLen) 'Sec.SeachMsgBytes(SchPwd)
                    sckUDP.SendTo(b, udpRep)
                Else
                    'if tcp is connected, disconnect it at first
                    If sckTCP.isConnected Then
                        sckTCP.Disconnect()
                    End If
                    directIP = Sec.LI.data

                    'Dim tRemEp As New IPEndPoint(Dns.GetHostEntry(directIP).AddressList(0), bPort)
                    Dim tRemEp As New IPEndPoint(IPAddress.Parse(directIP), bPort)
                    sckTCP.Connect(tRemEp)
                    cmdState = S_UPLOAD
                End If
                'Else
                '   MessageBox.Show("The length of firmware file should be less than 50K bytes.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                '  Exit Sub
                'End If
            End If
        End If

    End Sub
    Private Sub tsbReset_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsbReset.Click
        Dim ret As DialogResult = MessageBox.Show("Do you really want to reset the selected device?", "Reset device", MessageBoxButtons.YesNo, MessageBoxIcon.Information)
        If ret = Windows.Forms.DialogResult.Yes Then
            If isBroadcast Then
                'send reset command
                Dim b() As Byte = Reset(Sec.MC.data, Sec.SP.data)

                sckUDP.SendTo(b, udpRep)
            Else
                If sckTCP.isConnected Then
                    sckTCP.Disconnect()
                End If
                'directIP = Sec.LI.data
                Debug.Print("directip=" & directIP)

                Dim tRemEp As New IPEndPoint(Dns.GetHostEntry(directIP).AddressList(0), bPort)

                sckTCP.Connect(tRemEp)
                cmdState = S_RESET
            End If

        End If
    End Sub

    Private Sub tsbFactory_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsbFactory.Click
        Dim ret As DialogResult = MessageBox.Show("Do you really want to reset the selected device with factory defaults?" & vbCrLf & "All settings will get the factory default values.", "Factory Reset device", MessageBoxButtons.YesNo, MessageBoxIcon.Information)
        If ret = Windows.Forms.DialogResult.Yes Then
            If isBroadcast Then
                'send factory reset command
                Dim b() As Byte = FactoryReset(Sec.MC.data, Sec.SP.data)
                sckUDP.SendTo(b, udpRep)
            Else
                If sckTCP.isConnected Then
                    sckTCP.Disconnect()
                End If
                directIP = Sec.LI.data

                Dim tRemEp As New IPEndPoint(Dns.GetHostEntry(directIP).AddressList(0), bPort)

                sckTCP.Connect(tRemEp)
                cmdState = S_FACTORY
            End If
           
        End If
    End Sub
    Private Sub tsbPing_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsbPing.Click
        frmPing.ShowDialog(Me)
    End Sub

    Private Sub tsbFirewall_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsbFirewall.Click
        Shell("rundll32.exe shell32.dll, Control_RunDLL FireWall.cpl", vbNormalFocus)
    End Sub
    Private Sub tsbExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsbExit.Click
        Me.Close()
    End Sub
    Private Sub tv_AfterSelect(ByVal sender As System.Object, ByVal e As System.Windows.Forms.TreeViewEventArgs) Handles tv.AfterSelect
        Dim lv As Int16 = tv.SelectedNode.Level
        Dim nd As Windows.Forms.TreeNode = Nothing
        If lv > 0 Then
            Select Case lv
                Case 1
                    nd = tv.SelectedNode
                Case 2
                    nd = tv.SelectedNode.Parent
            End Select
            EnableControls(True)
            DisplayValue(nd.Tag)
            Sec = nd.Tag
            'show tool strip message
            tlblMsg.Text = nd.Text
            'set current selected node
            'sNode = nd
            sIndex = nd.Index


        Else
            'show tool strip message
            tlblMsg.Text = "None device selected"
            EnableControls(False)
        End If
    End Sub

    Private Sub rbStatic_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rbStatic.CheckedChanged, rbDHCP.CheckedChanged, rbPPP.CheckedChanged
        Dim obj As RadioButton = CType(sender, RadioButton)
        If obj.Checked = True Then
            Select Case obj.Name
                Case "rbStatic"
                    txtLIP.Enabled = True
                    txtSubnet.Enabled = True
                    txtGw.Enabled = True
                    txtDNS.Enabled = True
                    txtPId.Enabled = False
                    txtPPwd.Enabled = False
                Case "rbDHCP"
                    txtLIP.Enabled = False
                    txtSubnet.Enabled = False
                    txtGw.Enabled = False
                    txtDNS.Enabled = False
                    txtPId.Enabled = False
                    txtPPwd.Enabled = False
                Case "rbPPP"
                    txtLIP.Enabled = False
                    txtSubnet.Enabled = False
                    txtGw.Enabled = False
                    txtDNS.Enabled = False
                    txtPId.Enabled = True
                    txtPPwd.Enabled = True
            End Select
        End If
    End Sub

    Private Sub rbClient_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rbClient.CheckedChanged, rbServer.CheckedChanged, rbMixed.CheckedChanged, rbUdp.CheckedChanged
        Dim obj As RadioButton = CType(sender, RadioButton)
        If obj.Checked = True Then
            Select Case obj.Name
                Case "rbClient"
                    txtRIP.Enabled = True
                    txtRp.Enabled = True
                    txtReconn.Enabled = True
                    chkConnPwd.Checked = False
                    chkConnPwd.Enabled = False
                    txtConnPwd.Enabled = False
                    '
                    txtInactiveTimer.Enabled = True
                    chkKa.Enabled = True

                Case "rbServer"
                    txtRIP.Enabled = False
                    txtRp.Enabled = False
                    txtReconn.Enabled = False
                    'txtReconn.Text = "0"

                    chkConnPwd.Enabled = True
                    txtConnPwd.Enabled = True
                    '
                    txtInactiveTimer.Enabled = True
                    chkKa.Enabled = True

                Case "rbMixed"
                    txtRIP.Enabled = True
                    txtRp.Enabled = True
                    txtReconn.Enabled = True
                    chkConnPwd.Enabled = True
                    txtConnPwd.Enabled = True

                    txtInactiveTimer.Enabled = True
                    chkKa.Enabled = True
                Case "rbUdp"
                    txtRIP.Enabled = True
                    txtRp.Enabled = True
                    txtReconn.Enabled = False
                    'txtReconn.Text = "0"
                    chkConnPwd.Checked = False
                    chkConnPwd.Enabled = False
                    txtConnPwd.Enabled = False

                    txtInactiveTimer.Enabled = False
                    chkKa.Enabled = False
            End Select
        End If
    End Sub

    Private Sub chkDD_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkDD.CheckedChanged
        If chkDD.Checked Then
            cboDdns.Enabled = True
            txtDPort.Enabled = True
            txtDID.Enabled = True
            txtDPwd.Enabled = True
            txtDHost.Enabled = True
        Else
            cboDdns.Enabled = False
            txtDPort.Enabled = False
            txtDID.Enabled = False
            txtDPwd.Enabled = False
            txtDHost.Enabled = False
        End If
    End Sub

    Private Sub chkTrigger_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkTrigger.CheckedChanged
        If chkTrigger.Checked Then
            txtTrigger1.Enabled = True
            txtTrigger2.Enabled = True
            txtTrigger3.Enabled = True
        Else
            txtTrigger1.Enabled = False
            txtTrigger2.Enabled = False
            txtTrigger3.Enabled = False
        End If
    End Sub

    Private Sub chkConnPwd_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkConnPwd.CheckedChanged
        If chkConnPwd.Checked Then
            txtConnPwd.Enabled = True
        Else
            txtConnPwd.Enabled = False
        End If
    End Sub

    Private Sub chkKa_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkKa.CheckedChanged
        If chkKa.Checked Then
            txtKA.Enabled = True
            txtKaRep.Enabled = True
        Else
            txtKA.Enabled = False
            txtKaRep.Enabled = False
        End If
    End Sub

    Private Sub chkShowChar3_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkShowChar3.CheckedChanged
        If chkShowChar3.Checked Then
            txtPPwd.PasswordChar = ""
        Else
            txtPPwd.PasswordChar = "*"
        End If
    End Sub
    Private Sub chkShowChar2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkShowChar2.CheckedChanged
        If chkShowChar2.Checked Then
            txtConnPwd.PasswordChar = ""
        Else
            txtConnPwd.PasswordChar = "*"
        End If
    End Sub
    Private Sub chkShowChar1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkShowChar1.CheckedChanged
        If chkShowChar1.Checked Then
            txtSearchPwd.PasswordChar = ""
        Else
            txtSearchPwd.PasswordChar = "*"
        End If
    End Sub

    
    Private Sub txtChar_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtChar.TextChanged

    End Sub

    Private Sub tmrPb_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tmrPb.Tick
        ' tpb.PerformStep()
        If sw.ElapsedMilliseconds > 3000 Then
            tpb.Style = ProgressBarStyle.Blocks
            tmrPb.Stop()
            tLblState.Text = "Find: " & rNode.Nodes.Count.ToString & " devices"
            tpb.Visible = False 'hide progressbar
            sw.Reset()
            sw.Stop()
            'sort
            If rNode.Nodes.Count > 0 Then
                If rNode.Nodes.Count > 1 Then Call SortNode(rNode)
                If rNode.Nodes.Count > sIndex Then
                    sNode = rNode.Nodes(sIndex)
                    tv.SelectedNode = sNode
                Else
                    sNode = rNode.Nodes(rNode.Nodes.Count - 1)
                    tv.SelectedNode = sNode
                End If

            End If
        End If
    End Sub


    Private Sub SplitContainer1_MouseHover(ByVal sender As Object, ByVal e As System.EventArgs) Handles SplitContainer1.MouseHover

        lblSplitUp.BackColor = Color.RoyalBlue

    End Sub

    Private Sub SplitContainer1_MouseLeave(ByVal sender As Object, ByVal e As System.EventArgs) Handles SplitContainer1.MouseLeave
        lblSplitUp.BackColor = Color.Transparent

    End Sub

    Private Sub SplitContainer1_SplitterMoved(ByVal sender As Object, ByVal e As System.Windows.Forms.SplitterEventArgs) Handles SplitContainer1.SplitterMoved
        If SplitContainer1.Panel2.Height > 0 And SplitContainer1.Panel2.Height < 10 Then
            'SplitContainer1.Panel2Collapsed = True
            SplitContainer1.SplitterDistance = SplitContainer1.Height

        End If
    End Sub

#Region "check serial data bits"
    'check the data bit
    Private Sub cboDataBit_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboDataBit.SelectedIndexChanged
        Select Case cboDataBit.SelectedIndex
            Case 0 '7 bits
                If Not cboParity.Items.Contains(New myDataItem("ODD", 1)) Then
                    cboParity.Items.Add(New myDataItem("ODD", 1))
                    cboParity.Items.Add(New myDataItem("EVEN", 2))
                End If
                If Not cboStopBit.Items.Contains(New myDataItem("2", 1)) Then
                    cboStopBit.Items.Add(New myDataItem("2", 1))
                End If
            Case 1 '8 bits
                If Not cboParity.Items.Contains(New myDataItem("ODD", 1)) Then
                    If cboStopBit.SelectedIndex = 0 Then
                        cboParity.Items.Add(New myDataItem("ODD", 1))
                        cboParity.Items.Add(New myDataItem("EVEN", 2))
                    End If
                Else
                    If cboStopBit.SelectedIndex > 0 Then
                        cboParity.Items.Remove(New myDataItem("ODD", 1))
                        cboParity.Items.Remove(New myDataItem("EVEN", 2))
                        cboParity.SelectedIndex = 0
                    End If

                End If
                If Not cboStopBit.Items.Contains(New myDataItem("2", 1)) Then
                    If cboParity.SelectedIndex = 0 Then
                        cboStopBit.Items.Add(New myDataItem("2", 1))

                    End If
                Else
                    If cboParity.SelectedIndex > 0 Then
                        cboStopBit.Items.Remove(New myDataItem("2", 1))
                        cboStopBit.SelectedIndex = 0
                    End If
                End If

            Case 2 '9 bits
                cboParity.Items.Remove(New myDataItem("ODD", 1))
                cboParity.Items.Remove(New myDataItem("EVEN", 2))
                cboParity.SelectedIndex = 0
                cboStopBit.Items.Remove(New myDataItem("2", 1))
                cboStopBit.SelectedIndex = 0

        End Select

    End Sub

    Private Sub cboParity_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboParity.SelectedIndexChanged
        Select Case cboParity.SelectedIndex
            Case 0
                'stopbit
                If cboStopBit.SelectedIndex > 0 Then '2 bits
                    If cboDataBit.SelectedIndex = 2 Then cboDataBit.SelectedIndex = 1
                    If cboDataBit.Items.Contains(New myDataItem("9", 2)) Then
                        cboDataBit.Items.Remove(New myDataItem("9", 2))
                    End If
                Else '1 bit
                    If Not cboDataBit.Items.Contains(New myDataItem("8", 1)) Then
                        cboDataBit.Items.Add(New myDataItem("8", 1))
                    End If
                    If Not cboDataBit.Items.Contains(New myDataItem("9", 2)) Then
                        cboDataBit.Items.Add(New myDataItem("9", 2))
                    End If

                End If
                'databit
                If cboDataBit.SelectedIndex > 1 Then '9 bits
                    If cboStopBit.SelectedIndex > 0 Then cboStopBit.SelectedIndex = 0
                    If cboStopBit.Items.Contains(New myDataItem("2", 1)) Then
                        cboStopBit.Items.Remove(New myDataItem("2", 1))
                    End If
                Else
                    If Not cboStopBit.Items.Contains(New myDataItem("2", 1)) Then
                        cboStopBit.Items.Add(New myDataItem("2", 1))
                    End If
                End If
            Case 1, 2
                If cboDataBit.Items.Contains(New myDataItem("9", 2)) Then
                    cboDataBit.Items.Remove(New myDataItem("9", 2))
                End If

                If cboDataBit.SelectedIndex > 0 Then '8 or 9 bits
                    cboStopBit.SelectedIndex = 0
                    If cboStopBit.Items.Contains(New myDataItem("2", 1)) Then
                        cboStopBit.Items.Remove(New myDataItem("2", 1))
                    End If
                Else '7 bits
                    If Not cboStopBit.Items.Contains(New myDataItem("2", 1)) Then
                        cboStopBit.Items.Add(New myDataItem("2", 1))
                    End If
                End If
                'stopbit
                If cboStopBit.SelectedIndex > 0 Then
                    cboDataBit.SelectedIndex = 0
                    If cboDataBit.Items.Contains(New myDataItem("8", 1)) Then
                        cboDataBit.Items.Remove(New myDataItem("8", 1))
                    End If

                Else
                    If Not cboDataBit.Items.Contains(New myDataItem("8", 1)) Then
                        cboDataBit.Items.Add(New myDataItem("8", 1))

                    End If

                End If
        End Select
    End Sub

    Private Sub cboStopBit_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboStopBit.SelectedIndexChanged
        If cboStopBit.SelectedIndex > 0 Then '2 bits

            If cboDataBit.SelectedIndex = 2 Then cboDataBit.SelectedIndex = 1
            If cboDataBit.Items.Contains(New myDataItem("9", 2)) Then
                cboDataBit.Items.Remove(New myDataItem("9", 2))
            End If
            If cboDataBit.SelectedIndex = 1 Then
                cboParity.SelectedIndex = 0
                If cboParity.Items.Contains(New myDataItem("ODD", 1)) Then
                    cboParity.Items.Remove(New myDataItem("ODD", 1))
                    cboParity.Items.Remove(New myDataItem("EVEN", 2))
                End If
            ElseIf cboDataBit.SelectedIndex = 0 Then

                If Not cboParity.Items.Contains(New myDataItem("ODD", 1)) Then
                    cboParity.Items.Add(New myDataItem("ODD", 1))
                    cboParity.Items.Add(New myDataItem("EVEN", 2))
                End If
            End If
            'parity
            If cboParity.SelectedIndex > 0 Then '1 bit
                If cboDataBit.SelectedIndex = 1 Then cboDataBit.SelectedIndex = 0
                If cboDataBit.Items.Contains(New myDataItem("8", 1)) Then
                    cboDataBit.Items.Remove(New myDataItem("8", 1))
                End If
            Else 'none
                If Not cboDataBit.Items.Contains(New myDataItem("8", 1)) Then
                    cboDataBit.Items.Add(New myDataItem("8", 1))
                End If
            End If
        Else '1 bit
            'databit
            If cboParity.SelectedIndex > 0 Then
                If Not cboDataBit.Items.Contains(New myDataItem("8", 1)) Then
                    cboDataBit.Items.Add(New myDataItem("8", 1))
                End If
                If cboDataBit.SelectedIndex = 2 Then cboDataBit.SelectedIndex = 1
                If cboDataBit.Items.Contains(New myDataItem("9", 2)) Then
                    cboDataBit.Items.Remove(New myDataItem("9", 2))
                End If
            Else
                If Not cboDataBit.Items.Contains(New myDataItem("8", 1)) Then
                    cboDataBit.Items.Add(New myDataItem("8", 1))
                End If
                If Not cboDataBit.Items.Contains(New myDataItem("9", 2)) Then
                    cboDataBit.Items.Add(New myDataItem("9", 2))
                End If
            End If
            'parity
            If cboDataBit.SelectedIndex > 1 Then
                If cboParity.SelectedIndex > 0 Then cboParity.SelectedIndex = 0
                If cboParity.Items.Contains(New myDataItem("ODD", 1)) Then
                    cboParity.Items.Remove(New myDataItem("ODD", 1))
                    cboParity.Items.Remove(New myDataItem("EVEN", 2))
                End If
            Else
                If Not cboParity.Items.Contains(New myDataItem("ODD", 1)) Then
                    cboParity.Items.Add(New myDataItem("ODD", 1))
                    cboParity.Items.Add(New myDataItem("EVEN", 2))
                End If
            End If
        End If
    End Sub

#End Region

    Private Sub sckUDP_DataArrival(ByVal len As Integer, ByVal dat() As Byte) Handles sckUDP.DataArrival
        Dim tmpDat(len - 1) As Byte
        Array.ConstrainedCopy(dat, 0, tmpDat, 0, len)
        If len < 10 Then
            Exit Sub
        End If
        Dim bMsg(len - 1 - 10) As Byte
        Array.ConstrainedCopy(tmpDat, 10, bMsg, 0, len - 10)
        Dim msg As String = Encoding.ASCII.GetString(bMsg)
        If msg.Substring(0, 2) = "PW" Then
            If Not isUploadCmd Then
                Dim nSec As New clsSEC
                nSec = parsingMsg(msg)
                If nSec.ER.data.Length > 0 Then
                    MsgBox(nSec.ER.data)
                Else
                    If nSec.MC.data.Length = 17 Then

                        If isSchOk Then isSchOk = False
                        Call tvAddNode(tv, rNode, nSec)
                    End If
                End If
            Else
                isUploadCmd = False
                'upload cmd
                'MA \r\nPW  \r\nPW IP:Port\r\n
                Dim s As String = msg.Replace("PW", "")
                s = s.Replace(Sec.SP.data, "").Trim
                Dim ipAddr As String = s.Split(":")(0)
                ipAddr = ipAddr.Replace("FW", "")
                Dim nPort As Long = CType(s.Split(":")(1), Long)
                'Dim tRemEp As New IPEndPoint(Dns.GetHostEntry(ipAddr).AddressList(0), nPort)
                Dim tRemEp As New IPEndPoint(IPAddress.Parse(ipAddr), nPort)
                sckTcpUp.Connect(tRemEp)
                isUploading = True

            End If
        End If

    End Sub
    Private Sub sckUDP_SocketError(ByVal err As System.Exception) Handles sckUDP.SocketError
        MessageBox.Show(err.Message, "UDP Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
    End Sub

    Private Sub sckTCP_Connected() Handles sckTCP.Connected
        Select Case cmdState
            Case S_SEARCH
                Dim b() As Byte = Sec.SeachMsgBytes(SchPwd)
                sckTCP.Send(b.Length, b)
                isSchOk = False
            Case S_SET
                sckTCP.Send(bSetMsg.Length, bSetMsg)
            Case S_RESET
                Dim b() As Byte = Reset(Sec.MC.data, Sec.SP.data)
                sckTCP.Send(b.Length, b)

            Case S_UPLOAD
                Dim b() As Byte = Sec.UploadMsg(Sec.MC.data, Sec.SP.data, fLen)
                sckTCP.Send(b.Length, b)
            Case S_FACTORY
                Dim b() As Byte = FactoryReset(Sec.MC.data, Sec.SP.data)
                sckTCP.Send(b.Length, b)

        End Select
        cmdState = S_NULL
        'If isSchOk Then
        'Dim b() As Byte = Sec.SeachMsgBytes(SchPwd)
        'sckTCP.Send(b.Length, b)
        'isSchOk = False

        'Else

        'If isUploadCmd Then
        'Dim b() As Byte = Sec.UploadMsg(Sec.MC.data, Sec.SP.data, fLen)
        'sckTCP.Send(b.Length, b)
        'Else
        'sckTCP.Send(bSetMsg.Length, bSetMsg)
        'End If
        'End If

    End Sub

    Private Sub sckTCP_DataArrival(ByVal len As Integer, ByVal dat() As Byte) Handles sckTCP.DataArrival

        Dim tmpDat(len - 1) As Byte
        Array.ConstrainedCopy(dat, 0, tmpDat, 0, len)
        Dim bMsg(len - 1 - 10) As Byte
        Array.ConstrainedCopy(tmpDat, 10, bMsg, 0, len - 10)
        Dim msg As String = Encoding.ASCII.GetString(bMsg)
        If msg.Substring(0, 2) = "PW" Then
            If Not isUploadCmd Then
                Sec = parsingMsg(msg)
                If Sec.ER.data.Length > 0 Then
                    MsgBox(Sec.ER.data)
                Else
                    If Sec.MC.data.Length = 17 Then
                        If isSchOk Then isSchOk = False
                        Call tvAddNode(tv, rNode, Sec)
                    End If
                End If
            Else
                isUploadCmd = False
                'upload cmd
                'MA \r\nPW  \r\nPW IP:Port\r\n
                Dim s As String = msg.Replace("PW", "")
                s = s.Replace(Sec.SP.data, "").Trim
                Dim ipAddr As String = s.Split(":")(0)
                ipAddr = ipAddr.Replace("FW", "")
                Dim nPort As Long = CType(s.Split(":")(1), Long)
                Dim tRemEp As New IPEndPoint(Dns.GetHostEntry(ipAddr).AddressList(0), nPort)
                sckTcpUp.Connect(tRemEp)
                isUploading = True
            End If
        End If

    End Sub

    Private Sub sckTCP_SocketError(ByVal err As System.Exception) Handles sckTCP.SocketError
        MessageBox.Show(err.Message, "TCP Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
    End Sub

    Private Sub sckTcpUp_Connected() Handles sckTcpUp.Connected
        Debug.Print("firmware uploading connected")
        'send the first firmware file data packet
        If fLen > bufLen Then
            fStrm.Seek(0, IO.SeekOrigin.Begin)
            fStrm.Read(fDat, 0, bufLen)
            sOffset += bufLen
            sckTcpUp.Send(bufLen, fDat)
            Debug.Print("send first 1024 bytes")
            'set progress bar value
            setVsBarVal(tpb, sOffset)

        Else
            ReDim fDat(fLen - 1)
            fStrm.Read(fDat, 0, fLen)
            sckTcpUp.Send(fLen, fDat)
        End If

    End Sub

    Private Sub sckTcpUp_DataArrival(ByVal len As Integer, ByVal dat() As Byte) Handles sckTcpUp.DataArrival
        'send firmware data
        Dim n As Long = dat(0) * 256 + dat(1)
        rxLen += n

        If rxLen < fLen Then
            If fLen - rxLen > bufLen Then
                fStrm.Seek(sOffset, IO.SeekOrigin.Begin)
                fStrm.Read(fDat, 0, bufLen)
                sOffset += bufLen
                sckTcpUp.Send(fDat.Length, fDat)
            Else
                Dim b(fLen - rxLen - 1) As Byte
                fStrm.Seek(sOffset, IO.SeekOrigin.Begin)
                fStrm.Read(b, 0, fLen - rxLen)
                sOffset += fLen - rxLen
                sckTcpUp.Send(fLen - rxLen, b)
            End If
            'set progress bar value
            setVsBarVal(tpb, rxLen)
        ElseIf rxLen = fLen Then
            fStrm.Close()
            MessageBox.Show("firmware upload over!", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information)
        End If
    End Sub

    Private Sub sckTcpUp_SocketError(ByVal err As System.Exception) Handles sckTcpUp.SocketError
        MessageBox.Show(err.Message, "Firmware Uploading Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
    End Sub

    'new treeview sorter
    Private Class NodeSorter
        Implements IComparer

        Private Function Compare(ByVal x As Object, ByVal y As Object) As Integer Implements System.Collections.IComparer.Compare
            Dim tx As TreeNode = CType(x, TreeNode)
            Dim ty As TreeNode = CType(y, TreeNode)
            Return String.Compare(tx.Text, ty.Text)
        End Function
    End Class
    Private Sub SortNode(ByVal pNd As TreeNode)
        If pNd.Nodes.Count = 0 Then Return
        Dim cNodes(pNd.Nodes.Count - 1) As TreeNode
        pNd.Nodes.CopyTo(cNodes, 0)
        Array.Sort(cNodes, New NodeSorter)
        pNd.Nodes.Clear()
        pNd.Nodes.AddRange(cNodes)
    End Sub

End Class
