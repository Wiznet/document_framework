<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmMain))
        Me.tsMain = New System.Windows.Forms.ToolStrip
        Me.tsbSrchAll = New System.Windows.Forms.ToolStripButton
        Me.tsbSet = New System.Windows.Forms.ToolStripButton
        Me.tsbUpload = New System.Windows.Forms.ToolStripButton
        Me.tsbReset = New System.Windows.Forms.ToolStripButton
        Me.tsbFactory = New System.Windows.Forms.ToolStripButton
        Me.ToolStripSeparator4 = New System.Windows.Forms.ToolStripSeparator
        Me.tsbPing = New System.Windows.Forms.ToolStripButton
        Me.tsbFirewall = New System.Windows.Forms.ToolStripButton
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator
        Me.tsbExit = New System.Windows.Forms.ToolStripButton
        Me.imgLst = New System.Windows.Forms.ImageList(Me.components)
        Me.tmrPb = New System.Windows.Forms.Timer(Me.components)
        Me.SplitContainer1 = New System.Windows.Forms.SplitContainer
        Me.lblSplitUp = New System.Windows.Forms.Label
        Me.tc = New System.Windows.Forms.TabControl
        Me.tpNet = New System.Windows.Forms.TabPage
        Me.GroupBox10 = New System.Windows.Forms.GroupBox
        Me.chkDD = New System.Windows.Forms.CheckBox
        Me.txtDPort = New System.Windows.Forms.TextBox
        Me.Label37 = New System.Windows.Forms.Label
        Me.Label36 = New System.Windows.Forms.Label
        Me.cboDdns = New System.Windows.Forms.ComboBox
        Me.txtDHost = New System.Windows.Forms.TextBox
        Me.txtDPwd = New System.Windows.Forms.TextBox
        Me.txtDID = New System.Windows.Forms.TextBox
        Me.Label35 = New System.Windows.Forms.Label
        Me.Label30 = New System.Windows.Forms.Label
        Me.Label29 = New System.Windows.Forms.Label
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.txtRp = New System.Windows.Forms.TextBox
        Me.Label8 = New System.Windows.Forms.Label
        Me.txtRIP = New System.Windows.Forms.TextBox
        Me.Label7 = New System.Windows.Forms.Label
        Me.rbUdp = New System.Windows.Forms.RadioButton
        Me.rbMixed = New System.Windows.Forms.RadioButton
        Me.rbServer = New System.Windows.Forms.RadioButton
        Me.rbClient = New System.Windows.Forms.RadioButton
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.Label28 = New System.Windows.Forms.Label
        Me.chkShowChar3 = New System.Windows.Forms.CheckBox
        Me.txtLP = New System.Windows.Forms.TextBox
        Me.Label13 = New System.Windows.Forms.Label
        Me.txtPPwd = New System.Windows.Forms.TextBox
        Me.txtPId = New System.Windows.Forms.TextBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.txtDNS = New System.Windows.Forms.TextBox
        Me.txtGw = New System.Windows.Forms.TextBox
        Me.txtSubnet = New System.Windows.Forms.TextBox
        Me.txtLIP = New System.Windows.Forms.TextBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.rbStatic = New System.Windows.Forms.RadioButton
        Me.rbPPP = New System.Windows.Forms.RadioButton
        Me.rbDHCP = New System.Windows.Forms.RadioButton
        Me.tpCOM = New System.Windows.Forms.TabPage
        Me.GroupBox6 = New System.Windows.Forms.GroupBox
        Me.txtTrigger3 = New System.Windows.Forms.TextBox
        Me.txtTrigger2 = New System.Windows.Forms.TextBox
        Me.txtTrigger1 = New System.Windows.Forms.TextBox
        Me.Label32 = New System.Windows.Forms.Label
        Me.Label31 = New System.Windows.Forms.Label
        Me.chkTrigger = New System.Windows.Forms.CheckBox
        Me.chkDebug = New System.Windows.Forms.CheckBox
        Me.GroupBox4 = New System.Windows.Forms.GroupBox
        Me.Label24 = New System.Windows.Forms.Label
        Me.Label23 = New System.Windows.Forms.Label
        Me.Label22 = New System.Windows.Forms.Label
        Me.txtChar = New System.Windows.Forms.TextBox
        Me.txtSize = New System.Windows.Forms.TextBox
        Me.txtTimer = New System.Windows.Forms.TextBox
        Me.Label21 = New System.Windows.Forms.Label
        Me.Label20 = New System.Windows.Forms.Label
        Me.Label19 = New System.Windows.Forms.Label
        Me.GroupBox5 = New System.Windows.Forms.GroupBox
        Me.cboFlow = New System.Windows.Forms.ComboBox
        Me.cboStopBit = New System.Windows.Forms.ComboBox
        Me.cboParity = New System.Windows.Forms.ComboBox
        Me.cboDataBit = New System.Windows.Forms.ComboBox
        Me.cboBaud = New System.Windows.Forms.ComboBox
        Me.Label18 = New System.Windows.Forms.Label
        Me.Label17 = New System.Windows.Forms.Label
        Me.Label16 = New System.Windows.Forms.Label
        Me.Label15 = New System.Windows.Forms.Label
        Me.Label14 = New System.Windows.Forms.Label
        Me.tpOption = New System.Windows.Forms.TabPage
        Me.GroupBox3 = New System.Windows.Forms.GroupBox
        Me.txtKaRep = New System.Windows.Forms.TextBox
        Me.txtKA = New System.Windows.Forms.TextBox
        Me.rbTelnet = New System.Windows.Forms.RadioButton
        Me.rbRaw = New System.Windows.Forms.RadioButton
        Me.Label12 = New System.Windows.Forms.Label
        Me.Label11 = New System.Windows.Forms.Label
        Me.Label10 = New System.Windows.Forms.Label
        Me.Label9 = New System.Windows.Forms.Label
        Me.chkKa = New System.Windows.Forms.CheckBox
        Me.GroupBox8 = New System.Windows.Forms.GroupBox
        Me.chkShowChar2 = New System.Windows.Forms.CheckBox
        Me.txtConnPwd = New System.Windows.Forms.TextBox
        Me.Label34 = New System.Windows.Forms.Label
        Me.chkConnPwd = New System.Windows.Forms.CheckBox
        Me.GroupBox7 = New System.Windows.Forms.GroupBox
        Me.chkShowChar1 = New System.Windows.Forms.CheckBox
        Me.txtSearchPwd = New System.Windows.Forms.TextBox
        Me.Label39 = New System.Windows.Forms.Label
        Me.Label33 = New System.Windows.Forms.Label
        Me.GroupBox9 = New System.Windows.Forms.GroupBox
        Me.Label42 = New System.Windows.Forms.Label
        Me.Label41 = New System.Windows.Forms.Label
        Me.Label40 = New System.Windows.Forms.Label
        Me.txtReconn = New System.Windows.Forms.TextBox
        Me.Label38 = New System.Windows.Forms.Label
        Me.Label27 = New System.Windows.Forms.Label
        Me.Label26 = New System.Windows.Forms.Label
        Me.txtInactiveTimer = New System.Windows.Forms.TextBox
        Me.Label25 = New System.Windows.Forms.Label
        Me.tv = New System.Windows.Forms.TreeView
        Me.GroupBox11 = New System.Windows.Forms.GroupBox
        Me.rtbLog = New System.Windows.Forms.RichTextBox
        Me.ssMain = New System.Windows.Forms.StatusStrip
        Me.tLblState = New System.Windows.Forms.ToolStripStatusLabel
        Me.tpb = New System.Windows.Forms.ToolStripProgressBar
        Me.tlblMsg = New System.Windows.Forms.ToolStripStatusLabel
        Me.ofd = New System.Windows.Forms.OpenFileDialog
        Me.BottomToolStripPanel = New System.Windows.Forms.ToolStripPanel
        Me.TopToolStripPanel = New System.Windows.Forms.ToolStripPanel
        Me.RightToolStripPanel = New System.Windows.Forms.ToolStripPanel
        Me.LeftToolStripPanel = New System.Windows.Forms.ToolStripPanel
        Me.ContentPanel = New System.Windows.Forms.ToolStripContentPanel
        Me.tsMain.SuspendLayout()
        Me.SplitContainer1.Panel1.SuspendLayout()
        Me.SplitContainer1.Panel2.SuspendLayout()
        Me.SplitContainer1.SuspendLayout()
        Me.tc.SuspendLayout()
        Me.tpNet.SuspendLayout()
        Me.GroupBox10.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.tpCOM.SuspendLayout()
        Me.GroupBox6.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.tpOption.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox8.SuspendLayout()
        Me.GroupBox7.SuspendLayout()
        Me.GroupBox9.SuspendLayout()
        Me.GroupBox11.SuspendLayout()
        Me.ssMain.SuspendLayout()
        Me.SuspendLayout()
        '
        'tsMain
        '
        Me.tsMain.ImageScalingSize = New System.Drawing.Size(32, 32)
        Me.tsMain.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.tsbSrchAll, Me.tsbSet, Me.tsbUpload, Me.tsbReset, Me.tsbFactory, Me.ToolStripSeparator4, Me.tsbPing, Me.tsbFirewall, Me.ToolStripSeparator2, Me.tsbExit})
        Me.tsMain.Location = New System.Drawing.Point(0, 0)
        Me.tsMain.Name = "tsMain"
        Me.tsMain.RenderMode = System.Windows.Forms.ToolStripRenderMode.System
        Me.tsMain.Size = New System.Drawing.Size(657, 39)
        Me.tsMain.TabIndex = 0
        Me.tsMain.Text = "ToolStrip1"
        '
        'tsbSrchAll
        '
        Me.tsbSrchAll.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tsbSrchAll.Image = CType(resources.GetObject("tsbSrchAll.Image"), System.Drawing.Image)
        Me.tsbSrchAll.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.tsbSrchAll.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbSrchAll.Margin = New System.Windows.Forms.Padding(1)
        Me.tsbSrchAll.Name = "tsbSrchAll"
        Me.tsbSrchAll.Size = New System.Drawing.Size(82, 37)
        Me.tsbSrchAll.Text = "Search"
        Me.tsbSrchAll.ToolTipText = "Search"
        '
        'tsbSet
        '
        Me.tsbSet.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tsbSet.Image = CType(resources.GetObject("tsbSet.Image"), System.Drawing.Image)
        Me.tsbSet.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.tsbSet.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbSet.Name = "tsbSet"
        Me.tsbSet.Size = New System.Drawing.Size(81, 36)
        Me.tsbSet.Text = "Setting"
        '
        'tsbUpload
        '
        Me.tsbUpload.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tsbUpload.Image = CType(resources.GetObject("tsbUpload.Image"), System.Drawing.Image)
        Me.tsbUpload.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.tsbUpload.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbUpload.Name = "tsbUpload"
        Me.tsbUpload.Size = New System.Drawing.Size(83, 36)
        Me.tsbUpload.Text = "Upload"
        '
        'tsbReset
        '
        Me.tsbReset.Image = CType(resources.GetObject("tsbReset.Image"), System.Drawing.Image)
        Me.tsbReset.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.tsbReset.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbReset.Name = "tsbReset"
        Me.tsbReset.Size = New System.Drawing.Size(76, 36)
        Me.tsbReset.Text = "Reset"
        '
        'tsbFactory
        '
        Me.tsbFactory.Image = CType(resources.GetObject("tsbFactory.Image"), System.Drawing.Image)
        Me.tsbFactory.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.tsbFactory.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbFactory.Name = "tsbFactory"
        Me.tsbFactory.Size = New System.Drawing.Size(86, 36)
        Me.tsbFactory.Text = "Factory"
        Me.tsbFactory.ToolTipText = "Factory Reset"
        '
        'ToolStripSeparator4
        '
        Me.ToolStripSeparator4.Name = "ToolStripSeparator4"
        Me.ToolStripSeparator4.Size = New System.Drawing.Size(6, 39)
        '
        'tsbPing
        '
        Me.tsbPing.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tsbPing.Image = CType(resources.GetObject("tsbPing.Image"), System.Drawing.Image)
        Me.tsbPing.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.tsbPing.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbPing.Name = "tsbPing"
        Me.tsbPing.Size = New System.Drawing.Size(68, 36)
        Me.tsbPing.Text = "Ping"
        '
        'tsbFirewall
        '
        Me.tsbFirewall.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tsbFirewall.Image = CType(resources.GetObject("tsbFirewall.Image"), System.Drawing.Image)
        Me.tsbFirewall.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.tsbFirewall.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbFirewall.Name = "tsbFirewall"
        Me.tsbFirewall.Size = New System.Drawing.Size(86, 36)
        Me.tsbFirewall.Text = "Firewall"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(6, 39)
        '
        'tsbExit
        '
        Me.tsbExit.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tsbExit.Image = CType(resources.GetObject("tsbExit.Image"), System.Drawing.Image)
        Me.tsbExit.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.tsbExit.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbExit.Name = "tsbExit"
        Me.tsbExit.Size = New System.Drawing.Size(62, 36)
        Me.tsbExit.Text = "Exit"
        '
        'imgLst
        '
        Me.imgLst.ImageStream = CType(resources.GetObject("imgLst.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.imgLst.TransparentColor = System.Drawing.Color.Transparent
        Me.imgLst.Images.SetKeyName(0, "networkoptions16.png")
        Me.imgLst.Images.SetKeyName(1, "cd16.png")
        Me.imgLst.Images.SetKeyName(2, "add16.png")
        '
        'tmrPb
        '
        Me.tmrPb.Enabled = True
        '
        'SplitContainer1
        '
        Me.SplitContainer1.Location = New System.Drawing.Point(0, 39)
        Me.SplitContainer1.Margin = New System.Windows.Forms.Padding(0)
        Me.SplitContainer1.Name = "SplitContainer1"
        Me.SplitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer1.Panel1
        '
        Me.SplitContainer1.Panel1.Controls.Add(Me.lblSplitUp)
        Me.SplitContainer1.Panel1.Controls.Add(Me.tc)
        Me.SplitContainer1.Panel1.Controls.Add(Me.tv)
        Me.SplitContainer1.Panel1MinSize = 2
        '
        'SplitContainer1.Panel2
        '
        Me.SplitContainer1.Panel2.Controls.Add(Me.GroupBox11)
        Me.SplitContainer1.Panel2MinSize = 0
        Me.SplitContainer1.Size = New System.Drawing.Size(657, 559)
        Me.SplitContainer1.SplitterDistance = 549
        Me.SplitContainer1.SplitterWidth = 8
        Me.SplitContainer1.TabIndex = 4
        '
        'lblSplitUp
        '
        Me.lblSplitUp.BackColor = System.Drawing.Color.Transparent
        Me.lblSplitUp.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.lblSplitUp.Location = New System.Drawing.Point(0, 547)
        Me.lblSplitUp.Margin = New System.Windows.Forms.Padding(0)
        Me.lblSplitUp.Name = "lblSplitUp"
        Me.lblSplitUp.Size = New System.Drawing.Size(657, 2)
        Me.lblSplitUp.TabIndex = 30
        '
        'tc
        '
        Me.tc.Controls.Add(Me.tpNet)
        Me.tc.Controls.Add(Me.tpCOM)
        Me.tc.Controls.Add(Me.tpOption)
        Me.tc.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tc.ImageList = Me.imgLst
        Me.tc.Location = New System.Drawing.Point(225, 3)
        Me.tc.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.tc.Name = "tc"
        Me.tc.SelectedIndex = 0
        Me.tc.Size = New System.Drawing.Size(430, 489)
        Me.tc.TabIndex = 4
        '
        'tpNet
        '
        Me.tpNet.Controls.Add(Me.GroupBox10)
        Me.tpNet.Controls.Add(Me.GroupBox2)
        Me.tpNet.Controls.Add(Me.GroupBox1)
        Me.tpNet.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tpNet.ImageIndex = 0
        Me.tpNet.Location = New System.Drawing.Point(4, 24)
        Me.tpNet.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.tpNet.Name = "tpNet"
        Me.tpNet.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.tpNet.Size = New System.Drawing.Size(422, 461)
        Me.tpNet.TabIndex = 0
        Me.tpNet.Text = "Network"
        Me.tpNet.UseVisualStyleBackColor = True
        '
        'GroupBox10
        '
        Me.GroupBox10.Controls.Add(Me.chkDD)
        Me.GroupBox10.Controls.Add(Me.txtDPort)
        Me.GroupBox10.Controls.Add(Me.Label37)
        Me.GroupBox10.Controls.Add(Me.Label36)
        Me.GroupBox10.Controls.Add(Me.cboDdns)
        Me.GroupBox10.Controls.Add(Me.txtDHost)
        Me.GroupBox10.Controls.Add(Me.txtDPwd)
        Me.GroupBox10.Controls.Add(Me.txtDID)
        Me.GroupBox10.Controls.Add(Me.Label35)
        Me.GroupBox10.Controls.Add(Me.Label30)
        Me.GroupBox10.Controls.Add(Me.Label29)
        Me.GroupBox10.Location = New System.Drawing.Point(6, 338)
        Me.GroupBox10.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox10.Name = "GroupBox10"
        Me.GroupBox10.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox10.Size = New System.Drawing.Size(409, 114)
        Me.GroupBox10.TabIndex = 2
        Me.GroupBox10.TabStop = False
        Me.GroupBox10.Text = "DDNS settings"
        '
        'chkDD
        '
        Me.chkDD.AutoSize = True
        Me.chkDD.Enabled = False
        Me.chkDD.Location = New System.Drawing.Point(15, 23)
        Me.chkDD.Margin = New System.Windows.Forms.Padding(1)
        Me.chkDD.Name = "chkDD"
        Me.chkDD.Size = New System.Drawing.Size(65, 19)
        Me.chkDD.TabIndex = 10
        Me.chkDD.Text = "Enable"
        Me.chkDD.UseVisualStyleBackColor = True
        '
        'txtDPort
        '
        Me.txtDPort.Enabled = False
        Me.txtDPort.Location = New System.Drawing.Point(294, 50)
        Me.txtDPort.Margin = New System.Windows.Forms.Padding(1)
        Me.txtDPort.Name = "txtDPort"
        Me.txtDPort.Size = New System.Drawing.Size(103, 21)
        Me.txtDPort.TabIndex = 9
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.Location = New System.Drawing.Point(215, 52)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(78, 15)
        Me.Label37.TabIndex = 8
        Me.Label37.Text = "Port number:"
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Location = New System.Drawing.Point(12, 53)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(48, 15)
        Me.Label36.TabIndex = 7
        Me.Label36.Text = "DDNS: "
        '
        'cboDdns
        '
        Me.cboDdns.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboDdns.Enabled = False
        Me.cboDdns.FormattingEnabled = True
        Me.cboDdns.Items.AddRange(New Object() {"dyndns.com"})
        Me.cboDdns.Location = New System.Drawing.Point(78, 50)
        Me.cboDdns.Margin = New System.Windows.Forms.Padding(1)
        Me.cboDdns.Name = "cboDdns"
        Me.cboDdns.Size = New System.Drawing.Size(131, 23)
        Me.cboDdns.TabIndex = 6
        '
        'txtDHost
        '
        Me.txtDHost.Enabled = False
        Me.txtDHost.Location = New System.Drawing.Point(163, 20)
        Me.txtDHost.Margin = New System.Windows.Forms.Padding(1)
        Me.txtDHost.MaxLength = 32
        Me.txtDHost.Name = "txtDHost"
        Me.txtDHost.Size = New System.Drawing.Size(234, 21)
        Me.txtDHost.TabIndex = 5
        '
        'txtDPwd
        '
        Me.txtDPwd.Enabled = False
        Me.txtDPwd.Location = New System.Drawing.Point(294, 80)
        Me.txtDPwd.Margin = New System.Windows.Forms.Padding(1)
        Me.txtDPwd.MaxLength = 16
        Me.txtDPwd.Name = "txtDPwd"
        Me.txtDPwd.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txtDPwd.Size = New System.Drawing.Size(103, 21)
        Me.txtDPwd.TabIndex = 4
        '
        'txtDID
        '
        Me.txtDID.Enabled = False
        Me.txtDID.Location = New System.Drawing.Point(78, 80)
        Me.txtDID.Margin = New System.Windows.Forms.Padding(1)
        Me.txtDID.MaxLength = 16
        Me.txtDID.Name = "txtDID"
        Me.txtDID.Size = New System.Drawing.Size(106, 21)
        Me.txtDID.TabIndex = 3
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Location = New System.Drawing.Point(86, 24)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(71, 15)
        Me.Label35.TabIndex = 2
        Me.Label35.Text = "Host name:"
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Location = New System.Drawing.Point(190, 84)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(103, 15)
        Me.Label30.TabIndex = 1
        Me.Label30.Text = "DDNS password:"
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Location = New System.Drawing.Point(12, 84)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(60, 15)
        Me.Label29.TabIndex = 0
        Me.Label29.Text = "DDNS ID:"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.txtRp)
        Me.GroupBox2.Controls.Add(Me.Label8)
        Me.GroupBox2.Controls.Add(Me.txtRIP)
        Me.GroupBox2.Controls.Add(Me.Label7)
        Me.GroupBox2.Controls.Add(Me.rbUdp)
        Me.GroupBox2.Controls.Add(Me.rbMixed)
        Me.GroupBox2.Controls.Add(Me.rbServer)
        Me.GroupBox2.Controls.Add(Me.rbClient)
        Me.GroupBox2.Location = New System.Drawing.Point(6, 251)
        Me.GroupBox2.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox2.Size = New System.Drawing.Size(409, 79)
        Me.GroupBox2.TabIndex = 1
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Select operation mode for the device"
        '
        'txtRp
        '
        Me.txtRp.Location = New System.Drawing.Point(329, 45)
        Me.txtRp.Margin = New System.Windows.Forms.Padding(1)
        Me.txtRp.Name = "txtRp"
        Me.txtRp.Size = New System.Drawing.Size(68, 21)
        Me.txtRp.TabIndex = 7
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(313, 48)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(10, 15)
        Me.Label8.TabIndex = 6
        Me.Label8.Text = ":"
        '
        'txtRIP
        '
        Me.txtRIP.Location = New System.Drawing.Point(150, 45)
        Me.txtRIP.Margin = New System.Windows.Forms.Padding(1)
        Me.txtRIP.MaxLength = 32
        Me.txtRIP.Name = "txtRIP"
        Me.txtRIP.Size = New System.Drawing.Size(157, 21)
        Me.txtRIP.TabIndex = 5
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(14, 48)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(130, 15)
        Me.Label7.TabIndex = 4
        Me.Label7.Text = "Remote IP/host name:"
        '
        'rbUdp
        '
        Me.rbUdp.AutoSize = True
        Me.rbUdp.Location = New System.Drawing.Point(329, 21)
        Me.rbUdp.Margin = New System.Windows.Forms.Padding(1)
        Me.rbUdp.Name = "rbUdp"
        Me.rbUdp.Size = New System.Drawing.Size(51, 19)
        Me.rbUdp.TabIndex = 3
        Me.rbUdp.TabStop = True
        Me.rbUdp.Text = "UDP"
        Me.rbUdp.UseVisualStyleBackColor = True
        '
        'rbMixed
        '
        Me.rbMixed.AutoSize = True
        Me.rbMixed.Location = New System.Drawing.Point(222, 21)
        Me.rbMixed.Margin = New System.Windows.Forms.Padding(1)
        Me.rbMixed.Name = "rbMixed"
        Me.rbMixed.Size = New System.Drawing.Size(85, 19)
        Me.rbMixed.TabIndex = 2
        Me.rbMixed.TabStop = True
        Me.rbMixed.Text = "TCP mixed"
        Me.rbMixed.UseVisualStyleBackColor = True
        '
        'rbServer
        '
        Me.rbServer.AutoSize = True
        Me.rbServer.Location = New System.Drawing.Point(125, 21)
        Me.rbServer.Margin = New System.Windows.Forms.Padding(1)
        Me.rbServer.Name = "rbServer"
        Me.rbServer.Size = New System.Drawing.Size(86, 19)
        Me.rbServer.TabIndex = 1
        Me.rbServer.TabStop = True
        Me.rbServer.Text = "TCP server"
        Me.rbServer.UseVisualStyleBackColor = True
        '
        'rbClient
        '
        Me.rbClient.AutoSize = True
        Me.rbClient.Location = New System.Drawing.Point(18, 21)
        Me.rbClient.Margin = New System.Windows.Forms.Padding(1)
        Me.rbClient.Name = "rbClient"
        Me.rbClient.Size = New System.Drawing.Size(81, 19)
        Me.rbClient.TabIndex = 0
        Me.rbClient.TabStop = True
        Me.rbClient.Text = "TCP client"
        Me.rbClient.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Label28)
        Me.GroupBox1.Controls.Add(Me.chkShowChar3)
        Me.GroupBox1.Controls.Add(Me.txtLP)
        Me.GroupBox1.Controls.Add(Me.Label13)
        Me.GroupBox1.Controls.Add(Me.txtPPwd)
        Me.GroupBox1.Controls.Add(Me.txtPId)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.txtDNS)
        Me.GroupBox1.Controls.Add(Me.txtGw)
        Me.GroupBox1.Controls.Add(Me.txtSubnet)
        Me.GroupBox1.Controls.Add(Me.txtLIP)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.rbStatic)
        Me.GroupBox1.Controls.Add(Me.rbPPP)
        Me.GroupBox1.Controls.Add(Me.rbDHCP)
        Me.GroupBox1.Location = New System.Drawing.Point(6, 8)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox1.Size = New System.Drawing.Size(409, 235)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Device network settings"
        '
        'Label28
        '
        Me.Label28.BackColor = System.Drawing.Color.Silver
        Me.Label28.Location = New System.Drawing.Point(12, 44)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(385, 1)
        Me.Label28.TabIndex = 29
        '
        'chkShowChar3
        '
        Me.chkShowChar3.AutoSize = True
        Me.chkShowChar3.Location = New System.Drawing.Point(316, 204)
        Me.chkShowChar3.Margin = New System.Windows.Forms.Padding(1)
        Me.chkShowChar3.Name = "chkShowChar3"
        Me.chkShowChar3.Size = New System.Drawing.Size(91, 19)
        Me.chkShowChar3.TabIndex = 28
        Me.chkShowChar3.Text = "Show chars"
        Me.chkShowChar3.UseVisualStyleBackColor = True
        '
        'txtLP
        '
        Me.txtLP.Location = New System.Drawing.Point(329, 52)
        Me.txtLP.Margin = New System.Windows.Forms.Padding(1)
        Me.txtLP.Name = "txtLP"
        Me.txtLP.Size = New System.Drawing.Size(68, 21)
        Me.txtLP.TabIndex = 27
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(313, 55)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(10, 15)
        Me.Label13.TabIndex = 26
        Me.Label13.Text = ":"
        '
        'txtPPwd
        '
        Me.txtPPwd.Location = New System.Drawing.Point(138, 201)
        Me.txtPPwd.Margin = New System.Windows.Forms.Padding(1)
        Me.txtPPwd.MaxLength = 32
        Me.txtPPwd.Name = "txtPPwd"
        Me.txtPPwd.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txtPPwd.Size = New System.Drawing.Size(169, 21)
        Me.txtPPwd.TabIndex = 25
        '
        'txtPId
        '
        Me.txtPId.Location = New System.Drawing.Point(137, 170)
        Me.txtPId.Margin = New System.Windows.Forms.Padding(1)
        Me.txtPId.MaxLength = 32
        Me.txtPId.Name = "txtPId"
        Me.txtPId.Size = New System.Drawing.Size(170, 21)
        Me.txtPId.TabIndex = 24
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(25, 205)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(107, 15)
        Me.Label6.TabIndex = 23
        Me.Label6.Text = "PPPoE password:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(67, 174)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(64, 15)
        Me.Label5.TabIndex = 22
        Me.Label5.Text = "PPPoE ID:"
        '
        'txtDNS
        '
        Me.txtDNS.Location = New System.Drawing.Point(138, 140)
        Me.txtDNS.Margin = New System.Windows.Forms.Padding(1)
        Me.txtDNS.Name = "txtDNS"
        Me.txtDNS.Size = New System.Drawing.Size(169, 21)
        Me.txtDNS.TabIndex = 21
        '
        'txtGw
        '
        Me.txtGw.Location = New System.Drawing.Point(138, 110)
        Me.txtGw.Margin = New System.Windows.Forms.Padding(1)
        Me.txtGw.Name = "txtGw"
        Me.txtGw.Size = New System.Drawing.Size(169, 21)
        Me.txtGw.TabIndex = 20
        '
        'txtSubnet
        '
        Me.txtSubnet.Location = New System.Drawing.Point(138, 81)
        Me.txtSubnet.Margin = New System.Windows.Forms.Padding(1)
        Me.txtSubnet.Name = "txtSubnet"
        Me.txtSubnet.Size = New System.Drawing.Size(169, 21)
        Me.txtSubnet.TabIndex = 19
        '
        'txtLIP
        '
        Me.txtLIP.Location = New System.Drawing.Point(138, 52)
        Me.txtLIP.Margin = New System.Windows.Forms.Padding(1)
        Me.txtLIP.Name = "txtLIP"
        Me.txtLIP.Size = New System.Drawing.Size(169, 21)
        Me.txtLIP.TabIndex = 18
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(59, 143)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(73, 15)
        Me.Label4.TabIndex = 17
        Me.Label4.Text = "DNS server:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(75, 114)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(57, 15)
        Me.Label3.TabIndex = 16
        Me.Label3.Text = "Gateway:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(49, 85)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(83, 15)
        Me.Label2.TabIndex = 15
        Me.Label2.Text = "Subnet mask:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(21, 52)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(110, 15)
        Me.Label1.TabIndex = 14
        Me.Label1.Text = "Device IP address:"
        '
        'rbStatic
        '
        Me.rbStatic.AutoSize = True
        Me.rbStatic.Location = New System.Drawing.Point(18, 21)
        Me.rbStatic.Margin = New System.Windows.Forms.Padding(1)
        Me.rbStatic.Name = "rbStatic"
        Me.rbStatic.Size = New System.Drawing.Size(175, 19)
        Me.rbStatic.TabIndex = 5
        Me.rbStatic.TabStop = True
        Me.rbStatic.Text = "Using the follow IP Address"
        Me.rbStatic.UseVisualStyleBackColor = True
        '
        'rbPPP
        '
        Me.rbPPP.AutoSize = True
        Me.rbPPP.Enabled = False
        Me.rbPPP.Location = New System.Drawing.Point(316, 21)
        Me.rbPPP.Margin = New System.Windows.Forms.Padding(1)
        Me.rbPPP.Name = "rbPPP"
        Me.rbPPP.Size = New System.Drawing.Size(64, 19)
        Me.rbPPP.TabIndex = 4
        Me.rbPPP.TabStop = True
        Me.rbPPP.Text = "PPPoE"
        Me.rbPPP.UseVisualStyleBackColor = True
        '
        'rbDHCP
        '
        Me.rbDHCP.AutoSize = True
        Me.rbDHCP.Location = New System.Drawing.Point(222, 21)
        Me.rbDHCP.Margin = New System.Windows.Forms.Padding(1)
        Me.rbDHCP.Name = "rbDHCP"
        Me.rbDHCP.Size = New System.Drawing.Size(60, 19)
        Me.rbDHCP.TabIndex = 3
        Me.rbDHCP.TabStop = True
        Me.rbDHCP.Text = "DHCP"
        Me.rbDHCP.UseVisualStyleBackColor = True
        '
        'tpCOM
        '
        Me.tpCOM.Controls.Add(Me.GroupBox6)
        Me.tpCOM.Controls.Add(Me.chkDebug)
        Me.tpCOM.Controls.Add(Me.GroupBox4)
        Me.tpCOM.Controls.Add(Me.GroupBox5)
        Me.tpCOM.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tpCOM.ImageIndex = 1
        Me.tpCOM.Location = New System.Drawing.Point(4, 24)
        Me.tpCOM.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.tpCOM.Name = "tpCOM"
        Me.tpCOM.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.tpCOM.Size = New System.Drawing.Size(422, 461)
        Me.tpCOM.TabIndex = 1
        Me.tpCOM.Text = "Serial"
        Me.tpCOM.UseVisualStyleBackColor = True
        '
        'GroupBox6
        '
        Me.GroupBox6.Controls.Add(Me.txtTrigger3)
        Me.GroupBox6.Controls.Add(Me.txtTrigger2)
        Me.GroupBox6.Controls.Add(Me.txtTrigger1)
        Me.GroupBox6.Controls.Add(Me.Label32)
        Me.GroupBox6.Controls.Add(Me.Label31)
        Me.GroupBox6.Controls.Add(Me.chkTrigger)
        Me.GroupBox6.Location = New System.Drawing.Point(34, 366)
        Me.GroupBox6.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox6.Size = New System.Drawing.Size(355, 57)
        Me.GroupBox6.TabIndex = 15
        Me.GroupBox6.TabStop = False
        Me.GroupBox6.Text = "Serial command mode switch code"
        '
        'txtTrigger3
        '
        Me.txtTrigger3.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTrigger3.Location = New System.Drawing.Point(232, 22)
        Me.txtTrigger3.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtTrigger3.MaxLength = 2
        Me.txtTrigger3.Name = "txtTrigger3"
        Me.txtTrigger3.Size = New System.Drawing.Size(26, 21)
        Me.txtTrigger3.TabIndex = 12
        Me.txtTrigger3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtTrigger2
        '
        Me.txtTrigger2.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTrigger2.Location = New System.Drawing.Point(200, 22)
        Me.txtTrigger2.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtTrigger2.MaxLength = 2
        Me.txtTrigger2.Name = "txtTrigger2"
        Me.txtTrigger2.Size = New System.Drawing.Size(26, 21)
        Me.txtTrigger2.TabIndex = 11
        Me.txtTrigger2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtTrigger1
        '
        Me.txtTrigger1.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTrigger1.Location = New System.Drawing.Point(168, 22)
        Me.txtTrigger1.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtTrigger1.MaxLength = 2
        Me.txtTrigger1.Name = "txtTrigger1"
        Me.txtTrigger1.Size = New System.Drawing.Size(26, 21)
        Me.txtTrigger1.TabIndex = 10
        Me.txtTrigger1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.ForeColor = System.Drawing.Color.Red
        Me.Label32.Location = New System.Drawing.Point(258, 25)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(97, 15)
        Me.Label32.TabIndex = 9
        Me.Label32.Text = "(Hexacode Only)"
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Location = New System.Drawing.Point(81, 25)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(82, 15)
        Me.Label31.TabIndex = 1
        Me.Label31.Text = "Trigger Code:"
        '
        'chkTrigger
        '
        Me.chkTrigger.AutoSize = True
        Me.chkTrigger.Location = New System.Drawing.Point(15, 24)
        Me.chkTrigger.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkTrigger.Name = "chkTrigger"
        Me.chkTrigger.Size = New System.Drawing.Size(65, 19)
        Me.chkTrigger.TabIndex = 0
        Me.chkTrigger.Text = "Enable"
        Me.chkTrigger.UseVisualStyleBackColor = True
        '
        'chkDebug
        '
        Me.chkDebug.AutoSize = True
        Me.chkDebug.Location = New System.Drawing.Point(34, 14)
        Me.chkDebug.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkDebug.Name = "chkDebug"
        Me.chkDebug.Size = New System.Drawing.Size(196, 19)
        Me.chkDebug.TabIndex = 14
        Me.chkDebug.Text = "Enable debug message output"
        Me.chkDebug.UseVisualStyleBackColor = True
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.Label24)
        Me.GroupBox4.Controls.Add(Me.Label23)
        Me.GroupBox4.Controls.Add(Me.Label22)
        Me.GroupBox4.Controls.Add(Me.txtChar)
        Me.GroupBox4.Controls.Add(Me.txtSize)
        Me.GroupBox4.Controls.Add(Me.txtTimer)
        Me.GroupBox4.Controls.Add(Me.Label21)
        Me.GroupBox4.Controls.Add(Me.Label20)
        Me.GroupBox4.Controls.Add(Me.Label19)
        Me.GroupBox4.Location = New System.Drawing.Point(35, 237)
        Me.GroupBox4.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox4.Size = New System.Drawing.Size(354, 121)
        Me.GroupBox4.TabIndex = 13
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Serial data packing condition settings"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.ForeColor = System.Drawing.Color.Red
        Me.Label24.Location = New System.Drawing.Point(231, 88)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(97, 15)
        Me.Label24.TabIndex = 8
        Me.Label24.Text = "(Hexacode Only)"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.ForeColor = System.Drawing.Color.Red
        Me.Label23.Location = New System.Drawing.Point(231, 58)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(83, 15)
        Me.Label23.TabIndex = 7
        Me.Label23.Text = "(0~255 Bytes)"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.ForeColor = System.Drawing.Color.Red
        Me.Label22.Location = New System.Drawing.Point(231, 27)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(82, 15)
        Me.Label22.TabIndex = 6
        Me.Label22.Text = "(0~65535ms)"
        '
        'txtChar
        '
        Me.txtChar.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtChar.Location = New System.Drawing.Point(145, 85)
        Me.txtChar.Margin = New System.Windows.Forms.Padding(3, 8, 3, 8)
        Me.txtChar.MaxLength = 2
        Me.txtChar.Name = "txtChar"
        Me.txtChar.Size = New System.Drawing.Size(80, 21)
        Me.txtChar.TabIndex = 3
        Me.txtChar.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtSize
        '
        Me.txtSize.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSize.Location = New System.Drawing.Point(145, 54)
        Me.txtSize.Margin = New System.Windows.Forms.Padding(3, 8, 3, 8)
        Me.txtSize.MaxLength = 3
        Me.txtSize.Name = "txtSize"
        Me.txtSize.Size = New System.Drawing.Size(80, 21)
        Me.txtSize.TabIndex = 2
        Me.txtSize.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtTimer
        '
        Me.txtTimer.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTimer.Location = New System.Drawing.Point(145, 24)
        Me.txtTimer.Margin = New System.Windows.Forms.Padding(3, 8, 3, 8)
        Me.txtTimer.MaxLength = 5
        Me.txtTimer.Name = "txtTimer"
        Me.txtTimer.Size = New System.Drawing.Size(80, 21)
        Me.txtTimer.TabIndex = 1
        Me.txtTimer.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(54, 88)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(81, 15)
        Me.Label21.TabIndex = 2
        Me.Label21.Text = "Character(&C):"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(87, 58)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(48, 15)
        Me.Label20.TabIndex = 1
        Me.Label20.Text = "Size(&Z):"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(78, 27)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(57, 15)
        Me.Label19.TabIndex = 0
        Me.Label19.Text = "Timer(&T):"
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.cboFlow)
        Me.GroupBox5.Controls.Add(Me.cboStopBit)
        Me.GroupBox5.Controls.Add(Me.cboParity)
        Me.GroupBox5.Controls.Add(Me.cboDataBit)
        Me.GroupBox5.Controls.Add(Me.cboBaud)
        Me.GroupBox5.Controls.Add(Me.Label18)
        Me.GroupBox5.Controls.Add(Me.Label17)
        Me.GroupBox5.Controls.Add(Me.Label16)
        Me.GroupBox5.Controls.Add(Me.Label15)
        Me.GroupBox5.Controls.Add(Me.Label14)
        Me.GroupBox5.Location = New System.Drawing.Point(34, 36)
        Me.GroupBox5.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox5.Size = New System.Drawing.Size(355, 193)
        Me.GroupBox5.TabIndex = 12
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "COM port settings"
        '
        'cboFlow
        '
        Me.cboFlow.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboFlow.FormattingEnabled = True
        Me.cboFlow.Location = New System.Drawing.Point(146, 155)
        Me.cboFlow.Margin = New System.Windows.Forms.Padding(3, 8, 3, 8)
        Me.cboFlow.Name = "cboFlow"
        Me.cboFlow.Size = New System.Drawing.Size(160, 23)
        Me.cboFlow.TabIndex = 15
        '
        'cboStopBit
        '
        Me.cboStopBit.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboStopBit.FormattingEnabled = True
        Me.cboStopBit.Location = New System.Drawing.Point(146, 121)
        Me.cboStopBit.Margin = New System.Windows.Forms.Padding(3, 8, 3, 8)
        Me.cboStopBit.Name = "cboStopBit"
        Me.cboStopBit.Size = New System.Drawing.Size(160, 23)
        Me.cboStopBit.TabIndex = 14
        '
        'cboParity
        '
        Me.cboParity.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboParity.FormattingEnabled = True
        Me.cboParity.Location = New System.Drawing.Point(146, 87)
        Me.cboParity.Margin = New System.Windows.Forms.Padding(3, 8, 3, 8)
        Me.cboParity.Name = "cboParity"
        Me.cboParity.Size = New System.Drawing.Size(160, 23)
        Me.cboParity.TabIndex = 13
        '
        'cboDataBit
        '
        Me.cboDataBit.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboDataBit.FormattingEnabled = True
        Me.cboDataBit.Location = New System.Drawing.Point(146, 54)
        Me.cboDataBit.Margin = New System.Windows.Forms.Padding(3, 8, 3, 8)
        Me.cboDataBit.Name = "cboDataBit"
        Me.cboDataBit.Size = New System.Drawing.Size(160, 23)
        Me.cboDataBit.TabIndex = 12
        '
        'cboBaud
        '
        Me.cboBaud.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboBaud.FormattingEnabled = True
        Me.cboBaud.ItemHeight = 15
        Me.cboBaud.Location = New System.Drawing.Point(146, 21)
        Me.cboBaud.Margin = New System.Windows.Forms.Padding(3, 8, 3, 8)
        Me.cboBaud.Name = "cboBaud"
        Me.cboBaud.Size = New System.Drawing.Size(160, 23)
        Me.cboBaud.TabIndex = 11
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(42, 159)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(94, 15)
        Me.Label18.TabIndex = 14
        Me.Label18.Text = "Flow Control(&F):"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(69, 125)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(68, 15)
        Me.Label17.TabIndex = 13
        Me.Label17.Text = "Stop Bit(&S):"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(80, 91)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(56, 15)
        Me.Label16.TabIndex = 12
        Me.Label16.Text = "Parity(&P):"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(66, 58)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(70, 15)
        Me.Label15.TabIndex = 11
        Me.Label15.Text = "Data Bit(&D):"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(51, 24)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(85, 15)
        Me.Label14.TabIndex = 10
        Me.Label14.Text = "Baud Rate(&R):"
        '
        'tpOption
        '
        Me.tpOption.Controls.Add(Me.GroupBox3)
        Me.tpOption.Controls.Add(Me.GroupBox8)
        Me.tpOption.Controls.Add(Me.GroupBox7)
        Me.tpOption.Controls.Add(Me.GroupBox9)
        Me.tpOption.ImageIndex = 2
        Me.tpOption.Location = New System.Drawing.Point(4, 24)
        Me.tpOption.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.tpOption.Name = "tpOption"
        Me.tpOption.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.tpOption.Size = New System.Drawing.Size(422, 461)
        Me.tpOption.TabIndex = 2
        Me.tpOption.Text = "Options"
        Me.tpOption.UseVisualStyleBackColor = True
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.txtKaRep)
        Me.GroupBox3.Controls.Add(Me.txtKA)
        Me.GroupBox3.Controls.Add(Me.rbTelnet)
        Me.GroupBox3.Controls.Add(Me.rbRaw)
        Me.GroupBox3.Controls.Add(Me.Label12)
        Me.GroupBox3.Controls.Add(Me.Label11)
        Me.GroupBox3.Controls.Add(Me.Label10)
        Me.GroupBox3.Controls.Add(Me.Label9)
        Me.GroupBox3.Controls.Add(Me.chkKa)
        Me.GroupBox3.Location = New System.Drawing.Point(6, 315)
        Me.GroupBox3.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox3.Size = New System.Drawing.Size(409, 110)
        Me.GroupBox3.TabIndex = 8
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Network protocol settings"
        '
        'txtKaRep
        '
        Me.txtKaRep.Location = New System.Drawing.Point(327, 71)
        Me.txtKaRep.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtKaRep.Name = "txtKaRep"
        Me.txtKaRep.Size = New System.Drawing.Size(45, 21)
        Me.txtKaRep.TabIndex = 10
        Me.txtKaRep.Text = "1000"
        '
        'txtKA
        '
        Me.txtKA.Location = New System.Drawing.Point(165, 71)
        Me.txtKA.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtKA.Name = "txtKA"
        Me.txtKA.Size = New System.Drawing.Size(45, 21)
        Me.txtKA.TabIndex = 9
        Me.txtKA.Text = "7000"
        '
        'rbTelnet
        '
        Me.rbTelnet.AutoSize = True
        Me.rbTelnet.Enabled = False
        Me.rbTelnet.Location = New System.Drawing.Point(254, 25)
        Me.rbTelnet.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.rbTelnet.Name = "rbTelnet"
        Me.rbTelnet.Size = New System.Drawing.Size(148, 19)
        Me.rbTelnet.TabIndex = 8
        Me.rbTelnet.TabStop = True
        Me.rbTelnet.Text = "Use Telnet (RFC2217)"
        Me.rbTelnet.UseVisualStyleBackColor = True
        '
        'rbRaw
        '
        Me.rbRaw.AutoSize = True
        Me.rbRaw.Location = New System.Drawing.Point(15, 25)
        Me.rbRaw.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.rbRaw.Name = "rbRaw"
        Me.rbRaw.Size = New System.Drawing.Size(229, 19)
        Me.rbRaw.TabIndex = 7
        Me.rbRaw.TabStop = True
        Me.rbRaw.Text = "Use row data transmission algorithm"
        Me.rbRaw.UseVisualStyleBackColor = True
        '
        'Label12
        '
        Me.Label12.BackColor = System.Drawing.Color.Silver
        Me.Label12.Location = New System.Drawing.Point(15, 58)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(385, 1)
        Me.Label12.TabIndex = 6
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(372, 75)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(25, 15)
        Me.Label11.TabIndex = 5
        Me.Label11.Text = "ms"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(237, 75)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(90, 15)
        Me.Label10.TabIndex = 3
        Me.Label10.Text = "if no reply every"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(209, 74)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(28, 15)
        Me.Label9.TabIndex = 2
        Me.Label9.Text = "ms,"
        '
        'chkKa
        '
        Me.chkKa.AutoSize = True
        Me.chkKa.Location = New System.Drawing.Point(15, 72)
        Me.chkKa.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkKa.Name = "chkKa"
        Me.chkKa.Size = New System.Drawing.Size(151, 19)
        Me.chkKa.TabIndex = 0
        Me.chkKa.Text = "Send ""KeepAlive"" every"
        Me.chkKa.UseVisualStyleBackColor = True
        '
        'GroupBox8
        '
        Me.GroupBox8.Controls.Add(Me.chkShowChar2)
        Me.GroupBox8.Controls.Add(Me.txtConnPwd)
        Me.GroupBox8.Controls.Add(Me.Label34)
        Me.GroupBox8.Controls.Add(Me.chkConnPwd)
        Me.GroupBox8.Location = New System.Drawing.Point(6, 238)
        Me.GroupBox8.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox8.Name = "GroupBox8"
        Me.GroupBox8.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox8.Size = New System.Drawing.Size(409, 69)
        Me.GroupBox8.TabIndex = 7
        Me.GroupBox8.TabStop = False
        Me.GroupBox8.Text = "Connection password (TCP server mode only)"
        '
        'chkShowChar2
        '
        Me.chkShowChar2.AutoSize = True
        Me.chkShowChar2.Location = New System.Drawing.Point(291, 30)
        Me.chkShowChar2.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkShowChar2.Name = "chkShowChar2"
        Me.chkShowChar2.Size = New System.Drawing.Size(94, 19)
        Me.chkShowChar2.TabIndex = 3
        Me.chkShowChar2.Text = "Show Chars"
        Me.chkShowChar2.UseVisualStyleBackColor = True
        '
        'txtConnPwd
        '
        Me.txtConnPwd.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtConnPwd.Location = New System.Drawing.Point(156, 28)
        Me.txtConnPwd.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtConnPwd.MaxLength = 8
        Me.txtConnPwd.Name = "txtConnPwd"
        Me.txtConnPwd.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txtConnPwd.Size = New System.Drawing.Size(120, 21)
        Me.txtConnPwd.TabIndex = 2
        Me.txtConnPwd.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Location = New System.Drawing.Point(84, 31)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(66, 15)
        Me.Label34.TabIndex = 1
        Me.Label34.Text = "Password:"
        '
        'chkConnPwd
        '
        Me.chkConnPwd.AutoSize = True
        Me.chkConnPwd.Location = New System.Drawing.Point(15, 30)
        Me.chkConnPwd.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkConnPwd.Name = "chkConnPwd"
        Me.chkConnPwd.Size = New System.Drawing.Size(65, 19)
        Me.chkConnPwd.TabIndex = 0
        Me.chkConnPwd.Text = "Enable"
        Me.chkConnPwd.UseVisualStyleBackColor = True
        '
        'GroupBox7
        '
        Me.GroupBox7.Controls.Add(Me.chkShowChar1)
        Me.GroupBox7.Controls.Add(Me.txtSearchPwd)
        Me.GroupBox7.Controls.Add(Me.Label39)
        Me.GroupBox7.Controls.Add(Me.Label33)
        Me.GroupBox7.Location = New System.Drawing.Point(6, 164)
        Me.GroupBox7.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox7.Name = "GroupBox7"
        Me.GroupBox7.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox7.Size = New System.Drawing.Size(409, 66)
        Me.GroupBox7.TabIndex = 6
        Me.GroupBox7.TabStop = False
        Me.GroupBox7.Text = "Search identification code"
        '
        'chkShowChar1
        '
        Me.chkShowChar1.AutoSize = True
        Me.chkShowChar1.Location = New System.Drawing.Point(291, 29)
        Me.chkShowChar1.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkShowChar1.Name = "chkShowChar1"
        Me.chkShowChar1.Size = New System.Drawing.Size(94, 19)
        Me.chkShowChar1.TabIndex = 2
        Me.chkShowChar1.Text = "Show Chars"
        Me.chkShowChar1.UseVisualStyleBackColor = True
        '
        'txtSearchPwd
        '
        Me.txtSearchPwd.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSearchPwd.Location = New System.Drawing.Point(56, 26)
        Me.txtSearchPwd.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtSearchPwd.MaxLength = 8
        Me.txtSearchPwd.Name = "txtSearchPwd"
        Me.txtSearchPwd.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txtSearchPwd.Size = New System.Drawing.Size(126, 21)
        Me.txtSearchPwd.TabIndex = 1
        Me.txtSearchPwd.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.ForeColor = System.Drawing.Color.Red
        Me.Label39.Location = New System.Drawing.Point(188, 30)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(81, 15)
        Me.Label39.TabIndex = 6
        Me.Label39.Text = "(Max. 8 bytes)"
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Location = New System.Drawing.Point(13, 30)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(40, 15)
        Me.Label33.TabIndex = 0
        Me.Label33.Text = "Code:"
        '
        'GroupBox9
        '
        Me.GroupBox9.Controls.Add(Me.Label42)
        Me.GroupBox9.Controls.Add(Me.Label41)
        Me.GroupBox9.Controls.Add(Me.Label40)
        Me.GroupBox9.Controls.Add(Me.txtReconn)
        Me.GroupBox9.Controls.Add(Me.Label38)
        Me.GroupBox9.Controls.Add(Me.Label27)
        Me.GroupBox9.Controls.Add(Me.Label26)
        Me.GroupBox9.Controls.Add(Me.txtInactiveTimer)
        Me.GroupBox9.Controls.Add(Me.Label25)
        Me.GroupBox9.Location = New System.Drawing.Point(6, 8)
        Me.GroupBox9.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox9.Name = "GroupBox9"
        Me.GroupBox9.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox9.Size = New System.Drawing.Size(409, 148)
        Me.GroupBox9.TabIndex = 4
        Me.GroupBox9.TabStop = False
        Me.GroupBox9.Text = "Timer interval"
        '
        'Label42
        '
        Me.Label42.AutoSize = True
        Me.Label42.ForeColor = System.Drawing.Color.Red
        Me.Label42.Location = New System.Drawing.Point(260, 85)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(85, 15)
        Me.Label42.TabIndex = 9
        Me.Label42.Text = "(1~65535 ms)"
        '
        'Label41
        '
        Me.Label41.BackColor = System.Drawing.Color.Silver
        Me.Label41.Location = New System.Drawing.Point(28, 72)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(348, 1)
        Me.Label41.TabIndex = 8
        '
        'Label40
        '
        Me.Label40.ForeColor = System.Drawing.SystemColors.Highlight
        Me.Label40.Location = New System.Drawing.Point(31, 111)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(347, 30)
        Me.Label40.TabIndex = 7
        Me.Label40.Text = "*The connection retry interval (Client mode only)."
        '
        'txtReconn
        '
        Me.txtReconn.Location = New System.Drawing.Point(165, 81)
        Me.txtReconn.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtReconn.Name = "txtReconn"
        Me.txtReconn.Size = New System.Drawing.Size(90, 21)
        Me.txtReconn.TabIndex = 5
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.Location = New System.Drawing.Point(31, 85)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(128, 15)
        Me.Label38.TabIndex = 4
        Me.Label38.Text = "Reconnection interval:"
        '
        'Label27
        '
        Me.Label27.ForeColor = System.Drawing.SystemColors.Highlight
        Me.Label27.Location = New System.Drawing.Point(31, 48)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(347, 30)
        Me.Label27.TabIndex = 3
        Me.Label27.Text = "*The connection holding period when no data transmission."
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.ForeColor = System.Drawing.Color.Red
        Me.Label26.Location = New System.Drawing.Point(228, 21)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(116, 15)
        Me.Label26.TabIndex = 2
        Me.Label26.Text = "(0~65535 Seconds)"
        '
        'txtInactiveTimer
        '
        Me.txtInactiveTimer.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtInactiveTimer.Location = New System.Drawing.Point(132, 18)
        Me.txtInactiveTimer.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtInactiveTimer.Name = "txtInactiveTimer"
        Me.txtInactiveTimer.Size = New System.Drawing.Size(90, 21)
        Me.txtInactiveTimer.TabIndex = 1
        Me.txtInactiveTimer.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(31, 21)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(90, 15)
        Me.Label25.TabIndex = 0
        Me.Label25.Text = "Inactivity Timer:"
        '
        'tv
        '
        Me.tv.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tv.HideSelection = False
        Me.tv.Location = New System.Drawing.Point(4, 4)
        Me.tv.Margin = New System.Windows.Forms.Padding(1)
        Me.tv.Name = "tv"
        Me.tv.ShowNodeToolTips = True
        Me.tv.Size = New System.Drawing.Size(217, 486)
        Me.tv.TabIndex = 3
        '
        'GroupBox11
        '
        Me.GroupBox11.Controls.Add(Me.rtbLog)
        Me.GroupBox11.Dock = System.Windows.Forms.DockStyle.Fill
        Me.GroupBox11.Location = New System.Drawing.Point(0, 0)
        Me.GroupBox11.Margin = New System.Windows.Forms.Padding(1)
        Me.GroupBox11.Name = "GroupBox11"
        Me.GroupBox11.Padding = New System.Windows.Forms.Padding(3, 0, 3, 0)
        Me.GroupBox11.Size = New System.Drawing.Size(657, 2)
        Me.GroupBox11.TabIndex = 31
        Me.GroupBox11.TabStop = False
        Me.GroupBox11.Text = "Log message"
        '
        'rtbLog
        '
        Me.rtbLog.BackColor = System.Drawing.Color.White
        Me.rtbLog.Dock = System.Windows.Forms.DockStyle.Fill
        Me.rtbLog.Location = New System.Drawing.Point(3, 14)
        Me.rtbLog.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.rtbLog.Name = "rtbLog"
        Me.rtbLog.ReadOnly = True
        Me.rtbLog.Size = New System.Drawing.Size(651, 0)
        Me.rtbLog.TabIndex = 0
        Me.rtbLog.Text = ""
        '
        'ssMain
        '
        Me.ssMain.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.tLblState, Me.tpb, Me.tlblMsg})
        Me.ssMain.Location = New System.Drawing.Point(0, 533)
        Me.ssMain.Name = "ssMain"
        Me.ssMain.Size = New System.Drawing.Size(657, 26)
        Me.ssMain.TabIndex = 5
        Me.ssMain.Text = "StatusStrip1"
        '
        'tLblState
        '
        Me.tLblState.Image = CType(resources.GetObject("tLblState.Image"), System.Drawing.Image)
        Me.tLblState.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.tLblState.Name = "tLblState"
        Me.tLblState.Size = New System.Drawing.Size(178, 21)
        Me.tLblState.Text = "WIZnet Configuration Tool"
        '
        'tpb
        '
        Me.tpb.Name = "tpb"
        Me.tpb.Size = New System.Drawing.Size(150, 20)
        '
        'tlblMsg
        '
        Me.tlblMsg.Image = CType(resources.GetObject("tlblMsg.Image"), System.Drawing.Image)
        Me.tlblMsg.Margin = New System.Windows.Forms.Padding(5, 3, 0, 2)
        Me.tlblMsg.Name = "tlblMsg"
        Me.tlblMsg.Size = New System.Drawing.Size(135, 21)
        Me.tlblMsg.Text = "No device selected"
        '
        'ofd
        '
        Me.ofd.Filter = "Bin files|*.bin|All files|*.*"
        '
        'BottomToolStripPanel
        '
        Me.BottomToolStripPanel.Location = New System.Drawing.Point(0, 0)
        Me.BottomToolStripPanel.Name = "BottomToolStripPanel"
        Me.BottomToolStripPanel.Orientation = System.Windows.Forms.Orientation.Horizontal
        Me.BottomToolStripPanel.RowMargin = New System.Windows.Forms.Padding(3, 0, 0, 0)
        Me.BottomToolStripPanel.Size = New System.Drawing.Size(0, 0)
        '
        'TopToolStripPanel
        '
        Me.TopToolStripPanel.Location = New System.Drawing.Point(0, 0)
        Me.TopToolStripPanel.Name = "TopToolStripPanel"
        Me.TopToolStripPanel.Orientation = System.Windows.Forms.Orientation.Horizontal
        Me.TopToolStripPanel.RowMargin = New System.Windows.Forms.Padding(3, 0, 0, 0)
        Me.TopToolStripPanel.Size = New System.Drawing.Size(0, 0)
        '
        'RightToolStripPanel
        '
        Me.RightToolStripPanel.Location = New System.Drawing.Point(0, 0)
        Me.RightToolStripPanel.Name = "RightToolStripPanel"
        Me.RightToolStripPanel.Orientation = System.Windows.Forms.Orientation.Horizontal
        Me.RightToolStripPanel.RowMargin = New System.Windows.Forms.Padding(3, 0, 0, 0)
        Me.RightToolStripPanel.Size = New System.Drawing.Size(0, 0)
        '
        'LeftToolStripPanel
        '
        Me.LeftToolStripPanel.Location = New System.Drawing.Point(0, 0)
        Me.LeftToolStripPanel.Name = "LeftToolStripPanel"
        Me.LeftToolStripPanel.Orientation = System.Windows.Forms.Orientation.Horizontal
        Me.LeftToolStripPanel.RowMargin = New System.Windows.Forms.Padding(3, 0, 0, 0)
        Me.LeftToolStripPanel.Size = New System.Drawing.Size(0, 0)
        '
        'ContentPanel
        '
        Me.ContentPanel.Size = New System.Drawing.Size(657, 475)
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(657, 559)
        Me.Controls.Add(Me.ssMain)
        Me.Controls.Add(Me.tsMain)
        Me.Controls.Add(Me.SplitContainer1)
        Me.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.MaximizeBox = False
        Me.Name = "frmMain"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "frmMain"
        Me.tsMain.ResumeLayout(False)
        Me.tsMain.PerformLayout()
        Me.SplitContainer1.Panel1.ResumeLayout(False)
        Me.SplitContainer1.Panel2.ResumeLayout(False)
        Me.SplitContainer1.ResumeLayout(False)
        Me.tc.ResumeLayout(False)
        Me.tpNet.ResumeLayout(False)
        Me.GroupBox10.ResumeLayout(False)
        Me.GroupBox10.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.tpCOM.ResumeLayout(False)
        Me.tpCOM.PerformLayout()
        Me.GroupBox6.ResumeLayout(False)
        Me.GroupBox6.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        Me.tpOption.ResumeLayout(False)
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox8.ResumeLayout(False)
        Me.GroupBox8.PerformLayout()
        Me.GroupBox7.ResumeLayout(False)
        Me.GroupBox7.PerformLayout()
        Me.GroupBox9.ResumeLayout(False)
        Me.GroupBox9.PerformLayout()
        Me.GroupBox11.ResumeLayout(False)
        Me.ssMain.ResumeLayout(False)
        Me.ssMain.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents tsMain As System.Windows.Forms.ToolStrip
    Friend WithEvents tsbSrchAll As System.Windows.Forms.ToolStripButton
    Friend WithEvents tsbSet As System.Windows.Forms.ToolStripButton
    Friend WithEvents tsbUpload As System.Windows.Forms.ToolStripButton
    Friend WithEvents tsbPing As System.Windows.Forms.ToolStripButton
    Friend WithEvents tsbFirewall As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents tsbExit As System.Windows.Forms.ToolStripButton
    Friend WithEvents imgLst As System.Windows.Forms.ImageList
    Friend WithEvents tmrPb As System.Windows.Forms.Timer
    Friend WithEvents SplitContainer1 As System.Windows.Forms.SplitContainer
    Friend WithEvents tc As System.Windows.Forms.TabControl
    Friend WithEvents tpNet As System.Windows.Forms.TabPage
    Friend WithEvents GroupBox10 As System.Windows.Forms.GroupBox
    Friend WithEvents chkDD As System.Windows.Forms.CheckBox
    Friend WithEvents txtDPort As System.Windows.Forms.TextBox
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents cboDdns As System.Windows.Forms.ComboBox
    Friend WithEvents txtDHost As System.Windows.Forms.TextBox
    Friend WithEvents txtDPwd As System.Windows.Forms.TextBox
    Friend WithEvents txtDID As System.Windows.Forms.TextBox
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents txtRp As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents txtRIP As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents rbUdp As System.Windows.Forms.RadioButton
    Friend WithEvents rbMixed As System.Windows.Forms.RadioButton
    Friend WithEvents rbServer As System.Windows.Forms.RadioButton
    Friend WithEvents rbClient As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents chkShowChar3 As System.Windows.Forms.CheckBox
    Friend WithEvents txtLP As System.Windows.Forms.TextBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents txtPPwd As System.Windows.Forms.TextBox
    Friend WithEvents txtPId As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents txtDNS As System.Windows.Forms.TextBox
    Friend WithEvents txtGw As System.Windows.Forms.TextBox
    Friend WithEvents txtSubnet As System.Windows.Forms.TextBox
    Friend WithEvents txtLIP As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents rbStatic As System.Windows.Forms.RadioButton
    Friend WithEvents rbPPP As System.Windows.Forms.RadioButton
    Friend WithEvents rbDHCP As System.Windows.Forms.RadioButton
    Friend WithEvents tpCOM As System.Windows.Forms.TabPage
    Friend WithEvents GroupBox6 As System.Windows.Forms.GroupBox
    Friend WithEvents txtTrigger3 As System.Windows.Forms.TextBox
    Friend WithEvents txtTrigger2 As System.Windows.Forms.TextBox
    Friend WithEvents txtTrigger1 As System.Windows.Forms.TextBox
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents chkTrigger As System.Windows.Forms.CheckBox
    Friend WithEvents chkDebug As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents txtChar As System.Windows.Forms.TextBox
    Friend WithEvents txtSize As System.Windows.Forms.TextBox
    Friend WithEvents txtTimer As System.Windows.Forms.TextBox
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents cboFlow As System.Windows.Forms.ComboBox
    Friend WithEvents cboStopBit As System.Windows.Forms.ComboBox
    Friend WithEvents cboParity As System.Windows.Forms.ComboBox
    Friend WithEvents cboDataBit As System.Windows.Forms.ComboBox
    Friend WithEvents cboBaud As System.Windows.Forms.ComboBox
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents tpOption As System.Windows.Forms.TabPage
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents rbTelnet As System.Windows.Forms.RadioButton
    Friend WithEvents rbRaw As System.Windows.Forms.RadioButton
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents chkKa As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox8 As System.Windows.Forms.GroupBox
    Friend WithEvents chkShowChar2 As System.Windows.Forms.CheckBox
    Friend WithEvents txtConnPwd As System.Windows.Forms.TextBox
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents chkConnPwd As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox7 As System.Windows.Forms.GroupBox
    Friend WithEvents chkShowChar1 As System.Windows.Forms.CheckBox
    Friend WithEvents txtSearchPwd As System.Windows.Forms.TextBox
    Friend WithEvents Label39 As System.Windows.Forms.Label
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents GroupBox9 As System.Windows.Forms.GroupBox
    Friend WithEvents Label41 As System.Windows.Forms.Label
    Friend WithEvents Label40 As System.Windows.Forms.Label
    Friend WithEvents txtReconn As System.Windows.Forms.TextBox
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents txtInactiveTimer As System.Windows.Forms.TextBox
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents tv As System.Windows.Forms.TreeView
    Friend WithEvents lblSplitUp As System.Windows.Forms.Label
    Friend WithEvents GroupBox11 As System.Windows.Forms.GroupBox
    Friend WithEvents rtbLog As System.Windows.Forms.RichTextBox
    Friend WithEvents ssMain As System.Windows.Forms.StatusStrip
    Friend WithEvents tLblState As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents tpb As System.Windows.Forms.ToolStripProgressBar
    Friend WithEvents tsbReset As System.Windows.Forms.ToolStripButton
    Friend WithEvents tsbFactory As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator4 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents tlblMsg As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ofd As System.Windows.Forms.OpenFileDialog
    Friend WithEvents txtKaRep As System.Windows.Forms.TextBox
    Friend WithEvents txtKA As System.Windows.Forms.TextBox
    Friend WithEvents BottomToolStripPanel As System.Windows.Forms.ToolStripPanel
    Friend WithEvents TopToolStripPanel As System.Windows.Forms.ToolStripPanel
    Friend WithEvents RightToolStripPanel As System.Windows.Forms.ToolStripPanel
    Friend WithEvents LeftToolStripPanel As System.Windows.Forms.ToolStripPanel
    Friend WithEvents ContentPanel As System.Windows.Forms.ToolStripContentPanel
    Friend WithEvents Label42 As System.Windows.Forms.Label

End Class
