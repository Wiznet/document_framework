﻿Public Class frmPwd
    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        frmMain.isSchOk = False
        Me.Close()

    End Sub

    Private Sub btnConfirm_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnConfirm.Click

        Dim pwd As String = txtSchPwd.Text.Trim
        If pwd.Length > 0 Then
            frmMain.SchPwd = pwd
        Else
            frmMain.SchPwd = " "
        End If
        
        If chkSavePwd.Checked Then My.Settings.schPwd = pwd.Trim


        If rbB.Checked Then
            frmMain.isSchOk = True
            frmMain.isBroadcast = True
            Me.Close()
        ElseIf rbU.Checked Then
            If txtIP.Text.Trim.Length > 0 Then
                frmMain.isSchOk = True
                frmMain.directIP = txtIP.Text.Trim
                If txtDirectPort.Text.Trim.Length = 0 Then
                    frmMain.directPort = 50001
                Else
                    frmMain.directPort = CType(txtDirectPort.Text.Trim, Integer)

                End If
                
                My.Settings.schIp = txtIP.Text.Trim
                frmMain.isBroadcast = False
                Me.Close()

            Else
                MessageBox.Show("Please input the IP address or domain name of target device.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                txtIP.Focus()
            End If
        End If

    End Sub

    Private Sub chkShowChar_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkShowChar.CheckedChanged
        If chkShowChar.Checked Then
            txtSchPwd.PasswordChar = ""
        Else
            txtSchPwd.PasswordChar = "*"
        End If
    End Sub

    Private Sub frmSchPwd_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'If My.Settings.schPwd.Length > 0 Then
        txtSchPwd.Text = My.Settings.schPwd
        'End If
        chkShowChar.Checked = True
        txtSchPwd.Focus()

        'test
        txtIP.Text = My.Settings.schIp


    End Sub

    Private Sub lLblDelPwd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles lLblDelPwd.Click
        My.Settings.schPwd = ""
    End Sub

    Private Sub rbB_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rbB.CheckedChanged, rbU.CheckedChanged
        Dim obj As RadioButton = CType(sender, RadioButton)
        If obj.Checked Then
            Select Case obj.Name
                Case "rbB"
                    pnB.Visible = True
                    pnU.Visible = False

                Case "rbU"
                    pnB.Visible = False
                    pnU.Visible = True
                    txtIP.Focus()

            End Select
        End If
    End Sub
End Class