﻿Public Class frmPing

    Private Sub btnPing_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPing.Click
        rtbPing.Clear()
        btnClose.Enabled = False
        btnPing.Enabled = False

        Dim objPingHost As New clsPing
        Dim lngPingReply As Long = 0
        If txtIP.Text.Trim.Length > 0 Then
            objPingHost.TimeOut = 5000               ' 5000 msec  Time Out
            objPingHost.DataSize = 32                '32 bytes Package Size
            objPingHost.Host = Trim(txtIP.Text) 'Host to Ping

            rtbPing.Text = "Trying to ping " & txtIP.Text.Trim & " ..."
            lngPingReply = objPingHost.Ping
            If lngPingReply = clsPing.PING_ERROR Then
                rtbPing.Text += vbCrLf & "Error: " & objPingHost.GetLastError.Description
            Else
                rtbPing.Text += vbCrLf & "Ping Reply " & lngPingReply & " msec."
            End If
        End If
        btnClose.Enabled = True
        btnPing.Enabled = True


    End Sub

    Private Sub frmPing_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        txtIP.Focus()

    End Sub

    Private Sub txtIP_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtIP.Click
        If txtIP.Text.Length > 0 Then
            txtIP.SelectAll()

        End If
    End Sub

    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        Me.Close()

    End Sub
End Class