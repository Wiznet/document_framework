﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmPwd
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmPwd))
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.lLblDelPwd = New System.Windows.Forms.LinkLabel
        Me.chkSavePwd = New System.Windows.Forms.CheckBox
        Me.chkShowChar = New System.Windows.Forms.CheckBox
        Me.txtSchPwd = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.btnExit = New System.Windows.Forms.Button
        Me.btnConfirm = New System.Windows.Forms.Button
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.rbU = New System.Windows.Forms.RadioButton
        Me.rbB = New System.Windows.Forms.RadioButton
        Me.pnB = New System.Windows.Forms.Panel
        Me.Label3 = New System.Windows.Forms.Label
        Me.pnU = New System.Windows.Forms.Panel
        Me.Label4 = New System.Windows.Forms.Label
        Me.txtIP = New System.Windows.Forms.TextBox
        Me.txtDirectPort = New System.Windows.Forms.TextBox
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.pnB.SuspendLayout()
        Me.pnU.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.lLblDelPwd)
        Me.GroupBox1.Controls.Add(Me.chkSavePwd)
        Me.GroupBox1.Controls.Add(Me.chkShowChar)
        Me.GroupBox1.Controls.Add(Me.txtSchPwd)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Location = New System.Drawing.Point(5, 10)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(1)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(0)
        Me.GroupBox1.Size = New System.Drawing.Size(299, 84)
        Me.GroupBox1.TabIndex = 1
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Input device search identification code"
        '
        'lLblDelPwd
        '
        Me.lLblDelPwd.AutoSize = True
        Me.lLblDelPwd.Location = New System.Drawing.Point(122, 55)
        Me.lLblDelPwd.Name = "lLblDelPwd"
        Me.lLblDelPwd.Size = New System.Drawing.Size(43, 15)
        Me.lLblDelPwd.TabIndex = 5
        Me.lLblDelPwd.TabStop = True
        Me.lLblDelPwd.Text = "Delete"
        '
        'chkSavePwd
        '
        Me.chkSavePwd.AutoSize = True
        Me.chkSavePwd.Location = New System.Drawing.Point(11, 54)
        Me.chkSavePwd.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkSavePwd.Name = "chkSavePwd"
        Me.chkSavePwd.Size = New System.Drawing.Size(110, 19)
        Me.chkSavePwd.TabIndex = 3
        Me.chkSavePwd.Text = "&Remember me"
        Me.chkSavePwd.UseVisualStyleBackColor = True
        '
        'chkShowChar
        '
        Me.chkShowChar.AutoSize = True
        Me.chkShowChar.Location = New System.Drawing.Point(173, 54)
        Me.chkShowChar.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkShowChar.Name = "chkShowChar"
        Me.chkShowChar.Size = New System.Drawing.Size(111, 19)
        Me.chkShowChar.TabIndex = 2
        Me.chkShowChar.Text = "Sho&w character"
        Me.chkShowChar.UseVisualStyleBackColor = True
        '
        'txtSchPwd
        '
        Me.txtSchPwd.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSchPwd.Location = New System.Drawing.Point(83, 25)
        Me.txtSchPwd.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtSchPwd.MaxLength = 8
        Me.txtSchPwd.Name = "txtSchPwd"
        Me.txtSchPwd.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txtSchPwd.Size = New System.Drawing.Size(206, 21)
        Me.txtSchPwd.TabIndex = 1
        Me.txtSchPwd.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(6, 25)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(67, 15)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Input &code:"
        '
        'btnExit
        '
        Me.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnExit.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExit.Image = CType(resources.GetObject("btnExit.Image"), System.Drawing.Image)
        Me.btnExit.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnExit.Location = New System.Drawing.Point(184, 193)
        Me.btnExit.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(76, 31)
        Me.btnExit.TabIndex = 9
        Me.btnExit.Text = "Clos&e"
        Me.btnExit.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'btnConfirm
        '
        Me.btnConfirm.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnConfirm.Image = CType(resources.GetObject("btnConfirm.Image"), System.Drawing.Image)
        Me.btnConfirm.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnConfirm.Location = New System.Drawing.Point(46, 192)
        Me.btnConfirm.Margin = New System.Windows.Forms.Padding(1)
        Me.btnConfirm.Name = "btnConfirm"
        Me.btnConfirm.Size = New System.Drawing.Size(81, 31)
        Me.btnConfirm.TabIndex = 8
        Me.btnConfirm.Text = "&Search"
        Me.btnConfirm.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnConfirm.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnConfirm.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.rbU)
        Me.GroupBox2.Controls.Add(Me.rbB)
        Me.GroupBox2.Controls.Add(Me.pnB)
        Me.GroupBox2.Controls.Add(Me.pnU)
        Me.GroupBox2.Location = New System.Drawing.Point(5, 103)
        Me.GroupBox2.Margin = New System.Windows.Forms.Padding(1)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Padding = New System.Windows.Forms.Padding(0)
        Me.GroupBox2.Size = New System.Drawing.Size(299, 85)
        Me.GroupBox2.TabIndex = 10
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Search method"
        '
        'rbU
        '
        Me.rbU.AutoSize = True
        Me.rbU.Location = New System.Drawing.Point(173, 21)
        Me.rbU.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.rbU.Name = "rbU"
        Me.rbU.Size = New System.Drawing.Size(92, 19)
        Me.rbU.TabIndex = 1
        Me.rbU.Text = "&TCP unicast"
        Me.rbU.UseVisualStyleBackColor = True
        '
        'rbB
        '
        Me.rbB.AutoSize = True
        Me.rbB.Checked = True
        Me.rbB.Location = New System.Drawing.Point(26, 21)
        Me.rbB.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.rbB.Name = "rbB"
        Me.rbB.Size = New System.Drawing.Size(109, 19)
        Me.rbB.TabIndex = 0
        Me.rbB.TabStop = True
        Me.rbB.Text = "&UDP broadcast"
        Me.rbB.UseVisualStyleBackColor = True
        '
        'pnB
        '
        Me.pnB.Controls.Add(Me.Label3)
        Me.pnB.Location = New System.Drawing.Point(13, 39)
        Me.pnB.Margin = New System.Windows.Forms.Padding(1)
        Me.pnB.Name = "pnB"
        Me.pnB.Size = New System.Drawing.Size(278, 41)
        Me.pnB.TabIndex = 2
        '
        'Label3
        '
        Me.Label3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label3.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.RoyalBlue
        Me.Label3.Location = New System.Drawing.Point(0, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(278, 41)
        Me.Label3.TabIndex = 0
        Me.Label3.Text = "Broadcast will find the all devices with the same identification code in the same" & _
            " subnet."
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'pnU
        '
        Me.pnU.Controls.Add(Me.txtDirectPort)
        Me.pnU.Controls.Add(Me.Label4)
        Me.pnU.Controls.Add(Me.txtIP)
        Me.pnU.Location = New System.Drawing.Point(13, 39)
        Me.pnU.Margin = New System.Windows.Forms.Padding(1)
        Me.pnU.Name = "pnU"
        Me.pnU.Size = New System.Drawing.Size(278, 41)
        Me.pnU.TabIndex = 3
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(3, 9)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(113, 15)
        Me.Label4.TabIndex = 1
        Me.Label4.Text = "&Host name/IP addr:"
        '
        'txtIP
        '
        Me.txtIP.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtIP.Location = New System.Drawing.Point(118, 7)
        Me.txtIP.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtIP.Name = "txtIP"
        Me.txtIP.Size = New System.Drawing.Size(103, 21)
        Me.txtIP.TabIndex = 0
        '
        'txtDirectPort
        '
        Me.txtDirectPort.Location = New System.Drawing.Point(227, 7)
        Me.txtDirectPort.Name = "txtDirectPort"
        Me.txtDirectPort.Size = New System.Drawing.Size(48, 21)
        Me.txtDirectPort.TabIndex = 2
        '
        'frmPwd
        '
        Me.AcceptButton = Me.btnConfirm
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.btnExit
        Me.ClientSize = New System.Drawing.Size(308, 231)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnConfirm)
        Me.Controls.Add(Me.GroupBox1)
        Me.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Name = "frmPwd"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Search"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.pnB.ResumeLayout(False)
        Me.pnU.ResumeLayout(False)
        Me.pnU.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents lLblDelPwd As System.Windows.Forms.LinkLabel
    Friend WithEvents chkSavePwd As System.Windows.Forms.CheckBox
    Friend WithEvents chkShowChar As System.Windows.Forms.CheckBox
    Friend WithEvents txtSchPwd As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents btnExit As System.Windows.Forms.Button
    Friend WithEvents btnConfirm As System.Windows.Forms.Button
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents pnB As System.Windows.Forms.Panel
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents rbU As System.Windows.Forms.RadioButton
    Friend WithEvents rbB As System.Windows.Forms.RadioButton
    Friend WithEvents pnU As System.Windows.Forms.Panel
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtIP As System.Windows.Forms.TextBox
    Friend WithEvents txtDirectPort As System.Windows.Forms.TextBox
End Class
