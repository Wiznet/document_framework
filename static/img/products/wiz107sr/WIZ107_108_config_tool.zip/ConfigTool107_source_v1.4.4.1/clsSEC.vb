﻿Public Class clsNetOption
    Dim _IpMode As Byte = 0
    Dim _Mode As Byte = 0
    Dim _Rd As Byte = 0
    Dim _Dd As Byte = 0
    Dim _Cp As Byte = 0
    Dim _Po As Byte = 0
    Property IpMode() As Byte
        Get
            Return _IpMode
        End Get
        Set(ByVal value As Byte)
            _IpMode = value
        End Set
    End Property
    Property ActMode() As Byte
        Get
            Return _Mode
        End Get
        Set(ByVal value As Byte)
            _Mode = value
        End Set
    End Property
    Property isRemoteHostDomain() As Byte
        Get
            Return _Rd
        End Get
        Set(ByVal value As Byte)
            _Rd = value
        End Set
    End Property
    Property isDdns() As Byte
        Get
            Return _Dd
        End Get
        Set(ByVal value As Byte)
            _Dd = value
        End Set
    End Property
    Property isConnPwd() As Byte
        Get
            Return _Cp
        End Get
        Set(ByVal value As Byte)
            _Cp = value
        End Set
    End Property
    Property isTelnet() As Byte
        Get
            Return _Po
        End Get
        Set(ByVal value As Byte)
            _Po = value
        End Set
    End Property
    Public Function calcNetworkOption() As Byte
        Dim ret As Byte
        ret = (_IpMode And &H3) Or ((_Mode And &H3) << 2) Or ((_Rd And &H1) << 4) Or ((_Dd And &H1) << 5) Or ((_Cp And &H1) << 6) Or ((_Po And &H1) << 7)
        Return ret
    End Function
End Class
Public Class clsCOM
    Dim _baudIdx As Byte = 0 'low 4 bits
    Dim _datBitIdx As Byte = 0 ' 2 bits
    Dim _parityIdx As Byte = 0 ' 2 bits
    Dim _stopBitIdx As Byte = 0 '2 bits
    Dim _flowIdx As Byte = 0 ' 2 bits
    Property BaudIndex() As Byte
        Get
            Return _baudIdx
        End Get
        Set(ByVal value As Byte)
            _baudIdx = value
        End Set
    End Property
    Property DataBitIndex() As Byte
        Get
            Return _datBitIdx
        End Get
        Set(ByVal value As Byte)
            _datBitIdx = value
        End Set
    End Property
    Property ParityIndex() As Byte
        Get
            Return _parityIdx
        End Get
        Set(ByVal value As Byte)
            _parityIdx = value
        End Set
    End Property
    Property StopBitIndex() As Byte
        Get
            Return _stopBitIdx
        End Get
        Set(ByVal value As Byte)
            _stopBitIdx = value
        End Set
    End Property
    Property FlowIndex() As Byte
        Get
            Return _flowIdx
        End Get
        Set(ByVal value As Byte)
            _flowIdx = value
        End Set
    End Property
    Public Function CalcComBytes() As Byte()
        Dim ret(1) As Byte
        ret(0) = (_baudIdx And &HF) Or ((_datBitIdx And &H3) << 4) Or ((_parityIdx And &H3) << 6)
        ret(1) = (_stopBitIdx And &H3) Or ((_flowIdx And &H3) << 2)
        Return ret
    End Function
End Class

Public Class clsConnector
    Dim _lPort As Int16 = 0
    Dim _rPort As Int16 = 0
    Dim _rHost(31) As Byte
    Dim _com As clsCOM
    Dim _iTmr As Int16 = 0
    Dim _pTmr As Int16 = 0
    Dim _pSize As Byte = 0
    Dim _pIdt As Byte = 0
    Dim _cStr(2) As Byte ' 3 bytes
    Dim _rsvd As Byte = 0 ' reserved
    Dim _cPwd(7) As Byte ' 8 bytes
    Property LocalPort() As Int16
        Get
            Return _lPort
        End Get
        Set(ByVal value As Int16)
            _lPort = value
        End Set
    End Property
    Property RemotePort() As Int16
        Get
            Return _rPort
        End Get
        Set(ByVal value As Int16)
            _rPort = value
        End Set
    End Property
    Property ComSettings() As clsCOM
        Get
            Return _com
        End Get
        Set(ByVal value As clsCOM)
            _com = value
        End Set
    End Property
    Property InactTimer() As Int16
        Get
            Return _iTmr

        End Get
        Set(ByVal value As Int16)
            _iTmr = value
        End Set
    End Property
    Property PackTimer() As Int16
        Get
            Return _pTmr
        End Get
        Set(ByVal value As Int16)
            _pTmr = value
        End Set
    End Property
    Property PackSize() As Byte
        Get
            Return _pSize
        End Get
        Set(ByVal value As Byte)
            _pSize = value
        End Set
    End Property
    Property PackIndicator() As Byte
        Get
            Return _pIdt
        End Get
        Set(ByVal value As Byte)
            _pIdt = value
        End Set
    End Property
    Property sConfigStr() As Byte()
        Get
            Return _cStr
        End Get
        Set(ByVal value As Byte())
            _cStr = value
        End Set
    End Property
    Property ConnPwd() As Byte()
        Get
            Return _cPwd

        End Get
        Set(ByVal value As Byte())
            _cPwd = value
        End Set
    End Property

End Class

Public Class COMMAND
    Dim _name As String = ""
    Dim _data As String = ""
    Property name() As String
        Get
            Return _name
        End Get
        Set(ByVal value As String)
            _name = value
        End Set
    End Property
    Property data() As String
        Get
            Return _data
        End Get
        Set(ByVal value As String)
            _data = value
        End Set
    End Property
End Class
Public Class clsSEC
    Dim COMMANDS() As String = {"MC", "VR", "MN", "UN", "ST", "IM", "OP", "DD", "CP", "PO", "DG", "KA", "KI", "KE", "RI", "LI", "SM", "GW", "DS", "PI", "PP", "DX", "DP", "DI", "DW", "DH", "LP", "RP", "RH", "BR", "DB", "PR", "SB", "FL", "IT", "PT", "PS", "PD", "TE", "SS", "NP", "SP"}
    Public Function SearchMsg() As String
        Dim ret As String = ""
        For i As Integer = 0 To COMMANDS.Length - 1
            ret += COMMANDS(i) & vbCrLf
        Next
        Return ret
    End Function
    Public Function SeachMsgBytes(ByVal pwd As String) As Byte()
        Dim i As Int16 = 0
        Dim msg As String = ""
        For i = 0 To COMMANDS.Length - 1
            msg += COMMANDS(i) & vbCrLf
        Next
        If pwd.Length = 0 Then pwd = " "

        msg = "PW" & pwd & vbCrLf & msg
        Dim bMsg() As Byte = System.Text.Encoding.ASCII.GetBytes(msg)
        Dim ret(10 + bMsg.Length - 1) As Byte
        Dim tmp() As Byte = frmMain.prefix_MA("FF:FF:FF:FF:FF:FF")

        Array.ConstrainedCopy(tmp, 0, ret, 0, 10)
        Array.ConstrainedCopy(bMsg, 0, ret, 10, bMsg.Length)
        Return ret
    End Function
    Public Function UploadMsg(ByVal mac As String, ByVal pwd As String, ByVal len As Integer) As Byte()
        Dim msg As String = ""
        msg = "PW" & pwd & vbCrLf & "FW" & len.ToString & vbCrLf
        Dim bMsg() As Byte = System.Text.Encoding.ASCII.GetBytes(msg)
        Dim ret(10 + bMsg.Length - 1) As Byte
        Dim tmp() As Byte = frmMain.prefix_MA(mac)
        Array.ConstrainedCopy(tmp, 0, ret, 0, 10)
        Array.ConstrainedCopy(bMsg, 0, ret, 10, bMsg.Length)
        Return ret
    End Function
    '
    Dim _MA As New COMMAND
    '
    Dim _MC As New COMMAND
    Dim _VR As New COMMAND
    Dim _ST As New COMMAND

    Dim _MN As New COMMAND
    Dim _IM As New COMMAND
    Dim _OP As New COMMAND
    Dim _DD As New COMMAND
    Dim _CP As New COMMAND
    Dim _PO As New COMMAND
    Dim _DG As New COMMAND
    Dim _KA As New COMMAND
    Dim _KI As New COMMAND
    Dim _KE As New COMMAND
    Dim _RI As New COMMAND
    Dim _LI As New COMMAND
    Dim _SM As New COMMAND
    Dim _GW As New COMMAND
    Dim _DS As New COMMAND
    Dim _PI As New COMMAND
    Dim _PP As New COMMAND
    Dim _DX As New COMMAND 'ddns server index
    Dim _DP As New COMMAND
    Dim _DI As New COMMAND
    Dim _DW As New COMMAND
    Dim _DH As New COMMAND
    Dim _LP As New COMMAND
    Dim _RP As New COMMAND
    Dim _RH As New COMMAND
    Dim _BR As New COMMAND
    Dim _DB As New COMMAND
    Dim _PR As New COMMAND
    Dim _SB As New COMMAND
    Dim _FL As New COMMAND
    Dim _IT As New COMMAND
    Dim _PT As New COMMAND
    Dim _PS As New COMMAND
    Dim _PD As New COMMAND
    Dim _TE As New COMMAND 'software trigger enable/disable
    Dim _SS As New COMMAND
    Dim _NP As New COMMAND
    Dim _SP As New COMMAND
    Dim _LG As New COMMAND
    Dim _ER As New COMMAND

    'firmware upload
    Dim _FW As New COMMAND
    'UART count
    Dim _UN As New COMMAND

    'search password
    'Dim _PW As COMMAND

    Property MC() As COMMAND
        Get
            Return _MC
        End Get
        Set(ByVal value As COMMAND)
            _MC = value
        End Set
    End Property
    Property VR() As COMMAND
        Get
            Return _VR
        End Get
        Set(ByVal value As COMMAND)
            _VR = value
        End Set
    End Property
    Property MN() As COMMAND
        Get
            Return _MN
        End Get
        Set(ByVal value As COMMAND)
            _MN = value
        End Set
    End Property
    Property ST() As COMMAND
        Get
            Return _ST
        End Get
        Set(ByVal value As COMMAND)
            _ST = value
        End Set
    End Property
    Property IM() As COMMAND
        Get
            Return _IM
        End Get
        Set(ByVal value As COMMAND)
            _IM = value
        End Set
    End Property
    Property OP() As COMMAND
        Get
            Return _OP
        End Get
        Set(ByVal value As COMMAND)
            _OP = value
        End Set
    End Property
    Property DD() As COMMAND
        Get
            Return _DD
        End Get
        Set(ByVal value As COMMAND)
            _DD = value
        End Set
    End Property
    Property CP() As COMMAND
        Get
            Return _CP
        End Get
        Set(ByVal value As COMMAND)
            _CP = value
        End Set
    End Property
    Property PO() As COMMAND
        Get
            Return _PO
        End Get
        Set(ByVal value As COMMAND)
            _PO = value
        End Set
    End Property
    Property DG() As COMMAND
        Get
            Return _DG
        End Get
        Set(ByVal value As COMMAND)
            _DG = value
        End Set
    End Property
    Property KA() As COMMAND
        Get
            Return _KA
        End Get
        Set(ByVal value As COMMAND)
            _KA = value
        End Set
    End Property
    Property KI() As COMMAND
        Get
            Return _KI
        End Get
        Set(ByVal value As COMMAND)
            _KI = value
        End Set
    End Property
    Property KE() As COMMAND
        Get
            Return _KE
        End Get
        Set(ByVal value As COMMAND)
            _KE = value
        End Set
    End Property
    Property RI() As COMMAND
        Get
            Return _RI
        End Get
        Set(ByVal value As COMMAND)
            _RI = value
        End Set
    End Property
    Property LI() As COMMAND
        Get
            Return _LI
        End Get
        Set(ByVal value As COMMAND)
            _LI = value
        End Set
    End Property
    Property SM() As COMMAND
        Get
            Return _SM
        End Get
        Set(ByVal value As COMMAND)
            _SM = value
        End Set
    End Property
    Property GW() As COMMAND
        Get
            Return _GW
        End Get
        Set(ByVal value As COMMAND)
            _GW = value
        End Set
    End Property
    Property DS() As COMMAND
        Get
            Return _DS
        End Get
        Set(ByVal value As COMMAND)
            _DS = value
        End Set
    End Property
    Property PI() As COMMAND
        Get
            Return _PI
        End Get
        Set(ByVal value As COMMAND)
            _PI = value
        End Set
    End Property
    Property PP() As COMMAND
        Get
            Return _PP
        End Get
        Set(ByVal value As COMMAND)
            _PP = value
        End Set
    End Property
    Property DX() As COMMAND
        Get
            Return _DX
        End Get
        Set(ByVal value As COMMAND)
            _DX = value
        End Set
    End Property
    Property DP() As COMMAND
        Get
            Return _DP
        End Get
        Set(ByVal value As COMMAND)
            _DP = value
        End Set
    End Property
    Property DI() As COMMAND
        Get
            Return _DI
        End Get
        Set(ByVal value As COMMAND)
            _DI = value
        End Set
    End Property
    Property DW() As COMMAND
        Get
            Return _DW
        End Get
        Set(ByVal value As COMMAND)
            _DW = value
        End Set
    End Property
    Property DH() As COMMAND
        Get
            Return _DH
        End Get
        Set(ByVal value As COMMAND)
            _DH = value
        End Set
    End Property
    Property LP() As COMMAND
        Get
            Return _LP
        End Get
        Set(ByVal value As COMMAND)
            _LP = value
        End Set
    End Property
    Property RP() As COMMAND
        Get
            Return _RP
        End Get
        Set(ByVal value As COMMAND)
            _RP = value
        End Set
    End Property
    Property RH() As COMMAND
        Get
            Return _RH
        End Get
        Set(ByVal value As COMMAND)
            _RH = value
        End Set
    End Property
    Property BR() As COMMAND
        Get
            Return _BR
        End Get
        Set(ByVal value As COMMAND)
            _BR = value
        End Set
    End Property
    Property DB() As COMMAND
        Get
            Return _DB
        End Get
        Set(ByVal value As COMMAND)
            _DB = value
        End Set
    End Property
    Property PR() As COMMAND
        Get
            Return _PR
        End Get
        Set(ByVal value As COMMAND)
            _PR = value
        End Set
    End Property
    Property SB() As COMMAND
        Get
            Return _SB
        End Get
        Set(ByVal value As COMMAND)
            _SB = value
        End Set
    End Property
    Property FL() As COMMAND
        Get
            Return _FL
        End Get
        Set(ByVal value As COMMAND)
            _FL = value
        End Set
    End Property
    Property IT() As COMMAND
        Get
            Return _IT
        End Get
        Set(ByVal value As COMMAND)
            _IT = value
        End Set
    End Property
    Property PT() As COMMAND
        Get
            Return _PT
        End Get
        Set(ByVal value As COMMAND)
            _PT = value
        End Set
    End Property
    Property PS() As COMMAND
        Get
            Return _PS
        End Get
        Set(ByVal value As COMMAND)
            _PS = value
        End Set
    End Property
    Property PD() As COMMAND
        Get
            Return _PD
        End Get
        Set(ByVal value As COMMAND)
            _PD = value
        End Set
    End Property
    Property TE() As COMMAND
        Get
            Return _TE
        End Get
        Set(ByVal value As COMMAND)
            _TE = value
        End Set
    End Property
    Property SS() As COMMAND
        Get
            Return _SS
        End Get
        Set(ByVal value As COMMAND)
            _SS = value
        End Set
    End Property
    Property NP() As COMMAND
        Get
            Return _NP
        End Get
        Set(ByVal value As COMMAND)
            _NP = value
        End Set
    End Property
    Property SP() As COMMAND
        Get
            Return _SP
        End Get
        Set(ByVal value As COMMAND)
            _SP = value
        End Set
    End Property
    Property LG() As COMMAND
        Get
            Return _LG
        End Get
        Set(ByVal value As COMMAND)
            _LG = value
        End Set
    End Property
    Property ER() As COMMAND
        Get
            Return _ER
        End Get
        Set(ByVal value As COMMAND)
            _ER = value
        End Set
    End Property
    Property FW() As COMMAND
        Get
            Return _FW
        End Get
        Set(ByVal value As COMMAND)
            _FW = value
        End Set
    End Property
    Property UN() As COMMAND
        Get
            Return _UN
        End Get
        Set(ByVal value As COMMAND)
            _UN = value
        End Set
    End Property
    Public Function SetMsg(ByVal mac As String, ByVal pwd As String) As Byte()
        Dim msg As String = ""
        msg = "PW" & pwd & vbCrLf & _
            _MC.name & _MC.data & vbCrLf & _
            _IM.name & _IM.data & vbCrLf & _
            _OP.name & _OP.data & vbCrLf & _
            _DD.name & _DD.data & vbCrLf & _
            _CP.name & _CP.data & vbCrLf & _
            _PO.name & _PO.data & vbCrLf & _
            _DG.name & _DG.data & vbCrLf & _
            _KA.name & _KA.data & vbCrLf & _
            _KI.name & _KI.data & vbCrLf & _
            _KE.name & _KE.data & vbCrLf & _
            _RI.name & _RI.data & vbCrLf & _
            _LI.name & _LI.data & vbCrLf & _
            _SM.name & _SM.data & vbCrLf & _
            _GW.name & _GW.data & vbCrLf & _
            _DS.name & _DS.data & vbCrLf & _
            _PI.name & _PI.data & vbCrLf & _
            _PP.name & _PP.data & vbCrLf & _
            _DP.name & _DP.data & vbCrLf & _
            _DI.name & _DI.data & vbCrLf & _
            _DW.name & _DW.data & vbCrLf & _
            _DH.name & _DH.data & vbCrLf & _
            _LP.name & _LP.data & vbCrLf & _
            _RP.name & _RP.data & vbCrLf & _
            _RH.name & _RH.data & vbCrLf & _
            _BR.name & _BR.data & vbCrLf & _
            _DB.name & _DB.data & vbCrLf & _
            _PR.name & _PR.data & vbCrLf & _
            _SB.name & _SB.data & vbCrLf & _
            _FL.name & _FL.data & vbCrLf & _
            _IT.name & _IT.data & vbCrLf & _
            _PT.name & _PT.data & vbCrLf & _
            _PS.name & _PS.data & vbCrLf & _
            _PD.name & _PD.data & vbCrLf & _
            _TE.name & _TE.data & vbCrLf & _
            _SS.name & _SS.data & vbCrLf & _
            _NP.name & _NP.data & vbCrLf & _
            _SP.name & _SP.data & vbCrLf

        Dim bMsg() As Byte = System.Text.Encoding.ASCII.GetBytes(msg)
        Dim ret(10 + bMsg.Length - 1) As Byte
        Dim tmp() As Byte = frmMain.prefix_MA(mac)
        Array.ConstrainedCopy(tmp, 0, ret, 0, 10)
        Array.ConstrainedCopy(bMsg, 0, ret, 10, bMsg.Length)
        Return ret

    End Function
End Class

