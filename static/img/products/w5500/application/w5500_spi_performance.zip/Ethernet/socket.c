//*****************************************************************************
//
//! \file socket.c
//! \brief SOCKET APIs Implements file.
//! \detail SOCKET APIs like as Berkeley Socket APIs. 
//! \version 1.0.0.0
//! \date 09/01/2013
//! \par  Revision history
//!       <09-01-2013> 1st Release
//! \author MidnightCow
//! \copy
//!
//! Copyright (c)  2013, WIZnet Co., LTD.
//! All rights reserved.
//! 
//! Redistribution and use in source and binary forms, with or without 
//! modification, are permitted provided that the following conditions 
//! are met: 
//! 
//!     * Redistributions of source code must retain the above copyright 
//! notice, this list of conditions and the following disclaimer. 
//!     * Redistributions in binary form must reproduce the above copyright
//! notice, this list of conditions and the following disclaimer in the
//! documentation and/or other materials provided with the distribution. 
//!     * Neither the name of the <ORGANIZATION> nor the names of its 
//! contributors may be used to endorse or promote products derived 
//! from this software without specific prior written permission. 
//! 
//! THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
//! AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
//! IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
//! ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE 
//! LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
//! CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF 
//! SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
//! INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
//! CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
//! ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF 
//! THE POSSIBILITY OF SUCH DAMAGE.
//
//*****************************************************************************
#include "socket.h"

#define SOCK_ANY_PORT_NUM  0xC000;

static uint16_t sock_any_port = SOCK_ANY_PORT_NUM;
static uint16_t sock_io_mode = 0;

#define CHECK_SOCKNUM()   \
   do{                    \
      if(sn > _WIZCHIP_SOCK_NUM_) return SOCKERR_SOCKNUM;   \
   }while(0);             \

#define CHECK_SOCKMODE(mode)  \
   do{                     \
      if((getSn_MR(sn) & 0x0F) != mode) return SOCKERR_SOCKMODE;  \
   }while(0);              \

#define CHECK_SOCKINIT()   \
   do{                     \
      if((getSn_SR(sn) != SOCK_INIT)) return SOCKERR_SOCKINIT; \
   }while(0);              \

#define CHECK_SOCKDATA()   \
   do{                     \
      if(len == 0) return SOCKERR_DATALEN;   \
   }while(0);              \



int8_t socket(uint8_t sn, uint8_t protocol, uint16_t port, uint8_t flag)
{
	CHECK_SOCKNUM();
	switch(protocol)
	{
      case Sn_MR_TCP :
      case Sn_MR_UDP :
      case Sn_MR_MACRAW :
         break;
   #if ( _WIZCHIP_ < 5200 )
      case Sn_MR_IPRAW :
      case Sn_MR_PPPoE :
         break;
   #endif
      default :
         return SOCKERR_SOCKMODE;
	}
	if((flag & 0x0F) != 0) return SOCKERR_SOCKFLAG;
	if(flag != 0)
	{
   	switch(protocol)
   	{
   	   case Sn_MR_TCP:
   	      if(flag != SF_TCP_NODELAY) return SOCKERR_SOCKFLAG;
   	      break;
   	   case Sn_MR_UDP:
   	      if(flag & SF_IGMP_VER2)
   	      {
   	         if((flag & SF_MULTI_ENABLE)==0) return SOCKERR_SOCKFLAG;
   	      }
   	      #if _WIZCHIP_ == 5500
      	      if(flag & SF_UNI_BLOCK)
      	      {
      	         if((flag & SF_MULTI_ENABLE) == 0) return SOCKERR_SOCKFLAG;
      	      }
   	      #endif
   	      break;
      #if _WIZCHIP_ == 5200
         case 0x10:
            return SOCKERR_SOCKFLAG;
      #endif
   	   default:
   	      break;
   	}
   }
	close(sn);
	setSn_MR(sn, (protocol | (flag & 0xF0)));
	if(!port)
	{
	   port = sock_any_port++;
	   if(sock_any_port == 0xFFF0) sock_any_port = SOCK_ANY_PORT_NUM;
	}
   setSn_PORT(sn,port);	
   setSn_CR(sn,Sn_CR_OPEN);
   while(getSn_CR(sn));
   return (int8_t)sn;
}	   

int8_t close(uint8_t sn)
{
	CHECK_SOCKNUM();
	
	setSn_CR(sn,Sn_CR_CLOSE);
   /* wait to process the command... */
	while( getSn_CR(sn) );
	/* clear all interrupt of the socket. */
	setSn_IR(sn, 0xFF);
	return SOCKOK_SUCC;
}

int8_t listen(uint8_t sn)
{
	CHECK_SOCKNUM();
   CHECK_SOCKMODE(Sn_MR_TCP);
	CHECK_SOCKINIT();
	setSn_CR(sn,Sn_CR_LISTEN);
	while(getSn_CR(sn));
   while(getSn_SR(sn) != SOCK_LISTEN)
   {
      if(getSn_CR(sn) == SOCK_CLOSED)
      {
         close(sn);
         return SOCKERR_SOCKCLOSED;
      }
   }
   return SOCKOK_SUCC;
}


int8_t connect(uint8_t sn, uint8_t * addr, uint16_t port)
{
   CHECK_SOCKNUM();
   CHECK_SOCKMODE(Sn_MR_TCP);
   CHECK_SOCKINIT();
	if( *((uint32_t*)addr) == 0xFFFFFFFF || *((uint32_t*)addr) == 0) return SOCKERR_IPINVALID;
	if(port == 0) return SOCKERR_PORTZERO;
	setSn_DIPR(sn,addr);
	setSn_DPORT(sn,port);
//	setSUBR();	 // set the subnet mask register
	setSn_CR(sn,Sn_CR_CONNECT);
   while(getSn_CR(sn));
   while(getSn_SR(sn) != SOCK_ESTABLISHED)
   {   
		if (getSn_IR(sn) & Sn_IR_TIMEOUT)
		{
			setSn_IR(sn, Sn_IR_TIMEOUT);
         return SOCKERR_TIMEOUT;
		}
	}
//	clearSUBR();   // clear the subnet mask again and keep it because of the ARP errata of W5100
   return SOCKOK_SUCC;
}

int8_t disconnect(uint8_t sn)
{
   CHECK_SOCKNUM();
   CHECK_SOCKMODE(Sn_MR_TCP);
	setSn_CR(sn,Sn_CR_DISCON);
	/* wait to process the command... */
	while(getSn_CR(sn));
	while(getSn_SR(sn) != SOCK_CLOSED)
	{
	   if(getSn_IR(sn) & Sn_IR_TIMEOUT)
	   {
	      close(sn);
	      return SOCKERR_TIMEOUT;
	   }
	}
	return SOCKOK_SUCC;
}

int32_t send(uint8_t sn, uint8_t * buf, uint16_t len)
{
   uint8_t tmp=0;
   uint16_t freesize=0;
   
   CHECK_SOCKNUM();
   CHECK_SOCKMODE(Sn_MR_TCP);
   CHECK_SOCKDATA();
   tmp = getSn_SR(sn);
   if(tmp != SOCK_ESTABLISHED && tmp != SOCK_CLOSE_WAIT) return SOCKERR_SOCKSTATUS;
   freesize = getSn_TxMAX(sn);
   if (len > freesize) len = freesize; // check size not to exceed MAX size.
   do 
   {
      freesize = getSn_TX_FSR(sn);
      tmp = getSn_SR(sn);
      if ((tmp != SOCK_ESTABLISHED) && (tmp != SOCK_CLOSE_WAIT))
      {
         close(sn);
         return SOCKERR_SOCKSTATUS;
      }
   } while (freesize < len);
   wiz_send_data(sn, buf, len);

   setSn_CR(sn,Sn_CR_SEND);
   /* wait to process the command... */
   while(getSn_CR(sn));
   while( ((tmp = getSn_IR(sn)) & Sn_IR_SENDOK) !=Sn_IR_SENDOK )
   {
      if(tmp & Sn_IR_TIMEOUT)
      {
         close(sn);
         return SOCKERR_TIMEOUT;
      }
   }
   setSn_IR(sn, Sn_IR_SENDOK);
   return len;
}


int32_t recv(uint8_t sn, uint8_t * buf, uint16_t len)
{
   uint8_t  tmp = 0;
   uint16_t recvsize = 0;
   CHECK_SOCKNUM();
   CHECK_SOCKMODE(Sn_MR_TCP);
   CHECK_SOCKDATA();
   
   recvsize = getSn_RxMAX(sn);
   if(recvsize < len) len = recvsize;
   do
   {
      recvsize = getSn_RX_RSR(sn);
      tmp = getSn_SR(sn);
      if ((tmp != SOCK_ESTABLISHED) && (tmp != SOCK_CLOSE_WAIT))
      {
         close(sn);
         return SOCKERR_SOCKSTATUS;
      }
   }while(recvsize < len);
   wiz_recv_data(sn, buf, len);
   setSn_CR(sn,Sn_CR_RECV);
   while(getSn_CR(sn));
   return len;
}


int32_t sendto(uint8_t sn, uint8_t * buf, uint16_t len, uint8_t * addr, uint16_t port)
{
   uint8_t tmp = 0;
   uint16_t freesize = 0;
   CHECK_SOCKNUM();
   //CHECK_SOCKMODE(Sn_MR_UDP);
   switch(getSn_MR(sn) & 0x0F)
   {
      case Sn_MR_UDP:
      case Sn_MR_MACRAW:
         break;
      default:
         return SOCKERR_SOCKMODE;
   }
   CHECK_SOCKDATA();
   if(*((uint32_t*)addr) == 0) return SOCKERR_IPINVALID;
   if(port == 0)               return SOCKERR_PORTZERO;
   tmp = getSn_SR(sn);
   if(tmp != SOCK_INIT && tmp != SOCK_UDP) return SOCKERR_SOCKSTATUS;
   setSn_DIPR(sn,addr);
   setSn_DPORT(sn,port);      

   freesize = getSn_TxMAX(sn);
   if (len > freesize) len = freesize; // check size not to exceed MAX size.
   do
   {
      freesize = getSn_TX_FSR(sn);
      if(getSn_SR(sn) == SOCK_CLOSED) return SOCKERR_SOCKCLOSED;
   }while(freesize < len);
	wiz_send_data(sn, buf, len);
// setSUBR();    // set the subnet mask register
	setSn_CR(sn,Sn_CR_SEND);
	/* wait to process the command... */
	while(getSn_CR(sn));
   while ( ((tmp = getSn_IR(sn)) & Sn_IR_SENDOK) != Sn_IR_SENDOK ) 
   {
      if(tmp & Sn_IR_TIMEOUT)
   	{
         setSn_IR(sn, (Sn_IR_SENDOK | Sn_IR_TIMEOUT)); /* clear SEND_OK & TIMEOUT */
         return SOCKERR_TIMEOUT;
   	}
   }
// clearSUBR();	   // clear the subnet mask again and keep it because of the ARP errata of W5100
	setSn_IR(sn, Sn_IR_SENDOK);
	return len;
}



int32_t recvfrom(uint8_t sn, uint8_t * buf, uint16_t len, uint8_t * addr, uint16_t *port)
{
   uint8_t  mr = 0;
   uint8_t  head[8];
	uint16_t pack_len=0;

   CHECK_SOCKNUM();
   //CHECK_SOCKMODE(Sn_MR_UDP);
   switch((mr=getSn_MR(sn)) & 0x0F)
   {
      case Sn_MR_UDP:
      case Sn_MR_MACRAW:
         break;
   #if ( _WIZCHIP_ < 5200 )         
      case Sn_MR_IPRAW:
      case Sn_MR_PPPoE:
         break;
   #endif
      default:
         return SOCKERR_SOCKMODE;
   }
   CHECK_SOCKDATA();
   do
   {
      pack_len = getSn_RX_RSR(sn);
      if(getSn_SR(sn) == SOCK_CLOSED) return SOCKERR_SOCKCLOSED;
   }while(pack_len < len);

	switch (mr & 0x07)
	{
	   case Sn_MR_UDP :
			wiz_recv_data(sn, head, 8);
			setSn_CR(sn,Sn_CR_RECV);
			while(getSn_CR(sn));
			// read peer's IP address, port number & packet length
 			addr[0] = head[0];
			addr[1] = head[1];
			addr[2] = head[2];
			addr[3] = head[3];
			*port = head[4];
			*port = (*port << 8) + head[5];
			pack_len = head[6];
			pack_len = (pack_len << 8) + head[7];
			//
			// Need to packet length check (default 1472)
			//
   		wiz_recv_data(sn, buf, pack_len); // data copy.
			break;
	   case Sn_MR_MACRAW :
			wiz_recv_data(sn, head, 2);
			setSn_CR(sn,Sn_CR_RECV);
			while(getSn_CR(sn));
			// read peer's IP address, port number & packet length
 			pack_len = head[0];
			pack_len = (pack_len<<8) + head[1];
			if(pack_len > 1514) 
			{
			   close(sn);
			   return SOCKFATAL_PACKLEN;
			}
			wiz_recv_data(sn,buf,pack_len);
		   break;
   #if ( _WIZCHIP_ < 5200 )
		case Sn_MR_IPRAW:
			wiz_recv_data(sn, head, 6);
			setSn_CR(sn,Sn_CR_RECV);
			while(getSn_CR(sn));
			addr[0] = head[0];
			addr[1] = head[1];
			addr[2] = head[2];
			addr[3] = head[3];
			pack_len = head[4];
			pack_len = (pack_len << 8) + head[5];
			//
			// Need to packet length check
			//
   		wiz_recv_data(sn, buf, pack_len); // data copy.
			break;
   #endif
      default:
         wiz_recv_data(sn, buf, pack_len); // data copy.
         break;
   }
	setSn_CR(sn,Sn_CR_RECV);
	/* wait to process the command... */
	while(getSn_CR(sn)) ;
 	return pack_len;
}


int8_t  ctlsocket(uint8_t sn, ctlsock_type cstype, void* arg)
{
   uint8_t tmp = 0;
   CHECK_SOCKNUM();
   switch(cstype)
   {
      case CS_SET_IOMODE:
         tmp = *((uint8_t*)arg);
         if(tmp == SOCK_IO_NONBLOCK)  sock_io_mode |= (1<<sn);
         else if(tmp == SOCK_IO_BLOCK) sock_io_mode &= ~(1<<sn);
         else return SOCKERR_ARG;
         break;
      case CS_GET_IOMODE:   
         *((uint8_t*)arg) = (sock_io_mode >> sn) & 0x0001;
         break;
      case CS_GET_MAXTXBUF:
         *((uint16_t*)arg) = getSn_TxMAX(sn);
         break;
      case CS_GET_MAXRXBUF:    
         *((uint16_t*)arg) = getSn_RxMAX(sn);
         break;
      case CS_CLR_INTERRUPT:
         if( (*(uint8_t*)arg) > SIK_ALL) return SOCKERR_ARG;
         setSn_IR(sn,*(uint8_t*)arg);
         break;
      case CS_GET_INTERRUPT:
         *((uint8_t*)arg) = getSn_IR(sn);
         break;
      case CS_SET_INTMASK:  
         if( (*(uint8_t*)arg) > SIK_ALL) return SOCKERR_ARG;
         setSn_IMR(sn,*(uint8_t*)arg);
         break;
      case CS_GET_INTMASK:   
         *((uint8_t*)arg) = getSn_IMR(sn);
      default:
         return SOCKERR_ARG;
   }
   return 0;
}

int8_t  setsockopt(uint8_t sn, sockopt_type sotype, void* arg)
{
   uint8_t tmp;
   CHECK_SOCKNUM();
   switch(sotype)
   {
      case SO_TTL:
         setSn_TTL(sn,*(uint8_t*)arg);
         break;
      case SO_TOS:
         setSn_TOS(sn,*(uint8_t*)arg);
         break;
      case SO_MSS:
         setSn_MSSR(sn,*(uint16_t*)arg);
         break;
      case SO_DESTIP:
         setSn_DIPR(sn, (uint8_t*)arg);
         break;
      case SO_DESTPORT:
         setSn_DPORT(sn, *(uint16_t*)arg);
         break;
   /*
      case SO_RAW:  
         tmp = getSn_MR(sn);
         if((tmp & 0x0F) != Sn_MR_MACRAW) return SOCKERR_SOCKMODE;
         if(*(uint8_t*)arg == RAW_ALLPACKET)
            tmp &= ~(Sn_MR_MFEN);
         else if(*(uint8_t*)arg == RAW_MYPACKET)
            tmp |= Sn_MR_MFEN;
         else
            return SOCKERR_ARG;
         setSn_MR(sn,tmp);
         break;
   #if _WIZCHIP_ == 5500    
      case SO_IPv6PACKET:
         tmp = getSn_MR(sn);
         if((tmp & 0x0F) != Sn_MR_MACRAW) return SOCKERR_SOCKMODE;
         if(*(uint8_t*)arg == SOV_UNBLOCK)
            tmp &= ~(Sn_MR_MIP6B);
         else if(*(uint8_t*)arg == SOV_BLOCK)
            tmp |= Sn_MR_MIP6B;
         else
            return SOCKERR_ARG;
         break;
   #endif   
      case SO_UNICAST:
         tmp = getSn_MR(sn);
         if((tmp & (Sn_MR_MULTI|Sn_MR_UDP)) != (Sn_MR_MULTI|Sn_MR_UDP)) return SOCKERR_MODE;
         if(*(uint8_t*)arg == SOV_UNBLOCK)
            tmp &= ~(Sn_MR_MIP6B);
         else if(*(uint8_t*)arg == SOV_BLOCK)
            tmp |= Sn_MR_MIP6B;
         else
            return SOCKERR_ARG;
         break;
      case SO_BROADCAST:
         tmp = getSn_MR(sn);
         if((tmp &0x0F) != Sn_MR_UDP) return SOCKERR_MODE;
         if(*(uint8_t*)arg == SOV_UNBLOCK)
            tmp &= ~(Sn_MR_BCASTB);
         else if(*(uint8_t*)arg == SOV_BLOCK)
            tmp |= Sn_MR_BCASTB;
         else
            return SOCKERR_ARG;
         break;
      case SO_MULTICAST:
         tmp = getSn_MR(sn);
         if((tmp &0x0F) != Sn_MR_UDP) return SOCKERR_MODE;
         if(*(uint8_t*)arg == SOV_DISABLE)
            tmp &= ~(Sn_MR_MULTI);
         else if(*(uint8_t*)arg == SOV_ENABLE)
            tmp |= Sn_MR_MULTI;
         else
            return SOCKERR_ARG;
         break;
      case SO_IGMP:
         tmp = getSn_MR(sn);
         if((tmp &0x0F) != Sn_MR_UDP) return SOCKERR_MODE;
         if((tmp & Sn_MR_MULTI) == 0)  return SOCKERR_MODE;
         if(*(uint8_t*)arg == IGMP_VER2)
            tmp &= ~(Sn_MR_MC);
         else if(*(uint8_t*)arg == IGMP_VER1)
            tmp |= Sn_MR_MC;
         else
            return SOCKERR_ARG;
         break;
      case SO_NODELAYACK:
         tmp = getSn_MR(sn);
         if((tmp & 0x0F) != Sn_MR_TCP) return SOCKERR_MODE;
         
   */
#if _WIZCHIP_ != 5100
      case SO_KEEPALIVESEND:
         CHECK_SOCKMODE(Sn_MR_TCP);
         #if _WIZCHIP_ > 5200
            if(getSn_KPALVTR(sn) != 0) return SOCKERR_SOCKOPT;
         #endif
            setSn_CR(sn,Sn_CR_SEND_KEEP);
            while((tmp = getSn_CR(sn)) != 0)
            {
         		if (getSn_IR(sn) & Sn_IR_TIMEOUT)
         		{
         			setSn_IR(sn, Sn_IR_TIMEOUT);
                  return SOCKERR_TIMEOUT;
         		}
            }
         break;
   #if _WIZCHIP_ > 5200
      case SO_KEEPALIVEAUTO:
         CHECK_SOCKMODE(Sn_MR_TCP);
         setSn_KPALVTR(sn,*(uint8_t*)arg);
         break;
   #endif      
#endif   
      default:
         return SOCKERR_ARG;
   }   
   return SOCKOK_SUCC;
}

int8_t  getsockopt(uint8_t sn, sockopt_type sotype, void* arg)
{
   CHECK_SOCKNUM();
   switch(sotype)
   {
      case SO_OPTION:
         *(uint8_t*)arg = getSn_MR(sn) & 0xF0;
         break;
      case SO_TTL:
         *(uint8_t*) arg = getSn_TTL(sn);
         break;
      case SO_TOS:
         *(uint8_t*) arg = getSn_TOS(sn);
         break;
      case SO_MSS:   
         *(uint8_t*) arg = getSn_MSSR(sn);
      case SO_DESTIP:
         getSn_DIPR(sn, (uint8_t*)arg);
         break;
      case SO_DESTPORT:  
         *(uint16_t*) arg = getSn_DPORT(sn);
         break;
   /*
      case SO_RAW:       
      #if _WIZCHIP_ == 5500    
        case SO_IPv6PACKET:
      #endif   
      case SO_UNICAST:
      case SO_BROADCAST:     
      case SO_MULTICAST:
      case SO_IGMP:
      case SO_NODELAYACK:
   */
   #if _WIZCHIP_ > 5200   
      case SO_KEEPALIVEAUTO:
         *(uint16_t*) arg = getSn_KPALVTR(sn);
         break;
   #endif      
      case SO_SENDBUF:
         *(uint16_t*) arg = getSn_TX_FSR(sn);
      case SO_RECVBUF:
         *(uint16_t*) arg = getSn_RX_RSR(sn);
      case SO_STATUS:
         *(uint8_t*) arg = getSn_SR(sn);
         break;
      default:
         return SOCKERR_SOCKOPT;
   }
   return SOCKOK_SUCC;
}

