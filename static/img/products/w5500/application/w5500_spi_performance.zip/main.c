#include <stdio.h>
#include "xhw_types.h"
#include "xhw_memmap.h"
#include "xhw_spi.h"
#include "xsysctl.h"
#include "xgpio.h"
#include "xuart.h"
#include "xspi.h"

#include "Ethernet/socket.h"



uint8_t gDATABUF[2048];
wiz_NetInfo gWIZNETINFO;


void  wizchip_select(void);
void  wizchip_deselect(void);
void  wizchip_write(uint8_t wb);
uint8_t wizchip_read();
int32_t loopback_tcps(uint8_t sn, uint8_t* buf, uint16_t port);
int32_t loopback_udps(uint8_t sn, uint8_t* buf, uint16_t port);
void platform_init(void);



void platform_init(void)
{
   uint32_t ubase, sbase, smode;
   // System Clock
#ifdef M0516LBN
    xSysCtlClockSet(50000000,  xSYSCTL_OSC_MAIN | xSYSCTL_XTAL_12MHZ);
#else
    xSysCtlClockSet(72000000,  xSYSCTL_OSC_MAIN | xSYSCTL_XTAL_8MHZ);
#endif

    xSysCtlDelay((xSysCtlClockGet()/1000)*50); // wait 500ms

//    SysCtlSysTickSourceSet (SYSCTL_STCLK_S_HCLK_2);
//    xSysTickPeriodSet(xSysCtlClockGet()/1000);
    // GPIOA enable
    xSysCtlPeripheralEnable( xSYSCTL_PERIPH_GPIOA );
#ifdef M0516LBN
    xSysCtlPeripheralEnable( xSYSCTL_PERIPH_GPIOB );
    xGPIODirModeSet( xGPIO_PORTB_BASE, xGPIO_PIN_1, xGPIO_DIR_MODE_OUT );
    xGPIODirModeSet( xGPIO_PORTB_BASE, xGPIO_PIN_2, xGPIO_DIR_MODE_OUT );
    xSysCtlPeripheralReset(xSYSCTL_PERIPH_UART0);
    xSysCtlPeripheralEnable(xSYSCTL_PERIPH_UART0);
    xSPinTypeUART(UART0TX,PA2);
    xSPinTypeUART(UART0RX,PA3);
    ubase = xUART0_BASE;
#else
    xSysCtlPeripheralReset(xSYSCTL_PERIPH_UART1);
    xSysCtlPeripheralEnable(xSYSCTL_PERIPH_UART1);
    xSPinTypeUART(UART1TX,PA9);
    xSPinTypeUART(UART1RX,PA10);
    ubase = xUART1_BASE;
#endif


    xGPIODirModeSet(xGPIO_PORTA_BASE, xGPIO_PIN_4, xGPIO_DIR_MODE_OUT);

    xUARTConfigSet(ubase, 115200, (UART_CONFIG_WLEN_8 |
                                         UART_CONFIG_STOP_ONE |
                                         UART_CONFIG_PAR_NONE));
    xUARTEnable(ubase, (UART_BLOCK_UART | UART_BLOCK_TX | UART_BLOCK_RX));


#ifdef M0516LBN
    xSysCtlPeripheralReset(xSYSCTL_PERIPH_SPI0);
    xSysCtlPeripheralEnable(xSYSCTL_PERIPH_SPI0);
    xSPinTypeSPI(SPI0CLK, PB7);  // xGPIODirModeSet(xGPIO_PORTA, xGPIO_PIN_5, GPIO_TYPE_AFOUT_STD, GPIO_OUT_SPEED_50M);
    xSPinTypeSPI(SPI0MOSI,PB5);  // xGPIODirModeSet(xGPIO_PORTA, xGPIO_PIN_7, GPIO_TYPE_AFOUT_STD, GPIO_OUT_SPEED_50M);
    xSPinTypeSPI(SPI0MISO,PB6);  // xGPIODirModeSet(xGPIO_PORTA, xGPIO_PIN_6, GPIO_TYPE_IN_FLOATING, GPIO_IN_SPEED_FIXED);
    sbase = xSPI0_BASE;
    smode = xSPI_MOTO_FORMAT_MODE_0 | xSPI_MODE_MASTER | xSPI_MSB_FIRST | xSPI_DATA_WIDTH8;
#else
    xSysCtlPeripheralReset(xSYSCTL_PERIPH_SPI1);
    xSysCtlPeripheralEnable(xSYSCTL_PERIPH_SPI1);
    xSPinTypeSPI(SPI1CLK(3), PA5);  // xGPIODirModeSet(xGPIO_PORTA, xGPIO_PIN_5, GPIO_TYPE_AFOUT_STD, GPIO_OUT_SPEED_50M);
    xSPinTypeSPI(SPI1MOSI(3),PA7);  // xGPIODirModeSet(xGPIO_PORTA, xGPIO_PIN_7, GPIO_TYPE_AFOUT_STD, GPIO_OUT_SPEED_50M);
    xSPinTypeSPI(SPI1MISO(1),PA6);  // xGPIODirModeSet(xGPIO_PORTA, xGPIO_PIN_6, GPIO_TYPE_IN_FLOATING, GPIO_IN_SPEED_FIXED);
    sbase = xSPI1_BASE;
    smode = xSPI_MOTO_FORMAT_MODE_0 | xSPI_MODE_MASTER | xSPI_MSB_FIRST | xSPI_DATA_WIDTH8 | SPI_2LINE_FULL;
#endif

    xSPIConfigSet(sbase, xSysCtlClockGet()/2, smode);

#ifdef M0516LBN
    //xHWREG(xSPI0_BASE+SPI_CNTRL) |= (1<< 23);
    //xHWREG(xSPI0_BASE+SPI_DIVIDER) = 0;
    SPIVariableClockSet(sbase,0,1,xSysCtlClockGet()/2,xSysCtlClockGet()/2);
#endif

    //xSPISSSet(SPI0_BASE, SPI_SS_SOFTWARE, xSPI_SS0);
    xSPISSSet(sbase, SPI_SS_SOFTWARE, xSPI_SS_NONE);

    xSPIEnable(sbase);

   printf("HCLK = %dMHz\r\n", (unsigned int)(xSysCtlClockGet()/1000000));

   //xSysTickEnable();
   //xSysTickIntEnable();

#ifndef M0516LBN
    printf("APH1 CLK=%dMHz\r\n",(unsigned int)(SysCtlAPB1ClockGet()/1000000));
    printf("APH2 CLK=%dMHz\r\n",(unsigned int)(SysCtlAPB2ClockGet()/1000000));
#endif
}

int main(void)
{
   uint8_t tmp;
   uint8_t tmpstr[6] = {0,};
   int32_t ret = 0;
   uint8_t memsize[2][8] = { {2,2,2,2,2,2,2,2},{2,2,2,2,2,2,2,2}};

   platform_init();

    //reg_wizchip_intr_cbfunc(0, 0);
#if   _WIZCHIP_IO_MODE_ == _WIZCHIP_IO_MODE_SPI_VDM_
    reg_wizchip_cs_cbfunc(wizchip_select, wizchip_deselect);
#elif _WIZCHIP_IO_MODE_ == _WIZCHIP_IO_MODE_SPI_FDM_
    reg_wizchip_cs_cbfunc(wizchip_select, wizchip_select);  // CS must be tried with LOW.
#else
   #if (_WIZCHIP_IO_MODE_ & _WIZCHIP_IO_MODE_SIP_) != _WIZCHIP_IO_MODE_SIP_
      #error "Unknown _WIZCHIP_IO_MODE_"
   #endif
#endif
    //reg_wizchip_bus_cbfunc(uint8_t (*bus_rb)(uint32_t addr), void (*bus_wb)(uint32_t addr, uint8_t wb));
    reg_wizchip_spi_cbfunc(wizchip_read, wizchip_write);

    /* wizchip sw reset */
    //setMR(MR_RST);
    //ctlwizchip(CW_RESET_WIZCHIP,0);
    /* wizchip initialize*/
    if(ctlwizchip(CW_INIT_WIZCHIP,(void*)memsize) == -1)
    {
       printf("WIZCHIP Initialized fail.\r\n");
       while(1);
    }
/*    for(i=0; i < _WIZCHIP_SOCK_NUM_ ; i++)
       if(getSn_TXBUF_SIZE(i) != 2 || getSn_RXBUF_SIZE(i) != 2)
       {
          printf("ERROR : WIZCHIP_MEM_SIZE\r\n");
          while(1);
       }*/

    do
    {
       if(ctlwizchip(CW_GET_PHYLINK, (void*)&tmp) == -1)
          printf("Unknown PHY Link stauts!");
    }while(tmp == PHY_LINK_OFF);

    /* wizchip netconf */
    /*
    gWIZNETINFO.mac[0] = 0x00;
    gWIZNETINFO.mac[1] = 0x08;
    gWIZNETINFO.mac[2] = 0xDC;
    gWIZNETINFO.mac[3] = 0x00;
    gWIZNETINFO.mac[4] = 0xAB;
    gWIZNETINFO.mac[5] = 0xCD;
    gWIZNETINFO.ip[0] = 192;
    gWIZNETINFO.ip[1] = 168;
    gWIZNETINFO.ip[2] = 1;
    gWIZNETINFO.ip[3] = 119;
    gWIZNETINFO.gw[0] = 192;
    gWIZNETINFO.gw[1] = 168;
    gWIZNETINFO.gw[2] = 1;
    gWIZNETINFO.gw[3] = 1;
    gWIZNETINFO.sn[0] = 255;
    gWIZNETINFO.sn[1] = 255;
    gWIZNETINFO.sn[2] = 255;
    gWIZNETINFO.sn[3] = 0;
    gWIZNETINFO.dns[0] = 0;
    gWIZNETINFO.dns[1] = 0;
    gWIZNETINFO.dns[2] = 0;
    gWIZNETINFO.dns[3] = 0;
    gWIZNETINFO.dhcp = NETINFO_STATIC;
    */
    ctlnetwork(CN_GET_NETINFO, (void*)&gWIZNETINFO);
    gWIZNETINFO.ip[0] = 192;
    gWIZNETINFO.ip[1] = 168;
    gWIZNETINFO.ip[2] = 1;
    gWIZNETINFO.ip[3] = 119;
    ctlnetwork(CN_SET_NETINFO, (void*)&gWIZNETINFO);
    ctlnetwork(CN_GET_NETINFO, (void*)&gWIZNETINFO);
    //DISPLAY NETWORK
    ctlwizchip(CW_GET_ID,(void*)tmpstr);
    printf("=== %s NET CONF ===\r\n",(char*)tmpstr);
    printf("MAC:%02X.%02X.%02X.%02X.%02X.%02X\r\n",gWIZNETINFO.mac[0],gWIZNETINFO.mac[1],gWIZNETINFO.mac[2],
          gWIZNETINFO.mac[3],gWIZNETINFO.mac[4],gWIZNETINFO.mac[5]);
    printf("GAR:%d.%d.%d.%d\r\n", gWIZNETINFO.gw[0],gWIZNETINFO.gw[1],gWIZNETINFO.gw[2],gWIZNETINFO.gw[3]);
    printf("SUB:%d.%d.%d.%d\r\n", gWIZNETINFO.sn[0],gWIZNETINFO.sn[1],gWIZNETINFO.sn[2],gWIZNETINFO.sn[3]);
    printf("SIP:%d.%d.%d.%d\r\n", gWIZNETINFO.ip[0],gWIZNETINFO.ip[1],gWIZNETINFO.ip[2],gWIZNETINFO.ip[3]);

   while(1)
   {

      if( (ret = loopback_tcps(0,gDATABUF,3000)) < 0)
      {
         printf("SOCKET ERROR : %d\r\n", ret);
         if(ret != SOCKERR_SOCKCLOSED )
            while(1);
      }
      if( (ret = loopback_udps(1,gDATABUF,3000)) < 0)
      {
         printf("SOCKET ERROR : %d\r\n", ret);
         if(ret != SOCKERR_SOCKCLOSED )
            while(1);
      }
	};
}


void  wizchip_select(void)
{
   xGPIOPinWrite( xGPIO_PORTA_BASE, xGPIO_PIN_4, 0);
}

void  wizchip_deselect(void)
{
   xGPIOPinWrite( xGPIO_PORTA_BASE, xGPIO_PIN_4, 1);
}

void  wizchip_write(uint8_t wb)
{
#ifdef M0516LBN
   xSPISingleDataReadWrite(xSPI0_BASE,wb);
#else
   xSPISingleDataReadWrite(xSPI1_BASE,wb);
#endif
}

uint8_t wizchip_read()
{
#ifdef M0516LBN
   return xSPISingleDataReadWrite(xSPI0_BASE,0xFF);
#else
   return xSPISingleDataReadWrite(xSPI1_BASE,0xFF);
#endif
}

//loopback_tcps
int32_t loopback_tcps(uint8_t sn, uint8_t* buf, uint16_t port)
{
   int32_t ret;
   uint16_t size = 0;
   switch(getSn_SR(sn))
   {
      case SOCK_ESTABLISHED :
         if(getSn_IR(sn) & Sn_IR_CON)
         {
            printf("%d:Connected\r\n",sn);
            setSn_IR(sn,Sn_IR_CON);
         }
         if((size = getSn_RX_RSR(sn)) > 0)
         {
            //printf("SR(%d)->",size);
            ret = recv(sn,buf,size);
            if(ret != (int32_t)size) return ret;
            //printf("SS(%d)->",size);
            ret = send(sn,buf,(uint16_t)size);
            if(ret != size) return ret;
         }
         break;
      case SOCK_CLOSE_WAIT :
         printf("%d:CloseWait\r\n",sn);
         if((ret=disconnect(sn)) != SOCKOK_SUCC) return ret;
         printf("%d:Closed\r\n",sn);
         break;
      case SOCK_INIT :
         printf("%d:Listen\r\n",sn);
         if( (ret = listen(sn)) != SOCKOK_SUCC) return ret;
         break;
      case SOCK_CLOSED:
         printf("%d:LBTStart\r\n",sn);
         if((ret=socket(sn,Sn_MR_TCP,port,0x00)) != sn)
            return ret;
         printf("%d:Opened\r\n",sn);
         break;
      default:
         break;
   }
   return 1;
}

int32_t loopback_udps(uint8_t sn, uint8_t* buf, uint16_t port)
{
   int32_t  ret;
   uint16_t size;
   uint8_t  destip[4];
   uint16_t destport;
   switch(getSn_SR(sn))
   {
      case SOCK_UDP :
         if((size = getSn_RX_RSR(sn)) > 0)
         {
            //printf("SR(%d):",size);
            ret = recvfrom(sn,buf,size,destip,(uint16_t*)&destport);
            //printf("%d:%d.%d.%d[%d]->",destip[0],destip[1],destip[2],destip[3],destport);
            if(ret < 0) return ret;
            //printf("SS(%d)->",ret);
            size = (uint16_t) ret;
            ret = sendto(sn,buf,size,destip,destport);
            if(ret < 0) return ret;
         }
         break;
      case SOCK_CLOSED:
         printf("%d:LBUStart\r\n",sn);
         if((ret=socket(sn,Sn_MR_UDP,port,0x00)) != sn)
            return ret;
         printf("%d:Opened\r\n",sn);
         break;
      default :
         break;
   }
   return 1;
}
