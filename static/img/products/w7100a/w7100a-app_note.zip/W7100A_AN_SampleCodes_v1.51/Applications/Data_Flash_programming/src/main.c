/*
**********************************************************************
* Description : Data FLASH Erase, Read and Write test function
* Argument : 
* Returns : 
* Note : Just use for testing
**********************************************************************
*/
#pragma userclass(CODE = ISP)
#include <stdio.h>
#include "..\..\..\drivers\TCPIPCore.h"

#define ISP_ENTRY 0x07FD

#define ISP_DATABPROG		 0xD6	 // Byte Program Command for Data Flash
#define ISP_DATABREAD		 0xD5	 // Byte Read Command for Data Flash
#define ISP_DATASPROG        0xD1    // Secter Program Command for Data Flash
#define ISP_DATASREAD        0xD2    // Secter Read Command for Data Flash
	  
#define ISP_data_sector_read(RSADDR) \
{\
   RAMBA16 = RSADDR; \
   do_isp(ISP_DATASREAD,0,0); \
}
#define ISP_data_sector_prog(RSADDR) \
{\
   RAMBA16 = RSADDR; \
   do_isp(ISP_DATASPROG,0,0); \
}

/*******************************************************************************************/
/* If you have QFN64pin package W7100A, have to use 'USE_QFN64' definition in TCPIPcore.h  */
/*******************************************************************************************/

unsigned char do_isp(unsigned char isp_id, unsigned short isp_addr, unsigned char isp_data)
{
   uint8 TMPR0 = 0;
   TMPR0 = EA;    // backup EA

   EA = 0;    // disable EA
   WCONF &= ~(0x40);     // Enable ISP Entry
   ISPID = isp_id;
   ISPADDR16 = isp_addr;
   ISPDATA = isp_data;
   ((void(code*)(void))ISP_ENTRY)();    // call ISP Entry
   WCONF |= 0x40;        // Disable ISP Entry
   EA = TMPR0;    // restore EA

   return ISPDATA;
}	

void ISP_data_erase(void)
{
	uint8 i;
	uint8 xdata tem[255];
	for(i=0x00; i<0xFE; i++)
	{
	   tem[i] = 0xFF;
	}
	ISP_data_sector_prog((uint16)tem);

}

void main()
{
	uint16 xdata i;
	uint8 xdata tem[255];

	Init_iMCU(); 					// Initialize MCU           
 	ISP_data_erase();				//Erase data FLASH

	wait_1ms(100);

	ISP_data_sector_read((uint16)tem);		//Read data FLASH
	
	printf("\r\nData_FLASH Erased!!\r\n");

	for(i=0x00; i<0xFE; i++)			//Print data FLASH atfer erasing
	{		
		printf("0x%bX\t", tem[i]);
		tem[i] = i;
		//if((i % 0x10) == 0x0F) printf("\r\n");
	}
	
	printf("\r\n\r\nData_FLASH writed!!\r\n");

	ISP_data_sector_prog((uint16)tem);		//Program data FLASH

	for(i=0x00; i<0xFE; i++)		//Print data FLASH after programming
	{		
		printf("0x%bX\t", tem[i]);
		//if((i % 0x10) == 0x0F) printf("\r\n");
	}
	 
	while(1);


}