/********************************************************************
*	2011 WIZnet technology all rights reserved
*	DHCP Client Application Note code for iMCU7100EVB
*	--------------------------------------------------
*	Ver 0.9	Release Feb. 2009
*	--------------------------------------------------
*	Ver 1.0 Release Dec. 2010	Update LCD driver
*	--------------------------------------------------
*	Ver 1.1 Release Feb. 2011	Modify dhcp_app.c
*								Fixed message parsing error
********************************************************************/

/***********************************************************
 * Do not use Init_Network() function in TCPIPCORE.c file. *
 ***********************************************************/

#include "..\..\..\drivers\tcpipcore.h"
#include "dhcp_app.h"

/*******************************************************************************************/
/* If you have QFN64pin package W7100A, have to use 'USE_QFN64' definition in TCPIPcore.h  */
/*******************************************************************************************/

uint8 xdata temp = 0;
uint8 xdata Mac[6];
uint8 xdata SubMask[4];
uint8 xdata Gateway[4];
uint8 xdata IpAddr[4];
uint8 xdata DHCP_flag;
uint8 xdata DHCPisSuccess;
uint8 xdata Enable_DHCP_Timer;

extern un_l2cval xdata lease_time;
extern uint32 xdata my_time;
volatile uint16 xdata lease_time_cnt = 0;	

void Init_Sock(void);

void Init_Net_DHCP(void)
{
	uint8 xdata i;
	uint8 xdata str[17];
					
	if (DHCP_SetIP())
	{ //DHCP success => Init Net
		DHCPisSuccess = 1;
		sprintf(str,"%.3bu.%.3bu.%.3bu.%.3bu ",
			IINCHIP_READ (SIPR0+0), IINCHIP_READ (SIPR0+1), 
			IINCHIP_READ (SIPR0+2), IINCHIP_READ (SIPR0+3));
		printf("> DHCP Success.\r\n");
	}
	else
	{	// DHCP Fail	=> Not init Net
		DHCPisSuccess = 0;
			printf("\n\r> DHCP Fail.")	 ;

		for (i = 0; i < 4; i++)
		{
			Gateway[i] = 0;
			SubMask[i] = 0;
			IpAddr[i] = 0;
		}

		((void (code *)(void)) 0x0000)();	  
	}
}

void timer0(void) interrupt 1		
{


    TR0 = 0;
    TF0 = 0;
    TL0 += predTL0;
    TH0 += predTH0;
    
    TR0 = 1;

    // for DHCP
    if (Enable_DHCP_Timer == 1)
    {
	    if (lease_time_cnt++ >= 5000)
	    {
		    lease_time_cnt = 0;
		    my_time++;
			P0_5 = !P0_5;
	    }
    }

}

void main()
{	
	Init_iMCU();		
	    
	printf("\r\n====================================\r\n");
	printf("       W7100A DHCP Application ! \r\n");
	printf("====================================\r\n");
	  
	//Initialztion MAC address
	Mac[0] = 0x00;
	Mac[1] = 0x08;
	Mac[2] = 0xdc;
	Mac[3] = 0x00;
	Mac[4] = 0x00;
	Mac[5] = 0x00;

	printf("\r\n Wait for linking \r\n");
	
	/*If you use sotfware reset(such as watchdog reset), 
	please don't use this code or you may can't escape this while loop!!*/	
	//while(!(EIF & 0x02));
	//EIF &= ~0x02;
	
	printf("\r\n Link !! \r\n");

	//DHCP mode flag	
	DHCP_flag = 1;

	if (DHCP_flag == 1)
	{
		Init_Net_Default();		// Init IP,G/W, and S/M by 0.0.0.0	 		
		wait_10ms(100);			
		Init_Net_DHCP();
	}
	
	else
	{
		Init_Net();			// Init 
  	}

	for(;;)
	{
		if ((DHCP_flag == 1) && (DHCPisSuccess == 1)) check_dhcp();
	} 
}

