/******************Include Part******************************/
#include "..\..\..\..\drivers\TCPIPCore.h"
#include "util.h"	 

/*******************************************************************************************/
/* If you have QFN64pin package W7100A, have to use 'USE_QFN64' definition in TCPIPcore.h  */
/*******************************************************************************************/

/************************Define Part**************************/
// Notice : [Timer select define] is located in 'serial.h' file.
//			Please check the 'serial.h' first.

/*************Function Prototype Declaration Part***************/

/*****************Function Implementation Part******************/
void main()
{
	Init_iMCU();		//Initialize iMCU
	while(1)  PutByte(GetByte());
}		
		