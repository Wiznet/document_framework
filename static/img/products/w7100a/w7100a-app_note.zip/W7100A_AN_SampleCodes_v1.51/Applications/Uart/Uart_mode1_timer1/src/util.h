/*
###############################################################################
Function Prototype Definition Part
###############################################################################
*/

void PutByte(unsigned char byData);		/* Output 1 character through Serial Port */

unsigned char GetByte(void);		/* Read 1 character from Serial. */

char IsPressedKey();				/* Check to input to Serial or not. */

void PutHTOA(unsigned char byData);		/* Output 1 Byte Hexadecimal digit to 2Byte ASCII character.  ex) 0x2E --> "2E" */

void PutITOA(unsigned int byData);		/* Output 2 Byte Integer to 4Byte ASCII character ex) 0x12FD --> "12FD" */

void PutLTOA(unsigned long byData);	/* Output 4 Byte Long to 8Byte ASCII character. ex) 0x001234FF --> "001234FF" */

void PutString(char *Str) reentrant;	/* Output to Serial. */

void PutStringLn(char *Str) reentrant;	/* Output to Serial and then specific character,'Carrage Return & New Line'. */

