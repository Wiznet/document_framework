/*
###############################################################################
Include Part
###############################################################################
*/


#include "..\..\..\..\drivers\TCPIPCore.h"


/*
###############################################################################
Function Implementation Part
###############################################################################
*/


/*
Description   :  Output 1 character through Serial Port
Argument      :  byData - character to output(INPUT)
Return Value  :  
Note          :
*/

void PutByte(unsigned char byData)
{
	// Write data into serial-buffer.
	SBUF = byData; 
	// Wait till data recording is finished.
	while(!TI);
	TI = 0;
}
/*
  char putchar(char byData)	reentrant
{
	// Write data into serial-buffer.
	SBUF = byData; 
	// Wait till data recording is finished.
	while(!TI);
	TI = 0;
	return byData;
}
  */

/*
Description   :  Read 1 character from Serial.
Argument      :  
Return Value  :   Read 1 character from Serial and Return.
Note          :  
*/
unsigned char GetByte(void)	
{
	unsigned char byData;
	// Wait till data is received.
	while(!RI);		
	RI = 0;
	// Read data.
	byData = SBUF;		
	return byData;
}


/*
Description   :  Check to input to Serial or not.
Argument      :  
Return Value  :    1)If there's input, then returned value is '1'.
	           2)If there's no input, then returned value is '-1'.
Note          :  
*/
char IsPressedKey()
{
	if( RI == 1 ) return 1;
	return -1;
}


/*
Description   :  Output 1 Byte Hexadecimal digit to 2Byte ASCII character.  ex) 0x2E --> "2E"
Argument      :   byData - character to output(INPUT)
Return Value  :  
Note          :  
*/
void PutHTOA(unsigned char byData)
{
	// HIGH DIGIT
	if((byData / 0x10) >= 10)
		PutByte('A'+((byData/0x10)%0x0A));
	else
		PutByte('0'+((byData/0x10)%0x0A));
	// LOW DIGIT
	if((byData % 0x10) >= 10)
		PutByte('A' + ((byData%0x10)%0x0A));
	else
		PutByte('0' + ((byData%0x10)%0x0A));
}

/*
Description   : Output 2 Byte Integer to 4Byte ASCII character ex) 0x12FD --> "12FD"
Argument      :    byData - Integer to output(INPUT)
Return Value  :  
Note          :  
*/
void PutITOA(unsigned int byData)
{
	PutHTOA(byData / 0x100);
	PutHTOA(byData % 0x100);
}

/*
Description   :   Output 4 Byte Long to 8Byte ASCII character. ex) 0x001234FF --> "001234FF"
Argument      :  byData - Long to output (INPUT)
Return Value  :  
Note          :  
*/
void PutLTOA(unsigned long byData)
{
	// upper 2 Byte
	PutITOA(byData / 0x10000);
	// lower 2 Byte
	PutITOA(byData % 0x10000);
}

/*
Description   :  Output to Serial.
Argument      :  Str - Character Stream to output (INPUT)
Return Value  :  
Note          :  Version 2.0
*/
void PutString(char *Str) reentrant 
{
	unsigned int i;
	for (i = 0; Str[i] != '\0'; i++)	PutByte(Str[i]);

}

/*
Description   :  Output to Serial and then specific character,'Carrage Return & New Line'.
Argument      : Str -  Character Stream to output(INPUT)
Return Value  :  
Note          :  Version 2.0
*/
void PutStringLn(char * Str) reentrant 
{
#ifdef __DEBUG
    PutString(Str);
	PutByte(0x0a);
	PutByte(0x0d);
#else
	;
#endif
}

