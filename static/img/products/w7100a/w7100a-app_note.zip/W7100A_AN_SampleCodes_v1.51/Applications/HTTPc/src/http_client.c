#include "..\..\..\drivers\TCPIPCore.h"
#include "dns.h"
#include "http_client.h"
#include "lcd.h"

#define	MAX_BUF_SIZE	8192		// Maximum receive buffer size

uint16 wrt_idx = 0;
uint8 flag = 1;

int16 http_client( uint8 s, uint8 *HTTPs_IP, uint8 *url_path,uint8 xdata * data_buf)
{
	int32 len;
	uint8 xdata http_req[1024];

	static uint16 xdata any_port = 5000;	

	switch (getSn_SR(s))
	{
			case SOCK_ESTABLISHED:				

				 		if(flag){
		            			printf("< Connect OK >\r\n");
		            			sprintf(http_req, "GET %s HTTP/1.1\r\nAccept: */*\r\nHost: %s\r\nUser-Agent: Mozilla/4.0 \r\n\r\n", url_path, HTTPs_IP);
								send(s, http_req, sizeof(http_req));
		           				flag = 0;							
						}
		         
						if ((len = getSn_RX_RSR(s)) > 0){
								if (len > MAX_BUF_SIZE) len = MAX_BUF_SIZE;
								len = recv(s, (data_buf+wrt_idx) , len);
						}
						wrt_idx += len;
				
					
						if(strstr(data_buf, "</html>")){
								return (wrt_idx);
						}
			break;
		
		 case SOCK_CLOSE_WAIT:                           		
						if ((len = getSn_RX_RSR(s)) > 0)  {
								len = recv(s, data_buf, len);		
						}				

						disconnect(s);
						printf("< Disconnect >\r\n");
				break;
				
		 case SOCK_CLOSED:                                            
		     	close(s);                           
		     if ( (socket(s,Sn_MR_TCP,any_port++, 0) )!=1 ){
						printf("< Fail : socket > \r\n");
		      }else{
				  	printf("\r\n<socket init OK! >\r\n");		
					}
					
			 break;
				
		 case SOCK_INIT:	
				if( (connect(s,(uint8*)HTTPs_IP, 80) )!= 1 ){
					printf("< Fail : connect >\r\n");
				}

		   break;
	
	}
		
		
	return 0;	
}


