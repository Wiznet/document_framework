#ifndef __HTTP_CLIENT_H
#define __HTTP_CLIENT_H
#include "..\..\..\drivers\types.h"
int16 http_client(uint8 s, uint8 *HTTPs_IP, uint8 *url_path, uint8 xdata * data_buf );
#endif
