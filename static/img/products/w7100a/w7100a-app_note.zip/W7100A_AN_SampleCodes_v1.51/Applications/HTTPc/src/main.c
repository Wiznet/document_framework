#include "..\..\..\drivers\TCPIPCore.h"
#include "dns.h"
#include "http_client.h"
#include "lcd.h"

#define MAX_URL_SIZE 128

/*******************************************************************************************/
/* If you have QFN64pin package W7100A, have to use 'USE_QFN64' definition in TCPIPcore.h  */
/*******************************************************************************************/

uint8 xdata * data_buf =(uint8 xdata *)0x7000;	// Position of receive buffer
uint8 str_start[6]= "<html>";
uint8 str_end[7]= "</html>";

int16 pased_idx(uint8 * st_buf, int16  size, int16 data_len){
	int16 i,j,idx;
	idx = 0; i=0;

			do{
				idx = 0;
				for(j=0; j<size; j++){					
					if(data_buf[i+j] == st_buf[j] ){
					  idx++;		
					}				
				}
				i++;
				if(i>data_len)
					break;
			}while( idx != (size) );
			
			idx  = i-1;					
			return idx;
}

void main()
{	
	uint8 xdata url[MAX_URL_SIZE];			//full url
	uint8 xdata url_dn[MAX_URL_SIZE];			//domain name url
	uint8 xdata url_path[MAX_URL_SIZE];		//local path in html server
	uint8 * split;				//string split pointer 
	uint8 HTTPs_IP[4];	
	uint8 done_dns = 0;
	int16 done_http = 0;
	uint8 s = 0;		
	int16 start_idx = 0 ;
	int16 end_idx = 0;
	int16 tmp_start;
	int16 tmp_end;
	uint8 BR [4]= "<BR>";
	uint8 rBR [4]= "\r\n";
	uint8 xdata TITLE [7]= "<TITLE>";
	uint8 xdata bTITLE [8]= "</TITLE>";
	uint8 xdata PRE [5]= "<PRE>";
	uint8 xdata bPRE [6]= "</PRE>";

	int16 i, tmp_idx;
	uint8 no_pr = 0;
	uint8 xdata  str[17];
	
	Init_iMCU();		// Initialize   iMCUW7100     
	Init_Network(); 	// Initialize   Network Configuration

	while(1)
	{
		/* ouput for LCD : Netconfig */
		//evb_set_lcd_text(0,(uint8 *) "iMCU7100EVB     ");     
		sprintf(str,"%.3bu.%.3bu.%.3bu.%.3bu ",
				IINCHIP_READ (SIPR0+0), IINCHIP_READ (SIPR0+1), 
				IINCHIP_READ (SIPR0+2), IINCHIP_READ (SIPR0+3));
		//evb_set_lcd_text(1,str);	

		/* Get Http Address  */
		printf("\r\n\r\n\r\n Please enter a HTTP Address without 'http://' \n\r"); 
		printf("http://");
		memset(url,0,sizeof(url));		    
		scanf("%s", url);
		printf("\r\n Your HTTP address is: %s \r\n",url);		
		
		/* Parse URL Path  */
	    split = strchr(url,'/');			
		strcpy(url_path,split); 			
		printf("Domain path: %s \r\n",url_path);
	
		/* Parse URL Domain  */
		split = strtok(url,"/");			
		strcpy(url_dn,split);				
		printf("Domain name: %s \r\n",url_dn);
		
		/* Do DNS Client */
		memset(HTTPs_IP,0,sizeof(HTTPs_IP));		    
		done_dns = dns_query(s, url_dn, HTTPs_IP);
		
		while( done_dns == 1 ){ // on success, done_dns is '1'
			/* ouput for LCD : DSN SERVER IP */
			//evb_set_lcd_text(0,"DNS SERVER IP  ");	
			sprintf(str,"%.3bu.%.3bu.%.3bu.%.3bu",
				HTTPs_IP[0], HTTPs_IP[1], HTTPs_IP[2], HTTPs_IP[3]);
			    //evb_set_lcd_text(1,str);	
 
			/* Do HTTP Client */
		 	done_http = http_client(s, HTTPs_IP, url_path, data_buf);	
		  	if(done_http) { // on success, done_dns is not  '0'
		  			 //printf("DONE_HTTPc : %d\r\n",(int16)done_http);
#define Recieved_DATA
#ifdef Recieved_DATA
					printf("\r\n<< Recieved Data -- START>> \r\n");
					for(i=0; i<done_http; i++){
						printf("%c",(uint8)data_buf[i]);
					  }   
					printf("\r\n");
					printf("<< Recieved Data -- END>> \r\n");
#endif
				    /* parsed index */
					//All other HTML elements are nested between the opening <html> and </html> tags.
					start_idx = pased_idx((uint8 *)str_start , sizeof(str_start), done_http );
					end_idx   = pased_idx((uint8 *)str_end , sizeof(str_end), done_http );			

					/* printf get <html> ...</html> */							
					for(i=start_idx; i<(end_idx+7); i++){						
						/* remove header */
						data_buf[i-start_idx] = data_buf[i];
					 }   
					printf("\r\n");
					

					/* replace <br> tag to \r\n */
					//The br tag is used for specifying a line break.
					do{
						tmp_idx = pased_idx((uint8*)BR, sizeof(BR) , end_idx-start_idx) ;
						if(tmp_idx == 0 ) 
							break;
						//printf("tmp_idx : %d (%d)\r\n", (int16)tmp_idx, (int16)(end_idx-start_idx));
						memcpy((uint8 *)data_buf+tmp_idx, (uint8*)rBR, sizeof(rBR)) ;
					}while(tmp_idx!=end_idx-start_idx);

#define Parsed_DATA
#ifdef Parsed_DATA
					/* parsed DATA */
					printf("\r\n<< Parsed Data -- START >>");
					printf("\r\nTITLE : \r\n");
					/* parse <TITLE> and </TITLE> tags */
					tmp_start = pased_idx((uint8 *)TITLE , sizeof(TITLE),(end_idx-start_idx) ) + sizeof(TITLE);
					tmp_end   = pased_idx((uint8 *)bTITLE , sizeof(bTITLE),(end_idx-start_idx) );												
					for(i=tmp_start; i<tmp_end; i++){
						printf("%c",(uint8)data_buf[i]); // printf title
					}   

					printf("\r\n BODY : \r\n");
					/*DO NOT PRINT TAG COMMAND: between '<' with '>' */
					for(i=tmp_end; i<(end_idx-start_idx); i++){
						//Tag command - ex.)<PRE>
						//'<' is a start point of tag command.
						if((uint8)data_buf[i]=='<'){ 
							no_pr = 0;
						}
						//'>' is a end point of Tag command.
						//To avoid in row tags -> ex.) <PRE><H1>						
						if((uint8)data_buf[i]=='>' && (uint8)data_buf[i+1] !='<' ) {
							no_pr = 1;
							i++;
						}					
						if(no_pr){
							printf("%c",(uint8)data_buf[i]);
						}
					}   
					printf("\r\n<< Parsed Data -- END >>\r\n");
#endif
					/* Init. parameter */
					start_idx= 0;
					end_idx= 0;				
			        done_dns = 0;  
		  		break;

			}//done_http
		}//while : done_dns == 1		
	}//while(1);
}//main
