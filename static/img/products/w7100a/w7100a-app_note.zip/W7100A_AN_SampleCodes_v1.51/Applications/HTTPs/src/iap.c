#pragma userclass(CODE = ISP)
#include <stdio.h>
#include "..\..\..\drivers\w7100.h"
#include "iap.h"
#include "..\..\..\drivers\serial.h"
#include "..\..\..\drivers\types.h"

unsigned int xdata rwAddr;
unsigned char xdata rwData;
unsigned char xdata Sector;

extern uint8 xdata Mac[6];
extern uint8 code default_setting[159];

#define FLASH_RESET()\    
{\
 PCON |= 0x10;\
 (*((volatile unsigned char xdata*) 0x0000) = 0xF0);\
 PCON &= ~0x10;\
}

#define ISP_ENTRY 0x07FD
#define ISP_SERASE         0x30    // Sector Erase Command
#define ISP_MERASE         0x10    // Chip Erase Command
#define ISP_BPROG          0xA0    // Byte Program Command
#define ISP_SECPROG        0xA1    // Sector Program Command
#define ISP_CHIPROG        0xA2    // Chip Program Command
#define ISP_BREAD          0x00    // Byte Read Command
#define ISP_DATAERASE       0xD0    // Sector Erase Command for Data Flash
#define ISP_DATAPROG        0xD1    // Byte Program Command for Data Flash
#define ISP_DATAREAD        0xD2    // Read Command for Data Flash
#define ISP_chip_erase()            do_isp(ISP_MERASE,0,0)
#define ISP_sector_erase(FSADDR)     do_isp(ISP_SERASE,FSADDR,0)
#define ISP_write_byte(FBADDR,DAT)   do_isp(ISP_BPROG,FBADDR,DAT)
//#define ISP_read_byte(FBADDR)        do_isp(ISP_BREAD,FBADDR,0)
#define ISP_data_erase()       do_isp(ISP_DATAERASE,0,0)

#define ISP_chip_prog(RSADDR,READDR,FSADDR) \
{\
   RAMBA16 = RSADDR; \
   RAMEA16 = READDR; \
   do_isp(ISP_CHIPROG,FSADDR,0); \
}

#define ISP_sector_prog(RSADDR,READDR,FSADDR) \
{\
   RAMBA16 = RSADDR; \
   RAMEA16 = READDR; \
   do_isp(ISP_SECPROG,FSADDR,0); \
}

#define ISP_data_sector_read(RSADDR) \
{\
   RAMBA16 = RSADDR; \
   do_isp(ISP_DATAREAD,0,0); \
}


#define ISP_data_sector_prog(RSADDR) \
{\
   RAMBA16 = RSADDR; \
   do_isp(ISP_DATAPROG,0,0); \
}


unsigned char do_isp(unsigned char isp_id, unsigned short isp_addr, unsigned char isp_data)
{
   uint8 TMPR0 = 0;
   TMPR0 = EA;    // backup EA
   EA = 0;    // disable EA
   WCONF &= ~(0x40);     // Enable ISP Entry
   ISPID = isp_id;
   ISPADDR16 = isp_addr;
   ISPDATA = isp_data;
   ((void(code*)(void))ISP_ENTRY)();    // call ISP Entry
   WCONF |= 0x40;        // Disable ISP Entry
   EA = TMPR0;    // restore EA
   return ISPDATA;
}

void user_flash_write(unsigned char *user_data)
{
	ISP_data_erase();
	ISP_data_sector_prog((unsigned short)user_data);
}

void user_flash_read(unsigned char *user_data)
{
	ISP_data_sector_read((unsigned short)user_data);
}

void flash_write( unsigned short isp_addr, unsigned char *user_data, int len )
{
	ISP_sector_prog((unsigned short)user_data, (unsigned short)(user_data+len), isp_addr);
}

void flash_read( unsigned short isp_addr, unsigned char *user_data, int len )
{
	int i;

	for (i=0 ; i < len ; i++)
	{
		//user_data[i] = ISP_read_byte(isp_addr+i);
		user_data[i] = *((unsigned int code*)(isp_addr + i - 1));
	}
}