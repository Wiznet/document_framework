/*
*
@file		timer.c
*
*/

#include <stdio.h> 
#include <string.h>
#include "..\..\..\drivers\types.h"
#include "timer.h"
#include "..\..\..\drivers\w7100.h"

uint16 xdata temp = 0;
static int timeout = 0;
void (*user_timer_handler)(void) = 0;

/**
@brief	This function initialize timer.
*/
void init_timer(void)
{
	TMOD = 0x01;				   
	TH0 = 0; TL0 = 0;			  
	ET0 = 1; 
	EA = 1;
	TR0 = 1; 
}

void int_test(void) interrupt 1	   //Timer0 interrupt
{
	TF0 = 0;				          
	if(timeout != 0)
	{
		temp++;	
		if (timeout <= temp)
		{
			if (user_timer_handler != 0) (*user_timer_handler)();
		}
	}
}

/**
@brief	Register the timer handler
*/
void set_timer(
	unsigned int a_timeout, 
	void (*handler)(void)	/**< user specific function to be called by timer interrupt */
	) 
{
	if (a_timeout == 0) timeout = 112;
	else timeout = a_timeout;
	user_timer_handler = handler;
}


/**
@brief	Unregister Timer Handler
*/
void kill_timer(void) 
{
	TR0 = 0;
	ET0 = 0; 
}
