#include "..\..\..\drivers\TCPIPcore.h"		// TCP/IP Core Definition
#include "httpd.h"
#include "task_config.h"
//#include "dhcp_task.h"
#include "romfile.h"	
#include "sockutil.h"
#include "lcd.h"


extern void user_flash_write(unsigned char *user_data);

/*******************************************************************************************/
/* If you have QFN64pin package W7100A, have to use 'USE_QFN64' definition in TCPIPcore.h  */
/*******************************************************************************************/

#define DEFAULT_HTTP_PORT			80

#define EVB_NET_SIP	"$SRC_IP_ADDRES$"
#define EVB_NET_GWIP	"$GW_IP_ADDRESS$"
#define EVB_NET_SN	"$SUB_NET__MASK$"
#define EVB_NET_MAC	"$SRC_MAC_ADDRESS$"
#define NET_CONFIG_CGI "NETCONF.CGI"

#define EVB_LCD_TEXT 	"$LCD_TEXT_VALUE$"
#define EVB_LED0_IMG	"$LED0_IMG$"
#define EVB_LED1_IMG	"$LED1_IMG$"
#define EVB_LED2_IMG	"$LED2_IMG$"
#define EVB_LED0_STAT	"$LED_0$"
#define EVB_LED1_STAT	"$LED_1$"
#define EVB_LED2_STAT	"$LED_2$"

void FlashWrite(unsigned char *pRcvBuffer, unsigned int len);
void DisplayBar(void);
void DisplayConfig(void);	  
void RomFileTest(void);
void ProcessWebSever(u_char ch);
static u_int replace_sys_env_value(u_char* base, u_int len);

static u_char* http_response;		/**< Pointer to HTTP response */
static st_http_request *http_request;	/**< Pointer to HTTP request */
extern StrConfigParam NetworkParam, MSGConfig;
char  homepage_default[ROM_FNAMELEN] = "index.html";

unsigned char bchannel_start;

unsigned char m_FlagWrite = 0;
unsigned char m_FlagFlashWrite = 0;

unsigned long m_FileSize = 0;
unsigned long m_FileWriteCount = 0;
//-----------------------------------------------------------------------------

//Initialize Functions
/***************************************************************************
 * Do not use Init_Network() function in TCPIPCORE.c file. *
 ***************************************************************************/	 		
void InitNetwork();					//Initialize Network 

/* HTTPs default network information setting */  	
uint8 xdata http_ip[4] = {192,168,1,2};                   		// for setting SIP register
uint8 xdata http_gw[4] = {192,168,1,1};                     	// for setting GAR register
uint8 xdata http_sn[4] = {255,255,255,0};                    	// for setting SUBR register			
uint8 xdata http_mac[6] = {0x00,0x08,0xDC,0x11,0x22,0x33};   	// for setting SHAR register

//TX/RX Buffer Memory Settings
//uint8 xdata txsize[MAX_SOCK_NUM] = {8,2,1,1,1,1,1,1};
//uint8 xdata rxsize[MAX_SOCK_NUM] = {8,2,1,1,1,1,1,1};
uint8 xdata txsize[MAX_SOCK_NUM] = {2,2,2,2,2,2,2,2};
uint8 xdata rxsize[MAX_SOCK_NUM] = {2,2,2,2,2,2,2,2};

#ifndef TEMP_FUNCTIONS
/* --------------------------------------------------------------------------------------------------*/

#define LED_ON								1
#define LED_OFF								0	
#define LCD_MAX_COL							16
uint8 xdata test_lcd_text[LCD_MAX_COL] = "WIZnet Test\0";
uint8 test_led_state[4] = {1,0,1,0};
uint8 test_sw_state[2] = {1,0};
unsigned int test_adc_val = 10;
unsigned int test_tc77_val = 0x8000;

u_char* evb_get_lcd_text(u_char row)
{
	row = row;
	return test_lcd_text;	
}

u_char led_state(u_char led)
{
	return test_led_state[led];
}

void led_off(u_char led)
{
	test_led_state[led] = 0;
}

void led_on(u_char led)
{
	test_led_state[led] = 1;
}

/* --------------------------------------------------------------------------------------------------*/
#endif

uint32 getIINCHIP_TxMAX(SOCKET s)
{
   return txsize[s];
}


void main()
{

	Init_iMCU(); 			// Initialize MCU
	lcd_init(); 
	InitNetwork();		// Initialize Network 

	printf("\r\nWIZ-Embedded WebServer Test Program.");
	
	SetConfig();
	
	//Display Net Configuration..
	DisplayConfig();	

	RomFileTest();
	
	while (1)
	{				   		
		/*
		if(NetworkParam.dhcp)
		{
			dhcp_task();
		}
		*/
		ProcessWebSever(0);
		ProcessWebSever(1);
		ProcessWebSever(2);
		ProcessWebSever(3);
		ProcessWebSever(4);
		ProcessWebSever(5);
		ProcessWebSever(6);
		ProcessWebSever(7);	
	}	

}

void InitNetwork()
{
	set_MEMsize(txsize, rxsize);
	// Set Retry Timer to 0x1388 (5000 x 100us = 0.5 seconds)  
	IINCHIP_WRITE(0x0017,0x13);  // RTR0 (0x0017) Upper Byte of register
	IINCHIP_WRITE(0x0018,0x88);	 // RTR1 (0x0018) Lower Byte of Register
}

void FlashWrite(unsigned char *pRcvBuffer, unsigned int len)
{
	if(m_FlagFlashWrite)
	{
		if (m_FileWriteCount == 0)
		{
			memcpy((unsigned char *)&m_FileSize, &pRcvBuffer[0], 4);
			write_to_flash(&pRcvBuffer[4], (len-4));
		}
		else
		{
			write_to_flash(&pRcvBuffer[0], len);
		}

		m_FileWriteCount += len;	

		if(m_FileWriteCount==(m_FileSize+4))
		{
			//end file send
			m_FlagFlashWrite =0;
			
			disconnect(0);
			
			((void (*)())0x0000)();		// reset
			return;
		}
	}
}


void DisplayBar(void)
{
	printf("\r\n================================================\r\n");
}

void DisplayConfig(void)
{

	u_char i = 0;
	DisplayBar();
	printf("       Net Config Information..\r\n");
	DisplayBar();
	
	printf("MAC ADDRESS      : ");
	//for(i=0; i<6;i++)printf("0x%02X.",IINCHIP_READ(SHAR0+i));
	printf("%02bX:%02bX:%02bX:%02bX:%02bX:%02bX",(uint8)IINCHIP_READ((uint16)(SHAR0+0)),(uint8)IINCHIP_READ((uint16)(SHAR0+1)),(uint8)IINCHIP_READ((uint16)(SHAR0+2)),(uint8)IINCHIP_READ((uint16)(SHAR0+3)),(uint8)IINCHIP_READ((uint16)(SHAR0+4)),(uint8)IINCHIP_READ((uint16)(SHAR0+5)));

	printf("\r\nSUBNET MASK      : ");
	for(i=0; i < 4; i++)
	{
		printf("%bu.", (uint8)IINCHIP_READ((uint16)(SUBR0+i)));
	}

	printf("\r\nG/W IP ADDRESS   : ");
	for(i=0; i < 4; i++)
	{
		printf("%bu.", (uint8)IINCHIP_READ((uint16)(GAR0+i)));
	}

	printf("\r\nLOCAL IP ADDRESS : ");
	for(i=0; i < 4; i++)
	{
		printf("%bu.", (uint8)IINCHIP_READ((uint16)(SIPR0+i)));
	}

	DisplayBar();
}

void RomFileTest(void)
{
	unsigned int address = 0;
	unsigned int len = 0;
	unsigned char ret;
	
	printf("index.html file search: ");	
	ret = search_file_rom(&homepage_default, (unsigned long *)&address, (unsigned long *)&len);

	if(ret>0)printf("OK.\r\n");
	else printf("Fail!\r\n");
}

void cgi_ipconfig(void)
{
	u_char * param;

	if((param = get_http_param_value(http_request->URI,"sip")))
	{
		inet_addr_((u_char*)param, &NetworkParam.ip[0]);		
	}
	if((param = get_http_param_value(http_request->URI,"gwip")))
	{
		inet_addr_((u_char*)param, &NetworkParam.gw[0]);	
	}			
	if((param = get_http_param_value(http_request->URI,"sn")))
	{
		inet_addr_((u_char*)param, &NetworkParam.subnet[0]);		
	}

	NetworkParam.ver[0] = VER_H;
	NetworkParam.ver[1] = VER_L;
	user_flash_write((unsigned char *)&NetworkParam);
}

//-----------------------------------------------------------------------------

/**
 @brief	Analyse HTTP request and then services WEB.
*/
extern unsigned int m_OldPage;
//static void proc_http(SOCKET s,	u_char * buf, int length)
static void proc_http(SOCKET s,	u_char * buf)
{
	//prog_char * content;
	char* name;
	char * param;
	unsigned long file_len;
	unsigned int send_len;
	unsigned long content = 0;
//	unsigned int i;
//	unsigned long value =0 ;
	
	http_response = (u_char*)RX_BUF;
	http_request = (st_http_request*)TX_BUF;
	
	parse_http_request(http_request, buf);			// After analyze request, convert into http_request

	//method Analyze
	switch (http_request->METHOD)				
	{
	case METHOD_ERR :	
		memcpy(http_response, ERROR_REQUEST_PAGE, sizeof(ERROR_REQUEST_PAGE));
		send(s, (u_char *)http_response, strlen((char*)http_response));
		break;
	case METHOD_HEAD:
	case METHOD_GET:
	case METHOD_POST:
		name = get_http_uri_name(http_request->URI);
		
		if (!strcmp(name, "/")) strcpy(name, homepage_default);	// If URI is "/", respond by index.htm 
#ifdef WEB_DEBUG
		if(strlen(name)	< 80)	printf("PAGE : %s", name);
		else printf("TOO LONG FILENAME");
#endif 			
		find_http_uri_type(&http_request->TYPE, name);	//Check file type (HTML, TEXT, GIF, JPEG are included)
#ifdef WEB_DEBUG			
		printf("find_type() ok");
#endif		

		if(http_request->TYPE == PTYPE_CGI)
		{
			if(strstr(name,"LCDCTL.CGI"))
			{
				if((param = get_http_param_value(http_request->URI,"lcd0")))
				{
					*(param+16) = 0;
					evb_set_lcd_text(1,(u_char*)param);
				}
				
				strcpy(name,"dout.htm");
				find_http_uri_type(&http_request->TYPE, name);				
			}
			else if(strstr(name,"LEDCTL.CGI"))
			{			
				if((param = get_http_param_value(http_request->URI,"led0")))
				{
					if(!strcmp(param,"on")) led_on(0);
					else			led_off(0);
				}
				else led_off(0);
				
				if((param = get_http_param_value(http_request->URI,"led1")))
				{
					if(!strcmp(param,"on"))led_on(1);
					else led_off(1);
				}
				else led_off(1);
				
				if((param = get_http_param_value(http_request->URI,"led2")))
				{
					if(!strcmp(param,"on"))led_on(2);
					else led_off(2);
				}
				else led_off(2);
				
				strcpy(name,"dout.htm");
				find_http_uri_type(&http_request->TYPE, name);
			}
			else	 if(strstr(name,NET_CONFIG_CGI))
			{
				cgi_ipconfig();

				memcpy(http_response, RETURN_CGI_PAGE, sizeof(RETURN_CGI_PAGE));
				send(s, (u_char *)http_response, strlen((char*)http_response));				
				
				disconnect(0);
				
				((void (*)())0x0000)();		// reset
				
				return;
			}
		}
		
		/* Search the specified file in stored binaray html image */
		//if (!search_file(name, &content, &file_len))		//if the file do not exist then
		if(!search_file_rom((unsigned char *)name, &content, &file_len))
		{
			memcpy(http_response, ERROR_HTML_PAGE, sizeof(ERROR_HTML_PAGE));
			send(s, (u_char *)http_response, strlen((char*)http_response));	
#ifdef WEB_DEBUG				
			printf("Unknown Page");
#endif				
		} 
		else	// if search file sucess 
		{
#ifdef WEB_DEBUG				
			printf("find file ok");
#endif				
			if(http_request->TYPE != PTYPE_CGI)			
			{
				make_http_response_head((char*)http_response, http_request->TYPE, (u_long)file_len);			
				send(s, http_response, strlen((char*)http_response));
			}
			
			//printf("name=%s\r\n", name);

			
			while(file_len) 
			{
				if (file_len >= TX_RX_MAX_BUF_SIZE-1)
					send_len = TX_RX_MAX_BUF_SIZE-1;
				else	send_len = file_len;
			
				#if 0
				for(i=0;i<send_len;i++)
				{
					http_response[i] = read_from_flash(m_CurRdAddress++);
				}
				#endif
				
				#if 1
				read_from_flashbuf(content, &http_response[0], send_len);
				#endif
				
				*(http_response+send_len+1) = 0;

				// Replace htmls' system environment value to real value
				if(http_request->TYPE==PTYPE_HTML)
				{
					send_len = replace_sys_env_value(http_response,send_len);
				}
				else 
				if(http_request->TYPE==PTYPE_CGI)
				{
					send_len = replace_sys_env_value(http_response,send_len);
				}
				else if(http_request->TYPE == PTYPE_TEXT)
				{
					if(strstr(name,"adc_val.xml"))
					{
						
						send_len = replace_sys_env_value(http_response,send_len);
					}						
				}
	
				send(s, http_response, send_len);
				content += send_len;
				file_len -= send_len;
			}
        }
		break;
	default :
		break;
	}
}



/**
 @brief	Replace HTML's variables to system configuration value
*/
static u_int replace_sys_env_value(u_char* base, u_int len)
{
	u_char str[18];	
	u_char *ptr = base;
	u_char *tptr = base;
	unsigned long temp;
	unsigned int read_val = 0;
	
	while((ptr=(u_char*)strchr((char*)tptr,'$')))
	{
		if((tptr=(u_char*)strstr((char*)ptr,EVB_NET_SIP)))
		{
			memcpy((unsigned char*)&temp, &NetworkParam.ip[0], 4);
			memcpy(tptr,(unsigned char*)inet_ntoa(ntohl(temp)),15);

			tptr+=15;
		}
		else if((tptr=(u_char*)strstr((char*)ptr,EVB_NET_GWIP)))
		{
			memcpy((unsigned char*)&temp, &NetworkParam.gw[0], 4);
			memcpy(tptr,(unsigned char*)inet_ntoa(ntohl(temp)),15);
			tptr+=15;
		}
		else if((tptr=(u_char*)strstr((char*)ptr,EVB_NET_SN)))
		{
			memcpy((unsigned char*)&temp, &NetworkParam.subnet[0],4);
			memcpy(tptr,(unsigned char*)inet_ntoa(ntohl(temp)),15);
			tptr+=15;
		}
		else if((tptr=(u_char*)strstr((char*)ptr,EVB_NET_MAC)))
		{
			sprintf((char*)str,"%02bX:%02bX:",NetworkParam.mac[0],NetworkParam.mac[1]);
			sprintf((char*)(str+6),"%02bX:%02bX:",NetworkParam.mac[2],NetworkParam.mac[3]);
			sprintf((char*)(str+12),"%02bX:%02bX",NetworkParam.mac[4],NetworkParam.mac[5]);
			memcpy(tptr,str,17);
			tptr+=17;
		}
		else if((tptr=(u_char*)strstr((char*)ptr,EVB_LCD_TEXT)))
		{
			memset(tptr,0x20,16);
			memcpy(tptr,(unsigned char*)evb_get_lcd_text(1),16);
			tptr+=16;
		}
		//-------------------------------------------------------		
		else if((tptr=(u_char*)strstr((char*)ptr,EVB_LED0_IMG)))
		{
			memset(tptr,0,10);
			
			if(led_state(0)==LED_ON){
				memcpy(tptr,"led_on.gif",10);
				P0_3 = 0;
			}
			else{
				memcpy(tptr,"led_of.gif",10);
				P0_3 = 1;
			}

			tptr+=10;
		}
		//-------------------------------------------------------
		else if((tptr=(u_char*)strstr((char*)ptr,EVB_LED1_IMG)))
		{
			memset(tptr,0,10);
			if(led_state(1)==LED_ON){
				memcpy(tptr,"led_on.gif",10);
				P0_4 = 0;
			}
			else{
				memcpy(tptr,"led_of.gif",10);
				P0_4 = 1;
			}
			tptr+=10;
		}
		else if((tptr=(u_char*)strstr((char*)ptr,EVB_LED2_IMG)))
		{
			memset(tptr,0,10);
			if(led_state(2)==LED_ON){
				memcpy(tptr,"led_on.gif",10);
				P0_5 = 0;
			}
			else{
				memcpy(tptr,"led_of.gif",10);
			 	P0_5 = 1;
			}
			tptr+=10;
		}	
		else if((tptr=(u_char*)strstr((char*)ptr,EVB_LED0_STAT)))
		{
			memset(tptr,0x20,7);
			if(led_state(0)==LED_ON) memcpy(tptr,"checked",7);
			tptr+=7;
		}			
		else if((tptr=(u_char*)strstr((char*)ptr,EVB_LED1_STAT)))
		{
			memset(tptr,0x20,7);
			if(led_state(1)==LED_ON) memcpy(tptr,"checked",7);
			tptr+=7;
		}
		//-------------------------------------------------------
		else if((tptr=(u_char*)strstr((char*)ptr,EVB_LED2_STAT)))
		{
			memset(tptr,0x20,7);
			if(led_state(2)==LED_ON) memcpy(tptr,"checked",7);
			tptr+=7;
		}

		else
		{
			return len;
			
			if(ptr==base)
			{
				return len;
			}
			tptr = ptr;
			break;
		}
	}

	if(!ptr) return len;
	
	return (u_int)(tptr-base);
}


//processing http protocol , and excuting the followed fuction.
void ProcessWebSever(u_char ch)
{
	int len;
	u_int wait_send=0;

	http_request = (st_http_request*)RX_BUF;		// struct of http request
	
	/* http service start */
	switch(getSn_SR(ch))
	{
	case SOCK_ESTABLISHED:
		if(bchannel_start==1)
		{
			bchannel_start = 2;
		}
		if ((len = getSn_RX_RSR(ch)) > 0)		
		{
			if ((u_int)len > MAX_URI_SIZE) len = MAX_URI_SIZE;				
			len = recv(ch, (u_char*)http_request, len);
			*(((u_char*)http_request)+len) = 0;
			
#ifdef WEB_DEBUG				
			printf( "- HTTP REQUEST -");
#endif				
			proc_http(ch, (u_char*)http_request);	// request is processed
		
			while(getSn_TX_FSR(ch)!= getIINCHIP_TxMAX(ch))
			{
			
				if(wait_send++ > 1500)
				{
#ifdef WEB_DEBUG				
					printf( "HTTP Response send fail");
#endif				
					break;
				}
				//Delay(1);
				
			}
			disconnect(ch);
		}
		break;


	case SOCK_CLOSE_WAIT:   
#ifdef WEB_DEBUG	
		printf("CLOSE_WAIT : %d",ch);	// if a peer requests to close the current connection
#endif		
		disconnect(ch);
		bchannel_start = 0;
	case SOCK_CLOSED:                   
		if(!bchannel_start)
		{
//#ifdef WEB_DEBUG		
			//printf("%d : Web Server Started.\r\n",ch);
			printf("Web Server Started.\r\n");
//#endif				
			bchannel_start = 1;
		}

		if(socket(ch, Sn_MR_TCP, DEFAULT_HTTP_PORT, 0x00) == 0)    /* reinitialize the socket */
		//DEFAULT_LISTEN_PORT
		{
			bchannel_start = 0;
		}
		else	listen(ch);
		break;
	}	// end of switch 
}

