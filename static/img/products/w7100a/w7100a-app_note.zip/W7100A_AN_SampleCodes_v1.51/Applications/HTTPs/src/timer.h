/*
*
@file		timer.h
@brief	DHCP Timer related functions. (AVR-GCC Compiler)
*
*/
#ifndef __TIMER_H__
#define __TIMER_H__

extern void init_timer(void);
extern void set_timer(unsigned int a_timeout, void (*handler)(void));
extern void kill_timer(void);
#endif
