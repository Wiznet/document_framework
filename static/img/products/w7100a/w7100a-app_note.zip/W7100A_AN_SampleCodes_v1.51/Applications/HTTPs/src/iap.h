#ifndef __IAP_H
#define __IAP_H

/*================================================================*/

#define BR_691200	0xAA
#define BR_230400	0xBB
#define BR_115200	0xFF
#define BR_57600	0xFE
#define BR_38400	0xFD
#define BR_19200	0xFA
#define BR_9600		0xF4
#define BR_4800		0xE8
#define BR_2400		0xD0
#define BR_1200		0xA0

#define F_XON  		1
#define F_RTS  		2

/*================================================================*/
#define EE_TOTAL  160	

#define EE_MODE  0  // Operation Mode

#define EE_MAC1  1 // MAC
#define EE_MAC2  2
#define EE_MAC3  3
#define EE_MAC4  4
#define EE_MAC5  5
#define EE_MAC6  6

#define EE_KIND  7  // sever 1, client 0, only server mode 2

#define EE_IA1   8  // IP addr
#define EE_IA2   9
#define EE_IA3   10
#define EE_IA4   11

#define EE_SM1   12  // Subnet mask
#define EE_SM2   13
#define EE_SM3   14
#define EE_SM4   15

#define EE_GW1   16 // Gateway addr
#define EE_GW2   17
#define EE_GW3   18
#define EE_GW4   19

#define EE_LPORTH 20
#define EE_LPORTL 21

#define EE_SIA1  22 // Server IP (if EE_KIND == client)
#define EE_SIA2  23
#define EE_SIA3  24
#define EE_SIA4  25

#define EE_SPORTH 26 // Server Port Number
#define EE_SPORTL 27

/* Serial Info */
#define EE_BAUD    28  // serial baudrate
#define EE_DSIZE   29  // Data size : 8, 7
#define EE_PARITY  30  // Parity : none, even, odd
#define EE_STOP    31  // Stop bit : 1, 2
#define EE_FLOW    32  // Flow control : None, Xon/off, RTS/CTS

/* Delimiter Info */
#define EE_D_CH	   33   // delimiter char..
#define EE_D_SIZE1  34  // delimiter SIZE..
#define EE_D_SIZE2  35  // delimiter SIZE..	
#define EE_D_TIME1  36  // delimiter TIME..
#define EE_D_TIME2  37  // delimiter TIME..

/* idle time parameter */
#define EE_I_TIME1  38  // delimiter TIME..
#define EE_I_TIME2  39  // delimiter TIME..

#define EE_DEBUG  40  // Debug code

#define EE_VER_H  41  // SW_Version
#define EE_VER_L  42  // SW_Version

#define EE_DHCP   43 // DHCP 1 0n, 0 0ff
#define EE_UDP   44 //

/* status byte */
#define EE_DNS_FLAG  46
#define EE_DNS_IP  	 47  // DNS server IP address
#define EE_DOMAIN 	 51  // 32 byte

#define EE_SCFG		83
#define EE_SCFGSTR	84

#define EE_PPPOE_ID		87
#define EE_PPPOE_PWD	119

#define EE_EnTCPPass	151
#define EE_TCPPass		152

#define PPP_MAC		160
#define PPP_SID		166

void user_flash_write(unsigned char *user_data);
void user_flash_read(unsigned char *user_data);
void flash_write( unsigned short isp_addr, unsigned char *user_data, int len );
void flash_read( unsigned short isp_addr, unsigned char *user_data, int len );
#endif

