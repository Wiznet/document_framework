/*
*
@file		util.h
*/

#ifndef _UTIL_H_
#define _UTIL_H_

#include "..\..\..\drivers\w7100.h"

#define sei() {EA = 1;}
#define cli() {EA = 0;}

extern char C2D(unsigned char c); 					/* Convert a character to HEX */
extern unsigned int ATOI(char* str, unsigned int base); 			/* Convert a string to integer number */
extern char * strtok(char * s,const char * ct); 		/* Tokenize a string */
extern void replacetochar(char * str, char oldchar, char newchar); /* Replace old character with new character in the string */
#endif /* _UTIL_H */

