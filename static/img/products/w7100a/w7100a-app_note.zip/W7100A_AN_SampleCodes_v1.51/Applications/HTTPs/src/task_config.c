#include <stdio.h>
#include <string.h>
#include "..\..\..\drivers\types.h"
#include "..\..\..\drivers\socket.h"
#include "util.h"
#include "sockutil.h"
#include "..\..\..\drivers\TCPIPCore.h"
#include "task_config.h"

StrConfigParam NetworkParam, MSGConfig;
extern unsigned char m_FlagFlashWrite;

extern void user_flash_write(unsigned char *user_data);
extern void user_flash_read(unsigned char *user_data);

/* HTTPs default network information setting */  	
extern uint8 xdata http_ip[4];          // for setting SIP register
extern uint8 xdata http_gw[4];          // for setting GAR register
extern uint8 xdata http_sn[4];          // for setting SUBR register			
extern uint8 xdata http_mac[6];   		// for setting SHAR register

void setSHAR(uint8 * addr)
{
	uint8 k;

	for(k = 0; k < 6; k++) {
		IINCHIP_WRITE(((uint16)SHAR0+k), addr[k]);
	}
}

void setGAR(uint8 * addr)
{
	IINCHIP_WRITE(((uint16)(GAR0)), addr[0]);
	IINCHIP_WRITE(((uint16)(GAR0+1)), addr[1]);
	IINCHIP_WRITE(((uint16)(GAR0+2)), addr[2]);
	IINCHIP_WRITE(((uint16)(GAR0+3)),addr[3]);
}

void setSUBR(uint8 * addr)
{
	IINCHIP_WRITE(((uint16)(SUBR0)), addr[0]);
	IINCHIP_WRITE(((uint16)(SUBR0+1)), addr[1]);
	IINCHIP_WRITE(((uint16)(SUBR0+2)), addr[2]);
	IINCHIP_WRITE(((uint16)(SUBR0+3)), addr[3]);
}

void setSIPR(uint8 * addr)
{
	IINCHIP_WRITE(((uint16)(SIPR0)), addr[0]);
	IINCHIP_WRITE(((uint16)(SIPR0+1)), addr[1]);
	IINCHIP_WRITE(((uint16)(SIPR0+2)) ,addr[2]);
	IINCHIP_WRITE(((uint16)(SIPR0+3)), addr[3]);
}



//-----------------------------------------------------------------------------
void default_network(void)
{	
	NetworkParam.op[0] = 0x82;
	NetworkParam.op[1] = 0x82;
	NetworkParam.op[2] = 0x82;
	NetworkParam.op[3] = 0x82;

	NetworkParam.ver[0] = 0x00;
	NetworkParam.ver[1] = 0x00;

	NetworkParam.mac[0] = http_mac[0];
	NetworkParam.mac[1] = http_mac[1];
	NetworkParam.mac[2] = http_mac[2];
	NetworkParam.mac[3] = http_mac[3];
	NetworkParam.mac[4] = http_mac[4];
	NetworkParam.mac[5] = http_mac[5];

	NetworkParam.ip[0] = http_ip[0];
	NetworkParam.ip[1] = http_ip[1];
	NetworkParam.ip[2] = http_ip[2];
	NetworkParam.ip[3] = http_ip[3];

	NetworkParam.subnet[0] = http_sn[0];
	NetworkParam.subnet[1] = http_sn[1];
	NetworkParam.subnet[2] = http_sn[2];
	NetworkParam.subnet[3] = http_sn[3];

	NetworkParam.gw[0] = http_gw[0];
	NetworkParam.gw[1] = http_gw[1];
	NetworkParam.gw[2] = http_gw[2];
	NetworkParam.gw[3] = http_gw[3];

	NetworkParam.dhcp = 0x01;
/*
	NetworkParam.myMac[0] = 0x00;
	NetworkParam.myMac[1] = 0x00;
	NetworkParam.myMac[2] = 0x00;
	NetworkParam.myMac[3] = 0x00;
	NetworkParam.myMac[4] = 0x00;
	NetworkParam.myMac[5] = 0x00;
*/
	NetworkParam.pad = 0x00;

	user_flash_write((unsigned char *)&NetworkParam);
}


//-----------------------------------------------------------------------------
void SetConfig(void)
{
	unsigned char temp;
	RawConfigParam * conf = &NetworkParam;

	// Get Network Parameters
	user_flash_read((unsigned char *)&NetworkParam);	
	temp = NetworkParam.op[0];

	
	if( temp != SPECIALOP) 
	{
		// This board is initial state
		default_network();
	}
	else
	{
		//check version
		if ((NetworkParam.ver[0] != VER_H)||(NetworkParam.ver[1] != VER_L))
		{
			NetworkParam.ver[0] = VER_H;
			NetworkParam.ver[1] = VER_L;
			user_flash_write((unsigned char *)&NetworkParam);
		}
	}

	setSIPR(NetworkParam.ip);
	setGAR(NetworkParam.gw);
	setSUBR(NetworkParam.subnet);
	setSHAR(NetworkParam.mac);
}
//-----------------------------------------------------------------------------
