/*
*
@file		util.c
@brief	The utility functions for AVREVB. (AVR-GCC Compiler)
*
*/

#include "..\..\..\drivers\types.h"
#include "httpd.h"

static char * ___strtok=NULL;


/**
@brief	CONVERT CHAR INTO HEX
@return	HEX
  
This function converts HEX(0-F) to a character
*/
char C2D(
	u_char c	/**< is a character('0'-'F') to convert to HEX */
	)
{
	if (c >= '0' && c <= '9')
		return c - '0';
	if (c >= 'a' && c <= 'f')
		return 10 + c -'a';
	if (c >= 'A' && c <= 'F')
		return 10 + c -'A';

	return (char)c;
}


/**
@brief	CONVERT STRING INTO INTEGER
@return	a integer number
*/
u_int ATOI(
	char* str,	/**< is a pointer to convert */
	u_int base	/**< is a base value (must be in the range 2 - 16) */
	)
{
        unsigned int num = 0;
        while (*str !=0)
                num = num * base + C2D(*str++);
	return num;
}

 /**
@brief	Calculate the length of the initial substring of "s" which only contain letters in "accept"
@return	The string to search for
*/
size_t strspn(
	const char *s, 		/**< The string to be searched */
	const char *accept	/**< The string to search for */
	)
{
	const char *p;
	const char *a;
	size_t count = 0;

	for (p = s; *p != '\0'; ++p) {
		for (a = accept; *a != '\0'; ++a) {
			if (*p == *a)
				break;
		}
		if (*a == '\0')
			return count;
		++count;
	}

	return count;
}

/**
@brief	Find the first occurrence of a set of characters
*/
char * strpbrk(
	const char * cs,	/**< The string to be searched */
	const char * ct	/**< The characters to search for */
	)
{
	const char *sc1,*sc2;

	for( sc1 = cs; *sc1 != '\0'; ++sc1) {
		for( sc2 = ct; *sc2 != '\0'; ++sc2) {
			if (*sc1 == *sc2)
				return (char *) sc1;
		}
	}
	return NULL;
}



/**
@brief	Split a string into tokens

		WARNING: strtok is deprecated, use strsep instead.
*/ 
char * strtok(
	char * s,			/**< The string to be searched */
	const char * ct	/**< The characters to search for */
	)
{
	char *sbegin, *send;

	sbegin  = s ? s : ___strtok;
	if (!sbegin) {
		return NULL;
	}
	sbegin += strspn(sbegin,ct);
	if (*sbegin == '\0') {
		___strtok = NULL;
		return( NULL );
	}
	send = strpbrk( sbegin, ct);
	if (send && *send != '\0')
		*send++ = '\0';
	___strtok = send;
	return (sbegin);
}


/**
@brief	replace the specified character in a string with new character
*/ 
void replacetochar(
	char * str, 		/**< pointer to be replaced */
	char oldchar, 	/**< old character */
	char newchar	/**< new character */
	)
{
	int x;
	for (x = 0; str[x]; x++) 
		if (str[x] == oldchar) str[x] = newchar;	
}

