uint32 bigint_create(uint32 len, bigint *xi)	//Bigint �����
{
	xi->len = len;
	xi->dats = (uint32 *)malloc(len*sizeof(uint32));	  
	if(xi -> dats == NULL) return 0;
	return len;
}

void bigint_release(bigint *xi)		//Bigint�����
{
 	xi->len = 0;
	SAFE_FREE(xi->dats);
}

uint32 bigint_resize(uint32 newsize, bigint *xi)	//Bigint ũ�� �缳��
{
 	xi->len = newsize;
	xi->dats = (uint32*)realloc(xi->dats, newsize*sizeof(uint32));
	if(xi->dats == NULL) return 0;
	return newsize;
}

void bigint_setu32(bigint *dest, uint32 src)	//Bigint�� uint32�� �ֱ�
{
 	dest->dats[0] = src;
	memset(&dest->dats[1], 0, (dest->len -1)*sizeof(uint32));
}

void bigint_set(bigint *dest, bigint *src)	   //Bigint�� Bigint�� �ֱ�
{
 	memcpy( dest->dats, src->dats, ( (dest->len < src->len)?dest->len:src->len)*sizeof(uint32) );
}

uint32 add_a(uint32 len, uint32* dest, uint32 *src)	//Add two uint32 array
{
	uint32 carry = 0;
	uint32 i;
	for(i=0; i<len; ++i)
	{
		dest[i] += src[i];
		if(carry)
		{
		 	if(dest[i] >= src[i]) carry = 0;
			if(dest[i] == 0xFFFFFFFF) carry = 1;
			++dest[i];
		}
		else
		{
		 	if(dest[i] < src[i]) carry = 1;
		}	
	}
	return carry;	
}

uint32 add_u32(uint32 len, uint32* dest, uint32 src)
{
	uint32 carry = 0;
	uint32 i;
	dest[0] += src;
	if(dest[0]<src) carry = 1;
	for(i=1; i<len; ++i)
	{
	 	if(carry)
		{
			if(dest[i] != 0xFFFFFFFF) carry = 0;
			++dest[i];
		}
		else
		{
			break;
		}
	}
	return carry;
}

void bigint_add(bigint *dest, const bigint *src)
{
	if(dest->len < src->len)
	{
	 	add_a(dest->len, dest->dats, src->dats);
	}
	else
	{
		if(add_a(src->len, dest->dats, src->dats))
		{
		 	add_u32(dest->len - src->len, &dest->dats[src->len], 1);
		}
	}

}