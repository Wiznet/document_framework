#include "..\..\..\..\drivers\TCPIPCore.h"
#include "lcd.h"
#include "loopback.h"																							

#define	MAX_BUF_SIZE	8192		// Maximum receive buffer size

/*******************************************************************************************/
/* If you have QFN64pin package W7100A, have to use 'USE_QFN64' definition in TCPIPcore.h  */
/*******************************************************************************************/

uint8 xdata * data_buf =(uint8 xdata *)0x7000;	// Position of receive buffer

void main()
{	   
	Init_iMCU();		// Initialize   iMCUW7100
	lcd_init();     // Initialize Charater LCD
	evb_set_lcd_text(0,(uint8 *) "iMCU7100EVB");
	Init_Network(); 	// Initialize   Network Configuration

	//start message
	printf("\r\n-------LOOPBACK_TEST_START--------\r\n");
	while(1){
			loopback_tcps(0, 5000,data_buf, 0);	
			loopback_tcps(1, 5000,data_buf, 0);	
			loopback_tcps(2, 5000,data_buf, 0);	
			loopback_tcps(3, 5000,data_buf, 0);	
			loopback_tcps(4, 5000,data_buf, 0);	
			loopback_tcps(5, 5000,data_buf, 0);	
			loopback_tcps(6, 5000,data_buf, 0);	
			loopback_tcps(7, 5000,data_buf, 0);	
	}

}