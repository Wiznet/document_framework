#include "..\..\..\..\drivers\TCPIPCore.h"
#include "loopback.h"


//#define DEBUG_PRINT

void loopback_tcps(SOCKET s, uint16 port, uint8 xdata * data_buf, uint16 mode)
{
  uint16 len;
 
  switch (getSn_SR(s))
	{
	case SOCK_ESTABLISHED:						/* if connection is established */
	    if(getSn_IR(s) & Sn_IR_CON)      // check Sn_IR_CON bit
        {
            printf("Connected from client!! \r\n");
            setSn_IR(s,Sn_IR_CON);        // clear Sn_IR_CON
        }
		if ((len = getSn_RX_RSR(s)) > 0) 			/* check Rx data */
		{
			len = recv(s, data_buf, len);			/* read the received data */
#ifdef DEBUG_PRINT
			printf("CH %bu: Received %bu bytes from Client \r\n",  s,len);
#endif
			len = send(s, data_buf, len);				/* send the received data */
#ifdef DEBUG_PRINT
			printf("CH %bu: Send %bu bytes to Client \r\n",  s, len);
#endif

		}
		break;
	case SOCK_CLOSE_WAIT:                       		/* If the client request to close */
		printf("CLOSE_WAIT : %bu\r\n",  s);
		if ((len = getSn_RX_RSR(s)) > 0) 			/* check the remain data */
		{
			len = recv(s, data_buf, len);			
			send(s, data_buf,len);                 
		}
		disconnect(s);
		break;

	case SOCK_CLOSED:                                               /* if a socket is closed */
		printf("CLOSED. CH : %bu\r\n",  s);
		close(s);
		socket(s, (Sn_MR_TCP), port, Sn_MR_ND);
		//socket(s, (Sn_MR_TCP),port,0x00);
		break;

	case SOCK_INIT:                                               /* if a socket is initiated */
		listen(s);
		printf("LOOPBACK_TCPSStarted. CH : %bu \r\n",  s);
		break;

	}
}





