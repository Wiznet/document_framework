
#include "..\..\..\..\drivers\TCPIPCore.h"
#include "loopback.h"

//#define DEBUG_PRINT

void loopback_tcpc(SOCKET s, uint16 port, uint8 xdata * data_buf, uint16 mode)
{																													  																													
	static uint8 bconnect = 0;
	uint16 xdata len;
	static uint16 xdata any_port = 1000;
	//uint8 destip[4] = {192,168,1,214};
	//uint8 destip[4] = {173,194,79,103}; // www.google.com - ARP Failed
	//uint8 destip[4] = {114,108,157,117}; // www.daum.net - ARP Failed
	//uint8 destip[4] = {118,129,166,160}; // www.wiznet.co.kr		 
	uint8 destip[4] = {203, 230, 100, 94}; 

	switch(getSn_SR(s))
	{
	 case SOCK_ESTABLISHED:              // ESTABLISHED?
         if(getSn_IR(s) & Sn_IR_CON)      // check Sn_IR_CON bit
         {
            printf(" %bu : Connected to %.3bu. %.3bu. %.3bu. %.3bu \r\n", 
			        s,  destip[0], destip[1], destip[2], destip[3]);
            setSn_IR(s,Sn_IR_CON);        // clear Sn_IR_CON
         }
         if((len=getSn_RX_RSR(s)) > 0)    // check the size of received data
         {
		 	printf("receive start!!!!!!!\r\n");

            len = recv(s,data_buf,len);        // recv

#ifdef DEBUG_PRINT
			printf("CH %bu: Received %bu bytes from Server: %.3bu. %.3bu. %.3bu. %.3bu \r\n", 
	  		        s, len,  destip[0], destip[1], destip[2], destip[3]);
#endif
										 
            len = send(s,data_buf,len);     // send

#ifdef DEBUG_PRINT
			printf("CH %bu: Send %bu bytes to Server \r\n",  s, len);
#endif
         }
         break;
                                          // ---------------
   case SOCK_CLOSE_WAIT:                  // PASSIVE CLOSED
      disconnect(s);                   // disconnect 
      break;
                                          // --------------
   case SOCK_CLOSED:                      // CLOSED
      close(s);                           // close the SOCKET
      socket(s,Sn_MR_TCP,any_port++, mode);   // open the SOCKET with TCP mode and any source port number
	  printf("socket init OK!\r\n");
	  bconnect = 0;
      break;
                                          // ------------------------------
   case SOCK_INIT:                        // The SOCKET opened with TCP mode
      if(bconnect) return;
	  connect(s, destip, port);             // Try to connect to "TCP SERVER"
	  bconnect = 1;
      printf(" : LOOPBACK_TCPC Started :\r\n");
      break;

   default:
      break;
  }
}





