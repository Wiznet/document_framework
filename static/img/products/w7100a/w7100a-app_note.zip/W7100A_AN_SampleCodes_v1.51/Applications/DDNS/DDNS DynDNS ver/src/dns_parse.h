#ifndef	_DNS_PARSE_H_
#define	_DNSPARSE_H_


#define	MAX_DNS_BUF_SIZE	256		/* maximum size of DNS buffer. */


uint8 parseMSG(struct dhdr * dhdr, uint8 * buf);

#endif

