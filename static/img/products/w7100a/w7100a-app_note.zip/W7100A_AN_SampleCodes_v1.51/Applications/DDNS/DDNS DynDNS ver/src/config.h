#ifndef _CONFIG_H_
#define _CONFIG_H_

struct _CHCONF
{
	unsigned char 	Setted;
	unsigned char 	Sock_Type;	 // TCP or UDP
	unsigned char    Connected;

	unsigned char 	Sock_Mode;	 // Server mode, Client mode
	unsigned char 	UDP_IP[4];
	unsigned int 	UDP_Port;
	unsigned char 	Sock_state;
};

#define CON_STATUS  		P0_5
#define RTS_PIN				P0_6
#define CTS_PIN				P0_7

#define PPP_TRIAL_COUNT		3
#define DNS_TRIAL_COUNT		2

//#define DEBUG_PPPoE
//#define DHCP_DEBUG


#endif /* _CONFIG_H_ */
