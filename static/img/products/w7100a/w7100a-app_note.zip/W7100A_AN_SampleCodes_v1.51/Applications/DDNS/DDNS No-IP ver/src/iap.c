#pragma userclass(CODE = ISP)
#include <stdio.h>
#include "..\..\..\..\drivers\w7100.h"
#include "iap.h"
#include "..\..\..\..\drivers\serial.h"
#include "..\..\..\..\drivers\types.h"

unsigned int xdata rwAddr;
unsigned char xdata rwData;
unsigned char xdata Sector;

extern uint8 xdata Mac[6];
extern uint8 code default_setting[159];

extern void iap_write_eeprom();			// 1 Byte EEPROM Write
extern void iap_erase_eeprom();			// 1 EEPROM Sector Erase (1 Sector = 256byte)
extern void iap_read_eeprom();			// 1 Byte EEPROM Read
extern void iap_write();				// 1 Byte Flash Write
extern void iap_erase();				// 1 Flash Sector Erase (1 Sector = 256byte)

#define FLASH_RESET()\    
{\
 PCON |= 0x10;\
 (*((volatile unsigned char xdata*) 0x0000) = 0xF0);\
 PCON &= ~0x10;\
}

#define ISP_ENTRY 0x07FD
#define ISP_SERASE         0x30    // Sector Erase Command
#define ISP_MERASE         0x10    // Chip Erase Command
#define ISP_BPROG          0xA0    // Byte Program Command
#define ISP_SECPROG        0xA1    // Sector Program Command
#define ISP_CHIPROG        0xA2    // Chip Program Command
#define ISP_BREAD          0x00    // Byte Read Command
#define ISP_DATAERASE       0xD0    // Sector Erase Command for Data Flash
#define ISP_DATAPROG        0xD1    // Byte Program Command for Data Flash
#define ISP_DATAREAD        0xD2    // Read Command for Data Flash
#define ISP_chip_erase()            do_isp(ISP_MERASE,0,0)
#define ISP_sector_erase(FSADDR)     do_isp(ISP_SERASE,FSADDR,0)
#define ISP_write_byte(FBADDR,DAT)   do_isp(ISP_BPROG,FBADDR,DAT)
#define ISP_read_byte(FBADDR)        do_isp(ISP_BREAD,FBADDR,0)
#define ISP_data_erase()       do_isp(ISP_DATAERASE,0,0)

#define ISP_chip_prog(RSADDR,READDR,FSADDR) \
{\
   RAMBA16 = RSADDR; \
   RAMEA16 = READDR; \
   do_isp(ISP_CHIPROG,FSADDR,0); \
}

#define ISP_sector_prog(RSADDR,READDR,FSADDR) \
{\
   RAMBA16 = RSADDR; \
   RAMEA16 = READDR; \
   do_isp(ISP_SECPROG,FSADDR,0); \
}

#define ISP_data_sector_read(RSADDR) \
{\
   RAMBA16 = RSADDR; \
   do_isp(ISP_DATAREAD,0,0); \
}


#define ISP_data_sector_prog(RSADDR) \
{\
   RAMBA16 = RSADDR; \
   do_isp(ISP_DATAPROG,0,0); \
}


unsigned char do_isp(unsigned char isp_id, unsigned short isp_addr, unsigned char isp_data)
{
   uint8 TMPR0 = 0;
   TMPR0 = EA;    // backup EA
   EA = 0;    // disable EA
   WCONF &= ~(0x40);     // Enable ISP Entry
   ISPID = isp_id;
   ISPADDR16 = isp_addr;
   ISPDATA = isp_data;
   ((void(code*)(void))ISP_ENTRY)();    // call ISP Entry
   WCONF |= 0x40;        // Disable ISP Entry
   EA = TMPR0;    // restore EA
   return ISPDATA;
}

void eraseApp(void)
{
	unsigned int j;

	for (j=0x4000; j<=0xf000; j=j+0x400) ISP_sector_erase(j);
}

void writeFlash(unsigned int add, unsigned char dat)
{
	ISP_write_byte(add, dat);
}


unsigned char EEP_Block_Write( unsigned char ee_rwAddr, unsigned char * ee_data, int data_len )
{
	unsigned int i;
	unsigned char xdata tmp[256];

	ISP_data_sector_read((uint16)&tmp[0]);
	
	// Change 1 byte
	for (i=0; i<data_len; ++i)
	{
		tmp[ee_rwAddr+i] = ee_data[i];
	}
	


	ISP_data_erase();
	ISP_data_sector_prog((uint16)&tmp[0]);

	return 1;
}

/*
********************************************************************************
* Description : Serial EEPROM Write routine
* Arguments   : ee_rwAddr - write position, ee_data - data
* Returns     : None
* Note        :
********************************************************************************
*/
unsigned char EEP_Write(unsigned char ee_rwAddr,unsigned char ee_data)
{
	unsigned char xdata tmp[256];

	ISP_data_sector_read((uint16)&tmp[0]);
	
	// Change 1 byte
	tmp[ee_rwAddr] = ee_data;
	ISP_data_erase();
	ISP_data_sector_prog((uint16)&tmp[0]);
	return 1;
}

/*
********************************************************************************
* Description : Serial EEPROM Read routine
* Arguments   : ee_rwAddr - read position
* Returns     : EEPROM data
* Note        :
********************************************************************************
*/
unsigned char EEP_Read(unsigned char ee_rwAddr)
{
	unsigned char xdata tmp[256];

	ISP_data_sector_read((uint16)&tmp[0]);
	
	return tmp[ee_rwAddr];


}

