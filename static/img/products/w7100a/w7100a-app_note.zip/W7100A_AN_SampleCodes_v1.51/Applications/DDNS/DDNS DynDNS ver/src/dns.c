#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "..\..\..\..\drivers\serial.h"
#include "..\..\..\..\drivers\socket.h"
#include "..\..\..\..\drivers\tcpipcore.h"
#include "..\..\..\..\drivers\delay.h"
#include "config.h"
#include "dns.h"
#include "dns_parse.h"
#include "iap.h"

extern struct _CHCONF xdata ChConf;
volatile uint16 xdata tmp_Tcnt;

/*
********************************************************************************
Local Variable Declaration Section
********************************************************************************
*/
uint16 xdata MSG_ID = 0x1122;
//extern IGM_INFO xdata ConfigMsg;
uint8 xdata dns_buf[MAX_DNS_BUF_SIZE];


/*
********************************************************************************
*              PUT NETWORK BYTE ORDERED INT.
*
* Description : This function copies uint16 to the network buffer with network byte order.
* Arguments   : s - is a pointer to the network buffer.
*               i - is a unsigned integer.
* Returns     : a pointer to the buffer.
* Note        : Internal Function
********************************************************************************
*/
uint8 * put16(uint8 * s, uint16 i)
{
	*s++ = i >> 8;
	*s++ = i;

	return s;
}


/*
********************************************************************************
*              MAKE DNS QUERY MESSAGE
*
* Description : This function makes DNS query message.
* Arguments   : op   - Recursion desired
*               name - is a pointer to the domain name.
*               buf  - is a pointer to the buffer for DNS message.
*               len  - is the MAX. size of buffer.
* Returns     : the pointer to the DNS message.
* Note        :
********************************************************************************
*/
int dns_makequery(uint16 op, uint8 * name, uint8 * buf, uint16 len)
{
	uint8 xdata *cp;
	char xdata *cp1;
	char xdata sname[MAX_DNS_BUF_SIZE];
	char xdata *dname;
	uint16 xdata p;
	uint16 xdata dlen;

	cp = buf;

	MSG_ID++;
	cp = put16(cp, MSG_ID);
	p = (op << 11) | 0x0100;			/* Recursion desired */
	cp = put16(cp, p);
	cp = put16(cp, 1);
	cp = put16(cp, 0);
	cp = put16(cp, 0);
	cp = put16(cp, 0);

	strcpy(sname, name);
	dname = sname;
	dlen = strlen(dname);
	for (;;)
	{
		/* Look for next dot */
		cp1 = strchr(dname, '.');

		if (cp1 != NULL) len = cp1 - dname;	/* More to come */
		else len = dlen;			/* Last component */

		*cp++ = len;				/* Write length of component */
		if (len == 0) break;

		/* Copy component up to (but not including) dot */
		strncpy((char *)cp, dname, len);
		cp += len;
		if (cp1 == NULL)
		{
			*cp++ = 0;			/* Last one; write null and finish */
			break;
		}
		dname += len+1;
		dlen -= len+1;
	}

	cp = put16(cp, 0x0001);				/* type */
	cp = put16(cp, 0x0001);				/* class */

	return ((int)((uint16)(cp) - (uint16)(buf)));
}

/*
********************************************************************************
*              MAKE DNS QUERY AND PARSE THE REPLY
*
* Description : This function makes DNS query message and parses the reply from DNS server.
* Arguments   : name - is a pointer to the domain name.
* Returns     : if succeeds : 1, fails : -1
* Note        :
********************************************************************************
*/
uint8 dns_query(uint8 s, uint8 * name)
{



	struct dhdr xdata dhp;
	uint8 xdata sip[4]; 
	uint16 xdata len, port, rport;
	uint16 xdata cnt;
	extern int xdata dns_ip[4]; 
	uint8 xdata connect_dns_ip[4];
	uint8 xdata  x; 
	
	for(x = 0; x < 4; x++)
	{
		connect_dns_ip[x] = (uint8)dns_ip[x];
	}


	#ifdef _DNS_DEBUG
	printf("Enter dns_query function \r\n");
	#endif

	srand(tmp_Tcnt);
	rport = rand() % 63535 + 2000;
	
	for(;socket(s, Sn_MR_UDP, rport, 0)!=1;);
	len = dns_makequery(0, name, dns_buf, MAX_DNS_BUF_SIZE);
	
	#ifdef _DNS_DEBUG
	printf("Prepared DNS MSG \r\n");
	#endif

	
	sendto(s, dns_buf, len,connect_dns_ip, IPPORT_DOMAIN);

	#ifdef _DNS_DEBUG
	printf("sent DNS message \r\n");
	#endif


	cnt = 0;

	while (1)
	{
		if ((len = getSn_RX_RSR(s)) > 0)
		{
			if (len > MAX_DNS_BUF_SIZE) len = MAX_DNS_BUF_SIZE;
			len = recvfrom(s, dns_buf, len, sip, &port);
			disconnect(s);
			close(s);
			#ifdef _DNS_DEBUG
			printf("Got DNS reply message \r\n");
			#endif
			break;
		}
		wait_1ms(1);
		if (cnt++ == 0x1388) return 0;
	}
	return(parseMSG(&dhp, dns_buf));	/* Convert to local format */
}

