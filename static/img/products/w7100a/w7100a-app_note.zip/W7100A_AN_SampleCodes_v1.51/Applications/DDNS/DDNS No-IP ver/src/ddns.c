#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "ddns.h"		//DDNS Header
#include "iap.h"		//flash Read/Write 
#include "dns.h"		//DNS Query
#include "dns_parse.h"  //Parse DNS Reply Message 
#include "..\..\..\..\drivers\TCPIPCore.h"	//TCP/IP Core Definition



//Local Functions
void base64_encode(uint8* usrpwd,uint8* base64_userpwd,int len);	// Encode user name and password into Base64  

void DDNS_update(SOCKET s)
{
	
	extern	uint8 xdata host_name[20] ; 				// Your NO-IP Host's name
	extern	uint8 xdata user_pass[75] ; 				// Your "username:password" for NO-IP (format matters!)

	//Local Variables	
	uint8 xdata current_ip[4];							// Server's IP Address to be Updated
	uint8 xdata flash_ip[4]; 							// IP Address Read from flash
	uint16 xdata port = 5000;							// Port Number
	uint8 xdata x = 0;			  						// For Loop Index 
	uint16 xdata len;									// Length 
	uint8 xdata sent_flag = 0; 							// Flag for checking send request or not
	uint8 xdata same_flag = 0;	 						// Flag for checking same IP or not
	uint8 xdata finish_flag = 0;						// Flag to indicate finish
	
	uint8* xdata split;									// Pointer for splitting string 
	uint8* xdata split_end;								// Pointer for indicating end of splitting 
	char xdata *scan; 									// Pointer for strchr function
	uint8 xdata count;									// Count the number of occurance
	uint8 xdata tmp_str[100]={0,}; 						// Tmp String Storage
	uint8 xdata ip_addr_str[20] = {0,}; 				// current Ip address string
	uint8 xdata base64_user_pass[100] = {0,}; 			// the base 64 encoeded "user:password"	

	uint8 xdata request_msg[MAX_LENGTH] = {0,}; 		// Http Request Msg 
	uint8 xdata reply_msg[MAX_LENGTH] = {0,}; 			// Http Reply Msg

	extern int xdata dns_ip[4];							// IP address of the ISP's DNS	   
	extern uint8 xdata noip_ip[4];				  	// IP Address of NO-IP's Server 
	extern uint8 xdata user_agent[75];		 			// User agent information
	

	 //Enter DNS Server IP address provided by the ISP
	
	if(dns_ip[0] == 0 && dns_ip[1] == 0 &&	dns_ip[2] == 0 && dns_ip[3] == 0)
		{
			start:	 
				
				printf("Enter the ISP's DNS server IP address in this format (255.255.255.255) \r\n");
				scanf("%s",tmp_str);																   	// Get DNS Server IP
				
				count = 0;
				scan = strchr(tmp_str,'.');
			
				while(scan!= NULL)
					{
						scan = strchr(scan+1,'.');
						count++;
					}
	
				if (count > 3) 
					{
						printf("\r\nError: Please re enter the IP address in this format (255.255.255.255) \r\n"); 
						goto start;
					}
			
			
	
				
				for(x = 0; x<4; x++)
					{
						if(x == 0) 
			
							split = strtok(tmp_str,".");
						else
							{
								split = strtok(NULL,".");					
							}
						
							dns_ip[x] = atoi(split);
			
						if(dns_ip[x] >255 || dns_ip[x] < 0)
							{
								printf("\r\nError: Please re enter the DNS IP address in this format (255.255.255.255) \r\n"); 
						 		goto start;									  						// Re Enter IP Address
							}
					}

				
				printf("\r\nThe DNS IP entered is %i.%i.%i.%i \r\n\r\n", (int)dns_ip[0], (int)dns_ip[1],	(int)dns_ip[2], (int)dns_ip[3]);
		}
		

	// Enter the new webserver's IP address to be updated

re_enter:

	printf("Enter the server's new IP address in this format (255.255.255.255) \r\n");
	scanf("%s",ip_addr_str);															

	count = 0;
	scan = strchr(ip_addr_str,'.');

	while(scan!= NULL)
		{
		 scan = strchr(scan+1,'.');
			count++;
		}
	
	if (count > 3) 
		{
			printf("\r\nError: Please re enter the IP address in this format (255.255.255.255) \r\n"); 
			goto re_enter;
		}
	

	
	memset(tmp_str,0,20);
	split = 0;
	memcpy(tmp_str,ip_addr_str,strlen(ip_addr_str));


	for(x = 0; x<4; x++)
		{
			if(x == 0) 
				split = strtok(tmp_str,".");
			else
				{
					split = strtok(NULL,".");					
				}
			current_ip[x] = atoi(split);

			if(current_ip[x] >255 || current_ip[x] < 0)
				{
					printf("\r\nError: Please re enter the IP address in this format (255.255.255.255) \r\n"); 
			 		goto re_enter;									  						// Re Enter IP Address
				}
		}

	printf("\r\nThe webserver IP address entered is %i.%i.%i.%i \r\n\r\n", (int)current_ip[0], (int)current_ip[1],(int)current_ip[2], (int)current_ip[3]);

		
	for(x = 0; x<4; x++)
		{
			flash_ip[x] = EEP_Read(x); 	//Read Previously Updated IP address from flash 

		}


	

   	if(memcmp(flash_ip,current_ip,4)==0)	// Compare previously IP address with current IP address
		{
			printf("\r\nNo Change in IP address detected. Skip update \r\n"); 
			goto exit;
		}


		
	dns_query(s,"dynupdate.no-ip.com");			// do DNS query with "members.dyndns.org" 

	// Check if we got IP from dns query or not
	if( noip_ip[0] == 0 && noip_ip[1] == 0 && noip_ip[2] == 0 && noip_ip[3] == 0)
		{
			printf("Failed to get an IP Address from DNS query.\r\nPlease Make sure the ISP's DNS server address is correct\r\n\r\n");
			goto start;	
		}


	while(finish_flag == 0)		
		 {
			switch(getSn_SR(s))	// check socket state
				{
					case SOCK_CLOSED:
						port++;					
						if(socket(s,Sn_MR_TCP, port, 0x00) == 1) // Open Socket in TCP mode 
							{
								printf("Created Socket %i \r\n",(int)s);
								sent_flag = 0;
							}
					    else
							{
								close(s);
								printf("Failed to Create Socket \r\n");
							}
				   
				   	break;
			
					case SOCK_INIT:
	
						if(	connect(s,noip_ip,80) == 1) 	// Connect to DynDNS Server 
							{
								sprintf(tmp_str,"Connected to %i.%i.%i.%i to update NO-IP record",(int)noip_ip[0], (int)noip_ip[1], (int)noip_ip[2], (int)noip_ip[3]);
								printf("%s\r\n",tmp_str);
							}
						else
							{
								printf("Failed to connect \r\n");
							}
			
			
					break;
			
					case SOCK_ESTABLISHED:
			
						if(sent_flag == 0)
							{
								base64_encode(user_pass,base64_user_pass,strlen(user_pass)); // Encode user and password into base64 
								
								// create HTTP GET request message
								sprintf(request_msg,"GET /nic/update?hostname=%s&myip=%s HTTP/1.0  \r\nHost: dynupdate.no-ip.com  \r\nAuthorization: Basic %s \r\nUser-Agent:%s \r\n\r\n",host_name ,ip_addr_str ,base64_user_pass,user_agent);  	
								
								//Send out Request Messages
								send(s,request_msg,strlen(request_msg)); 
								printf("Sent Request Message \r\n");
								// set sent flag
								sent_flag = 1;
							
							}	
	
						//Check if there is data in receive buffer  								
						len = getSn_RX_RSR(s);
						
						if (len > 0)
							{
								printf("\r\nReceived %i Bytes of Data from Server\r\n",(int) len);
							
								//check if received data is bigger than buffer or not 
								if(len > MAX_LENGTH) len = MAX_LENGTH;
				
								//Place Data into reply_msg
								len = recv(s, reply_msg, len);
								
								finish_flag = 1; // end while loop flag				
								
							}
			
					break;
			
					case SOCK_CLOSE_WAIT: 
					
					disconnect(s);
					break;

					default:
					break;
			}

	}
	

	// search for update success in reply string

	if((split = strstr(reply_msg,"good")) != NULL)
		{
			//write newly updated ip address into flash (0x00~0x03)
			EEP_Block_Write(0,current_ip, 4);

			printf("The Reply Message is:");
			
		
			printf("%s",split);
	
			

		}
   	else 
		{
			split = strstr(reply_msg,"\r\n\r\n");

			printf("The Reply Message is:");	
			split += 4;
			printf("%s",split);

	
			printf("\r\n\r\nFailed to update with the new IP. "
			"Please check this website ( http://www.no-ip.com/integrate/response/ )"
				"for more details about the error message\r\n");


		}
	
	
	
	/*				split = strstr(reply_msg,"good");
	if(split == NULL)
		{
			split = strstr(reply_msg,"\r\n\r\n");
			split += 4;



		}
	else
		{
			//write newly updated ip address into flash (0x00~0x03)
			EEP_Block_Write(0,current_ip, 4);

		}


	len = split - reply_msg;
	printf("the received buffer is \r\n\r\n");
	
	for(x = 0; x < len; x++)
		{
			printf("%c",split[x]);	
		}	
*/
 

exit:
	
	printf("\r\nExit DDNS Update \r\n");


}


void  base64_encode(uint8* usrpwd,uint8* base64_userpwd,int len)
{

	static char xdata encodingTable [64] = {
 
    'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P',
    
    'Q','R','S','T','U','V','W','X','Y','Z','a','b','c','d','e','f',
    
    'g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v',
    
    'w','x','y','z','0','1','2','3','4','5','6','7','8','9','+','/'
	};
	
	uint8 xdata in_idx = 0;		//input buffer index
	uint8 xdata out_idx = 0;	//output buffer index
	uint8 xdata remaining = 0;  //remaining characters to be processed
	uint8 xdata num = 0;		//number of characters to be processed 
	uint8 xdata tmp[100] = {0,}; // tmp string

	num = (len%3);
	
	if(num == 0) 
		{
			remaining = len + (len/3);	// compute length remaining
		}
	else 
		{
			switch(num)
				{
					case 1: remaining =  ((len *4)/3)+ 3;						
					break;
 	
					case 2: remaining =  ((len *4)/3)+ 2;						
					break;

					default:
					break;

				}
		}
	
 			
	while(remaining > 0)
		{
				
					tmp[out_idx] 	= (usrpwd[in_idx]&0xFC) >> 2;
					base64_userpwd[out_idx] = 	encodingTable[tmp[out_idx]];				
	
					tmp[out_idx + 1]	= (((usrpwd[in_idx]&0x03) <<4) | ((usrpwd[in_idx+1]&0xF0)>>4)); 
					base64_userpwd[out_idx + 1] = 	encodingTable[tmp[out_idx + 1]];				
					
					tmp[out_idx + 2]	= (((usrpwd[in_idx+1]&0x0F) <<2) | ((usrpwd[in_idx+2]&0xC0)>>6));
					base64_userpwd[out_idx + 2] = 	encodingTable[tmp[out_idx + 2]];				
					
					tmp[out_idx + 3]	= (usrpwd[in_idx+2]&0x3F); 
					base64_userpwd[out_idx + 3] = 	encodingTable[tmp[out_idx + 3]];				
	
					if(remaining == 4)
						{
	
							switch(num)
									{
				
										case 1: 						
										memcpy(base64_userpwd+out_idx + 2,"==",2);
										break;
				
										case 2:
				
										tmp[out_idx + 2]	= (((usrpwd[in_idx+1]&0x0F) <<2) | ((usrpwd[in_idx+2]&0xC0)>>6));
										base64_userpwd[out_idx + 2] = 	encodingTable[tmp[out_idx + 2]];				
										memcpy(base64_userpwd+out_idx + 3,"=",1);
				
										break;
				
										default:
										break;
									}
						}	
								
			out_idx += 4; 
			in_idx += 3; 		
			remaining -= 4;  
	
					
		}

//		printf("The Encoded String is \r\n");
//		printf("%s \r\n",base64_userpwd);
}



