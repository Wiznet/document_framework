#include <stdio.h>	     
#include <string.h>
#include <stdlib.h>

#include "DDNS.h"			// DDNS Header
#include "..\..\..\..\drivers\TCPIPcore.h"		// TCP/IP Core Definition

/*******************************************************************************************/
/* If you have QFN64pin package W7100A, have to use 'USE_QFN64' definition in TCPIPcore.h  */
/*******************************************************************************************/

//Initialize Functions
/***************************************************************************
 * Do not use Init_iMCU() and Init_Network() function in TCPIPCORE.c file. *
 ***************************************************************************/
void InitMCU();						//Initialize MCU 			
void InitNetwork();					//Initialize Network 


// User Settings
uint8 xdata mac[6] = "\x00\x08\xDC\x11\x22\x33"; 	//MAC Address 
uint8 xdata gw[4] = {192,168,0,1};					//Gateway Address
uint8 xdata source_ip[4] = {192,168,0,10};			//Source IP Address
uint8 xdata sub[4] = {255,255,255,0};				//Subnet Mask
int xdata dns_ip[4] = {0,};							//DNS Server IP from Internet Provider  
uint8 xdata host_name[20] = "<hostname>"; 	// Your No-IP Host's name
uint8 xdata user_pass[75] = "<username>:<password>"; 			// Your "username:password" for No-IP (format matters!)
uint8 xdata user_agent[75] = "WIZnetW7100/1.0 test@abc.com"; // User agent information

uint8 xdata noip_ip[4] ={0,};						//NO-IP Server IP (Provided by DNS Query) 

//TX/RX Buffer Memory Settings
uint8 xdata txsize[MAX_SOCK_NUM] = {2,2,2,2,2,2,2,2};	//Set 2 Kbytes of TX memory for each socket
uint8 xdata rxsize[MAX_SOCK_NUM] = {2,2,2,2,2,2,2,2};	//Set 2 Kbytes of RX memory for each socket

void main()
{

	InitMCU(); 			// Initialize MCU 
//	wait_1ms(2000); 	// Wait for 5 Seconds for auto negotiation to be completed 
	InitNetwork();		// Initialize Network 
	DDNS_update(7); 		// call update DDNS update function 

}

void InitMCU()
{	 
	CHIP_Init(); // MCU Core init
	EA = 0;						// Disable Global Interrupt
	IINCHIP_WRITE(MR,0x80);		// Reset Wiznet Chipset
	WTST = 0x03;				// Set Memory Access Wait State for  4 clk
	CKCON = 0x02; 				// Set Read/Write Access Time 3 pulse width
	InitSerial();				// Initialize Serial
	P0_PU = 0xFF;	// GPIO Pull-up setting for 3.3V output     
	P1_PU = 0xFF;
	P2_PU = 0xFF;
	P3_PU = 0xFF;
	EA = 1;	
}

void InitNetwork()
{

	uint8 xdata x = 0;			//For Loop Index  	
		
	// Set Retry Timer to 0x1388 (5000 x 100us = 0.5 seconds)  
	IINCHIP_WRITE(0x0017,0x13);  // RTR0 (0x0017) Upper Byte of register
	IINCHIP_WRITE(0x0018,0x88);	 // RTR1 (0x0018) Lower Byte of Register

	// Set Source IP Address
	IINCHIP_WRITE(SIPR0    ,source_ip[0]);
	IINCHIP_WRITE(SIPR0 + 1,source_ip[1]);
	IINCHIP_WRITE(SIPR0 + 2,source_ip[2]);
	IINCHIP_WRITE(SIPR0 + 3,source_ip[3]);
	
	// Set Gateway Address
	IINCHIP_WRITE(GAR0    ,gw[0]);
	IINCHIP_WRITE(GAR0 + 1,gw[1]);
	IINCHIP_WRITE(GAR0 + 2,gw[2]);
	IINCHIP_WRITE(GAR0 + 3,gw[3]);

	// Set Subnet Mask 
 	IINCHIP_WRITE(SUBR0    ,sub[0]);
 	IINCHIP_WRITE(SUBR0 + 1,sub[1]);
 	IINCHIP_WRITE(SUBR0 + 2,sub[2]);
 	IINCHIP_WRITE(SUBR0 + 3,sub[3]);

	// Set MAC Address
 	IINCHIP_WRITE(SHAR0    ,mac[0]);
 	IINCHIP_WRITE(SHAR0 + 1,mac[1]);
 	IINCHIP_WRITE(SHAR0 + 2,mac[2]);
 	IINCHIP_WRITE(SHAR0 + 3,mac[3]);
 	IINCHIP_WRITE(SHAR0 + 4,mac[4]);
 	IINCHIP_WRITE(SHAR0 + 5,mac[5]);
	
	
	set_MEMsize(txsize,rxsize);		// Set RX/TX Buffer memory for WIZnet's Chipset

	printf("***************Network Settings***************\r\n");
	printf("\rIP: 		%i.%i.%i.%i \r\n", (int)IINCHIP_READ(SIPR0), (int)IINCHIP_READ(SIPR0 + 1), (int)IINCHIP_READ(SIPR0 +2), (int)IINCHIP_READ(SIPR0 +3));
	printf("Gateway: 	%i.%i.%i.%i \r\n", (int)IINCHIP_READ(GAR0), (int)IINCHIP_READ(GAR0 + 1), (int)IINCHIP_READ(GAR0 +2), (int)IINCHIP_READ(GAR0 +3));
	printf("Subnet:		%i.%i.%i.%i \r\n", (int)IINCHIP_READ(SUBR0), (int)IINCHIP_READ(SUBR0 + 1), (int)IINCHIP_READ(SUBR0 +2), (int)IINCHIP_READ(SUBR0 +3));
	printf("MAC: 		%x.%x.%x.%x.%x.%x \r\n", (int)IINCHIP_READ(SHAR0), (int)IINCHIP_READ(SHAR0 + 1), (int)IINCHIP_READ(SHAR0 + 2), (int)IINCHIP_READ(SHAR0 + 3), (int)IINCHIP_READ(SHAR0 + 4), (int)IINCHIP_READ(SHAR0 + 5));
	printf("DNS:		%i.%i.%i.%i \r\n", dns_ip[0],dns_ip[1],dns_ip[2],dns_ip[3]);
	printf("***************DDNS Account Settings**********\r\n");
	printf("Hostname:		%s\r\n",host_name );
	printf("Username & Password:	%s\r\n",user_pass );
	printf("User Agent:		%s\r\n",user_agent);
	printf("**********************************************\r\n\r\n");																				   
}


