#ifndef _DDNS_H
#define _DDNS_H
#include "..\..\..\..\drivers\types.h"

void DDNS_update(SOCKET s);

#define MAX_URL_SIZE 128 			// Maximum URL size
#define MAX_LENGTH 1024

#endif

