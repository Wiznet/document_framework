
#include "..\..\..\..\drivers\TCPIPCore.h"
//#include "..\..\..\..\drivers\serial.h"
#include "lcd.h"

#define	MAX_EBUF_SIZE	1024
// Maximum receive buffer size
#define	MAX_SBUF_SIZE	1024

/*******************************************************************************************/
/* If you have QFN64pin package W7100A, have to use 'USE_QFN64' definition in TCPIPcore.h  */
/*******************************************************************************************/

//#define USE_StoE			// If your EVB using Serial interrupt, use this definition

void StoE(SOCKET s, uint16 port, uint8  xdata * data_buf, uint16 mode);
uint16 SerialToEthernet(SOCKET s);
void Int();

uint8 xdata e_buf[MAX_EBUF_SIZE];    // Ethernet Buffer
uint8 xdata s_buf[MAX_SBUF_SIZE];	 // Serial Buffer
uint8 xdata tmp_s_buf[MAX_SBUF_SIZE];	 //Temporal serial Buffer
uint16 xdata s_write_ptr = 0;			 // Serial write pointer
uint16 xdata s_read_ptr = 0;			 // Serial read pointer
uint16 xdata e_write_ptr = 0;			 // Ethernet write pointer
uint16 xdata e_read_ptr = 0;			 // Ethernet read pointer
uint16 xdata tmp_read;		             // Temporal read pointer for memcpy
uint16 xdata tmp_write;	                 // Tempora write pointer for memcpy
uint8 xdata s_buf_ov = 0;				//Serial Buffer overflow

/*
void InitSerial_Interrupt2(void)
{

	RI = 0; 		
	TI = 0; 			
	ES0	= 1; 
}
*/
void main()
{
	Init_iMCU();				// Initialize   iMCUW7100	  	
	Init_Network(); 			// Initialize   Network Configuration	
	InitSerial_Interrupt();

	while(1)
	{
			StoE(0, 5000,e_buf, 0);	
/*			StoE(1, 5000,e_buf, 0);	
			StoE(2, 5000,e_buf, 0);	
			StoE(3, 5000,e_buf, 0);	
			StoE(4, 5000,e_buf, 0);	
			StoE(5, 5000,e_buf, 0);	
			StoE(6, 5000,e_buf, 0);	
			StoE(7, 5000,e_buf, 0);
*/
	}
}


void Int() interrupt 4	// Serial Interrupt Processing
{
	if(RI)				//Check for Receive Interrupt flag 
	{
		s_buf[s_write_ptr] = SBUF;		//write data from Serial buffer to uart rx buffer	
		s_write_ptr++;
									// increment write pointer
		if(s_write_ptr >= MAX_SBUF_SIZE) 	// check if write pointer is bigger than Maximum size of Serial buffer
		{
			s_write_ptr = 0;			
			if(s_write_ptr == s_read_ptr) s_buf_ov = 1;
		}
		else
		{
			if(s_write_ptr == s_read_ptr) s_buf_ov = 1;			//If the buffer is full		
		}
		RI = 0;											// Disable Receive Interrupt flag		 
	}
				//Enable UART Interrupt
}

uint16 SerialToEthernet(SOCKET s)
{

	uint16 xdata length;		// length of data
				  
	EA = 0;								//disable all interrupt
	tmp_read = s_read_ptr;		// get current value of read pointer
	tmp_write = s_write_ptr; 	// get current value of write pointer
	EA = 1;								//enable all interrupt 
	
	if(s_buf_ov)
	{
		length = (MAX_SBUF_SIZE - tmp_read) + tmp_write;  // calculate the length of data to be read
		send(s, (uint8*)&s_buf[tmp_read], sizeof(uint8)*(MAX_SBUF_SIZE - tmp_read));
		send(s, (uint8*)&s_buf[0], tmp_write);
		s_buf_ov = 0;
	}

	if(tmp_write == tmp_read) return 0;	// constraint: read and write pointer can not be the same

	if(tmp_write > tmp_read)											 
	{
		
		length = tmp_write - tmp_read; 	// 	calculte the length of data to be read
		send(s, (uint8*)&s_buf[tmp_read], sizeof(uint8)*length);
	}

	else
	{
		length = (MAX_SBUF_SIZE - tmp_read) + tmp_write;  // calculate the length of data to be read
		send(s, (uint8*)&s_buf[tmp_read], sizeof(uint8)*(MAX_SBUF_SIZE - tmp_read));
		send(s, (uint8*)&s_buf[0], tmp_write);
	}

	s_read_ptr = s_read_ptr + length;			//Updata the read pointer
	if(s_read_ptr >= MAX_SBUF_SIZE) s_read_ptr -= MAX_SBUF_SIZE;
	return length;						//return length of data read
}


void StoE(SOCKET s, uint16 port, uint8 xdata * e_buf, uint16 mode)
{
  uint16 e_len;
  uint16 s_len;			//Serial data length
  uint16 xdata i;
  static uint16 xdata any_port = 1000;
  uint8 xdata destIP[4] = {192,168,1,214};

  switch (getSn_SR(s))
	{
	case SOCK_ESTABLISHED:				 // if connection is established *
	    if(getSn_IR(s) & Sn_IR_CON)      // check Sn_IR_CON bit
        {
            printf("CH: %d connect to server\r\n", (int)s);
            setSn_IR(s, Sn_IR_CON);        // clear Sn_IR_CON
        }
		// Ethernet to Serial
		if((e_len = getSn_RX_RSR(s)) > 0) 			// check Rx data
		{
			if(e_len > MAX_EBUF_SIZE) e_len = MAX_EBUF_SIZE;

			s_len = recv(s, e_buf, e_len);			// read the received data
			for(i=0; i < s_len; i++)
			{
			    putchar(*(e_buf + i));		// transmit to serial data
		    }
		}
		// Serial to Ethernet
		SerialToEthernet(s);
		break;

 	case SOCK_CLOSE_WAIT:                       		/* If the client request to close */
		disconnect(s);
		break;

	case SOCK_CLOSED:                                               /* if a socket is closed */
		close(s);
//		printf("CH: %d closed\r\n", (int)s);
		socket(s,Sn_MR_TCP, any_port++,mode);
		break;

	case SOCK_INIT:                                               /* if a socket is initiated */
		connect(s, destIP, port);  
//		printf("CH: %d Try to Connect \r\n", (int)s);
		break;

	default:
		break;
	}
}
