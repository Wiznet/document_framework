#include "..\..\..\..\drivers\TCPIPcore.h"
#include "lcd.h"
		
#define	MAX_EBUF_SIZE	2048
// Maximum receive buffer size
#define	MAX_SBUF_SIZE	2048

/*******************************************************************************************/
/* If you have QFN64pin package W7100A, have to use 'USE_QFN64' definition in TCPIPcore.h  */
/*******************************************************************************************/

void StoE(SOCKET s, uint16 port, uint8  xdata * data_buf, uint16 mode);
uint16 SerialToEthernet(SOCKET s, uint8 xdata* destIP, uint16 xdata destport);
void Int();

uint8 xdata e_buf[MAX_EBUF_SIZE];    // Ethernet Buffer
uint8 xdata s_buf[MAX_SBUF_SIZE];	 // Serial Buffer
uint8 xdata tmp_s_buf[MAX_SBUF_SIZE];	 //Temporal serial Buffer
uint16 xdata s_write_ptr = 0;			 // Serial write pointer
uint16 xdata s_read_ptr = 0;			 // Serial read pointer
uint16 xdata e_write_ptr = 0;			 // Ethernet write pointer
uint16 xdata e_read_ptr = 0;			 // Ethernet read pointer
uint16 xdata tmp_read;		             // Temporal read pointer for memcpy
uint16 xdata tmp_write;	                 // Tempora write pointer for memcpy
uint8 xdata s_buf_ov = 0;				//Serial Buffer overflow

void main()
{
	Init_iMCU();				// Initialize   iMCUW7100	 	
	Init_Network(); 			// Initialize   Network Configuration
	InitSerial_Interrupt();		// Initialize	Serial port - Serial interrupt enable

	while(1)
	{
			StoE(0, 3000,e_buf, 0);	
/*			StoE(1, 3001,e_buf, 0);	
			StoE(2, 3002,e_buf, 0);	
			StoE(3, 3003,e_buf, 0);	
			StoE(4, 3004,e_buf, 0);	
			StoE(5, 3005,e_buf, 0);	
			StoE(6, 3006,e_buf, 0);	
			StoE(7, 3007,e_buf, 0);
*/
	}
}


void Int() interrupt 4	// Serial Interrupt Processing
{
	if(RI)				//Check for Receive Interrupt flag 
	{
		s_buf[s_write_ptr] = SBUF;		//write data from Serial buffer to uart rx buffer	
		s_write_ptr++;
									// increment write pointer
		if(s_write_ptr >= MAX_SBUF_SIZE) 	// check if write pointer is bigger than Maximum size of Serial buffer
		{
			s_write_ptr = 0;			
			if(s_write_ptr == s_read_ptr) 
			{
				s_buf_ov = 1;
			}
		}
		else
		{
			if(s_write_ptr == s_read_ptr) 
			{
				s_buf_ov = 1;			//If the buffer is full		
			}
		}
		RI = 0;											// Disable Receive Interrupt flag		 
	}
			//Enable UART Interrupt
}

uint16 SerialToEthernet(SOCKET s, uint8 xdata *destIP, uint16 xdata destport)
{

	uint16 xdata length;		// length of data
				  
	ES = 0;								//disable all interrupt
	tmp_read = s_read_ptr;		// get current value of read pointer
	tmp_write = s_write_ptr; 	// get current value of write pointer
	ES = 1;								//enable all interrupt 
	
	

	if(s_buf_ov)
	{
		length = (MAX_SBUF_SIZE - tmp_read) + tmp_write;  // calculate the length of data to be read
		sendto(s, (uint8*)&s_buf[tmp_read], (MAX_SBUF_SIZE - tmp_read), (uint8 *)destIP, destport);
		sendto(s, (uint8*)&s_buf[0], tmp_write, (uint8 *)destIP, destport);
		s_buf_ov = 0;
	}

	if(tmp_write == tmp_read) return 0;	// constraint: read and write pointer can not be the same

	if(tmp_write > tmp_read)											 
	{
		
		length = tmp_write - tmp_read; 	// 	calculte the length of data to be read
		sendto(s, (uint8*)&s_buf[tmp_read], length, (uint8 *)destIP, destport);
	}

	else
	{
		length = (MAX_SBUF_SIZE - tmp_read) + tmp_write;  // calculate the length of data to be read
		sendto(s, (uint8*)&s_buf[tmp_read], (MAX_SBUF_SIZE - tmp_read), (uint8 *)destIP, destport);
		sendto(s, (uint8*)&s_buf[0], tmp_write, (uint8 *)destIP, destport);
	}

	s_read_ptr = s_read_ptr + length;			//Updata the read pointer
	if(s_read_ptr >= MAX_SBUF_SIZE) s_read_ptr -= MAX_SBUF_SIZE;
	return length;						//return length of data read
}


void StoE(SOCKET s, uint16 port, uint8 xdata * e_buf, uint16 mode)
{
    uint16 e_len;
    uint16 s_len;			//Serial data length
    uint16 xdata i;
    uint16 xdata destport;
    uint8 xdata destIP[4];

    switch (getSn_SR(s))
	{
	case SOCK_UDP:				 // if connection is established *
		// Serial to Ethernet
		// Ethernet to Serial
		if((e_len = getSn_RX_RSR(s)) > 0) 			// check Rx data
		{
			if(e_len > MAX_EBUF_SIZE)  e_len = MAX_EBUF_SIZE;
			s_len = recvfrom(s, e_buf, e_len, (uint8 *)destIP, &destport);			// read the received data
			for(i=0; i < s_len; i++)
			{
			    putchar(*(e_buf + i));		// transmit to serial data
		    }
		}
		SerialToEthernet(s, destIP, destport);
		
		break;

	case SOCK_CLOSED:                                               /* if a socket is closed */
		printf("CLOSED. CH : %d\r\n", (int)s);
		close(s);
		socket(s, Sn_MR_UDP, port, mode);
		printf("CH: %d UDP Ready!!\r\n", (int)s);
		break;

	default:
		break;
	}
}

