#ifndef __SERIAL_H
#define __SERIAL_H
#define X2MODE				// For MCU supported X2 Mode

void InitSerial(void);			/* Initialization of Serial Port(Ex.Baud Rate setting) */
void InitSerial_Interrupt(void);	/* Initialization of Serial Port - Serial interrupt enable */
void PutString(char *Str) reentrant;
#endif