
#include "..\..\..\drivers\TCPIPcore.h"
#include "ping.h"			
#include "sockutil.h"

PINGMSGR xdata PingRequest;	 // Variable for Ping Request
PINGMSGR xdata *PingReply;	     // Variable for Ping Reply
static uint16 RandomID = 0x1234; 
static uint16 RandomSeqNum = 0x4321;
uint8 ping_reply_received = 0; 
void ping(SOCKET s, uint16 pCount, uint8 *addr, uint16 port){

	uint16 rlen, cnt,i;
 
   
	cnt = 0;
	 	 
	for(i=0; i<pCount+1;i++){

	if(i!=0){
		/* Output count number */
			printf( "\r\nNo.%.2bu\r\n",   (i-1)) ;
	}

  	switch(getSn_SR(s))
		{
			case SOCK_CLOSED:
				close(s);  
				                                                  // close the SOCKET
				/* Create Socket */  
				IINCHIP_WRITE(Sn_PROTO(s), IPPROTO_ICMP);              // set ICMP Protocol
				if(socket(s,Sn_MR_IPRAW,port,0)==0){       // open the SOCKET with IPRAW mode, if fail then Error
					printf( "\r\nsocket %.2bu fail r\n",   (s)) ;
				}	
				/* Check socket register */
			    while(getSn_SR(s)!=SOCK_IPRAW); 
				wait_1ms(1000); 
		         wait_1ms(1000);  
				break;

			case SOCK_IPRAW:
				   ping_request(s, addr, port);
			
					while(1){
						if ( (rlen = getSn_RX_RSR(s) ) > 0){
							//printf( "\r\nIPRAW : Socket recv. \r\n") ;					
							ping_reply(s, addr, port, rlen);	
							if (ping_reply_received)  break;
						   
						}

					     /* wait_time for 2 seconds, Break on fail*/
						if ( (cnt > 100) ) {
							printf( "\r\nRequest Time out. r\n") ;					
							break;
						}else { 
							cnt++; 	
							wait_1ms(50);
						}
				     }

				break;

			default:		
				break;
		
       }
	  
	  
	
   }


}

uint8 ping_request(SOCKET s, uint8 *addr, uint16 port){
  uint16 xdata i;
  uint16 val=0,val1=0;
 
	//Initailize flag for ping reply
	ping_reply_received = 0;

	/* make header of the ping-request  */
	PingRequest.Type = PING_REQUEST;                      // Ping-Request 
	PingRequest.Code = CODE_ZERO;	                   // Always '0'
	PingRequest.ID = htons(RandomID++);	       // set ping-request's ID to random integer value
	PingRequest.SeqNum = htons(RandomSeqNum++);// set ping-request's sequence number to ramdom integer value      
	//size = 32;                                 // set Data size

	/* Fill in Data[]  as size of BIF_LEN (Default = 32)*/
  	for(i = 0 ; i < BUF_LEN; i++){	                                
		PingRequest.Data[i] = (i) % 8;		  //'0'~'8' number into ping-request's data 	
	}
	 /* Do checksum of Ping Request */
	PingRequest.CheckSum = 0;		               // value of checksum before calucating checksum of ping-request packet
	PingRequest.CheckSum = htons(checksum((uint8*)&PingRequest,sizeof(PingRequest)));  // Calculate checksum


	
     /* sendto ping_request to destination */
	if(sendto(s,(uint8 *)&PingRequest,sizeof(PingRequest),addr,port)==0){  // Send Ping-Request to the specified peer.
	  	 printf( "\r\n Fail to send ping-reply packet  r\n") ;					
	}else{
	 	  printf( "Send Ping Request  to Destination (") ;					
          printf( "%bu.%bu.%bu.%bu )",   (addr[0]),  (addr[1]),  (addr[2]),  (addr[3])) ;
		  printf( " ID:%.2bx  SeqNum:%.2bx CheckSum:%.2bx\r\n",   (PingRequest.ID),  (PingRequest.SeqNum),  (PingRequest.CheckSum)) ;
	}
	return 0;
} // ping request

uint8 ping_reply(SOCKET s, uint8 *addr, uint16 port, uint16 rlen){
	 
	 uint16 tmp_checksum;	
	 uint16 len;
	 uint8 xdata * data_buf = 0x007000;			
		/* receive data from a destination */
	   	len = recvfrom(s, (uint8 *)data_buf,rlen,addr,&port);  

			/* check the Type, If TYPE is 0, the received msg is the ping reply msg.*/ 
			if(data_buf[0] == PING_REPLY) {
				   	PingReply = 0x007000;	
					/* check Checksum of Ping Reply */
					tmp_checksum = PingReply->CheckSum;
					PingReply->CheckSum = 0;
					PingReply->CheckSum = checksum((uint8*)PingReply,len);
						if(tmp_checksum != PingReply->CheckSum){
							printf( " \n CheckSum is in correct %.2bx shold be %.2bx \n",   (tmp_checksum),  (PingReply->CheckSum)) ;
						}else{
							//printf( "\r\n Checksum is correct  \r\n") ;					
						}
		
					/*  Output the Destination IP and the size of the Ping Reply Message*/
				    	printf("Reply from %bu.%bu.%bu.%bu  ID:%.2bx SeqNum:%.2bx  :data size %bu bytes\r\n",
						  (addr[0]),  (addr[1]),  (addr[2]),  (addr[2]),  (PingReply->ID),  (PingReply->SeqNum),  (rlen+6) );

					/*  SET ping_reply_receiver to '1' and go out the while_loop (waitting for ping reply)*/
					ping_reply_received =1;
			}
			else if(data_buf[0] == PING_REQUEST){
					PingReply = 0x007000;	
					/* check Checksum of Ping Reply */
					tmp_checksum = PingReply->CheckSum;
					PingReply->CheckSum = 0;
					PingReply->CheckSum = checksum((uint8*)PingReply,len);
						if(tmp_checksum != PingReply->CheckSum){
							printf( " \n CheckSum is in correct %.2bx shold be %.2bx \n",   (tmp_checksum),  (PingReply->CheckSum)) ;
						}else{
							//printf( "\r\n Checksum is correct  \r\n") ;					
						}
		
					/*  Output the Destination IP and the size of the Ping Reply Message*/
				    	printf("Request from %bu.%bu.%bu.%bu  ID:%.2bx SeqNum:%.2bx  :data size %bu bytes\r\n",
						  (addr[0]),  (addr[0]),  (addr[0]),  (addr[0]),  (PingReply->ID),  (PingReply->SeqNum),  (rlen+6) );
					/*  SET ping_reply_receiver to '1' and go out the while_loop (waitting for ping reply)*/		   
					ping_reply_received =1;

			}
			else{      
 					 printf(" Unkonwn msg. \n");
			}


			return 0;
}// ping_reply















