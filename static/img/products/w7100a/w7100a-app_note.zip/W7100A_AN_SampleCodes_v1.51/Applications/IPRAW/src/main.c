
#include "..\..\..\drivers\TCPIPcore.h"
#include "ping.h"

#define	MAX_BUF_SIZE	8192		// Maximum receive buffer size

/*******************************************************************************************/
/* If you have QFN64pin package W7100A, have to use 'USE_QFN64' definition in TCPIPcore.h  */
/*******************************************************************************************/

void main()
{
	//Init. Ping_Request
	uint8 xdata pDestaddr[4];
	uint16 xdata pCount;
	uint16 xdata pPort;	

	Init_iMCU();		// Initialize   iMCUW7100   
	Init_Network(); 	// Initialize   Network Configuration
 
	//start message
	printf("\r\n-------PING_TEST_START--------\r\n");
	//set Dest. IP address & Port
	pDestaddr[0]= 192;
	pDestaddr[1]= 168;
	pDestaddr[2]= 1;
	pDestaddr[3]= 226;
	pPort = 3000;
	printf( "Destination IP  : %.3bu.%.3bu.%.3bu.%.3bu \r\n", 
		pDestaddr[0], pDestaddr[1], pDestaddr[2], pDestaddr[3] 
	) ;
	//set ping request count
	pCount = 3;
	

	ping(0, pCount, &pDestaddr, pPort);
	printf("\r\n-------PING_TEST_END--------\r\n");
	while(1);


}

