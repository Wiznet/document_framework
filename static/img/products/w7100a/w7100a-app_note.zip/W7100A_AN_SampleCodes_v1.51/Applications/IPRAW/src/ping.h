#include "..\..\..\drivers\types.h"

#define BUF_LEN 32
#define PING_REQUEST 8
#define PING_REPLY 0
#define CODE_ZERO 0

typedef struct pingmsg
{
  uint8  Type; 		// 0 - Ping Reply, 8 - Ping Request
  uint8  Code;		// Always 0
  int16  CheckSum;	// Check sum
  int16  ID;	            // Identification 
  int16  SeqNum; 	// Sequence Number
  int8	 Data[BUF_LEN];// Ping Data  : 1452 = IP RAW MTU - sizeof(Type+Code+CheckSum+ID+SeqNum)
} PINGMSGR;


void ping(SOCKET s, uint16 pCount, uint8 *addr, uint16 Pprt); 
uint8 ping_request(SOCKET s, uint8 *addr, uint16 port); 
uint8 ping_reply(SOCKET s,  uint8 *addr, uint16 port, uint16 rlen); 

