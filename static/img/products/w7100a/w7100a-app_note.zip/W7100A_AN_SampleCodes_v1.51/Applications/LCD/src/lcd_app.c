
#include "..\..\..\drivers\TCPIPcore.h"
#include "lcd_app.h"
#include "lcd.h"


#define LCD_SCROLL_CNT 32

uint8 xdata recv_cnt = 0; //receved data counter
uint8 xdata dis_idx = 0;   //lcd display index
uint8 xdata buf_idx = 0;  //buffer index
uint8 xdata tmp_data_buf[LCD_SCROLL_CNT][17] = { {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},}; //Initialize tmp_data_buf [LCD_SCROLL_CNT(32)][17]

void lcd_app(SOCKET s, uint16 port, uint8 xdata * data_buf)
{
  uint16 len;
  uint8 xdata welcome_msg1[]	= "Welcome to Network CH_LCD";
  uint8 xdata welcome_msg2[]	= "\r\niMCU W7100 controls 16x2 Character_LCD.";
  uint8 xdata drt_msg1[]		= "-th row (max:32 rows), Input 16 characters : ";
  uint8 xdata sucess_msg[]		= "\r\n from iMCU7100EVB :" ; 
  uint8 xdata str[31];
  sprintf(str,"\r\nIP ADDRESS : %.3bu.%.3bu.%.3bu.%.3bu",
			 IINCHIP_READ (SIPR0+0),  IINCHIP_READ (SIPR0+1), 
			 IINCHIP_READ (SIPR0+2),  IINCHIP_READ (SIPR0+3));

  switch (getSn_SR(s))
	{
	case SOCK_ESTABLISHED:	
		 /* if connection is established */
		 
		 /* If Socket Interrupt Register valure is Sn_IR_CON(0x01)*/
		 if(getSn_IR(s) & Sn_IR_CON) 
		 	{
				/* Initialize coounter, index, and buffers.	*/
				recv_cnt = 0;
				dis_idx = 0;
				buf_idx = 0;
				memset((void*) tmp_data_buf, '\0', sizeof(tmp_data_buf)); 

				/* Clear LCD & Output Init. messege */
				lcd_command(LCD_CLEAR);	
				evb_set_lcd_text(0," Network CH_LCD ");	

				/* Send welcome messeges to remote PC	*/
				send(s, welcome_msg1, sizeof(welcome_msg1));	
				send(s, str, sizeof(str));	
				send(s, welcome_msg2, sizeof(welcome_msg2));	
				
				/* Set Sn_IR to Sn_IR_CON */
				setSn_IR(s, Sn_IR_CON);		 		

			    /* Send input msg to remote PC */
			    sprintf(data_buf,"\r\n  %.2bu\0",buf_idx);
			    send(s, data_buf, strlen(data_buf));			 
				send(s, drt_msg1, sizeof(drt_msg1));			 
		 	}

		/* check RX data */
		if ((len = getSn_RX_RSR(s)) >= 16) 		       // If the received data length is larger than 16
		{
			/* read the received data */	
			len = recv(s, data_buf, 16);			          
			/* Input Null ,'0', to divide data_bufs */
			data_buf[len]=0;    

			/* Copy data_buf to tmp_data_buf with buf idx */				                        
			memcpy(tmp_data_buf[buf_idx],data_buf,len);

			/* send msg to Remote PC*/
			send(s, sucess_msg, sizeof(sucess_msg));
			send(s, tmp_data_buf[buf_idx], len);				 

			/* increase and update buf_idx */
			buf_idx++;
			buf_idx = buf_idx % LCD_SCROLL_CNT;

			/* Send input msg to remote PC */
	    	sprintf(data_buf,"\r\n  %.2bu\0",buf_idx);
	    	send(s, data_buf, strlen(data_buf));			 
			send(s, drt_msg1, sizeof(drt_msg1));			 
			
			if(recv_cnt++ > LCD_SCROLL_CNT) recv_cnt=LCD_SCROLL_CNT;

		}

		break;
	case SOCK_CLOSE_WAIT:                           		/* If the client request to close */
		printf("CLOSE_WAIT : %bu\r\n",  s);
		disconnect(s);
		break;

	case SOCK_CLOSED:                                               /* if a socket is closed */
		printf("CLOSED. CH : %bu\r\n",  s);
		close(s);
		socket(s,Sn_MR_TCP,port,0x00);
		break;

	case SOCK_INIT:                                               /* if a socket is initiated */
		listen(s);
		printf("Started. CH : %bu \r\n",  s);
		break;
		
	default:
		break;
	
	}
	/* Scroll Up */
  lcd_scroll();
  
}

/* Scroll Up*/
void lcd_scroll()
{
	if((recv_cnt)<3){
		evb_set_lcd_text(1,tmp_data_buf[dis_idx]);//Output tmp_data_buf to Ch_LCD
	}else{
		evb_set_lcd_text(0,tmp_data_buf[dis_idx]);//Output tmp_data_buf to Ch_LCD

		/*for indexing of display */
		dis_idx = (dis_idx + 1) % (recv_cnt);	 	
    	dis_idx %= LCD_SCROLL_CNT;

		evb_set_lcd_text(1,tmp_data_buf[dis_idx]);//Output tmp_data_buf to Ch_LCD
		
		wait_10ms(100); // delay for 1Sec.
	}
}

