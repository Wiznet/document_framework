
#include "..\..\..\drivers\TCPIPcore.h"
#include "lcd_app.h"
#include "lcd.h"        //lcd driver

#define	MAX_BUF_SIZE	8192		// Maximum receive buffer size

/*******************************************************************************************/
/* If you have QFN64pin package W7100A, have to use 'USE_QFN64' definition in TCPIPcore.h  */
/*******************************************************************************************/

//void Init_iMCU(); 		
//void Init_Network();	
uint8 xdata * data_buf =(uint8 xdata *)0x7000;	// Position of receive buffer

void main()
{

	Init_iMCU();		// Initialize iMCUW7100    
	lcd_init();     // Initialize Charater LCD
	
	evb_set_lcd_text(0,(uint8 *) "iMCU7100EVB");
	
	Init_Network(); // Initialize Network configuration

	printf("\r\n-------NETWORK_CH_LCD_TEST_START--------\r\n"); // output to serial port
	
	/* Output LCD */
	lcd_command(LCD_CLEAR);	
	evb_set_lcd_text(0," Network CH_LCD ");	
	
	/* Call lcd_app */		
	while(1){
			lcd_app(0, 5000, data_buf);
	}				  	
}  