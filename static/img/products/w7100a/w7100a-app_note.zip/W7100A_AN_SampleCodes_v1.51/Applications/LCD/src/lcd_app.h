#include "..\..\..\drivers\types.h"

void lcd_app(SOCKET s, uint16 port, uint8  xdata * data_buf);
void lcd_scroll();