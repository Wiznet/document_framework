
#include "..\..\..\..\drivers\TCPIPCore.h"

/*******************************************************************************************/
/* If you have QFN64pin package W7100A, have to use 'USE_QFN64' definition in TCPIPcore.h  */
/*******************************************************************************************/

uint16 xdata temp = 0;
uint8 RLDH_tmp = 0;
uint8 RLDL_tmp = 0;

void main()
{
	CHIP_Init(); // MCU Core init

	P0_PU = 0xFF;	// GPIO Pull-up setting for 3.3V output     
	P1_PU = 0xFF;
	P2_PU = 0xFF;
	P3_PU = 0xFF;

   	 T2CON = 0x00;
	 CT2 = 0;
	 EXEN2 = 1;
	 CPRL2 = 1;
	 TH2 = 0; TL2 = 0;
	 RLDH = 0; RLDL = 0;
	 EA = 1; ET2 = 1;
	 TR2 = 1;		
     while(1);
}

void int_test2(void) interrupt 5		 //Timer2 interrupt
{
  	 TF2 = 0;		
	 if(EXF2)
	 {
	 RLDH_tmp =	RLDH;	   // Capture
	 RLDL_tmp = RLDL;
	 }
	 EXF2 = 0;

	 temp++;
	 if(temp == 8000)
	 {
		 P0_3 = ~P0_3;	
		 temp = 0;
	 }
}
