#include "..\..\..\..\drivers\TCPIPCore.h"

uint16 xdata temp = 0;
uint16 xdata temp1 = 0;

void Init8051(); 		

/*******************************************************************************************/
/* If you have QFN64pin package W7100A, have to use 'USE_QFN64' definition in TCPIPcore.h  */
/*******************************************************************************************/


void main()
{
	CHIP_Init(); // MCU Core init

	P0_PU = 0xFF;	// GPIO Pull-up setting for 3.3V output     
	P1_PU = 0xFF;
	P2_PU = 0xFF;
	P3_PU = 0xFF;
    TMOD = 0x00;
    TH0 = 0x00; TL0 = 0x00;			   
	TH1 = 0; TL1 = 0;			   
    ET0 = 1; ET1 = 1;			   
    EA = 1;
    TR0 = 1;
	P0_3 = 1;
	P0_4 = 0;                    
 	while(1);

}

void int_test(void) interrupt 1	   //Timer0 interrupt
{

	temp++;					 
	TF0 = 0;				
	if(temp == 200)
	{
		P0_3 = ~P0_3;				
		temp = 0;
	}
}

void int_test1(void) interrupt 3    //Timer1 interrupt
{

	temp1++;				 
	TF1 = 0;				
	if(temp1 == 200)
	{
		P0_4 = ~P0_4;
		temp1 = 0;
	}

}