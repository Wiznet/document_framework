#include "..\..\..\..\drivers\TCPIPCore.h"
uint16 xdata temp = 0;

/*******************************************************************************************/
/* If you have QFN64pin package W7100A, have to use 'USE_QFN64' definition in TCPIPcore.h  */
/*******************************************************************************************/
		
void main()
{	
	CHIP_Init(); // MCU Core init
//	TMOD &= 0xF0;
//  TMOD |= 0x00;
	P0_PU = 0xFF;	// GPIO Pull-up setting for 3.3V output     
	P1_PU = 0xFF;
	P2_PU = 0xFF;
	P3_PU = 0xFF;
	TMOD = 0x00;				   
    TH0 = 0; TL0 = 0;			  
    ET0 = 1; 
    EA = 1;
    TR0 = 1; 
 	while(1);

}

void int_test(void) interrupt 1	   //Timer0 interrupt
{
	temp++;					           
	TF0 = 0;				          
	if(temp == 200)
	{
		P0_3 = ~P0_3;				   
		temp = 0;
	}
}

void int_test2(void) interrupt 2
{
 	P0_4 = ~P0_4;
}

