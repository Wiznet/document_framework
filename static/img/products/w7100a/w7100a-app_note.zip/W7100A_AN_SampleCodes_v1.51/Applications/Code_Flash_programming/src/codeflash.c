#pragma userclass(code=ISP)

#include "..\..\..\drivers\w7100.h"
#include "codeflash.h"
#include "codeflash_callFunc.h"


/*****************************************************************************************
	Function name: code_read_byte
	Input	: 	isp_addr; Code flash memory address for read
	Output	:	ret; read data 
	Description
	: A code flash function for read 1 byte data.
*****************************************************************************************/
unsigned char code_read_byte(unsigned short isp_addr)
{
	unsigned char ret;
	EA = 0;    				// Disable EA
	WCONF &= ~(0x40);     	// Enable ISP Entry
	
	ISPID = ISP_BREAD;
	ISPADDR16 = isp_addr;
	codeflash_callFunc();		// Call ISP Entry
	ret = ISPDATA;
	
	WCONF |= 0x40;        	// Disable ISP Entry
	EA =1;					// Enable EA

	return ret;
}

/*****************************************************************************************
	Function name: code_write_byte
	Input	:	isp_addr; Code flash memory address for write, 
				isp_data; data for write
	Output	:	ISPDATA; written data
	Description
	: A code flash function for write 1 byte data.
*****************************************************************************************/			
unsigned char code_write_byte(unsigned short isp_addr, unsigned char isp_data)
{
	EA = 0;    				// Disable EA
	WCONF &= ~(0x40);     	// Enable ISP Entry	
			 
	ISPID = ISP_BPROG;
	ISPADDR16 = isp_addr;
	ISPDATA = isp_data;
	codeflash_callFunc();		// Call ISP Entry	

	WCONF |= 0x40;        	// Disable ISP Entry
	EA =1;					// Enable EA

	return ISPDATA;
}


/*****************************************************************************************
	Function name: code_sector_erase
	Input	:	isp_addr; Code flash memory address for erase start
	Output	:	non
	Description
	: A code flash function for erase 256 byte(sector) data.
*****************************************************************************************/
void code_sector_erase(unsigned short isp_addr)
{		
	EA = 0;    				// Disable EA
	WCONF &= ~(0x40);    	// Enable ISP Entry
	
	ISPID = ISP_ERASE;
	codeflash_callFunc();		// Call ISP Entry	
	
	ISPID = ISP_SERASE;		// Sector erase
	ISPADDR16 = isp_addr; 	// First delete address(sector)
	ISPDATA = 0;
	codeflash_callFunc();		// Call ISP Entry	
	
	WCONF |= 0x40;			// Disable ISP Entry
	EA = 1;					// Enable EA
}

/*****************************************************************************************
	Function name: code_chip_erase
	Input	:	non
	Output	:	non
	Description
	: A code flash function for whole data erase in chip.
*****************************************************************************************/
void code_chip_erase(void)
{
	EA = 0;    				// Disable EA
	WCONF &= ~(0x40);    	// Enable ISP Entry
	
	ISPID = ISP_ERASE;
	codeflash_callFunc();		// Call ISP Entry		
	
	ISPID = ISP_MERASE;		// Whole code flash memory data erase
	codeflash_callFunc();		// Call ISP Entry	
	
	WCONF |= 0x40;			// Disable ISP Entry
	EA = 1;					// Enable EA
}