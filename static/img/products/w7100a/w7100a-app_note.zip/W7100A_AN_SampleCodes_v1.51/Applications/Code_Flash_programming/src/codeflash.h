#ifndef __ISP_H_
#define __ISP_H_

#define ISP_ENTRY          	0x07FD

#define ISP_ERASE			0x80

#define ISP_SERASE         	0x30 				   
#define ISP_MERASE         	0x10 
                          
#define ISP_BREAD          	0x00 		
#define ISP_BPROG          	0xA0
			
unsigned char code_read_byte(unsigned short isp_addr);
unsigned char code_write_byte(unsigned short isp_addr, unsigned char isp_data);
void code_sector_erase(unsigned short isp_addr);	 
void code_chip_erase(void);

#endif
