#pragma userclass(CODE = PRO)

void codeflash_callFunc(void)
{
;
}
