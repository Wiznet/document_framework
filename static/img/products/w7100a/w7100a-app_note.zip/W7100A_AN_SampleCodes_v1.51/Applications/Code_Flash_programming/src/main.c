#pragma userclass(CODE = ISP)
#include <stdio.h>
#include "..\..\..\drivers\tcpipcore.h"	
#include "codeflash.h"
#include "codeflash_callFunc.h"

/*******************************************************************************************/
/* If you have QFN64pin package W7100A, have to use 'USE_QFN64' definition in TCPIPcore.h  */
/*******************************************************************************************/

#define FLASH_DEBUG

void code_flash_test(unsigned int base_addr);

void main(void)
{	
	uint16 base_addr;	 
	Init_iMCU();			 
	base_addr = 0x5000; // set base address	   

	code_flash_test(base_addr);

	//code_chip_erase(); // whole data erase in code flash

	while(1);			
}

void code_flash_test(unsigned int base_addr)
{
 	uint16 i;
	uint8 j = 0;
	uint16 addr;	
	uint8 wd[256];
	uint8 verify_failed_flag = 0;

	printf("\r\n==============================================\r\n");
	printf("  Code Flash [Read / Write / Erase] Test\r\n");	  
	printf("  [Base memory address : 0x%x]", base_addr);
	printf("\r\n==============================================\r\n");	
	
	// code flash erase
	printf("\r\n=> Code Flash erase ... (0x%x ~ 0x%x)\r\n", base_addr, base_addr+0xff);
	addr = base_addr;
	code_sector_erase(addr);

	// code flash write	
	printf("\r\n=> Code Flash write ... (0 ~ ff)\r\n");
	addr = base_addr;
	for(i=0; i<=0xff; i++)
	{	
		wd[i] = code_write_byte(addr, j);
		addr += 1; j += 1;				  	
	}	
	
	// code flash verify
	// if written data and read data are same, the code flash access process success.	
	printf("\r\n=> Code Flash verify ... (0x%x ~ 0x%x)\r\n", base_addr, base_addr+0xff);
	printf("\r\n[(O); correct data, (X); incorrect data]\r\n");
	addr = base_addr;	 		
	for(i=0; i<=0xff; i++)
	{
		if((i % 0x10) == 0x00) printf("0x%x ", addr);		
				
		if (code_read_byte(addr) == wd[i])
		{
			printf("(O) ");	
		}
		else 
		{	
			verify_failed_flag = 1;
			printf("(X) ");
		}		  
		if((i % 0x10) == 0x0F) printf(" 0x%x\r\n", addr);	
		addr +=1;
	}	
	if(verify_failed_flag) printf("\r\nVerify failed!\r\n");					  	 	
	else printf("\r\nProgramming / verify OK!\r\n");
						  
	printf("\r\n==============================================\r\n");
	printf("  Code Flash [Read / Write / Erase] Test end  ");	  
	printf("\r\n==============================================\r\n");
}
