#ifndef _FLASH_DM_H_
#define _FLASH_DM_H_

void codeflash_callFunc(void);

#endif
