#include "..\..\..\drivers\TCPIPcore.h"


/*******************************************************************************************/
/* If you have QFN64pin package W7100A, have to use 'USE_QFN64' definition in TCPIPcore.h  */
/*******************************************************************************************/
						

uint8 led_blink_trigger = 0;

void wd_init(void);
void wd_resetTimer(void);
void chip_reset(void);


void chip_reset(void)
{
#pragma ASM
		POP  ACC  //; pop return address
		POP  ACC
		CLR  A    //; push 0 as new
		PUSH ACC  //; return address to stack
		PUSH ACC
		RETI      //; execute return of interrupt
#pragma ENDASM
}

void wd_resetTimer(void)
{
 	TA=0xAA;TA=0x55;RWT=1;
}

void wd_init(void)
{
	uint8 tmpEA;

	tmpEA = EA;
	EA = 0;

	//CKCON |= 0xC0;	  					// CKCON.7-6 = WD[1:0] : Watchdog Interval
	CKCON |= 0x80;	  					// CKCON.7-6 = WD[1:0] : Watchdog Interval
	TA=0xAA;TA=0x55;WDCON = 0x00;		// WDCON Clear

	TA=0xAA;TA=0x55;EWT = 0;			// Disable Watchdog Timer Reset (WDCON)	
	//TA=0xAA;TA=0x55;WDIF = 1;			// Watchdog Interrupt flag set (WDCON), if WDIF sets 1, watchdog interrupt occur immediately followed by end of the wd_init() function. 	
	TA=0xAA;TA=0x55;WDIF = 0;			// Watchdog Interrupt flag clear (WDCON)	
	EWDI = 1;		   					// Enable Watchdog Timer Interrupt (EIE)		

	EA = tmpEA;	   					
}

void main()
{
	 
	Init_iMCU();	 	// Initialize   iMCUW7100
	Init_Network(); 	// Initialize   Network Configuration

	wd_init();		 
	EA = 1;				// Global interrupt enable

	while(1)
	{			
		printf(".");
		//wd_resetTimer();
	}
}

void wd_isr(void) interrupt 12
{
 	uint8 tmpEA;

	tmpEA = EA;					// Backup global interrupt status
 	EA = 0;	 					// Global interrupt disable

	TA=0xAA; TA=0x55; WDIF = 0; // Watchdog interrupt flag clear

	chip_reset(); 				// Chip reset

	EA = tmpEA;				   	// Global interrupt restoration
}
