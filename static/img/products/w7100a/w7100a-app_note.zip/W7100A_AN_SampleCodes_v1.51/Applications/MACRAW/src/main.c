
#include "..\..\..\drivers\TCPIPcore.h"
#include "arp.h"
#include "lcd.h"
#define	MAX_BUF_SIZE	8192		// Maximum receive buffer size

/*******************************************************************************************/
/* If you have QFN64pin package W7100A, have to use 'USE_QFN64' definition in TCPIPcore.h  */
/*******************************************************************************************/

void main()
{
	//Init. Ping_Request
	uint8 xdata ip[4];
	uint8 xdata mac[6];      
	uint8 xdata pDestaddr[4];
	uint16 xdata pCount;
	uint16 xdata pPort;	
  
	Init_iMCU();		// Initialize   iMCUW7100
	lcd_init();  
	evb_set_lcd_text(0,(uint8 *) "iMCU7100EVB");     
	Init_Network(); 	// Initialize   Network Configuration 

	//start message
	printf("\r\n-------ARP_TEST_START--------\r\n");

	/* Read MAC address of W7100A from SHAR register */
	mac[0] = IINCHIP_READ (SHAR0+0);
	mac[1] = IINCHIP_READ (SHAR0+1);
	mac[2] = IINCHIP_READ (SHAR0+2);
	mac[3] = IINCHIP_READ (SHAR0+3);
	mac[4] = IINCHIP_READ (SHAR0+4);
	mac[5] = IINCHIP_READ (SHAR0+5);

	/* Read IP address of W7100A from SIPR register */
	ip[0] = IINCHIP_READ (SIPR0+0);
	ip[1] = IINCHIP_READ (SIPR0+1);
	ip[2] = IINCHIP_READ (SIPR0+2);
	ip[3] = IINCHIP_READ (SIPR0+3);
	
	//set Dest. IP address & Port
	pDestaddr[0]= 192;
	pDestaddr[1]= 168;
	pDestaddr[2]= 1;
	pDestaddr[3]= 214;
	pPort = 3000;

	printf( "Destination IP  : %.3bu.%.3bu.%.3bu.%.3bu\r\n", pDestaddr[0], pDestaddr[1], pDestaddr[2], pDestaddr[3] ) ;

	//set ping request count
	pCount = 3;		  	
	
	arp(0, pPort, &ip, &mac, &pDestaddr, pCount);
	printf("\r\n-------ARP_TEST_END--------\r\n");
	
	while(1);

}

