void ExMEM_WRITE(uint16 addr,uint8 dat);
uint8 ExMEM_READ(uint16 addr);
void ExMEM_TEST(void);