#include <stdio.h>
#include "..\..\..\drivers\TCPIPCore.h"
#include "external_memory.h"

/*******************************************************************************************/
/* If you have QFN64pin package W7100A, have to use 'USE_QFN64' definition in TCPIPcore.h  */
/*******************************************************************************************/

void main()
{	
	Init_iMCU(); 					// Initialize MCU        	

   	ExMEM_TEST();					// Call External memory access test function
	while(1);
}