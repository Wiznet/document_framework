/*
**********************************************************************
* Description : W7100A External memory access test function
* Argument : 
* Returns : 
* Note : Just use for testing
**********************************************************************
*/		 
#include "..\..\..\drivers\TCPIPCore.h"


#define MEMSIZE		0x7fff // 32KB

/* Define mode selection */
//#define 	STANDARD1
#define 	DIRECT1

void ExMEM_WRITE(uint16 addr, uint8 dat) 
{
	uint8 tmpEA; 

	tmpEA = EA;		// Interrupt register backup
	EA = 0;			// Interrupt disable							   	
	DPX0 = 0x01; 	// DPX0 for External memory	
	*((vuint8 xdata*)(addr)) = dat;
	DPX0 = 0x00;	// DPX0 clear
	EA = tmpEA;		// Interrupt register recover
}

uint8 ExMEM_READ(uint16 addr)
{
	uint8 dat;
	uint8 tmpEA;
	
	tmpEA = EA;		// Interrupt register backup
	EA = 0;			// Interrupt disable	
	DPX0 = 0x01; 	// DPX0 for External memory	
	dat = *((vuint8 xdata*)(addr));	
	DPX0 = 0x00;	// DPX0 clear	
	EA = tmpEA;		// Interrupt register recover

	return dat;		// Return read data
}


//***************************************************************************************************
// External Memory Access Test
// Mode : [Standard 1] [Direct 1]
//***************************************************************************************************
// [Standard mode 1] (standard 8051 external interface)
// EM[2:0] = (001)b	(WCONF)
// P0 = Data[7:0] / Addr[7:0], P1 = GPIO, P2 = Addr[15:8], P3 = GPIO
// CS = Addr[15]
// ALE
//
// [Direct access mode 1]
// EM[2:0] = (101)b	(WCONF)
// P0 = Data[7:0], P1 = Addr[7:0], P2 = Addr[15:8], P3 = GPIO
// CS = Addr[15]
//***************************************************************************************************
void ExMEM_TEST(void)
{		
	uint8 xdata read;		// Read data
	uint8 xdata d;			// Write data for test	
	uint8 xdata kbcount;
	uint16 xdata rcount, ecount;
	uint16 xdata i;
	
	// WCONF: W7100 Configuration Register
	// ALECON: Address Latch Enable Register
#ifdef STANDARD1	
	WCONF |= 0x48;		// Standard mode 1, (0100 1000)b
	ALECON = 0xff;		// default 
#endif	
#ifdef DIRECT1	
	WCONF |= 0x68;		// Direct access mode 1, (0110 1000)b
	ALECON = 0; 
#endif 
	printf("WCONF - Enable external memory access\r\n");
	printf("WCONF = 0x%.2bx\r\n", WCONF);			
	printf("ALECON = 0x%.2bx\r\n", ALECON);			 

	// External memory WR/RD timing control (16-bits), default : 0xffff	
	EXTWTST0 = 0x10;
	EXTWTST1 = 0x00;
	printf("EXTWTST0 = 0x%.2bx, EXTWTST1 = 0x%.2bx\r\n", EXTWTST0, EXTWTST1);

	// 1. Write		
	printf("[ExMEM access: Write - Start]\r\n");	
	kbcount = 1;
	d = 0x01;
	for(i = 0x0000; i <= MEMSIZE; i++)	
	{					  		
		ExMEM_WRITE(i, d);
			
		if (((i+1) % 0x0400) == 0) 		
		{			 	
			d++;
			//printf("\r\nWrite [%buKByte]\r\n", kbcount++);
			printf(".");	
		}		
	}
	printf("\r\n[ExMEM access: Write - done]\r\n");	
	printf("\r\n");
	
	// 2. Read and compare
	printf("[ExMEM access: Read and Compare - Start]\r\n");		
	d = 0x01;
	rcount = 0; // read count
	ecount = 0; // error count								
	for(i = 0x0000; i <= MEMSIZE; i++)
	{			
		if((i % 0x10) == 0x00) printf("[0x01%.4x] ", i);
		read = ExMEM_READ(i);
		if(read == d) 	
		{				
			printf("%.2bx ", read);
		}
		else 
		{				
			printf("%.2bx ", read);
			ecount++;
		}		
		
		if((i % 0x10) == 0x0F) printf("\r\n");  		
		if (((i+1) % 0x0400) == 0)		
		{
			printf("========================================================== %buKByte end\r\n", d);		
			d++;			
		}		 
		rcount++;		
	}
	printf("\r\n");
	printf("[ExMEM access: Read and Compare - End]\r\n");
	printf("[ExMEM R/W Test result] Written byte count = %u, Error count = %u\r\n", rcount, ecount);
	printf("\r\n");

//	WCONF &= ~(0x28);
//	printf("WCONF - Disable external memory access\r\n");
//	printf("WCONF = %bx\r\n", WCONF);	 
}