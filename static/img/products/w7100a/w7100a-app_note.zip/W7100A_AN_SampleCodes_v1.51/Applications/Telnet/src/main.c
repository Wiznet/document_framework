#include "..\..\..\drivers\TCPIPCore.h"
#include "telnet.h"
//#include "delay.h"

//define __DEF_IINCHIP_INT__;

/*******************************************************************************************/
/* If you have QFN64pin package W7100A, have to use 'USE_QFN64' definition in TCPIPcore.h  */
/*******************************************************************************************/

int main()
{
	Init_iMCU();		// Initialize   iMCUW7100
	Init_Network(); 	// Initialize   Network Configuration

	while(1)
	{
		TELNETS(0, 23);		// Telnet port 23
	}
	return 0;
}


