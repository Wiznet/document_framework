/* 
(c) Copyright 2009, WIZnet
File name : telnet.h
Version : 0.9Beta
Programmer : Y.S. Lee
Description : The header of Telnet
*/

#include <ctype.h>
#include "..\..\..\drivers\TCPIPCore.h"
#include "telnet.h"

/*Telnet commands*/
enum tel_cmd{
	HELP_CMD,
	GET_LED_CMD,
	LED0_ON_CMD,
	LED1_ON_CMD,
	LED2_ON_CMD,	
	LED0_OFF_CMD,
	LED1_OFF_CMD,
	LED2_OFF_CMD,
	EXIT_CMD
};


/*Command table*/
char *commands[] = {
	"help",
	"get led",
	"led0 on",
	"led1 on",
	"led2 on",
	"led0 off",
	"led1 off",
	"led2 off",
	"exit",
	NULL
};

char *tel_options[] = {
	"Transmit Binary",
	"Echo",
	"",
	"Suppress Go Ahead",
	"",
	"Status",
	"Timing Mark"
};


char xdata remote[NOPTIONS] = {0};		//Remote option settings
char xdata buf[LINELEN] = {0};

uint8 xdata user_name[DATA_BUF_SIZE];
uint8 xdata user_password[DATA_BUF_SIZE];
uint8 xdata data_buf[DATA_BUF_SIZE];

uint8 user_state;
uint8 first = 1;
int xdata buf_index = 0;
/*Function Implementation Part*/

void TELNETS(SOCKET s, uint16 port)
{

		switch(getSn_SR(s))
		{
			case SOCK_ESTABLISHED:
				if(first == 1)
				{
					printf("W7100 TELENT server started via SOCKET%bu\r\n", s);
					init_telopt(s);
					first = 0;
				}
				if((getSn_RX_RSR(s)) > 0)
				{
					tel_input(s);
				}
				break;
		
			case SOCK_CLOSE_WAIT:
				disconnect(s);
				break;

			case SOCK_CLOSED:
				printf("Close SOCKET:%bu\r\n", s);
				close(s);
				socket(s, Sn_MR_TCP, port, 0);
				break;

			case SOCK_INIT:
				listen(s);
				printf("Listen SOCKET:%bu for Telnet server\r\n", s);
				user_state = USERNAME;
				first = 1;
				break;
		}
}

void init_telopt(SOCKET s)
{
//	sendIAC(s, DO, TN_TERMINAL_TYPE);
	sendIAC(s, DO, TN_ENVIRONMENT);
	sendIAC(s, WILL, TN_ECHO);
} 
void sendIAC(SOCKET s, char r1, char r2)
{
	switch(r1)
	{
		case WILL:
			printf("sent: will");
			break;

		case WONT:
			printf("sent: wont");
			break;

		case DO:
			printf("sent: do");
			break;

		case DONT:
			printf("sent: dont");
			break;
	}
	if(r2 <= NOPTIONS)
		printf("%s\r\n", tel_options[r2]);
	else
		printf("%u\r\n", r2);

	sprintf(buf, "%c%c%c", IAC, r1, r2);
	send(s, buf, strlen(buf));
}


void tel_input(SOCKET s)
{
	uint8 xdata c;
	while(1)
	{
	 	if((getSn_RX_RSR(s)) == 0) break;
		
		if(recv(s, &c, 1) == 0) break;
		
		if(user_state == LOGOUT) break;
		
		if(c != IAC)
		{
			data_buf[buf_index++] = c;
			putchar(c);

			if(user_state == LOGOUT) break;

			if(user_state != PASSWORD)
			{
			 	sprintf(buf, "%c", c);
				send(s, buf, strlen(buf));
			}
			
			if(c == '\n')
			{
				if(buf_index > 1)
				{
					if(data_buf[buf_index-2] == '\r') data_buf[buf_index-2] = '\0';
		
					else data_buf[buf_index-1] = '\0';
													
					proc_command(s);
		
					if(user_state == LOGIN)
					{
			 			sprintf(buf, "W7100>");
						send(s, buf, strlen(buf));
					}
				}
				else
				{
			 		sprintf(buf, "W7100>");
					send(s, buf, strlen(buf));
				}
				buf_index = 0;
			}
			continue;
		}

		if(recv(s, &c, 1) == 0) break;
		switch(c)
		{
			case WILL:
				if(recv(s, &c, 1) == 0) break;
				willopt(s, c);
				break;
			case WONT:
				if(recv(s, &c, 1) == 0) break;
				wontopt(s, c);
				break;
			case DO:
				if(recv(s, &c, 1) == 0) break;
				doopt(s, c);
				break;			
			case DONT:
				if(recv(s, &c, 1) == 0) break;
				dontopt(c);
				break;
			case IAC:
				break;
		}
		break;
	}
	return;
}

void proc_command(SOCKET s)
{
	char **cmdp, *cp;
	char *help = {"       HELP: Show all available commands\r\n\    GET LED: Show all LED status\
				  \r\nLED0 ON/OFF: Turn ON/OFF the LED0\r\nLED1 ON/OFF: Turn ON/OFF the LED1\
				  \r\nLED2 ON/OFF: Turn ON/OFF the LED2\r\n       EXIT: Exit from W7100 Telnet server\r\n"};
//	uint16 len;
	uint8 i;
	/*Translate the first word to lower case*/	   
	for(cp = data_buf; *cp !='\0'; cp++)
	{
		*cp = tolower(*cp);
	}

	/*Allow only permitted USER, PASS and QUIT berfore logging in*/
	if(user_state == USERNAME)
	{
		strcpy(user_name, data_buf);
		sprintf(buf, "Please insert your PW: ");
		send(s, buf, strlen(buf));
		user_state = PASSWORD;
		return;
	}
	else if(user_state == PASSWORD)
	{
		strcpy(user_password, data_buf);
		/*Check the client name and password*/
		sprintf(buf, "\r\nSuccessfully connected!!\r\nImplemented Command: HELP, GET LED, LED0 ON/OFF, LED1 ON/OFF, LED2 ON/OFF, EXIT\r\n");
		send(s, buf, strlen(buf));
		user_state = LOGIN;
		return;
	}

	/*Find the input command in table; if it isn't there, return Syntax Error*/
	for(cmdp = commands; *cmdp != NULL; cmdp++)
	{
		if(strncmp(*cmdp, data_buf, strlen(*cmdp)) == 0)	break;
	}
	
	if(*cmdp == NULL)
	{
		printf("NULL command\r\n");
		sprintf(buf, "BAD command\r\n");
		send(s, buf, strlen(buf));
		return;
	}
	
	/*Execute specific command*/
	switch(cmdp - commands)
	{
		case HELP_CMD:
			printf("HELP_CMD\r\n");
			sprintf(buf, help);
			send(s, buf, strlen(buf));
			break;

		case GET_LED_CMD:
			printf("GET_LED_CMD\r\n");
			for(i = 0 ; i < 3 ; i++)
			{ 
				sprintf(buf, "LED%bd is %s\r\n", i, ((P0 >> (i+3)) & 0x01) ? "OFF" : "ON");
				send(s, buf, strlen(buf));
			}
			break;

		case LED0_ON_CMD:
			printf("LED0_ON_CMD\r\n");
			sprintf(buf, "Turn ON the LED0\r\n");
			send(s, buf, strlen(buf));
			P0_3 = 0;
			break;

		case LED1_ON_CMD:
			printf("LED1_ON_CMD\r\n");
			sprintf(buf, "Turn ON the LED1\r\n");
			send(s, buf, strlen(buf));
			P0_4 = 0;
			break;
		
		case LED2_ON_CMD:
			printf("LED2_ON_CMD\r\n");
			sprintf(buf, "Turn ON the LED2\r\n");
			send(s, buf, strlen(buf));
			P0_5 = 0;
			break;

		case LED0_OFF_CMD:
			printf("LED0_OFF_CMD\r\n");
			sprintf(buf, "Turn OFF the LED0\r\n");
			send(s, buf, strlen(buf));
			P0_3 = 1;
			break;

		case LED1_OFF_CMD:
			printf("LED1_OFF_CMD\r\n");
			sprintf(buf, "Turn OFF the LED1\r\n");
			send(s, buf, strlen(buf));
			P0_4 = 1;
			break;
		
		case LED2_OFF_CMD:
			printf("LED2_OFF_CMD\r\n");
			sprintf(buf, "Turn OFF the LED2\r\n");
			send(s, buf, strlen(buf));
			P0_5 = 1;
			break;
		
		case EXIT_CMD:
			printf("EXIT command\r\n");
			sprintf(buf, "EXIT command\r\n Good Bye~~\r\n Logout from W7100 TELNET");
			send(s, buf, strlen(buf));
			close(s);
			user_state = LOGOUT;
			break;

		default:
			break;
	}
}

void willopt(SOCKET s, int opt)
{
	int ack;
	printf("Recv: will");
	if(opt <= NOPTIONS) printf("%s\r\n", tel_options[opt]);
	else printf("%u\r\n", opt);

	switch(opt)
	{
		case TN_TRANSMIT_BINARY:
		case TN_ECHO:
		case TN_SUPPRESS_GA:
			ack = DO;
			break;
		default:
			ack = DONT;  /*We don't know what his offering; refuse*/	
	}
	sendIAC(s, ack, opt);
}

void wontopt(SOCKET s, int opt)
{
	printf("recv: wont");
	if (opt <= NOPTIONS) printf("%s\r\n", tel_options[opt]);
	else printf("%u\r\n", opt);

	switch(opt)
	{
	case TN_TRANSMIT_BINARY:
	case TN_ECHO:
	case TN_SUPPRESS_GA:
		if (remote[opt] == 0)
		{ 
			remote[opt] = 1;
			sendIAC(s, DONT, opt);	 /* Must be always acceptted */
		}
		break;
	}
}

void doopt(SOCKET s, int opt)
{
	printf("recv: do ");
	if (opt <= NOPTIONS) printf("%s\r\n", tel_options[opt]);
	else printf("%u\r\n", opt);

	switch(opt)
	{
	case TN_SUPPRESS_GA:
		sendIAC(s, WILL, opt);
		break;
	case TN_ECHO:
		sprintf(buf, "WELCOME TO THE W7100 TELNET SERVER!!\r\nPlease insert your ID: ");
		send(s, buf, strlen(buf));
		break;
	default:
		sendIAC(s, WONT, opt);
	}
}

void dontopt(int opt)
{
	printf("recv: dont ");
	if (opt <= NOPTIONS) printf("%s\r\n", tel_options[opt]);
	else printf("%u\r\n", opt);

	switch(opt)
	{
	case TN_TRANSMIT_BINARY:
	case TN_ECHO:
	case TN_SUPPRESS_GA:
		if (remote[opt] == 0) remote[opt] = 1;
		break;
	}
}