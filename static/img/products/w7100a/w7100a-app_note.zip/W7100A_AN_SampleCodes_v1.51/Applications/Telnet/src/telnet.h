/* 
(c) Copyright 2009, WIZnet
File name : telnet.h
Version : 0.9Beta
Programmer : Y.S. Lee
Description : The header of Telnet
*/

#define IPPORT_TELNET 23      //Telnet port
#define LINELEN 400
#define DATA_BUF_SIZE 100
#define	TELNET_SOCK 0        //Telnet socket

#define USERNAME 1
#define	PASSWORD 2
#define	LOGIN 3
#define	LOGOUT 4


/*Define Telnet Commands*/
#define	IAC 0xFF      //Interpret as command
#define DONT 254      
#define DO 253
#define WONT 252
#define WILL 251

#define NOP	241
#define DATA_MARK 242
#define BRK 243	      //break
#define INT_PROC 244       //Innterrupt process
#define AO		//Abort output
#define AYT 246       //Are You There
#define	EC 247        //Erase character
#define EL 248		  //Erase Line
#define GA 249		  //Go Ahead
#define SB 250		  //SuBnegotiation


/*Telnet options*/
#define NOPTIONS 6

#define TN_TRANSMIT_BINARY 0	 //TelNet transmit binary
#define TN_ECHO 1
#define TN_SUPPRESS_GA 3       //Supress Go Ahead
#define TN_STATUS 5
#define TN_TIMING_MARK 6
#define EXOPL 0xff	  //EXtended OPtion List
#define TN_TERMINAL_TYPE 0x18
#define TN_NE_WIN_SIZE 0x1f     //TelNet NEgotiate WINdow SIZE
#define TN_ENVIRONMENT 0x24
#define TN_NEW_ENVIRONMENT 0x27

void init_telopt(SOCKET s);
void tel_input(SOCKET s);
void proc_command(SOCKET s);

void willopt(SOCKET s, int opt);
void wontopt(SOCKET s, int opt);
void doopt(SOCKET s,int opt);
void dontopt(int opt);

void sendIAC(SOCKET s, char r1, char r2);
void TELNETS(SOCKET s, uint16 port);					