
#include "..\..\..\drivers\TCPIPCore.h"
#include "dns.h"

/*******************************************************************************************/
/* If you have QFN64pin package W7100A, have to use 'USE_QFN64' definition in TCPIPcore.h  */
/*******************************************************************************************/

void main()
{
	char xdata dn[100] = {0};
	Init_iMCU();		// Initialize   iMCUW7100
	Init_Network(); 	// Initialize   Network Configuration
	while(1)
	{
		printf("\r\nInput the domain name (ex>www.wiznet.co.kr):");
		scanf("%s", dn);
		dns_query(0, dn);
	}
}

