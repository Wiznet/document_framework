#include "..\..\..\drivers\TCPIPcore.h"
#include "eeprom.h"
#include "stdio.h"

#define HIGH 1 // SDA or SCL HIGH
#define LOW	0 // SDA or SCL LOW 
#define SCL_DUTY	1 	// UNIT 1us

void eep_sendstart(void)
{
	P3_0 = HIGH;	
	wait_1us(SCL_DUTY);
	P3_1 = HIGH;	
	wait_1us(SCL_DUTY);
	P3_0 = LOW;	
	wait_1us(SCL_DUTY);
	P3_1 = LOW;	
	wait_1us(SCL_DUTY);
}

void eep_sendend(void)
{
	P3_1 = LOW;	
	wait_1us(SCL_DUTY);
	P3_0 = LOW;	
	wait_1us(SCL_DUTY);
	P3_1 = HIGH;	
	wait_1us(SCL_DUTY);
	P3_0 = HIGH;   
	wait_1us(SCL_DUTY);
}

int8 eep_checkack(void)
{				
	int8 ack;

	P3_1 = LOW;
	wait_1us(SCL_DUTY);
	P3_1 = HIGH;
	wait_1us(SCL_DUTY);
	ack = 0;	
	wait_1us(SCL_DUTY);
	P3_1 = LOW;
	wait_1us(SCL_DUTY);

	return ack;
}

void eep_sendnoack(void)
{
	P3_1 = LOW;
	wait_1us(SCL_DUTY);
	P3_0 = HIGH; 
	wait_1us(SCL_DUTY);
	P3_1 = HIGH;
	wait_1us(SCL_DUTY);
	P3_1 = LOW;
	wait_1us(SCL_DUTY);
}



int8 eep_readdata(void)
{
	int8 ret;
	int8 i;

	ret = 0;
	EA = 0;

	P3_0 = HIGH;	
	wait_1us(SCL_DUTY);
	
	
	for(i = 7; i >= 0  ; i--)
	{
		P3_1 = HIGH;	
		wait_1us(SCL_DUTY);
		
		P3_1 = LOW;	
		if (P3_0 & HIGH) ret |= (1<<i);
		wait_1us(SCL_DUTY);
	}
	EA = 1;
	return ret;
}

void eep_writedata(uint8 b)
{
	int8 i;
	
	EA = 0;
	for(i = 0 ; i < 8  ; i++) 
	{
		P3_1 = LOW;   
		wait_1us(SCL_DUTY);
		if( ((b << i) & 0x80) )  {
			P3_0 = HIGH;
		}
		else {
			P3_0 = LOW;
		}
		wait_1us(SCL_DUTY*2);

		P3_1 = HIGH;	
		wait_1us(SCL_DUTY);
	}

	P3_1 = LOW;  
	wait_1us(SCL_DUTY);
	EA = 1;
}

/*
********************************************************************************
* Description : Serial EEPROM Write routine
* Arguments   : ee_addr - write position, ee_data - data
* Returns     : None
* Note        : 
********************************************************************************
*/
void EEP_Write(uint8 ee_addr,uint8 ee_data)
{
    eep_sendstart();
	eep_writedata(0xa0); //  H/W address
	eep_checkack();
	eep_writedata(ee_addr); // addr
	eep_checkack();
	eep_writedata(ee_data); //data
	eep_checkack();
	eep_sendend();
	wait_1us(SCL_DUTY*3);
}

/*
********************************************************************************
* Description : Serial EEPROM Read routine
* Arguments   : ee_addr - read position
* Returns     : EEPROM data
* Note        : 
********************************************************************************
*/
uint8 EEP_Read(uint8 ee_addr)
{
	uint8 ee_data;

    eep_sendstart();
	eep_writedata(0xa0);
	eep_checkack();
	eep_writedata(ee_addr);
	eep_checkack();
	eep_sendstart();
	eep_writedata(0xa1);
	eep_checkack();
	ee_data = eep_readdata();
	eep_sendnoack();
	eep_sendend();

	return ee_data;
}
