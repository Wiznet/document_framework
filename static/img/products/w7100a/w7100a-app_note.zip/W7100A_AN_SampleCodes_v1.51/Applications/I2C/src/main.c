
#include "..\..\..\drivers\TCPIPcore.h"
#include "lcd.h"        //lcd driver
#include "eeprom.h"


#define	MAX_BUF_SIZE	8192// Maximum receive buffer size
#define MAX_EEPROM_SIZE 256 // byte 2048 bit

/*******************************************************************************************/
/* If you have QFN64pin package W7100A, have to use 'USE_QFN64' definition in TCPIPcore.h  */
/*******************************************************************************************/

void EEPROM_READ(void);
void EEPROM_WRITE(void);
void EEPROM_ERASE_ALL(void);
						
uint8 xdata * data_buf =(uint8 xdata *)0x7000;	// Position of receive buffer


void main()
{
	uint8 flag = 0;
		
	Init_iMCU();	// Initialize iMCUW7100
    lcd_init();     // Initialize Charater LCD
    evb_set_lcd_text(0,(uint8 *) "iMCU7100EVB");     
	Init_Network(); // Initialize Network configuration
	printf("\r\n-- EEPROM TEST IN iMCU W7100 START --\r\n"); // 

	printf("\r\n*************************************\r\n");
	/* Output LCD */
	lcd_command(LCD_CLEAR);	
	evb_set_lcd_text(0," EEPROM TEST ");	

    do{
		
		printf("1) EEPROM_WRITE \r\n"); 
		printf("2) EEPROM_READ \r\n"); 
		printf("3) EEPROM_ERASE_ALL \r\n"); 
		printf("4) Exit \r\n");  
		printf("Select number(1~4) : \r\n");
		scanf("%bd",&flag);		
		switch(flag) {
		case 1:
			EEPROM_WRITE();
			evb_set_lcd_text(0," EEPROM TEST ");		
			evb_set_lcd_text(1,"  EEPROM WRITE  ");	
			lcd_command(LCD_CLEAR);	
			break;
		case 2:
			EEPROM_READ();
			lcd_command(LCD_CLEAR);	
			evb_set_lcd_text(0," EEPROM TEST ");		
			evb_set_lcd_text(1,"  EEPROM READ   ");	
			break;
		case 3:			
			EEPROM_ERASE_ALL();
			lcd_command(LCD_CLEAR);	
			evb_set_lcd_text(0," EEPROM TEST ");		  
			evb_set_lcd_text(1,"EEPROM ERASE ALL");				
			break;
		case 4:
			lcd_command(LCD_CLEAR);	
			evb_set_lcd_text(0," EEPROM TEST ");		  
			break;
		}
			
		if(flag==4)	{
			flag =0;
			break;	
		}
	}while(1);
	printf("\r\n Bye~! \r\n"); 
	printf("\r\n*************************************\r\n");

}

void EEPROM_READ(void)
{
	uint8 s_idx, e_idx, i, tmp;
	s_idx = 0;
	e_idx = 0;
	tmp = 0;
	
	printf("\r\n**** EEPROM_WRITE ****");		
	printf("\r\n Input start address (0~%bu) :",MAX_EEPROM_SIZE-1);
	scanf("%bd", &s_idx);
	printf("\r\n Input end address (0~%bu) :",MAX_EEPROM_SIZE-1);
	scanf("%bd", &e_idx);
	printf("\r\n Read data (%bu ~ %bu)",s_idx,e_idx);
	printf("\r\n------------------------------------\r\n");
	for(i=s_idx; i<=e_idx; i++){
		tmp = EEP_Read(i);
		printf("%bu  ", tmp);
		if( (i%10) == 0 ) printf("\r\n");
	}
	printf("\r\n------------------------------------\r\n");
	
}

void EEPROM_WRITE(void)
{
	uint8 s_idx, e_idx, i, tmp;
	s_idx = 0;
	e_idx = 0;
	tmp = 0;
	printf("\r\n**** EEPROM_WRITE ****");	
	printf("\r\n Input start address (0~%bu) :",MAX_EEPROM_SIZE-1);
	scanf("%bd", &s_idx);
	printf("\r\n Input end address (0~%bu) :",MAX_EEPROM_SIZE-1);
	scanf("%bd", &e_idx);
	
	printf("\r\n Input data (%bu ~ %bu) \r\n",s_idx,e_idx);
	for(i=s_idx; i<=e_idx; i++){	
		printf("Address [ %bu ] : ",i);
		scanf("%bd", &tmp);
		EEP_Write(i,tmp);
		printf("\r\n");
	}
	
	printf("\r\n Write data (%bu ~ %bu)",s_idx,e_idx);
	printf("\r\n------------------------------------\r\n");
	for(i=s_idx; i<=e_idx; i++){	
		tmp = EEP_Read(i);
		printf("%bu  ", tmp);
		if( (i%10) == 0 ) printf("\r\n");
	}
	printf("\r\n------------------------------------\r\n");
	
}


void EEPROM_ERASE_ALL(void)
{
	uint8 add_idx;
	int16 i ;
	add_idx = 0;
	i=0;
	printf("\r\n ERASE ALL (256 byte)\r\n");
	printf("\r\n------------------------------------\r\n");
	for(i=0; i<256; i++){
	  EEP_Write(add_idx,0x00); 
	  if((add_idx%16)==0) printf(".");
	  add_idx++;
	}
	printf("\r\nFinished!\r\n");
	printf("------------------------------------\r\n");
}