#ifndef __EEPROM
#define __EEPROM
#include "..\..\..\drivers\types.h"
void EEP_Write(uint8 ee_addr, uint8 ee_data);
uint8 EEP_Read(uint8 ee_addr);
#endif

