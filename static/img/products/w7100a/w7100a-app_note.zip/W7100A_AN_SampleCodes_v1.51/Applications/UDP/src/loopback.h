
#include "..\..\..\drivers\types.h"



void loopback_udp(SOCKET s, uint16 port, uint8 xdata * data_buf, uint16 mode);
