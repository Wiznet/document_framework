1. copy the 7100Webserver.bin file and wizweb.rom file
2. Execute allbin.bat
3. Check All_YearMonthDay.bin file
4. Write All_YearMonthDay.bin file to iMCU7100EVB