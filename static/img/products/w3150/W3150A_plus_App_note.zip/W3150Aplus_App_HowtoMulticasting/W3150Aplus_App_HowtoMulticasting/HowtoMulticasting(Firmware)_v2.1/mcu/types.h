/*
 * Copyright (c) 2001-2004, Wiznet Inc.
 * All rights reserved. 
*/
/**
 * W3150 type definition
 */

#ifndef _TYPE_H_
#define _TYPE_H_

/**
 * \addtogroup w3150def_1
 * @{
 */
/** global define */
#define FW_VERSION		0x02010000	/* System F/W Version : 2.1.0.0	*/
/****/
/**
 * The 8-bit signed data type.
 */
typedef char int8;
/**
 * The volatile 8-bit signed data type.
 */
typedef volatile char vint8;
/**
 * The 8-bit unsigned data type.
 */
typedef unsigned char uint8;
/**
 * The volatile 8-bit unsigned data type.
 */
typedef volatile unsigned char vuint8;

/**
 * The 16-bit signed data type.
 */
typedef int int16;
/**
 * The volatile 16-bit signed data type.
 */
typedef volatile int vint16;
/**
 * The 16-bit unsigned data type.
 */
typedef unsigned int uint16;
/**
 * The volatile 16-bit unsigned data type.
 */
typedef volatile unsigned int vuint16;
/**
 * The 32-bit signed data type.
 */
typedef long int32;
/**
 * The volatile 32-bit signed data type.
 */
typedef volatile long vint32;
/**
 * The 32-bit unsigned data type.
 */
typedef unsigned long uint32;
/**
 * The volatile 32-bit unsigned data type.
 */
typedef volatile unsigned long vuint32;

/**
 * The SOCKET data type.
 *
 * The 8-bit unsigned data.
 */
typedef uint8 SOCKET;

/**
 * The un_l2cval data type.
 * 
 * using 4byte long value or 1byte data * 4
 */
typedef union _un_l2cval {
	uint32	lVal; /**< 32-bit value iVal */
	uint8	cVal[4]; /**< 8-bit array value cVal[4] */
}un_l2cval;

/**
 *
 * The un_i2cval data type.
 *
 * using 2byte long value or 1byte data * 2
 *
 */
typedef union _un_i2cval {
	uint16	iVal; /**< 16bit value iVal*/
	uint8	cVal[2]; /**< 8bit array value cVal[2]*/
}un_i2cval;

/** @} */

/*
 * By default, byte ordering is BIG_ENDIAN.
 * you should change follow macro function, if byte ordering is LITTLE_ENDIAN.
 */
#define htons(x) (x)
#define htonl(x) (x)
#define ntohs(x) (x)
#define ntohl(x) (x)

#endif		/* _TYPE_H_ */

/** @} */
/** @} */
