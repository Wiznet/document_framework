/*
********************************************************************************
* Brief : source codes for Multicasting application with W3150A+
* Optimized compiler : WINAVR 4.2.2(20071221).
********************************************************************************
*/
/*
********************************************************************************
File Include Section
********************************************************************************
*/
#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/eeprom.h>
#include <stdio.h> 
#include <string.h>
#include "../mcu/mcu.h"
#include "../mcu/delay.h"
#include "../mcu/serial.h"
#include "../iinchip/socket.h"

#define __TEST_MULTICAST__
/*
********************************************************************************
Define Part
********************************************************************************
*/
#define	MAX_BUF_SIZE	2048		/* maximum size of Rx buffer. */

/*
********************************************************************************
Local Variable Declaration Section
********************************************************************************
*/
uint8 * rx_buf = (uint8 *)(0x7000);	/* Rx buffer for Application */

/*
*******************************************************************************
Function Prototype Declaration Part
*******************************************************************************
*/

/*
********************************************************************************
* Re-initialization function for the disconnected channel.
* Description: Waits in the server mode after re-initialization for the disconnected channel.
********************************************************************************
*/

void init_sock(SOCKET s, uint16 port, uint8 flag, uint8 udp_mode, uint8 client_mode) 
{
	uint8 sel;
	uint8 ip[4];
	uint16 dport;
           
	printf("-- Socket %d\r\n", s);
	if (udp_mode == 1)
		{
			socket(s, Sn_MR_UDP, port, flag);	/* Create a new UDP socket */
			printf("UDP open, port number(%d) \r\n", port); 
			printf("Socket status is %.2x \r\n", getSn_SR(s));
			
		}
	else
		{
			socket(s, Sn_MR_TCP, port, flag);	/* Create a new TCP socket */
			printf("-- TCP open, port number(%d) \r\n", port); 
			printf("-- Socket status is %.2x \r\n", getSn_SR(s));
			//wait_10ms(200);
			//wait_10ms(200);
			if (client_mode == 1)
			{
			   printf("1. keep previous information\r\n2. change information\r\nselect : ");
			   scanf("%d",(int*)&sel);
			   printf("\r\n");
			   if (sel == 2)
			   {
		   	   printf("input [ip3 ip2 ip1 ip0 port]\r\n -->> ");
		   	   scanf("%d %d %d %d %d",(int*)ip,(int*)(ip+1),(int*)(ip+2),(int*)(ip+3),(int*)(&dport));
			   }
				printf("connect %d.%d.%d.%d:%d ", ip[0], ip[1], ip[2], ip[3], dport);
				if (connect(s, ip, dport) == 0) {
					printf("fail\r\n");
					printf("socket (%d): ", port);
					socket(s, Sn_MR_TCP, port, flag);	/* Create a new socket */
					printf("%d ok\r\n", s);
					printf("listen (%d): ", port);
					listen(s);           			/* Server Mode */
					printf("%d ok..\r\n", s);
				}
			}
			else
			{
				printf("-- listen (%d): \r\n", port);
				printf("------------------------------------------\r\n");
				listen(s);           			/* Server Mode */
			}

		}
}

/*
********************************************************************************
Function Implementation Part
********************************************************************************
*/
int16 main(void)
{
	SOCKET i;
	int16 len;		/* size of rx data */
	uint8 ip[6];
	//uint16 loop_idx;
	uint16 dummy;

	mcu_init();
	uart_init(0, 7);		// Serial Port Initialize
	sei();			/* enable interrupts */
	iinchip_init();
   setIMR(0xff);

   	printf("\r\n");
	printf("******* Firmware Version : %d.%d.%d.%d *******\r\n",
			(uint8)(FW_VERSION>>24),
			(uint8)(FW_VERSION>>16),
			(uint8)(FW_VERSION>>8),
			(uint8)(FW_VERSION) );
   
	ip[0] = 0x00; ip[1] = 0x08; ip[2] = 0xdc; ip[3] = 0x00; ip[4] = 0x11; ip[5] = 0x19;
	setSHAR(ip);
	ip[0] = 192; ip[1] = 168; ip[2] = 1; ip[3] = 1;
	setGAR(ip);
	ip[0] = 255; ip[1] = 255; ip[2] = 255; ip[3] = 0;
	setSUBR(ip);
	ip[0] = 192; ip[1] = 168; ip[2] = 1; ip[3] = 2;
	setSIPR(ip);

	// display network information
	printf("\r\n====================================\r\n");
	printf("        Network Information\r\n");
	printf("====================================\r\n");

	printf("MAC ADDRESS      : ");
   getSHAR(ip);
	for (i = 0; i < 5; i++)	printf("%.2X.", ip[i]);
	printf("%.2X", ip[i]);
	printf("\r\n");
	
	printf("SUBNET MASK      : ");
   getSUBR(ip);
	for (i = 0; i < 3; i++)	printf("%d.", ip[i]);
	printf("%d", ip[i]);
	printf("\r\n");

	printf("G/W IP ADDRESS   : ");
   getGAR(ip);
	for (i = 0; i < 3; i++)	printf("%d.", ip[i]);
	printf("%d", ip[i]);
	printf("\r\n");

	printf("LOCAL IP ADDRESS : ");
   getSIPR(ip);
	for (i = 0; i < 3; i++)	printf("%d.", ip[i]);
	printf("%d", ip[i]);
	printf("\r\n");
	printf("====================================\r\n");

	setRCR(0x05); // timeout count is 5
	sysinit(0x55,0x55); // set 2K memory each socket

   #ifdef __TEST_MULTICAST__
   {
   	printf("For Multicasting Test --> 'm' \r\n");
   	if (uart0_getchar() == 'm')
   	{
   		printf("socket : ");
   		// 1. write multicasting mac address to destination hardware address
   		ip[0] = 0x01; ip[1] = 0x00; ip[2] = 0x5E; ip[3] = 0x01; ip[4] = 0x01; ip[5] = 0x01;
   		setSn_DHAR(0,ip);
   		
   		// 2. write multicasting ip address to destination ip address
   		ip[0] = 224; ip[1] = 1; ip[2] = 1; ip[3] = 1;
   		setSn_DIPR(0,ip);
   		
   		// 3. write multicasting port number to destination port number
   		ip[0] = 0x0F; ip[1] = 0xA0;//4000
   		setSn_DPORT(0,ip);
   		
   		setSn_TTL(0,1);
   		
   		// 4. set udp, multicasting on socket Mode register & open socket
   		if (socket(0, Sn_MR_UDP, 2000, Sn_MR_MULTI) == 1) printf("0 %.2X ok\r\n", getSn_SR(0));
   		   
   		printf("MULTICASING MAC ADDRESS : ");
   		getSn_DHAR(0,ip);
      	for (i = 0; i < 5; i++)	printf("%.2X.", ip[i]);
      	printf("%.2X", ip[i]);
      	printf("\r\n");
   		printf("MULTICASTING IP ADDRESS : ");
   		getSn_DIPR(0,ip);
   		for (i = 0; i < 3; i++) printf("%d.", ip[i]);
   		printf("%d", ip[i]);
   		printf("\r\n");
   		for (i = 1 ; i < MAX_SOCK_NUM - 1 ; i++ )
   		{
   			init_sock(i, 3000+i,0 ,1 ,0);
   		}
   	}
   	else
   	{
   		for (i = 0 ; i < MAX_SOCK_NUM ; i++ )
   		{
   			init_sock(i, 3000+i,0 ,1 ,0);
   		}
   	}
   }
   #else
   {
	   for (i = 0 ; i < MAX_SOCK_NUM ; i++ )
	   {
	   	//nit_server(i, 3000+i, Sn_MR_ND);
	   	init_sock(i, 3000+i,0 ,1 ,0);
	   }
   }
   #endif
	// Loop-back Service
	while (1)
	{
		for (i = 0 ; i < MAX_SOCK_NUM ; i++ )
		{
			switch ( getSn_SR(i) )
			{
			case SOCK_ESTABLISHED: // if connection is established
				if ((len = getSn_RX_RSR(i)) > 0) // check Rx data
				{
					if (len > MAX_BUF_SIZE) len = MAX_BUF_SIZE;	// if Rx data size is lager than MAX_BUF_SIZE,
											                           // the data size to read is MAX_BUF_SIZE.
					len = recv(i, rx_buf, len); // read the received data
					//printf("tcp recv : %s [%d]\r\n",rx_buf,len);
					len = send(i, rx_buf, len);
					//printf("udp recv : %s [%d]\r\n",rx_buf,len);
				}
				break;

			case SOCK_CLOSE_WAIT: // If the client request to close
				printf("CLOSE_WAIT : %d\r\n", i);
				disconnect(i); // try to disconnect the socket
            break;

			case SOCK_CLOSED: // if a socket is already closed
				printf("CLOSED : %d %.2x %.2x\r\n", i, getSn_IR(i), getSn_SR(i) );
				init_sock(i,3000+i,0,1,0);
				break;
				
		   case SOCK_UDP :						/* if connection is established */
				if ((len = getSn_RX_RSR(i)) > 0) // check Rx data
				{
				   if (len > MAX_BUF_SIZE) len = MAX_BUF_SIZE;	/* if Rx data size is lager than MAX_BUF_SIZE, */
											/* the data size to read is MAX_BUF_SIZE. */
					len = recvfrom(i,rx_buf,len,ip,&dummy);
					
					//printf("udp recv : %s [%d]\r\n",rx_buf,len);
					igmpsend(i, rx_buf, len);
					//printf("udp send : %s [%d]\r\n",rx_buf,len);
				}   
            break;
            
			default :
				break;
			}
		}
	}		
}
