/*
********************************************************************************
* Brief : source codes for PPPoE application with W3150A+
* Optimized compiler : WINAVR 4.2.2(20071221).
********************************************************************************
*/

/*
********************************************************************************
File Include Section
********************************************************************************
*/
#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/eeprom.h>
#include <stdio.h> 
#include <string.h>
#include "../mcu/mcu.h"
#include "../mcu/delay.h"
#include "../mcu/serial.h"
#include "../mcu/types.h"
#include "../iinchip/socket.h"
#include "../iinchip/w3150a.h"

/*
********************************************************************************
Define Part
********************************************************************************
*/
#define	MAX_BUF_SIZE	2048		/* maximum size of Rx buffer. */

/*
********************************************************************************
Local Variable Declaration Section
********************************************************************************
*/
uint8 * rx_buf = (uint8 *)(0x7000);	/* Rx buffer for Application */

/*
*******************************************************************************
Function Prototype Declaration Part
*******************************************************************************
*/

/*
********************************************************************************
* Re-initialization function for the disconnected channel.
* Description: Waits in the server mode after re-initialization for the disconnected channel.
********************************************************************************
*/
void init_sock(SOCKET s, uint16 port, uint8 flag, uint8 udp_mode, uint8 client_mode) 
{
	uint8 sel;
	uint8 ip[4];
	uint16 dport;
           
	printf("-- Socket %d\r\n", s);
	if (udp_mode == 1)
		{
			socket(s, Sn_MR_UDP, port, flag);	/* Create a new UDP socket */
			printf("UDP open, port number(%d) \r\n", port); 
			printf("Socket status is %.2x \r\n", getSn_SR(s));
			
		}
	else
		{
			socket(s, Sn_MR_TCP, port, flag);	/* Create a new TCP socket */
			printf("-- TCP open, port number(%d) \r\n", port); 
			printf("-- Socket status is %.2x \r\n", getSn_SR(s));
			//wait_10ms(200);
			//wait_10ms(200);
			if (client_mode == 1)
			{
			   printf("1. keep previous information\r\n2. change information\r\nselect : ");
			   scanf("%d",(int*)&sel);
			   printf("\r\n");
			   if (sel == 2)
			   {
		   	   printf("input [ip3 ip2 ip1 ip0 port]\r\n -->> ");
		   	   scanf("%d %d %d %d %d",(int*)ip,(int*)(ip+1),(int*)(ip+2),(int*)(ip+3),(int*)&dport);
			   }
				printf("connect %d.%d.%d.%d:%d ", ip[0], ip[1], ip[2], ip[3], dport);
				if (connect(s, ip, dport) == 0) {
					printf("fail\r\n");
					printf("socket (%d): ", port);
					socket(s, Sn_MR_TCP, port, flag);	/* Create a new socket */
					printf("%d ok\r\n", s);
					printf("listen (%d): ", port);
					listen(s);           			/* Server Mode */
					printf("%d ok..\r\n", s);
				}
			}
			else
			{
				printf("-- listen (%d): \r\n", port);
				printf("------------------------------------------\r\n");
				listen(s);           			/* Server Mode */
			}

		}
}

/*
********************************************************************************
Function Implementation Part
********************************************************************************
*/
int16 main(void)
{
	SOCKET i;
	int16 len;		/* size of rx data */
	uint8 ip[6];
	int16 dummy;
	
	mcu_init();
	uart_init(0, 7);		// Serial Port Initialize
	
#ifdef _20060701_
	printf(" Version _20060701_\r\n");
#endif

	printf("\r\n*** ADSL Test using W3150A+ ");
#if (__DEF_IINCHIP_BUS__ == __DEF_IINCHIP_DIRECT_MODE__)
	printf("[DIRECT MODE]");
#elif(__DEF_IINCHIP_BUS__ == __DEF_IINCHIP_INDIRECT_MODE__)	/* INDIRECT MODE I/F */
	printf("[INDIRECT MODE]");
#elif (__DEF_IINCHIP_BUS__ == __DEF_IINCHIP_SPI_MODE__)
	printf("[SPI MODE]");
#else
	#error "unknown bus type"
#endif	
	printf(" ***\r\n");
	printf("******* Firmware Version : %d.%d.%d.%d *******\r\n",
			(uint8)(FW_VERSION>>24),
			(uint8)(FW_VERSION>>16),
			(uint8)(FW_VERSION>>8),
			(uint8)(FW_VERSION) );

	
	sei();			/* enable interrupts */
	iinchip_init();

	ip[0] = 0x00; ip[1] = 0x08; ip[2] = 0xdc; ip[3] = 0x00; ip[4] = 0x00; ip[5] = 0x01;
	setSHAR(ip);
	ip[0] = 192; ip[1] = 168; ip[2] = 10; ip[3] = 1;
	setGAR(ip);
	ip[0] = 255; ip[1] = 255; ip[2] = 255; ip[3] = 0;
	setSUBR(ip);
	//ip[0] = 192; ip[1] = 168; ip[2] = 10; ip[3] = 31;
	//setSIPR(ip);
   setRCR(0x05); // timeout count is 5
	sysinit(0x55,0x55); // set 2K memory each socket
	
	/* -------------------------------------------------
 * adsl connection code begin
 * -------------------------------------------------*/
	uint8 pppmac[6], pppsessionid[2], pppip[4];
	uint8 pppid[128];
	uint8 ppppasswd[128];
	uint8 pppid_len;
	uint8 ppppasswd_len;
	uint8 ret;
	uint8 ppp_state;
	uint8 scanf_ret;
	printf("* W3150A+ PPPoE(ADSL) test program *\r\n");
	printf("- For PPPoE(adsl) test, Input 'a' key -\r\n");
	if (uart0_getchar() == 'a')
	{
AUTH_FAIL:
		printf("<<Setup PPPoE connection>>\r\n");

		/* 1. Get the user id for pppoe(adsl) connection */
		printf("Enter user id : ");
		scanf_ret = scanf("%s", pppid);
		printf("%s\r\n",pppid);
		pppid_len = strlen((const char*)pppid);

		/* 2. Get the password for pppoe(adsl) connection */
		printf("Enter user password : ");
		scanf_ret = scanf("%s", ppppasswd);
		printf("%s\r\n",ppppasswd);
		printf("\r\n");
		ppppasswd_len = strlen((const char*)ppppasswd);

		//printf("%d %d\r\n",pppid_len,ppppasswd_len);

      // pppoe(socket0)
		i = 0;
		
		/* 3. Disconnect the previous pppoe(adsl) connection */
		pppterm(pppmac, pppsessionid);

		/* 4. Start to connect. If ret is 1, then adsl connection is established. */
		while ((ret = pppinit( pppid, pppid_len, ppppasswd, ppppasswd_len)) != 1)
		{
			switch (ret)
			{
				/* if ret is 2, authentication fail */
				case 2 : 
					getSn_DHAR(0, pppmac);
					getSn_DPORT(0, pppsessionid);
					goto AUTH_FAIL; 
					break;
				default : break;
			}				
			i++;
   		/*  */
			if (i == 5) break;
		}
		
		/* 5. save information about adsl connection */
		if (i != 5)
		{
			ppp_state = IINCHIP_READ(IR); // remove already setted value of INT_REG
			printf("<<PPP Connection established>>\r\n");
			getSn_DHAR(0, pppmac);
			getSn_DPORT(0, pppsessionid);
			getSIPR(pppip);
			printf("Get IP ADDRESS : ");
			for (i = 0; i < 3; i++) printf("%d.", pppip[i]);
			printf("%d", pppip[i]);
			printf("\r\n");
			setSIPR(pppip);
		}
		else
		{
			setMR(0x00);
		}
	}
/* -------------------------------------------------
 * adsl connection code end
 * -------------------------------------------------*/
 
	// display network information
	printf("\r\n====================================\r\n");
	printf("        Network Information\r\n");
	printf("====================================\r\n");

	printf("MAC ADDRESS      : ");
   getSHAR(ip);
	for (i = 0; i < 5; i++)	printf("%.2X.", ip[i]);
	printf("%.2X", ip[i]);
	printf("\r\n");
	
	printf("SUBNET MASK      : ");
   getSUBR(ip);
	for (i = 0; i < 3; i++)	printf("%d.", ip[i]);
	printf("%d", ip[i]);
	printf("\r\n");

	printf("G/W IP ADDRESS   : ");
   getGAR(ip);
	for (i = 0; i < 3; i++)	printf("%d.", ip[i]);
	printf("%d", ip[i]);
	printf("\r\n");

	printf("LOCAL IP ADDRESS : ");
   getSIPR(ip);
	for (i = 0; i < 3; i++)	printf("%d.", ip[i]);
	printf("%d", ip[i]);
	printf("\r\n");
	printf("====================================\r\n");

	//setRCR(0x05); // timeout count is 5
	//sysinit(0x55,0x55); // set 2K memory each socket

	for (i = 0 ; i < MAX_SOCK_NUM ; i++ )
	{
		init_sock(i, 3000+i, 0,0,0);
	}

	// Loop-back Service
	while (1)
	{
		for (i = 0 ; i < MAX_SOCK_NUM ; i++ )
		{
			switch ( getSn_SR(i) )
			{
			case SOCK_ESTABLISHED: // if connection is established
				if ((len = getSn_RX_RSR(i)) > 0) // check Rx data
				{
					if (len > MAX_BUF_SIZE) len = MAX_BUF_SIZE;	// if Rx data size is lager than MAX_BUF_SIZE,
											                           // the data size to read is MAX_BUF_SIZE.
					len = recv(i, rx_buf, len); // read the received data
					send(i, rx_buf, len);
				}
				break;

			case SOCK_CLOSE_WAIT: // If the client request to close
				printf("CLOSE_WAIT : %d\r\n", i);
				disconnect(i); // try to disconnect the socket
            break;

			case SOCK_CLOSED: // if a socket is already closed
				printf("CLOSED : %d %.2x %.2x\r\n", i, getSn_IR(i), getSn_SR(i) );
				init_sock(i, 3000+i, 0,0,0); // reinitialize the socket
				break;
				
		   case SOCK_UDP:
		      if ((len = getSn_RX_RSR(i)) > 0)		/* check Rx data */
				{
					if (len > MAX_BUF_SIZE) len = MAX_BUF_SIZE;	/* if Rx data size is lager than MAX_BUF_SIZE, */
											/* the data size to read is MAX_BUF_SIZE. */
					printf("udp recv in select : %d\r\n",len);
					len = recvfrom(i,rx_buf,len,ip,(uint16*)&dummy);
					rx_buf[len] = 0;
					printf("udp recv : %s [%d]\r\n",rx_buf,len);
					len = sendto(i, rx_buf, len,ip,dummy);
					printf("udp send %d\r\n", len);
				}
            break;
            
			default :
				break;
			}
		}
	}		
}
