#include "delay.h"

void wait_1us(uint16 cnt)
{
	//+200804 - jhpark	winaver 2007 version inline asm option
	
	asm volatile
	(
		"movw	r24, %A0"		"\n\t"
		"L_US%=:"				"\n\t"
		"nop"				"\n\t"
		"nop"				"\n\t"
		"nop"				"\n\t"
		"nop"				"\n\t"
		"nop"				"\n\t"
		"sbiw	r24, 1"			"\n\t"
		"brne	L_US%="			"\n\t"
		"nop"				"\n\t"
		:  :"r" (cnt)
	);
}

/*
********************************************************************************
*               WAIT FUNCTION
*
* Description : This function waits for 10 milliseconds
* Arguments   : cnt - is the time to wait
* Returns     : None
* Note        : Internal Function
********************************************************************************
*/
void wait_10ms(uint16 cnt)
{
	for (; cnt; cnt--) wait_1ms(10);
}


/*
********************************************************************************
*               WAIT FUNCTION
*
* Description : This function waits for 1 milliseconds
* Arguments   : cnt - is the time to wait
* Returns     : None
* Note        : Internal Function
********************************************************************************
*/
void wait_1ms(uint16 cnt)
{
	for (; cnt; cnt--) wait_1us(1000);
}
