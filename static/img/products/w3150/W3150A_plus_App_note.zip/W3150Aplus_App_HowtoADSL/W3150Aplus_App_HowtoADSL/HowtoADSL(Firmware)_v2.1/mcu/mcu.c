#include <avr/io.h>
#include <avr/interrupt.h>
#include "mcu.h"

//#define	ATMEGA128_0WAIT
#define	ATMEGA128_1WAIT
//#define	ATMEGA128_2WAIT
//#define	ATMEGA128_3WAIT

void mcu_init(void) 
{
	EICRA=0x00;
	EICRB=0x00;
	EIMSK=0x40;
	EIFR=0x00;

#ifdef ATMEGA128_0WAIT
	MCUCR = 0x80;
	XMCRA=0x40;
#endif	
#ifdef ATMEGA128_1WAIT
	MCUCR = 0xc0;
	XMCRA=0x40;
#endif	
#ifdef ATMEGA128_2WAIT
	MCUCR = 0x80;
	XMCRA=0x42;
#endif	
#ifdef ATMEGA128_3WAIT
	MCUCR = 0xc0;
	XMCRA=0x42;
#endif	

/*
	EICRA = 0x00;			// External Interrupt Control Register A clear
	EICRB = 0xA0;			// External Interrupt Control Register B clear // edge 
	EIMSK = 0xB0;			// External Interrupt Mask Register : 0x80
	EIFR = 0xFF;			// External Interrupt Flag Register all clear

	MCUCR = 0x80;			// MCU control regiseter : enable external ram
	XMCRA = 0x40;			// External Memory Control Register A : 
					// Low sector   : 0x1100 ~ 0x7FFF
					// Upper sector : 0x8000 ~ 0xFFFF
*/
	sei();				// enable interrupts
}

