#ifndef _DELAY_H
#define _DELAY_H

#include "types.h"

void wait_1us(uint16 cnt);

void wait_1ms(uint16 cnt);

void wait_10ms(uint16 cnt);

#endif
