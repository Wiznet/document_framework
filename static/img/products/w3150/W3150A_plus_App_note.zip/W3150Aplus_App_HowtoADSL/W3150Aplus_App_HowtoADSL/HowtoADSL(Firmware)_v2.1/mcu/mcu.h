#ifndef _MCU_H
#define _MCU_H

void mcu_init(void);

#endif
