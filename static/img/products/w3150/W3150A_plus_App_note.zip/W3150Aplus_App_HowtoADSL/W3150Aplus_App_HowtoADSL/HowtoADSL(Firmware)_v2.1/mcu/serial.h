#ifndef _SERIAL_H_
#define _SERIAL_H_

/*
********************************************************************************
* (c) Copyright 2002, Wiznet, Seoul, Korea
*
* Filename	: serial.h
* Version	: 1.0
* Programmer(s)	: 
* Created	: 2003/01/28
* Modified      :
*
* Description   : Header file for ATmega64 UART. (AVR-GCC Compiler)
********************************************************************************
*/

#include "types.h"

#define MAX_SIO_COUNT		32
#define CLK_CPU			16000000		/* 16Mhz */
//#define CLK_CPU			2000000		/* 16Mhz */
#define UART_BAUD_RATE(X)	((X==0) ? 2400 : 	\
				 (X==1) ? 4800 : 	\
				 (X==2) ? 9600 : 	\
				 (X==3) ? 14400 : 	\
				 (X==4) ? 19200 : 	\
				 (X==5) ? 28800 : 	\
				 (X==6) ? 38400 :	\
				 (X==7) ? 57600 : 	\
				 (X==8) ? 76800 :	\
				 (X==9) ? 115200 :	\
				 (X==10) ? 250000 :	\
				 (X==11) ? 500000 :	\
				 1000000)

#define UART_BAUD_SELECT(X) 	(CLK_CPU/(UART_BAUD_RATE(X)*16l)-1)

#define XON_CHAR	0x11
#define XOFF_CHAR	0x13

#define UART_DEVICE_CNT		2

typedef struct _UARTHANDLER
{
	char (*uart_get_handler)(void);
	void (*uart_put_handler)(char);
}UARTHANDLER;

/*
********************************************************************************
Function Prototype Definition Part
********************************************************************************
*/
void uart_init(uint8 uart, uint8 baud_index);		/* Initialize the UART of ATmega64 */
       
void uart_databit(uint8 uart, uint8 dbit);

void uart_stopbit(uint8 uart, uint8 sbit);

void uart_paritybit(uint8 uart, uint8 pbit);

void uart_flowctrl(uint8 uart, uint8 flow);

uint16 uart_keyhit(uint8 uart);	/* Check if there is Rx */

void uart0_putchar(char c);	/* Send a character through UART */
char uart0_getchar(void);	/* Get a character from UART */
void uart1_putchar(char c);	/* Send a character through UART */
char uart1_getchar(void);	/* Get a character from UART */

void uart_puts(uint8 uart, char * str);	/* Send a string to UART */
int uart_gets(uint8 uart, char * str,char bpasswordtype, int max_len);	/* Get a string from UART */
void uart_flush_rx(uint8 uart);	/* Flush RX Buffer */


#endif		/* _SERIAL_H_ */

