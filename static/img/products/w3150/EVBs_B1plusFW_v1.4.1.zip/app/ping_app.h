#ifndef __PING_APP_H
#define __PING_APP_H

void ping_request(void);
void ping_usage(void);	// Display the usage of ping command

#endif
