#ifndef _LOOPBACK_H
#define _LOOPBACK_H


#include "../mcu/types.h"


void loopback_tcps(u_char ch);
void loopback_tcpc(u_char ch);
void loopback_udp(u_char ch);

#endif
