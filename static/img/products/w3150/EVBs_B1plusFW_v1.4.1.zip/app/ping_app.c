//#include <stdio.h>
#include <string.h>
#include "../mcu/types.h"
#include "../mcu/serial.h"
#include "../util/util.h"
#include "../util/myprintf.h"
#include "../util/sockutil.h"
#include "../iinchip/socket.h"
#include "../inet/dns.h"
#include "../inet/ping.h"

#include "ping_app.h"



/*
********************************************************************************
* Description: ping request to peer
* Arguments  : None.
* Returns    : None.
* Note       : 
********************************************************************************
*/
void ping_request(void)
{
	PINGLOG PingLog;			// Variable for result of pinging
	char command[81];			// Variable for command from serial terminal
	char qname[MAX_QNAME_LEN];
	char* NextTok;				// Pointer to next token string
	char PeerIp[50];			// Peer IP Address String
	u_long peerip;				// 32bit Peer IP Address
	char PingArgsFlags=0;			// If ping arguments are correct then IsValidPingArgs = 0, else -1
	int pingcnt;				// Count of sending ping-request to a peer
	int pingsize;                           // Size of ping-request's data
	u_int pingtimeout;                        // wait time for ping-reply


	memset(qname,0,sizeof(qname));
	PRINTLN("\r\nPing Reqeust program started...\r\n");
	/* Wait for command, and call ping function. Then display the result of pinging */
	ping_usage();
	while(1)
	{
		/* Initialize local variables */
		pingcnt = pingsize = pingtimeout = 0;	
		PingArgsFlags = 0;
		PRINT("\r\nPING> ");				// Display prompt 'PING>'
		uart_gets(0,command,0,sizeof(command));                  		// Wait for command from serial Terminal
		if(*command=='\0') continue;			// Is command empty?
		NextTok = strtok(command,"\t\r\n ");    	// Get first token from command
		NextTok = strupr(NextTok);			// Converts first token to an uppercase string.
		if(!strcmp(NextTok,"EXIT"))	break;		// If first token is equal to "EXIT" then end program
		else if(strcmp(NextTok,"PING"))     		// If first token is not equal to "PING" then enter command again
		{
			PRINTLN("Unknown Command");
			PRINTLN("You can use 'ping' or 'exit' commands");
			PRINTLN("If you want to ping request then use 'ping'.");
			PRINTLN("If you want to terminate the program, use 'exit'.");
			continue;
		}
		while( (NextTok=strtok(NULL,"\t\r\n ")) )
		{
			if(!strcmp(NextTok,"-t"))
			{
				pingcnt = -1;
				PingArgsFlags |= 0x01;
			}
			else if(!strcmp(NextTok,"-a"))
			{
				PingArgsFlags |= 0x02;
			}
			else if(!strcmp(NextTok,"-n"))
			{
				NextTok = strtok(NULL,"\t\r\n ");	// get value of '-n' option
				if(!ValidATOI(NextTok,10,&pingcnt))	// If value of '-n' option is valid
				{
					PRINTLN1("Bad value for option -n, valid range is from 1 to %d.",0x7FFF);
					PingArgsFlags |= 0x80;
					break;
				}
				if(PingArgsFlags & 0x01) pingcnt = -1;
				else PingArgsFlags |= 0x04;				
			}
			else if(!strcmp(NextTok,"-l"))
			{
				
				NextTok = strtok(NULL,"\t\r\n ");	// Get value of '-l' option
				if(!ValidATOI(NextTok,10,&pingsize))	// If value of '-l' option is valid
				{
					PRINTLN1("Bad value for option -l, valid range is from 1 to %d.",PINGBUF_LEN);
					PingArgsFlags |= 0x80;
					break;
				}
				PingArgsFlags |= 0x08;
			}
			else if(!strcmp(NextTok,"-w"))
			{
				NextTok = strtok(NULL,"\t\r\n ");	// Get value of '-w' option
				if(!ValidATOI(NextTok,10,(int*)&pingtimeout))	// If value of '-w' option is valid
				{
					PRINTLN1("Bad value for option -w, valid range is from 1 to %d.\r\n",0x7FFF);
					PingArgsFlags |= 0x80;
					break;
				}
				PingArgsFlags |= 0x10;
			}
			else if(!strcmp(NextTok,"-h")|| !strcmp(NextTok,"-?") || !strcmp(NextTok,"/?"))
			{
				ping_usage();
				PingArgsFlags |= 0x80;
				break;
			}
			else if(strchr(NextTok,'-') && strlen(NextTok)==2)
			
			{
				PingArgsFlags |= 0x80;
				PRINTLN("Bad options.");
				break;
			}
			else if(strchr(NextTok,'.'))
			{
				if(PingArgsFlags & 0x20)
				{
					PRINTLN("You can use only one destination-list");
					PingArgsFlags |= 0x80;
					break;
				}
				strcpy(qname,NextTok);
				PingArgsFlags |= 0x20;
			}
			else
			{
				PingArgsFlags |= 0x80;
				PRINTLN("Unknown option");
			}
		}
		if( PingArgsFlags == 0)				// no arguments
		{
			PRINTLN("ping command must have one more auguments");
			continue;
		}		
		if(PingArgsFlags & 0x80) continue;		// fail to parse arguments

		if(!(PingArgsFlags & 0x20))
		{
			PRINTLN("ping command have a destination-list");
			continue;
		}
		if(VerifyIPAddress(qname))			// Get the peer IP address string
		{
			strcpy(PeerIp,qname);
			peerip = inet_addr((unsigned char*)PeerIp);
			if(PingArgsFlags & 0x02)
			{
				if(!gethostbyaddr(htonl(peerip),qname))
				{
					PRINTLN("Unknown host.");
					continue;
				}				
			}
		}
		else
		{
			peerip = ntohl(gethostbyname(qname));
			if(!peerip)
			{
				PRINTLN("Unknown host name.");
				continue;
			}
			PingArgsFlags |= 0x40;
		}
		strcpy(PeerIp,inet_ntoa(peerip));
		PRINT1("\r\nPing Request to %s",PeerIp);
		if((PingArgsFlags & 0x42))
			PRINT1("[%s]",qname);
		PRINTLN("");
		if(!ping(pingcnt,pingsize,pingtimeout,(u_char*)PeerIp,&PingLog))		// call ping function
			PRINTLN("Fail to ping()");
		else
			DisplayPingStatistics(PingLog);                    	// Display the result of pinging
	}
	PRINTLN("Ping Test Program ended.");
}	

/*
********************************************************************************
* Description: Display usage of ping
* Arguments  : None.
* Returns    : None.
* Note       : 
********************************************************************************
*/
void ping_usage(void)
{
	PRINTLN("\r\nUsage : ping [-t] [-a] [-n count] [-l size] [-w timeout] destination-list");
	PRINTLN("\r\nOption : ");
	PRINTLN("    -t            Ping the specified host until stopped.");
	PRINTLN("                  To see statistics and continue - type Control-Break;");
	PRINTLN("                  To stop - type Control-C.");
	PRINTLN("    -a            Resolve addresses to hostnames");
	PRINTLN("    -n count      Number of echo requests to send.");
	PRINTLN("    -l size       Send buffer size.\r\n");
	PRINTLN("    -w timeout    Timeout in milliseconds to wait for each reply.\r\n");	
}
