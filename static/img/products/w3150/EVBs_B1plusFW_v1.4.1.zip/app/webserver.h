#ifndef __WEBSERVER_H
#define __WEBSERVER_H

#include "../mcu/types.h"


#define EVB_NET_SIP	"$SRC_IP_ADDRES$"
#define EVB_NET_GWIP	"$GW_IP_ADDRESS$"
#define EVB_NET_SN	"$SUB_NET__MASK$"
#define EVB_NET_DNS	"$DNS_SERVER_IP$"
#define EVB_NET_MAC	"$SRC_MAC_ADDRESS$"

#define EVB_LCD_TEXT 	"$LCD_TEXT_VALUE$"
#define EVB_LED0_IMG	"$LED0_IMG$"
#define EVB_LED1_IMG	"$LED1_IMG$"
#define EVB_LED0_STAT	"$LED_0$"
#define EVB_LED1_STAT	"$LED_1$"

void web_server(u_char ch);

#endif
