#ifndef __TIMER_H__
#define __TIMER_H__

/*
*
* Filename	: timer.h
* Description   : DHCP Timer related functions. (AVR-GCC Compiler)
*
*/

#include "types.h"

#define MAX_TIMER0_CNT	0	// MAX Timer0 Handler Count
#define MAX_TIMER2_CNT	1	// MAX Timer2 Handler Count
#define MAX_TIMER_CNT	(MAX_TIMER0_CNT+MAX_TIMER2_CNT)	// Max Timer Handler

#define DHCP_CHECK_TIMER2	0

/* Timer handler */
typedef struct _TIMER_IRQ
{
	void (*user_timer_handler)(void);
}TIMER_IRQ;




void init_timer(void);

void set_timer(u_int timer, void (*handler)(void));

void kill_timer(u_int timer);

void timer0_irq(void);

void timer2_irq(void);

#endif
