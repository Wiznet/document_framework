#ifndef _LCD_H
#define _LCD_H
/*
*
* File Name :  LCD.H
* Description :  LCD Basic Function Definition
*  
*/

#include "../mcu/types.h"


#define LCD_MAX_COL		16
#define LCD_MAX_ROW		2

#define LCD_BASEADDR		0x9000
// LCD Command Write Register
#define LcdCommandW (*((unsigned char*)LCD_BASEADDR))

// LCD Command Read Register
#define LcdCommandR (*((unsigned char*)(LCD_BASEADDR+1)))

// LCD Data Write Register
#define LcdDataW    (*((unsigned char*)(LCD_BASEADDR+2)))

// LCD Data Read Register
#define LcdDataR    (*((unsigned char*)(LCD_BASEADDR+3)))


/* If there are unused functions in program and on compiling with Keil-C, it result in warning.In this reason, wrong operation could be happend.
So it prevent to compile unused functions to use define-function.
*/
#define __LCD_UNUSED   // If defined with " __LCD_UNUSED", actually it's not to be compiled "__LCD_UNUSED Block"


char lcd_ready(void);			// Check for LCD to be ready
void lcd_clrscr(void);			// Clear LCD. 
char lcd_init(void);			// LCD Init
void lcd_gotoxy(u_char x, u_char y);	// Output character string in current Cursor.
char* lcd_puts(char* str);		// Output character stream in current Cursor.
void lcd_putch(char ch);		// Output 1 character in current Cursor.



#ifndef __LCD_UNUSED

void lcd_home_cursor(void);		// Move Cursor first Column.
void lcd_set_cursor_type(u_char type);	// Decide Cursor type.
void lcd_shitf_cursor(u_char dir);	// Shift to Left and Right current Cursor.

#endif

#endif
