#ifndef _CHANNEL_H
#define _CHANNEL_H

#include "../mcu/types.h"
#include "../iinchip/socket.h"

typedef struct _CHANNELHANDLE
{
	void (*Handler)(u_char);
}CHANNELHANDLER;

extern CHANNELHANDLER ChannelHandler[MAX_SOCK_NUM];


void init_channel_handler(void);
void register_channel_handler(u_char ch, void (*handler)(u_char));
void unregister_channel_handler(u_char ch);

extern u_char bchannel_start[MAX_SOCK_NUM];

#endif
