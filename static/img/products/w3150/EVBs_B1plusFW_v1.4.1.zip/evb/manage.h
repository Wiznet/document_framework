/**
 @file		manage.h
 */

#ifndef _MANAGE_H
#define _MANAGE_H

extern void check_manage(void);
extern void manage_config(void);

#endif
