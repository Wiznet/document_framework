#ifndef _LED_H
#define _LED_H

#include "../mcu/types.h"

#define LED_AVR_PORT_VAL	PORTG
#define LED_AVR_PORT_DIR	DDRG

#define LED_PIN_0		3
#define LED_PIN_1		4

#define LED_ON			1
#define LED_OFF			0	

void led_init(void);
void led_toggle(u_char led);
void led_off(u_char led);
void led_on(u_char led);

u_char led_state(u_char led);

#endif
