/*
*
* File Name : LCD.C
* Description : LCD Basic Function Implement File
*		This source file is open, so it's easy to look for through Internet.
*		Do not need to controll LCD.
*
*/

//start of modified 2008.10.24

#include "../mcu/types.h"
#include "../evb/lcd.h"//#include "lcd.h"
//end of modified 2008.10.24
#define BUSY		0x80


/*
Description     :  Check to be ready LCD.
Argument       :  
Return Value  :  If it's ready ,then '1',else then '-1'.
Note              :   If LCD Device is not insert actually,then return '-1'.
*/
char lcd_ready(void)
{
	u_char flag;
	while( (flag=LcdCommandR) & BUSY)  
	{
		if(flag == 0xFF) return -1;  
	}
	return 1;
}


/*
Description    :  Clear LCD. 
Argument      :   
Return Value :   
Note             : 
*/
void lcd_clrscr(void)       
{
	lcd_ready();
	LcdCommandW = 0x01;
}



/*
Description    :   Initialize LCD.
Argument      : 
Return Value :  If initialization is O.K, then return '1', else then return '0'. 
Note             
*/
char lcd_init(void)
{
	if((char)-1 ==lcd_ready()) return 0;
	LcdCommandW = 0x38;

	lcd_ready();
	LcdCommandW = 0x0C;

	lcd_clrscr();
	lcd_gotoxy(0,0);
	return 1;
}


/*
Description    :  Move Cursor to X Column, Y Row.
Argument      :  x - Column to move(INPUT), 
                      y - Row to move(INPUT), 
Return Value :
Note             :  LCD to be offered by WIZnet is '2*16' Dimension, so Row(Argument y) is not above 1.
*/
void lcd_gotoxy(u_char x, u_char y)
{
    lcd_ready();
    switch(y)
    {
        case 0 : LcdCommandW = 0x80 + x; break;
        case 1 : LcdCommandW = 0xC0 + x; break;
        case 2 : LcdCommandW = 0x94 + x; break;
        case 3 : LcdCommandW = 0xD4 + x; break;
    }
}


/*
Description    :  Output character string in current Cursor.
Argument      :   str - Character to be output in LCD. (INPUT)
Return Value :   Character string's Pointer to be output 
Note :
*/
char * lcd_puts(char* str)
{
	unsigned char i;

	for (i=0; str[i] != '\0'; i++){
		lcd_ready();
		LcdDataW = str[i];
	}
	return str;
}

/*
Description    :   Output 1 character in current Cursor.
Argument      :  str - Character to be output in LCD. (INPUT)
Return Value :   
Note             :
*/
void lcd_putch(char ch)
{
	lcd_ready();
	LcdDataW = ch;
}


#ifndef __LCD_UNUSED

/*
Description    :   Decide Cursor type.
Argument      :   type - Cursor type(INPUT)
Return Value :   
Note             :
*/
void lcd_set_cursor_type(u_char type)	
{
	lcd_ready();
	switch(type) 
	{
			//No Cursor 
	        case 0 : LcdCommandW = 0x0C; break;  
			// Normal Cursor 
	        case 1 : LcdCommandW = 0x0E; break; 
		// No Cursor | Blink
		case 2 : LcdCommandW = 0x0D; break; 
			// Normal Cursor | Blink 
	        case 3 : LcdCommandW = 0x0F; break; 
}

/*
Description    :  Shift to Left and Right current Cursor.
Argument      :   dir - Decide direction to be Shift.(INPUT)  dir !=0  -> Right Shift, dir == 0 -> Left Shift
Return Value :   
Note             :   
*/
void ShiftCursor(u_char dir)	
{
	lcd_ready();
	LcdCommandW = (dir ? 0x14: 0x10);
}

/*
Description    : Move Cursor first Column.
Argument      :
Return Value  :
Note :
*/
void lcd_home_cursor(void)       
{
	lcd_ready();
	LcdCommandW = 2;
}

#endif
