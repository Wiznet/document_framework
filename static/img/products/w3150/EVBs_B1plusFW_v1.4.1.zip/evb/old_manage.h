#ifndef _MANAGE_H
#define _MANAGE_H

void check_manage(void);
void manage_config(void);

#endif
