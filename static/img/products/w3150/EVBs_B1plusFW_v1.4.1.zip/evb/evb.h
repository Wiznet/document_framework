#ifndef _EVB_H
#define _EVB_H

#include "../mcu/types.h"

void mcu_init(void);
void evb_init(void);
void net_init(void);

void evb_soft_reset(void);

void evb_logo(void);
void evb_lcd_logo(void);

char* evb_get_lcd_text(u_char row);
void evb_set_lcd_text(u_char row, u_char* lcd);

#endif
