#include <avr/io.h>
#include <avr/interrupt.h>
#include <string.h>
#include "../mcu/serial.h"
#include "../mcu/delay.h"
#include "../iinchip/socket.h"
#include "../util/util.h"
#include "../util/sockutil.h"
#include "../util/myprintf.h"
#include "../evb/lcd.h"
#include "../evb/led.h"
#include "../evb/config.h"
#include "evb.h"

#define	ATMEGA128_0WAIT
//#define	ATMEGA128_1WAIT
//#define	ATMEGA128_2WAIT
//#define	ATMEGA128_3WAIT



u_char evb_lcd_text[LCD_MAX_ROW][LCD_MAX_COL+1];

void evb_init(void)
{
	u_int i;
	mcu_init();
	wait_10ms(30);
	lcd_init();
	for(i = 0; i < LCD_MAX_ROW;i++) memset(evb_lcd_text[i],' ',LCD_MAX_COL+1);
	uart_init(0, 7);		// Serial Port Initialize
	led_init();
	init_conf_variables();	
}

void evb_soft_reset(void)
{
	PRINTLN("System Reset.");
	set_reset_flag(SYSTEM_AUTO_RESET);
	asm volatile("jmp 0x0000");	
}

void evb_logo(void)
{
	PRINTLN("\r\n###########################################");
	PRINT("EVB-B1+  Test in ");
#if (__DEF_IINCHIP_BUS__ == __DEF_IINCHIP_DIRECT_MODE__)
	PRINTLN("Direct Mode");
#else 
	{
	if (__DEF_IINCHIP_BUS__ == __DEF_IINCHIP_INDIRECT_MODE__)
		PRINTLN("Indirect Mode");
	else 
	PRINTLN("SPI Mode");
	}
#endif
	PRINTLN("###########################################");
	PRINTLN("Copyright : WIZnet, Inc. 2006");
	PRINTLN("Homepage  : http://www.wiznet.co.kr");
	PRINTLN("Support   : support@wiznet.co.kr");
	PRINTLN("Sales     : sales@wiznet.co.kr");
	PRINTLN("-------------------------------------------");
	PRINTLN4("F/W Version   : %d.%d.%d.%d",(u_char)(SysInfo.ver>>24),(u_char)(SysInfo.ver>>16),
					(u_char)(SysInfo.ver>>8),(u_char)(SysInfo.ver));
	PRINTLN("H/W Version   : PM :1.2, NM:1.0, MB:1.0");

	display_netconf(&NetConf);
	PRINTLN("###########################################\r\n");
	evb_lcd_logo();
}

void evb_lcd_logo(void)
{
	u_char logo[17];
	lcd_clrscr();
	lcd_gotoxy(0,0);
	sprintf((char*)logo, "<EVB-B1+ VER%d.%d>",(u_char)(SysInfo.ver>>24),(u_char)(SysInfo.ver>>16));
	evb_set_lcd_text(0,logo);
	evb_set_lcd_text(1,(u_char*)inet_ntoa_pad(ntohl(NetConf.sip)));
}

char* evb_get_lcd_text(u_char row)
{
	if(row < LCD_MAX_ROW)
		return (char*)evb_lcd_text[row];
	return 0;
	
}
void evb_set_lcd_text(u_char row, u_char* lcd)
{
	if(row < LCD_MAX_ROW && strlen((char*)lcd) <= LCD_MAX_COL)
	{
		memset(evb_lcd_text[row],' ',LCD_MAX_COL);
		evb_lcd_text[row][LCD_MAX_COL] = 0;
		memcpy(evb_lcd_text[row],lcd,strlen((char*)lcd));
		lcd_gotoxy(0,row);
		lcd_puts((char*)evb_lcd_text[row]);
	}
}

void mcu_init(void) 
{
#ifndef __DEF_IINCHIP_INT__	
	EICRA=0x00;
	EICRB=0x00;
	EIMSK=0x00;
	EIFR=0x00;
#else
	EICRA = 0x00;			// External Interrupt Control Register A clear
	EICRB = 0x02;			// External Interrupt Control Register B clear // edge 
	EIMSK = (1 << INT4);		// External Interrupt Mask Register : 0x10
	EIFR = 0xFF;			// External Interrupt Flag Register all clear
	DDRE &= ~(1 << INT4);		// Set PE Direction 
	PORTE |= (1 << INT4);		// Set PE Default value
#endif
#ifdef ATMEGA128_0WAIT
	MCUCR = 0x80;		
	XMCRA=0x40;
#endif	
#ifdef ATMEGA128_1WAIT
	MCUCR = 0xc0;		// MCU control regiseter : enable external ram
	XMCRA=0x40;		// External Memory Control Register A : 
						// Low sector   : 0x1100 ~ 0x7FFF
						// Upper sector : 0x8000 ~ 0xFFFF
#endif	
#ifdef ATMEGA128_2WAIT
	MCUCR = 0x80;
	XMCRA=0x42;
#endif	
#ifdef ATMEGA128_3WAIT
	MCUCR = 0xc0;
	XMCRA=0x42;
#endif	

	sei();				// enable interrupts
}

void net_init(void)
{
	iinchip_init();
	get_netconf(&NetConf);
	setSIPR((u_char*)&NetConf.sip);
	setGAR((u_char*)&NetConf.gwip);
	setSUBR((u_char*)&NetConf.sn);
	setSHAR(NetConf.mac);
#ifdef __DEF_IINCHIP_INT__
	setIMR(0xEF);
#endif	
	sysinit(NetConf.Mem_alloc,NetConf.Mem_alloc);
}
