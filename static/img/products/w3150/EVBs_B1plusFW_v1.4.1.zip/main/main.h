#ifndef __MAIN_H
#define __MAIN_H


#define TX_RX_MAX_BUF_SIZE	2048

#define TX_BUF	0x1100
#define RX_BUF	(TX_BUF+TX_RX_MAX_BUF_SIZE)


#endif
