/*
 * (c)COPYRIGHT
 * ALL RIGHT RESERVED
 *
 * FileName : main.c
 * Brief : source codes for EVB-B1+
 * Optimized compiler : WINAVR 4.3.2(20081118).
 
 * Revision History :
 * ----------	-------		----------- ------------------------------------------------
 * 	Date		version		Author      Description
 * ----------	-------  	----------- ------------------------------------------------
 * 11/24/2006	1.0.0.0					Release version
 * ----------	-------					------------------------------------------------
 * 12/27/2006	1.1.0.0					W3150A+ Driver updated. (Optimization)
 * ----------	-------					------------------------------------------------
 * 01/23/2007	1.1.1.0					Bug fix(setMR function in indirect mode)
 * ----------	-------					------------------------------------------------
 * 04/07/2008	1.2.0.0					W3150A+ Driver updated.
 *			 							Modified check_leaseIP() function in DHCP.C.
 * ----------	-------					------------------------------------------------
 * 11/21/2008	1.3.0.0					optimized at Compiler WinAVR 20081118rc2 version
										Changed wait_1us() function delay.c
										Changed lcd_ready() function in lcd.c
 * ----------	-------					------------------------------------------------
 *  3/21/2012	1.4.0.0		Eunkyoung	Modify a ARP error.
 *										Modify 'w3150a.c'
 *											- function ( getSUBR(), setSUBR(), ApplySubnet(), ClearSubnet() )
 *										Modify 'socket.c'
 *											- function( connect() & sendto() )						
 * ----------	-------		------------------------------------------------
 * 12/08/2015	1.4.1.0		Eunkyoung	modify setSUBR() fuctions
 *										when setSUBR use, it dosen't save the subnetmask value.
 *										(w3150a.c)	
 * ----------  -------  -----------  ----------------------------		
 */

#include <string.h>
#include "../util/myprintf.h"
#include "../mcu/types.h"
#include "../mcu/timer.h"
#include "../mcu/delay.h"
#include "../mcu/serial.h"
#include "../iinchip/socket.h"
#include "../evb/lcd.h"
#include "../evb/evb.h"
#include "../evb/manage.h"
#include "../evb/channel.h"
#include "../evb/config.h"
#include "../inet/dhcp.h"
#include "../app/webserver.h"
#include "../app/loopback.h"
#include "../app/ping_app.h"
#include "main.h"


int main(void)
{
	SOCKET i;
	evb_init();
	check_manage();
	init_timer();
	ClearSubnet();

	for (i = 0; i < MAX_SOCK_NUM; i++)
	{
		switch(ChConf.ch[i].type)
		{
		case NOTUSE: unregister_channel_handler(i);
			break;

		case DHCP_CLIENT: PRINTLN1("%d : DHCH Client Start.",i);
			evb_set_lcd_text(0,(u_char*)"< DHCP  CLIENT >");
			evb_set_lcd_text(1,(u_char*)" Wait a minute ");
			get_netconf(&NetConf);
			memcpy(SRC_MAC_ADDR,NetConf.mac,6);
			init_dhcp_client(i, evb_soft_reset,evb_soft_reset);
			if(!getIP_DHCPS())
			{
				evb_set_lcd_text(1,(u_char*)" Fail to get IP ");
				PRINTLN("Fail to get a IP adress from DHCP server");
				PRINTLN("Apply the default network information!!!");
				ChConf.ch[i].type =  NOTUSE;	// Disable DHCPC;
				unregister_channel_handler(i);
				wait_10ms(100);
			}
			else
			{
				NetConf.sip  = *((u_long*)GET_SIP);
				NetConf.gwip = *((u_long*)GET_GW_IP);
				NetConf.sn   = *((u_long*)GET_SN_MASK);
				NetConf.dns  = *((u_long*)GET_DNS_IP);
				PRINTLN("Get network information from DHCP Server...");	
				register_channel_handler(i,check_DHCP_state);
			}
			set_netconf(&NetConf);
			break;
		case LB_TCPS:
			register_channel_handler(i,loopback_tcps);
			break;
		case LB_TCPC:
			register_channel_handler(i,loopback_tcpc);
			break;
		case LB_UDP:
			register_channel_handler(i,loopback_udp);
			break;
		case WEB_SERVER:
			register_channel_handler(i,web_server);
			break;
		}
	}
	
	net_init();
	evb_logo();
	
	while (1)
	{
			for (i = 0 ; i < MAX_SOCK_NUM ; i++ )
			if(ChannelHandler[i].Handler) (*ChannelHandler[i].Handler)(i);
	}		
}
