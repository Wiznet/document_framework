/*
*
* Filename	: util.c
* Description   : The utility functions for AVREVB. (AVR-GCC Compiler)
*
*/

#include <string.h>
#include "util.h"


/*
********************************************************************************
*              CONVERT HEX INTO CHAR
*
* Description : This function converts HEX(0-F) to a character
* Arguments   : c -  is a Hex(0x00~0x0F) to convert to a character
* Returns     : a character
* Note        :
********************************************************************************
*/
u_char D2C(char c)
{
	u_int t = (u_int) c;
	if (t >= 0 && t <= 9)
		return '0' + c;
	if (t >= 10 && t <= 15)
		return 'A' + c - 10;

	return c;
}

/*
********************************************************************************
*              CONVERT CHAR INTO HEX
*
* Description : This function converts a character('0'-'F') to a HEX
* Arguments   : c -  is a character('0'-'F') to convert to HEX
* Returns     : HEX
* Note        :
********************************************************************************
*/
char C2D(u_char c)
{
	if (c >= '0' && c <= '9')
		return c - '0';
	if (c >= 'a' && c <= 'f')
		return 10 + c -'a';
	if (c >= 'A' && c <= 'F')
		return 10 + c -'A';

	return (char)c;
}

/*
********************************************************************************
*              CONVERT STRING INTO INTEGER
*
* Description : This function converts a string to a integer number.
* Arguments   : str  -  is a pointer to convert
*               base - is a base value (must be in the range 2 - 16)
* Returns     : a integer number
* Note        :
********************************************************************************
*/
u_int ATOI(char* str,u_int base)
{
        unsigned int num = 0;
        while (*str !=0)
                num = num * base + C2D(*str++);
	return num;
}

/*
********************************************************************************
*              CONVERT STRING INTO HEX OR DECIMAL
*
* Description : This function converts a string to a HEX number or a decimal number.
* Arguments   : str  - is a pointer to string to be converted
*               base - is a base value (must be in the range 2 - 16)
*               ret  - is a integer pointer to return
* Returns     : success - 1, fail - 0
* Note        :
********************************************************************************
*/
int ValidATOI(char* str, int base, int* ret)
{
	int c;
	char* tstr = str;
	if(str == 0 || *str == '\0') return 0;
	while(*tstr != '\0')
	{
		c = C2D(*tstr);
		if( c >= 0 && c < base) tstr++;
		else    return 0;
	}
	
	*ret = ATOI(str,base);
	return 1;
}


/**
 * strspn - Calculate the length of the initial substring of @s which only
 * 	contain letters in @accept
 * @s: The string to be searched
 * @accept: The string to search for
 */
size_t strspn(const char *s, const char *accept)
{
	const char *p;
	const char *a;
	size_t count = 0;

	for (p = s; *p != '\0'; ++p) {
		for (a = accept; *a != '\0'; ++a) {
			if (*p == *a)
				break;
		}
		if (*a == '\0')
			return count;
		++count;
	}

	return count;
}

/**
 * strpbrk - Find the first occurrence of a set of characters
 * @cs: The string to be searched
 * @ct: The characters to search for
 */
char * strpbrk(const char * cs,const char * ct)
{
	const char *sc1,*sc2;

	for( sc1 = cs; *sc1 != '\0'; ++sc1) {
		for( sc2 = ct; *sc2 != '\0'; ++sc2) {
			if (*sc1 == *sc2)
				return (char *) sc1;
		}
	}
	return NULL;
}

char * ___strtok;
/**
 * strtok - Split a string into tokens
 * @s: The string to be searched
 * @ct: The characters to search for
 *
 * WARNING: strtok is deprecated, use strsep instead.
 */
char * strtok(char * s,const char * ct)
{
	char *sbegin, *send;

	sbegin  = s ? s : ___strtok;
	if (!sbegin) {
		return NULL;
	}
	sbegin += strspn(sbegin,ct);
	if (*sbegin == '\0') {
		___strtok = NULL;
		return( NULL );
	}
	send = strpbrk( sbegin, ct);
	if (send && *send != '\0')
		*send++ = '\0';
	___strtok = send;
	return (sbegin);
}


/*
Description   :  replace the specified character in a string with new character
Argument      :  str - pointer to be replaced
		 oldchar - old character
                 newchar - new character
Return Value  :  None.
Note          :  
*/
void replacetochar(char * str, char oldchar, char newchar)
{
	int x;
	for (x = 0; str[x]; x++) 
		if (str[x] == oldchar) str[x] = newchar;	
}

////---- ADD_2006_06_05 (These functions are used in dns.c & sockutil.c)
u_short swaps(u_int i)
{
	u_short ret=0;
	ret = (i & 0xFF) << 8;
	ret |= ((i >> 8)& 0xFF);
	return ret;	
}

u_long swapl(u_long l)
{
	u_long ret=0;
	ret = (l & 0xFF) << 24;
	ret |= ((l >> 8) & 0xFF) << 16;
	ret |= ((l >> 16) & 0xFF) << 8;
	ret |= ((l >> 24) & 0xFF);
	return ret;
}
/////---- END_ADD

#ifndef NO_USE_UTIL_FUNC
/*
********************************************************************************
*              CONVERT INTEGER INTO STRING
*
* Description : This function converts a integer number to a string.
* Arguments   : value - is a integer value to be converted
*               str   - is a pointer to string to be returned
*               base  - is a base value (must be in the range 2 - 16)
* Returns     : a pointer to string
* Note        :
********************************************************************************
*/
char* ITOA(u_int value,char* str,u_int base)
{
	char c;
	char* tstr = str;
	char* ret = str;
	if(value == 0) *str++='0';
	while(value > 0)
	{
		*str++ =(char)D2C((char)(value%base));
		value /= base;
	}
	*str-- ='\0';
	while(tstr < str )
	{
		c = *tstr;
		*tstr++ = *str;	
		*str-- = c;
	}
	return ret;
}

#endif
