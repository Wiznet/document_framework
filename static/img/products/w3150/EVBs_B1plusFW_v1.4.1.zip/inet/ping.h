/*
*
* Filename      : ping.h
* Description   : Implemation of Ping
*		  To send 'ping-request' to peer & To receive 'ping-reply' from peer.
*		  Add the logic of sending ping-reply to version 1.0
*
*/

#ifndef __PING_API__
#define __PING_API__

#include "../mcu/types.h"

#define PINGBUF_LEN 32

typedef struct _PINGMSG
{
	char	Type; 		// 0 - Ping Reply, 8 - Ping Request
	char 	Code;		// Always 0
	u_short CheckSum;	// Check sum
	u_short	ID;		// Identification 
	u_short SeqNum;		// Sequence Number
	char	Data[PINGBUF_LEN];// Ping Data  : 1452 = IP RAW MTU - sizeof(Type+Code+CheckSum+ID+SeqNum)
}PINGMSG;

typedef struct __PINGLOG
{
	u_short CheckSumErr;	// Check sum Error Count
	u_short UnreachableMSG;	// Count of receiving unreachable message from a peer
	u_short TimeExceedMSG;	// Count of receiving time exceeded message from a peer
	u_short UnknownMSG;	// Count of receiving unknown message from a peer
	u_short ARPErr;		// count of fail to send ARP to the specified peer
	u_short PingRequest;	// Count of sending ping-request message to the specified peer
	u_short PingReply;	// Count of receiving ping reply message from the specifed peer
	u_short Loss;		// Count of timeout  
}PINGLOG;


void ping_request(void);

char ping(int count, u_int size, u_int time, u_char* addr, PINGLOG* log); /* Send ping-request to the specified peer and receive ping-reply from the specified peer. */

void DisplayPingStatistics(PINGLOG log);				/* Display result of ping */

#endif	// end __PING_API_
