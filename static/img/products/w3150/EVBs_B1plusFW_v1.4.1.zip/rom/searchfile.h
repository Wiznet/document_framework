#ifndef __ROMFILE_SEARCH
#define __ROMFILE_SEARCH

#include "../mcu/types.h"
#include "../rom/romfs.h"

u_char search_file(u_char * name, prog_char ** buf, u_int * len);	// Search a file from ROM FILE 

#endif
