#include <string.h>
#include "searchfile.h"


/*
Description  : Search a file from ROM FILE 
Argument     : name - file name
               buf - file contents to be return
               len - file length to be return
Return Value : 
Note         : 
*/
u_char search_file(u_char * name, prog_char ** buf, u_int * len) 
{
	int i;
    	ROMFILE *romfs;
    
	i = 0;

    	for (romfs = romfl_list; romfs; romfs = romfs->romfl_next)
    	{
		if (!strcmp((char*)name, (char*)romfs->romfl_name))
		{
			*len = romfs->romfl_size;
			*buf = romfs->romfl_data;
			return ++i;
		}
	}

	return 0;
}
