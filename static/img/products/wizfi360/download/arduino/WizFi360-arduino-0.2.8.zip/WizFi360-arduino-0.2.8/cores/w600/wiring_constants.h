#ifndef _WIRING_CONSTANTS_#define _WIRING_CONSTANTS_
#define HIGH	0x01#define LOW		0x00
#define INPUT	0x00#define OUTPUT	0x01
#ifndef USER_BTN_PRESS#define USER_BTN_PRESS      0#define USER_BTN_RELEASE    1#endifenum BitOrder {    LSBFIRST = 0,    MSBFIRST = 1};#endif