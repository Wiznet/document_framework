#ifndef _VARIANT_ARDUINO_
#define _VARIANT_ARDUINO_

#ifdef __cplusplus
extern "C" {
#endif

#define NUM_ANALOG_INPUTS	10

#ifdef __cplusplus
}
#endif

#endif
