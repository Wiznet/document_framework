https://github.com/Wiznet/W7500/tree/master/W7500x_Library_Examples/Projects/Peripheral_Examples/UART/Printf(WIZwiki-W7500ECO)


