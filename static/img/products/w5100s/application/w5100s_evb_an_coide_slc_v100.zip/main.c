#include <stdio.h>
#include <stdlib.h>
#include "HAL_Config.h"
#include "HALInit.h"
#include "wizchip_conf.h"
#include "inttypes.h"
#include "stm32f10x_gpio.h"
#include "stm32f10x_exti.h"
#include "W5100SRelFunctions.h"
#include "serialCommand.h"

#include "arp.h"
#include "ping.h"
wiz_NetInfo gWIZNETINFO = { .mac = {0x00,0x08,0xdc,0xff,0xff,0x02},
							.ip = {192,168,77,4},
							.sn = {255, 255, 255, 0},
							.gw = {192, 168, 77, 1},
							.dns = {168, 126, 63, 1},
							.dhcp = NETINFO_STATIC};



uint8_t dest_ip[4]={192,168,77,232};


void print_network_information(void);
void delay(unsigned int count);

//#define PING_AUTO
#define PING_SEND
//#define ARP_AUTO
//#define ARP_SEND

int main(void)
{
	volatile int i;
	volatile int j,k;

	gpioInitialize();
	usartInitialize();
	timerInitialize();
	printf("System start.\r\n");




#if _WIZCHIP_IO_MODE_ & _WIZCHIP_IO_MODE_SPI_
	/* SPI method callback registration */
	reg_wizchip_spi_cbfunc(spiReadByte, spiWriteByte);
	/* CS function register */
	reg_wizchip_cs_cbfunc(csEnable,csDisable);
#else
	/* Indirect bus method callback registration */
	//reg_wizchip_bus_cbfunc(busReadByte, busWriteByte);
#endif

#if _WIZCHIP_IO_MODE_ == _WIZCHIP_IO_MODE_BUS_INDIR_
	FSMCInitialize();
#else
	spiInitailize();
#endif
	resetAssert();
	delay(10);
	resetDeassert();
	delay(10);
	wizchip_setnetinfo(&gWIZNETINFO);
	W5100SInitialze();


#ifdef PING_AUTO
	int ret=ping_auto(0, dest_ip, wiz_delay_ms);
	if(ret==PING_RECV) printf("PING : successful\r\n");
	else printf("PING : failure\r\n", ret);
#endif

#ifdef PING_SEND
	int ret=ping_send(0, dest_ip, 5, 100, 0x1234, 0x4321, wiz_delay_ms);
	if(ret==PING_RECV) printf("PING : successful\r\n");
	else printf("PING : failure\r\n", ret);

#endif


#ifdef ARP_AUTO
	uint8_t addr0[6];
	int8_t ret=arp_auto(dest_ip, wiz_delay_ms);
	if(ret==ARP_RECV) printf("ARP : successful\r\n");
	else printf("ARP : failure\r\n", ret);
	arp_getMacAddress(addr0);
	printf("%.2x:%.2x:%.2x:%.2x:%.2x:%.2x\r\n",addr0[0],addr0[1],addr0[2],addr0[3],addr0[4],addr0[5],addr0[6]  );
#endif



#ifdef ARP_SEND
		uint8_t addr0[6];
		int8_t ret=arp_send(dest_ip, 5, 100, wiz_delay_ms);
		if(ret==ARP_RECV) printf("ARP : successful\r\n");
		else printf("ARP : failure \r\n", ret);
		arp_getMacAddress(addr0);
		printf("%.2x:%.2x:%.2x:%.2x:%.2x:%.2x\r\n",addr0[0],addr0[1],addr0[2],addr0[3],addr0[4],addr0[5],addr0[6]  );
#endif



	while(1){

	}
}

void delay(unsigned int count)
{
	int temp;
	temp = count + TIM2_gettimer();
	while(temp > TIM2_gettimer()){}
}


void print_network_information(void)
{
	wizchip_getnetinfo(&gWIZNETINFO);
	printf("Mac address: %02x:%02x:%02x:%02x:%02x:%02x\n\r",gWIZNETINFO.mac[0],gWIZNETINFO.mac[1],gWIZNETINFO.mac[2],gWIZNETINFO.mac[3],gWIZNETINFO.mac[4],gWIZNETINFO.mac[5]);
	printf("IP address : %d.%d.%d.%d\n\r",gWIZNETINFO.ip[0],gWIZNETINFO.ip[1],gWIZNETINFO.ip[2],gWIZNETINFO.ip[3]);
	printf("SM Mask	   : %d.%d.%d.%d\n\r",gWIZNETINFO.sn[0],gWIZNETINFO.sn[1],gWIZNETINFO.sn[2],gWIZNETINFO.sn[3]);
	printf("Gate way   : %d.%d.%d.%d\n\r",gWIZNETINFO.gw[0],gWIZNETINFO.gw[1],gWIZNETINFO.gw[2],gWIZNETINFO.gw[3]);
	printf("DNS Server : %d.%d.%d.%d\n\r",gWIZNETINFO.dns[0],gWIZNETINFO.dns[1],gWIZNETINFO.dns[2],gWIZNETINFO.dns[3]);
}
