
#include "ping.h"
PINGMSGR PingRequest;	 // Variable for Ping Request
PINGMSGR PingReply;	     // Variable for Ping Reply
static uint16_t RandomID = 0x1234; 
static uint16_t RandomSeqNum = 0x4321;
static uint16_t PingRCR = 0x08;
static uint16_t PingRTR = 0x07d0;
uint8_t ping_reply_received = 0; 
uint8_t req=0;
uint8_t rep=0;


uint8_t ping_auto(uint8_t s, uint8_t *addr)
{
	uint8_t i;
	int32_t len = 0;
	uint8_t cnt=0,ret;
	configure_ping_request();
	for(i = 0; i<=3;i++)
	{
		send_ping_request(s, addr);
		while(1)
		{
			ret=recv_ping_reply(s);
			if(ret==1){
				rep++;
				break;
			}
			else if(ret==2){
				break;
			}
		}
	}

	return rep;
}

void configure_ping_request(void){
  uint16_t i;
#if   (_WIZCHIP_ != W5100S)
  	setSLIR(SLIR_TIMEOUT | SLIR_PING);
  	setSLRCR(PingRCR);
  	setSLRTR(PingRTR);
  	setPINGSEQR(htons(RandomID++));
  	setPINGIDR(htons(RandomSeqNum++));
#else
	//Initailize flag for ping reply
	ping_reply_received = 0;
	/* make header of the ping-request  */
	PingRequest.Type = PING_REQUEST;                   // Ping-Request
	PingRequest.Code = CODE_ZERO;	                   // Always '0'
	PingRequest.ID = htons(RandomID++);	       // set ping-request's ID to random integer value
	PingRequest.SeqNum =htons(RandomSeqNum++);// set ping-request's sequence number to ramdom integer value
	//size = 32;                                 // set Data size

	/* Fill in Data[]  as size of BIF_LEN (Default = 32)*/
  	for(i = 0 ; i < BUF_LEN; i++){	                                
		PingRequest.Data[i] = (i) % 8;		  //'0'~'8' number into ping-request's data 	
	}
	 /* Do checksum of Ping Request */
	PingRequest.CheckSum = 0;		               // value of checksum before calucating checksum of ping-request packet
	PingRequest.CheckSum = htons(checksum((uint8_t*)&PingRequest,sizeof(PingRequest)));  // Calculate checksum
#endif

} // ping request


uint8_t send_ping_request(uint8_t s, uint8_t *addr)
{
	uint16_t ret;
#if   (_WIZCHIP_ != W5100S)
	setSLPIPR(addr);
	setSLCR(SLCMD_PING);
	req++;
#else
	while(1){
		switch(getSn_SR(s))
			{
				case SOCK_CLOSED:
					close(s);  // close the SOCKET
					/* Create Socket */
					IINCHIP_WRITE(Sn_PROTO(s), IPPROTO_ICMP);              // set ICMP Protocol
					if(ret=socket(s,Sn_MR_IPRAW,3000,0)!=s){       // open the SOCKET with IPRAW mode, if fail then Error
						return ret;
					}
					break;

				case SOCK_IPRAW:
					/* sendto ping_request to destination */
						if(ret = sendto(s,(uint8_t *)&PingRequest,sizeof(PingRequest),addr,3000)<0) {
							return ret;
						}
						return ret;
						req++;
					break;

				default:
					break;
		   }
	}
#endif

}
uint8_t recv_ping_reply(uint8_t s){
	 
	 uint16_t tmp_checksum;	
	 uint16_t len, rlen;
	 uint16_t i;
	 uint8_t data_buf[128],ret;
	 uint16_t port = 3000;
	 static uint8_t cnt=0;
	 PINGMSGR PingReply;
	 uint8_t *addr;

#if   (_WIZCHIP_ != W5100S)
	 if(getSLIR()&SLIR_PING){
		 setSLIR(SLIR_PING);
		 return 1;
	 }
	 else if(getSLIR()&SLIR_TIMEOUT){
		 setSLIR(SLIR_TIMEOUT);
		 return 2;
	 }
#else
	switch(getSn_SR(s))
		{
			case SOCK_CLOSED:
				close(s);  // close the SOCKET
				/* Create Socket */
				IINCHIP_WRITE(Sn_PROTO(s), IPPROTO_ICMP);              // set ICMP Protocol
				socket(s,Sn_MR_IPRAW,3000,0);       // open the SOCKET with IPRAW mode, if fail then Error

			case SOCK_IPRAW:
				if(rlen = getSn_RX_RSR(s) ){
					len = recvfrom(s, (uint8_t *)data_buf,rlen,addr,&port);
					if((data_buf[0]==PING_REPLY)&&(PingRequest.ID==(data_buf[5]<<8)+data_buf[4])&&(PingRequest.SeqNum==(data_buf[7]<<8)+data_buf[6]))
					{
						return 1;
					}
					else {
						return 2;
					}
				}
				else if(cnt > 100)
				{
					cnt = 0;
					return 2;
				}
				else
				{
					cnt++;
					wiz_delay_ms(50); // wait 50ms
			    }

				break;

			default:
				break;
	   }
#endif
}// ping_reply



uint16_t checksum(uint8_t * data_buf, uint16_t len)

{
  uint16_t sum, tsum, i, j;
  uint32_t lsum;

  j = len >> 1;
  lsum = 0;
  tsum = 0;
  for (i = 0; i < j; i++)
    {
      tsum = data_buf[i * 2];
      tsum = tsum << 8;
      tsum += data_buf[i * 2 + 1];
      lsum += tsum;
    }
   if (len % 2)
    {
      tsum = data_buf[i * 2];
      lsum += (tsum << 8);
    }
    sum = (uint16_t)lsum;
    sum = ~(sum + (lsum >> 16));
  return sum;

}


uint16_t htons( uint16_t hostshort)
{
#if 1
  //#ifdef LITTLE_ENDIAN
	uint16_t netshort=0;
	netshort = (hostshort & 0xFF) << 8;

	netshort |= ((hostshort >> 8)& 0xFF);
	return netshort;
#else
	return hostshort;
#endif
}


/*****************************************************************************************
	Function name: wait_1us
	Input		:	cnt; Delay duration = cnt * 1u seconds
	Output	:	non
	Description
	: A delay function for waiting cnt*1u second.
*****************************************************************************************/
void wait_1us(unsigned int cnt)
{
	unsigned int i;

	for(i = 0; i<cnt; i++) {

		}
}


/*****************************************************************************************
	Function name: wait_1ms
	Input		:	cnt; Delay duration = cnt * 1m seconds
	Output	:	non
	Description
	: A delay function for waiting cnt*1m second. This function use wait_1us but the wait_1us
		has some error (not accurate). So if you want exact time delay, please use the Timer.
*****************************************************************************************/
void wait_1ms(unsigned int cnt)
{
	unsigned int i;
	for (i = 0; i < cnt; i++) wait_1us(1000);
}

/*****************************************************************************************
	Function name: wait_10ms
	Input		:	cnt; Delay duration = cnt * 10m seconds
	Output	:	non
	Description
	: A delay function for waiting cnt*10m second. This function use wait_1ms but the wait_1ms
		has some error (not accurate more than wait_1us). So if you want exact time delay,
		please use the Timer.
*****************************************************************************************/
void wait_10ms(unsigned int cnt)
{
	unsigned int i;
	for (i = 0; i < cnt; i++) wait_1ms(10);
}



