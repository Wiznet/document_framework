#include "Ethernet/wizchip_conf.h"


#define BUF_LEN 18


#define SOCKET_ERROR 1
#define TIMEOUT_ERROR 2
#define SUCCESS 3
#define REPLY_ERROR 4
#define arp_DEBUG


typedef struct arpmsg
{
  uint8_t	DstMac[6];
  uint8_t	SrcMac[6];
  int16_t	Type;
  int16_t	HwType;
  int16_t	ProtoType;
  int8_t	HwSize;
  int8_t	ProtoSize;
  int16_t	Opcode;
  int8_t	SenderMac[6];
  int8_t	SenderIp[4];
  int8_t	TargetMac[6];
  int8_t	TargetIp[4];
  int8_t	Padding[BUF_LEN];
} ARPMSGR;


uint8_t arp_auto(uint8_t *addr);
void configure_arp_request(void);
void send_arp_request(uint8_t *addr);
uint8_t recv_arp_reply();
void get_arp_MacAddress(uint8_t* addr);
