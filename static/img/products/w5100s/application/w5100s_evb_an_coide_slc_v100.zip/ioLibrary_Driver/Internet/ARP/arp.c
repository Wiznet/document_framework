
#include "arp.h"
ARPMSGR ArpRequest;	 // Variable for arp Request
ARPMSGR ArpReply;	     // Variable for arp Reply

static uint8_t BroadcastMac[6]={0xff,0xff,0xff,0xff,0xff,0xff};
static uint8_t SrcMac[6];

//static uint16_t ARP = 0x0806;
//static uint16_t Ethernet = 0x0001;
//static uint16_t Ipv4 = 0x0800;
//static uint8_t	ARP_Request =0x01;
//static uint8_t	ARP_Relpy =0x02;

static uint16_t ARP = 0x0608;
static uint16_t Ethernet = 0x0100;
static uint16_t Ipv4 = 0x0008;
static uint16_t	ARP_Request =0x0100;
static uint16_t	ARP_Relpy =0x0200;
static uint8_t	hw_len= 0x06;
static uint8_t	proto_len=0x04;

static uint16_t ArpRCR = 0x08;
static uint16_t ArpRTR = 0x07d0;
uint8_t arp_reply_received = 0;



uint8_t arp_auto(uint8_t *addr)
{
	uint8_t i;
	int32_t len = 0;
	uint8_t cnt=0,ret=0;
	configure_arp_request();
	send_arp_request(addr);
	while(1)
	{
		ret=recv_arp_reply();
		if(ret!=0) break;
	}

	return ret;
}

void configure_arp_request(void){
  uint16_t i;
#if   (_WIZCHIP_== W5100S)
  	setSLIR(SLIR_TIMEOUT | SLIR_ARP);
  	setSLRCR(ArpRCR);
  	setSLRTR(ArpRTR);
#else
	ArpRequest.DstMac[0] = BroadcastMac[0];
	ArpRequest.DstMac[1] = BroadcastMac[1];
	ArpRequest.DstMac[2] = BroadcastMac[2];
	ArpRequest.DstMac[3] = BroadcastMac[3];
	ArpRequest.DstMac[4] = BroadcastMac[4];
	ArpRequest.DstMac[5] = BroadcastMac[5];
	getSHAR(ArpRequest.SrcMac);
	ArpRequest.Type=ARP;
	ArpRequest.HwType=Ethernet;
	ArpRequest.ProtoType=Ipv4;
	ArpRequest.HwSize=hw_len;
	ArpRequest.ProtoSize=proto_len;
	ArpRequest.Opcode=ARP_Request;
	getSHAR(ArpRequest.SenderMac);
	getSIPR(ArpRequest.SenderIp);
  	for(i = 0 ; i < BUF_LEN; i++){
		ArpRequest.Padding[i] = 0x00;
	}
#endif
}


uint8_t send_arp_request(uint8_t *addr)
{
	int32_t ret;
#if   (_WIZCHIP_== W5100S)
	setSLPIPR(addr);
	setSLCR(SLCMD_ARP);
#else
	ArpRequest.TargetIp[0]=addr[0];
	ArpRequest.TargetIp[1]=addr[1];
	ArpRequest.TargetIp[2]=addr[2];
	ArpRequest.TargetIp[3]=addr[3];


	while(1){
		switch(getSn_SR(0))
			{
				case SOCK_CLOSED:
					close(0);  // close the SOCKET
					/* Create Socket */

					if(ret=socket(0,Sn_MR_MACRAW,3000,0)!=s){       // open the SOCKET with IPRAW mode, if fail then Error
						return ret;
					}
					break;

				case SOCK_MACRAW:
					/* sendto arp_request to destination */
						if((ret = sendto(0,(uint8_t *)&ArpRequest,sizeof(ArpRequest),addr,3000))<0) {
							printf("ret :%d\r\n", ret);
							return ret;
						}
						return ret;
						//req++;
					break;

				default:
					break;
		   }
	}
#endif

}


uint8_t recv_arp_reply()
{

	 uint16_t tmp_checksum;
	 uint16_t len, rlen;
	 uint16_t i;
	 uint8_t data_buf[128],ret;
	 uint16_t port = 3000;
	 static uint8_t cnt=0;
	 uint8_t* addr;


#if   (_WIZCHIP_== W5100S)
	 if(getSLIR()&SLIR_ARP){
		 setSLIR(SLIR_ARP);
		 return 1;
	 }
	 else if(getSLIR()&SLIR_TIMEOUT){
		 setSLIR(SLIR_TIMEOUT);
		 return 2;
	 }
	 else return 0;
#else
	switch(getSn_SR(s))
		{
			case SOCK_CLOSED:
				close(s);
				socket(0,Sn_MR_MACRAW,3000,0);

			case SOCK_MACRAW:
				if(rlen = getSn_RX_RSR(s) ){
					len = recvfrom(0, (uint8_t *)data_buf,rlen,addr,&port);
					if((data_buf[0]==ArpRequest.SrcMac[0]) &&(data_buf[1]==ArpRequest.SrcMac[1]) &&(data_buf[2]==ArpRequest.SrcMac[2]) && (data_buf[3]==ArpRequest.SrcMac[3]) \
							&&(data_buf[4]==ArpRequest.SrcMac[4])&& (data_buf[5]==ArpRequest.SrcMac[5]) && (data_buf[6]==ArpRequest.SrcMac[6])	\
							&& ( ARP == (data_buf[13]<<8 |data_buf[12])) && (Ethernet == (data_buf[15]<<8 |data_buf[14])) && ( Ipv4 == (data_buf[17]<<8 | data_buf[16])) \
							&& (data_buf[18]==hw_len) && (data_buf[19]==proto_len) && ( ARP_Relpy == (data_buf[21]<<8 |data_buf[20]) )
							)
					{
						ArpReply.SenderMac[0]=data_buf[22]; ArpReply.SenderMac[1]=data_buf[23]; ArpReply.SenderMac[2]=data_buf[24];
						ArpReply.SenderMac[3]=data_buf[25]; ArpReply.SenderMac[4]=data_buf[26]; ArpReply.SenderMac[5]=data_buf[27];
						return 1;
					}
					else {
						return 2;
					}
				}
				else if(cnt > 1000)
				{
					cnt = 0;
					return 2;
				}
				else
				{
					cnt++;
					wiz_delay_ms(50); // wait 50ms
					return 0;
			    }

				break;

			default:
				break;
	   }
#endif
}// arp_reply

void get_arp_MacAddress(uint8_t* addr)
{
#if   (_WIZCHIP_== W5100S)
	getSLPHAR(addr);
#else
	addr[0]=ArpReply.SenderMac[0];
	addr[1]=ArpReply.SenderMac[1];
	addr[2]=ArpReply.SenderMac[2];
	addr[3]=ArpReply.SenderMac[3];
	addr[4]=ArpReply.SenderMac[4];
	addr[5]=ArpReply.SenderMac[5];
#endif
}
