#ifndef	_W5300_H_
#define	_W5300_H_

#include <linux/netdevice.h>
#include <net/sock.h>

#include <linux/dma-mapping.h>
#include <asm/dma.h>
#include <asm/arch/dma.h>

/* Maximum socket number. W5300 supports max 8 channels. */
#define MAX_SOCK_NUM 8

#ifdef DEBUG 
#define DPRINTK(format,args...) printk(format,##args)
#else
#define DPRINTK(format,args...)
#endif

/* 
 * This is W5300 information structure.
 * Additional information is included in struct net_device.
 */
struct wiz_private {
  void __iomem *regs;               /* The base address of W5300 register */
  struct net_device *dev;           /* Struct net_device address to manage W5300 */
  u8 rxbuf_conf[MAX_SOCK_NUM];      /* Rx FIFO Size Information */
  u8 txbuf_conf[MAX_SOCK_NUM];      /* Tx FIFO Size Information */
  u16 int_status[MAX_SOCK_NUM];     /* Interrupt status of each channel */
  struct net_device_stats stats;    /* Statistical Information */
  struct napi_struct napi;
  struct sock *gSock[MAX_SOCK_NUM]; /* struct sock address of each channel. MACRAW channel is not used. */
  unsigned long first_send;
  spinlock_t lock; 
};

/* Global variables to access wiz_private */
extern struct wiz_private *wiz_desc;

/* W5300 Register Memory Map */

/* FIXME: This value is dependent on the system. It should be modified according to system requirement. */
#define W5300_REG_BASE	0xF0000000

/* socket register */
#define CH_BASE		(W5300_REG_BASE + 0x0200)

/* size of each channel register map */
#define CH_SIZE		0x40

/* Mode Register address */
#define MR		(W5300_REG_BASE)
#define MR1		(MR + 1)

/* Direct accessable register if IINCHIP bus mode is indirect(MR_IND is set in MR register) */
#define IDM_AR		(W5300_REG_BASE + 0x02)
#define IDM_AR1		(IDM_AR + 1)

#define IDM_DR		(W5300_REG_BASE + 0x04)
#define IDM_DR1		(IDM_DR + 1)

/* Interrupt Register */
#define IR		(W5300_REG_BASE + 0x02)
#define IR1		(IR + 1);

/*  Interrupt mask register */
#define IMR		(W5300_REG_BASE + 0x04)
#define IMR1		(IMR + 1)

/* Interrupt mask register */
#define STAR		(W5300_REG_BASE + 0x06)
#define STAR1		(STAR + 1)

/*  Source MAC Register address */
#define SHAR		(W5300_REG_BASE + 0x08)
#define SHAR1		(SHAR + 1)
#define SHAR2		(SHAR + 2)
#define SHAR3		(SHAR + 3)
#define SHAR4		(SHAR + 4)
#define SHAR5		(SHAR + 5)

/* Gateway IP Register address */
#define GAR		(W5300_REG_BASE + 0x10)
#define GAR1		(GAR + 1)
#define GAR2		(GAR + 2)
#define GAR3		(GAR + 3)

/* Subnet mask Register address */
#define SUBR		(W5300_REG_BASE + 0x14)
#define SUBR1		(SUBR + 1)
#define SUBR2		(SUBR + 2)
#define SUBR3		(SUBR + 3)

/* Source IP Register address */
#define SIPR		(W5300_REG_BASE + 0x18)
#define SIPR1		(SIPR + 1)
#define SIPR2		(SIPR + 2)
#define SIPR3		(SIPR + 3)

/* Timeout register address(1 is 100us) */
#define RTR		(W5300_REG_BASE + 0x1C)
#define RTR1		(RTR + 1)

/* Retry count reigster */
#define RCR		(W5300_REG_BASE + 0x1E)
#define RCR1		(RCR + 1)

/* Transmit memory size reigster */
#define TMSR0		(W5300_REG_BASE + 0x20)
#define TMSR1		(TMSR0 + 1)
#define TMSR2		(TMSR0 + 2)
#define TMSR3		(TMSR0 + 3)
#define TMSR4		(TMSR0 + 4)
#define TMSR5		(TMSR0 + 5)
#define TMSR6		(TMSR0 + 6)
#define TMSR7		(TMSR0 + 7)

#define TMSR_01		(W5300_REG_BASE + 0x20)
#define TMSR_23		(TMSR_01 + 2)
#define TMSR_45		(TMSR_01 + 4)
#define TMSR_67		(TMSR_01 + 6)

/* Receive memory size reigster */
#define RMSR0		(W5300_REG_BASE + 0x28)
#define RMSR1		(RMSR0 + 1)
#define RMSR2		(RMSR0 + 2)
#define RMSR3		(RMSR0 + 3)
#define RMSR4		(RMSR0 + 4)
#define RMSR5		(RMSR0 + 5)
#define RMSR6		(RMSR0 + 6)
#define RMSR7		(RMSR0 + 7)

#define RMSR_01		(W5300_REG_BASE + 0x28)
#define RMSR_23		(RMSR_01 + 2)
#define RMSR_45		(RMSR_01 + 4)
#define RMSR_67		(RMSR_01 + 6)

/* Memory Type Register
 * '1' - TX memory
 * '0' - RX memory */
#define MTYPER		(W5300_REG_BASE + 0x30)
#define MYYPER1		(MTYPER + 1)

/* Authentication type register address in PPPoE mode */
#define PATR		(W5300_REG_BASE + 0x32)
#define PATR1		(PATR + 1)

#define PTIMER		(W5300_REG_BASE + 0x36)
#define PTIMER1		(PTIMER + 1)

#define PMAGIC		(W5300_REG_BASE + 0x38)
#define PMAGIC1		(PMAGIC + 1)

/* PPPoE session ID register */
#define PSIDR           (W5300_REG_BASE + 0x3C)
#define PSIDR1          (PSIDR + 1)

/* PPPoE destination hardware address register */
#define PDHAR           (W5300_REG_BASE + 0x40)
#define PDHAR0          PDHAR
#define PDHAR1          (PDHAR + 1)
#define PDHAR2          (PDHAR + 2)
#define PDHAR3          (PDHAR + 3)
#define PDHAR4          (PDHAR + 4)
#define PDHAR5          (PDHAR + 5)

/* Unreachable IP register address in UDP mode */
#define UIPR		(W5300_REG_BASE + 0x48)
#define UIPR1		(UIPR + 1)
#define UIPR2		(UIPR + 2)
#define UIPR3		(UIPR + 3)

/* Unreachable Port register address in UDP mode */
#define UPORT		(W5300_REG_BASE + 0x4C)
#define UPORT1		(UPORT + 1)

/* Fragment register */
#define FMTUR		(W5300_REG_BASE + 0x4E)
#define FMTUR1		(FMTUR + 1)

/* PIN 'BRDYn' configure register */
#define Pn_BRDYR(n)     (W5300_REG_BASE + 0x60 + n*4)
#define Pn_BRDYR1(n)    (Pn_BRDYR(n) + 1)

/* PIN 'BRDYn' buffer depth register */
#define Pn_BDPTHR(n)    (W5300_REG_BASE + 0x62 + n*4)
#define Pn_BDPTHR1(n)   (Pn_BDPTHR(n) + 1)

/* Chip ID register(=0x5300) */
#define IDR		(W5300_REG_BASE + 0xFE)
#define IDR1		(IDR + 1)

/* socket Mode register */
#define Sn_MR(ch)	(CH_BASE + ch * CH_SIZE + 0x00)
#define Sn_MR1(ch)	(Sn_MR(ch)+1)

/* socket command register */
#define Sn_CR(ch)	(CH_BASE + ch * CH_SIZE + 0x02)
#define Sn_CR1(ch)	(Sn_CR(ch)+1);   

/* socket interrupt mask register */
#define Sn_IMR(ch)	(CH_BASE + ch * CH_SIZE + 0x04)
#define Sn_IMR1(ch)	(Sn_IMR(ch)+1)

/* socket interrupt register */
#define Sn_IR(ch)	(CH_BASE + ch * CH_SIZE + 0x06)
#define Sn_IR1(ch)	(Sn_IR(ch)+1)

/* socket status register */
#define Sn_SSR(ch)	(CH_BASE + ch * CH_SIZE + 0x08)
#define Sn_SSR1(ch)	(Sn_SSR(ch)+1);

/* source port register */
#define Sn_PORTR(ch)	(CH_BASE + ch * CH_SIZE + 0x0A)
#define Sn_PORTR1(ch)	(Sn_PORTR(ch)+1)

/* Peer MAC register address */
#define Sn_DHAR(ch)	(CH_BASE + ch * CH_SIZE + 0x0C)
#define Sn_DHAR1(ch)	(Sn_DHAR(ch)+1)
#define Sn_DHAR2(ch)	(Sn_DHAR(ch)+2)
#define Sn_DHAR3(ch)	(Sn_DHAR(ch)+3)
#define Sn_DHAR4(ch)	(Sn_DHAR(ch)+4)
#define Sn_DHAR5(ch)	(Sn_DHAR(ch)+5)

/* Peer port register address */
#define Sn_DPORTR(ch)	(CH_BASE + ch * CH_SIZE + 0x12)
#define Sn_DPORTR1(ch)	(Sn_DPORTR(ch)+1)

/* Peer IP register address */
#define Sn_DIPR(ch)	(CH_BASE + ch * CH_SIZE + 0x14)
#define Sn_DIPR1(ch)	(Sn_DIPR(ch)+1)
#define Sn_DIPR2(ch)	(Sn_DIPR(ch)+2)
#define Sn_DIPR3(ch)	(Sn_DIPR(ch)+3)

/* Maximum Segment Size(Sn_MSSR0) register address */
#define Sn_MSSR(ch)	(CH_BASE + ch * CH_SIZE + 0x18)
#define Sn_MSSR1(ch)	(Sn_MSSR(ch)+1)

/* Protocol of IP Header field register in IP raw mode */
#define Sn_PROTOR(ch)	(CH_BASE + ch * CH_SIZE + 0x1A)
#define Sn_PROTOR1(ch)	(Sn_PROTOR(ch)+1)

/* Socket keep alive timer register */
#define Sn_KPALVTR(ch)  Sn_PROTOR(ch)

/* IP Type of Service(TOS) Register */
#define Sn_TOSR(ch)	(CH_BASE + ch * CH_SIZE + 0x1C)
#define Sn_TOSR1(ch)	(Sn_TOSR(ch)+1)

/* IP Time to live(TTL) Register */
#define Sn_TTLR(ch)	(CH_BASE + ch * CH_SIZE + 0x1E)
#define Sn_TTLR1(ch)	(Sn_TTLR(ch)+1)

/* Transmit Size Register (Byte count) */
#define Sn_TX_WRSR(ch)	(CH_BASE + ch * CH_SIZE + 0x20)
#define Sn_TX_WRSR1(ch)	(Sn_TX_WRSR(ch) + 1)
#define Sn_TX_WRSR2(ch)	(Sn_TX_WRSR(ch) + 2)
#define Sn_TX_WRSR3(ch)	(Sn_TX_WRSR(ch) + 3)

/* Transmit free memory size register (Byte count) */
#define Sn_TX_FSR(ch)	(CH_BASE + ch * CH_SIZE + 0x24)
#define Sn_TX_FSR1(ch)	(Sn_TX_FSR(ch) + 1)
#define Sn_TX_FSR2(ch)	(Sn_TX_FSR(ch) + 2)
#define Sn_TX_FSR3(ch)	(Sn_TX_FSR(ch) + 3)

/* Received data size register (Byte count) */
#define Sn_RX_RSR(ch)	(CH_BASE + ch * CH_SIZE + 0x28)
#define Sn_RX_RSR1(ch)	(Sn_RX_RSR(ch) + 1)
#define Sn_RX_RSR2(ch)	(Sn_RX_RSR(ch) + 2)
#define Sn_RX_RSR3(ch)	(Sn_RX_RSR(ch) + 3)

/* Socket fragment register */
#define Sn_FRAGR(ch)    (CH_BASE + ch * CH_SIZE + 0x2C)
#define Sn_FRAGR1(ch)   (Sn_FRAGR(ch) + 1)

/* FIFO register for Transmit */
#define Sn_TX_FIFO(ch)	(CH_BASE + ch * CH_SIZE + 0x2E)
#define Sn_TX_FIFO1(ch)	(Sn_TX_FIFO(ch) + 1)

/* FIFO register for Receive */
#define Sn_RX_FIFO(ch)	(CH_BASE + ch * CH_SIZE + 0x30)
#define Sn_RX_FIFO1(ch)	(Sn_RX_FIFO(ch) + 1)

/* For Debugging */
//#define Sn_TX_SADR(n)      (SOCKET_REG_BASE + n * SOCKET_REG_SIZE + 0x32)
//#define Sn_TX_SADR0(n)     Sn_TX_SADR(n)
//#define Sn_TX_SADR1(n)     (Sn_TX_SADR(n) + 1)

//#define Sn_RX_SADR(n)      (SOCKET_REG_BASE + n * SOCKET_REG_SIZE + 0x34)
//#define Sn_RX_SADR0(n)     Sn_RX_SADR(n)
//#define Sn_RX_SADR1(n)     (Sn_RX_SADR(n) + 1)

//#define Sn_TX_RD(n)        (SOCKET_REG_BASE + n * SOCKET_REG_SIZE + 0x36)
//#define Sn_TX_RD0(n)       (Sn_TX_RD(n) + 1)
//#define Sn_TX_RD1(n)       (Sn_TX_RD(n) + 1)

//#define Sn_TX_WR(n)        (SOCKET_REG_BASE + n * SOCKET_REG_SIZE + 0x38)
//#define Sn_TX_WR0(n)       Sn_TX_WR(n)
//#define Sn_TX_WR1(n)       (Sn_TX_WR(n) + 1)

//#define Sn_TX_ACK(n)       (SOCKET_REG_BASE + n * SOCKET_REG_SIZE + 0x3A)
//#define Sn_TX_ACK0(n)      (Sn_TX_ACK(n) + 1)
//#define Sn_TX_ACK1(n)      (Sn_TX_ACK(n) + 1)

//#define Sn_RX_RD(n)       	(SOCKET_REG_BASE + n * SOCKET_REG_SIZE + 0x3C)
//#define Sn_RX_RD0(n)	      Sn_RX_RD(n)
//#define Sn_RX_RD1(n)	      (Sn_RX_RD(n) + 1)

//#define Sn_RX_WR(n)        (SOCKET_REG_BASE + n * SOCKET_REG_SIZE + 0x3E)
//#define Sn_RX_WR0(n)        Sn_RX_WR(n)
//#define Sn_RX_WR1(n)       (Sn_RX_WR(n) + 1)

/* MODE register values */
#define MR_DBW    (1 << 15) /**< Data bus width bit of MR. */
#define MR_MPF    (1 << 14) /**< Mac layer pause frame bit of MR. */
#define MR_WDF(x) ((x & 0x07) << 11) /**< Write data fetch time bit of  MR. */
#define MR_RDH    (1 << 10) /**< Read data hold time bit of MR. */
#define MR_FS     (1 << 8)  /**< FIFO swap bit of MR. */
#define MR_RST    (1 << 7)  /**< S/W reset bit of MR. */
#define MR_MT     (1 << 5)  /**< Memory test bit of MR. */
#define MR_PB     (1 << 4)  /**< Ping block bit of MR. */
#define MR_PPPoE  (1 << 3)  /**< PPPoE bit of MR. */
#define MR_DBS    (1 << 2)  /**< Data bus swap of MR. */
#define MR_IND    (1 << 0)  /**< Indirect mode bit of MR. */

/* IR register values */
#define IR_IPCF     (1 << 7)    /**< IP conflict bit of IR. */
#define IR_DPUR     (1 << 6)    /**< Destination port unreachable bit of IR. */
#define IR_PPPT     (1 << 5)    /**< PPPoE terminate bit of IR. */
#define IR_FMTU     (1 << 4)    /**< Fragment MTU bit of IR. */
#define IR_SnINT(n) (0x01 << n) /**< SOCKETn interrupt occurrence bit of IR. */

/* Pn_BRDYR values */
#define Pn_PEN      (1 << 7)    /**< PIN 'BRDYn' enable bit of Pn_BRDYR. */
#define Pn_MT       (1 << 6)    /**< PIN memory type bit of Pn_BRDYR. */
#define Pn_PPL      (1 << 5)    /**< PIN Polarity bit of Pn_BRDYR. */
#define Pn_SN(n)    ((n & 0x07) << 0)  /**< PIN Polarity bit of Pn_BRDYR. */

/* Sn_MR values */
#define Sn_MR_ALIGN     (1 << 8)  /**< Alignment bit of Sn_MR. */
#define Sn_MR_MULTI     (1 << 7)  /**< Multicasting bit of Sn_MR. */
#define Sn_MR_MF        (1 << 6)  /**< MAC filter bit of Sn_MR. */
#define Sn_MR_IGMPv     (1 << 5)  /**< IGMP version bit of Sn_MR. */
#define Sn_MR_ND        (1 << 5)  /**< No delayed ack bit of Sn_MR. */
#define Sn_MR_CLOSE     0x00      /**< Protocol bits of Sn_MR. */
#define Sn_MR_TCP       0x01      /**< Protocol bits of Sn_MR. */
#define Sn_MR_UDP       0x02      /**< Protocol bits of Sn_MR. */
#define Sn_MR_IPRAW     0x03      /**< Protocol bits of Sn_MR. */
#define Sn_MR_MACRAW    0x04      /**< Protocol bits of Sn_MR. */
#define Sn_MR_MACRAW_MF 0x44      /**< Protocol bits of Sn_MR  */
#define Sn_MR_PPPoE     0x05      /**< Protocol bits of Sn_MR. */

/* Sn_CR values */
#define Sn_CR_OPEN      0x01    /**< OPEN command value of Sn_CR. */
#define Sn_CR_LISTEN    0x02    /**< LISTEN command value of Sn_CR. */
#define Sn_CR_CONNECT   0x04    /**< CONNECT command value of Sn_CR. */
#define Sn_CR_DISCON    0x08    /**< DISCONNECT command value of Sn_CR. */
#define Sn_CR_CLOSE     0x10    /**< CLOSE command value of Sn_CR. */
#define Sn_CR_SEND      0x20    /**< SEND command value of Sn_CR. */
#define Sn_CR_SEND_MAC  0x21    /**< SEND_MAC command value of Sn_CR. */ 
#define Sn_CR_SEND_KEEP 0x22    /**< SEND_KEEP command value of Sn_CR */
#define Sn_CR_RECV      0x40    /**< RECV command value of Sn_CR */
#define Sn_CR_PCON      0x23    /**< PCON command value of Sn_CR */
#define Sn_CR_PDISCON   0x24    /**< PDISCON command value of Sn_CR */ 
#define Sn_CR_PCR       0x25    /**< PCR command value of Sn_CR */
#define Sn_CR_PCN       0x26    /**< PCN command value of Sn_CR */
#define Sn_CR_PCJ       0x27    /**< PCJ command value of Sn_CR */

/* Sn_IR values */
#define Sn_IR_PRECV     0x80    /**< PPP receive bit of Sn_IR */
#define Sn_IR_PFAIL     0x40    /**< PPP fail bit of Sn_IR */
#define Sn_IR_PNEXT     0x20    /**< PPP next phase bit of Sn_IR */
#define Sn_IR_SENDOK    0x10    /**< Send OK bit of Sn_IR */
#define Sn_IR_TIMEOUT   0x08    /**< Timout bit of Sn_IR */
#define Sn_IR_RECV      0x04    /**< Receive bit of Sn_IR */
#define Sn_IR_DISCON    0x02    /**< Disconnect bit of Sn_IR */
#define Sn_IR_CON       0x01    /**< Connect bit of Sn_IR */

/* Sn_SSR values */
#define SOCK_CLOSED      0x00   /**< SOCKETn is released */
#define SOCK_ARP         0x01   /**< ARP-request is transmitted in order to acquire destination hardware address. */
#define SOCK_INIT        0x13   /**< SOCKETn is open as TCP mode. */
#define SOCK_LISTEN      0x14   /**< SOCKETn operates as "TCP SERVER" and waits for connection-request (SYN packet) from "TCP CLIENT". */
#define SOCK_SYNSENT     0x15   /**< Connect-request(SYN packet) is transmitted to "TCP SERVER". */
#define SOCK_SYNRECV     0x16   /**< Connect-request(SYN packet) is received from "TCP CLIENT". */
#define SOCK_ESTABLISHED 0x17   /**< TCP connection is established. */
#define SOCK_FIN_WAIT    0x18   /**< SOCKETn is closing. */
#define SOCK_CLOSING     0x1A   /**< SOCKETn is closing. */
#define SOCK_TIME_WAIT   0x1B   /**< SOCKETn is closing. */
#define SOCK_CLOSE_WAIT  0x1C   /**< Disconnect-request(FIN packet) is received from the peer. */
#define SOCK_LAST_ACK    0x1D   /**< SOCKETn is closing. */
#define SOCK_UDP         0x22   /**< SOCKETn is open as UDP mode. */
#define SOCK_IPRAW       0x32   /**< SOCKETn is open as IPRAW mode. */
#define SOCK_MACRAW      0x42   /**< SOCKET0 is open as MACRAW mode. */
#define SOCK_PPPoE       0x5F   /**< SOCKET0 is open as PPPoE mode. */

/* IP PROTOCOL */
#define IPPROTO_IP	0   /* Dummy for IP */
#define IPPROTO_ICMP	1   /* Control message protocol */
#define IPPROTO_IGMP	2   /* Internet group management protocol */
#define IPPROTO_GGP	3   /* Gateway^2 (deprecated) */
#define IPPROTO_TCP	6   /* TCP */
#define IPPROTO_PUP	12  /* PUP */
#define IPPROTO_UDP	17  /* UDP */
#define IPPROTO_IDP	22  /* XNS idp */
#define IPPROTO_ND	77  /* UNOFFICIAL net disk protocol */
#define IPPROTO_RAW	255 /* Raw IP packet */

/* W5300 Register READ/WRITE funtions */
#define w5300_write(addr, val) iowrite16(val, addr)
#define w5300_read(addr) ioread16(addr)
#define w5300_write_sockcmd(s, cmd) \
  do { \
    w5300_write(Sn_CR(s), cmd); \
    while (w5300_read(Sn_CR(s))) udelay(1); \
  } while(0)

/* Notifying packet size in the RX FIFO */
static inline int w5300_get_rxsize(int s)
{
  u32 val;
  val = w5300_read(Sn_RX_RSR(s));
  val = (val<<16) + w5300_read(Sn_RX_RSR2(s));
  return val;
}

/* Packet Receive Function. It reads received packet from the Rx FIFO. */
static int w5300_recv_data(int s, u8 *buf, ssize_t len, int swap_enable)
{
  int i;
  u16 temp;
 
  if (unlikely(len <= 0)) return 0; 

  if (swap_enable) {
    /* read from RX FIFO */
    for (i=0; i<len; i+=2)
    {
      temp = w5300_read(Sn_RX_FIFO(s));
      buf[i] = (u8)((temp & 0xFF00) >> 8);
      buf[i+1] = (u8)(temp & 0x00FF);
    }
  } else {
    for (i=0; i<len; i+=2)
    {
      temp = w5300_read(Sn_RX_FIFO(s));
      buf[i] = (u8)(temp & 0x00FF);
      buf[i+1] = (u8)((temp & 0xFF00) >> 8);
    }
  }
  return len;
}

static int wiz_wait_for_sendok(int s, struct sock *sk, long timeo)
{
  int ret = 0;

  /* Waiting until data comes into RX FIFO */
  while (!(wiz_desc->int_status[s] & Sn_IR_SENDOK))
  {
    release_sock(sk);
    timeo = schedule_timeout(timeo);
    lock_sock(sk);

    if (signal_pending(current) || !timeo)
      break;

    if (unlikely( sk->sk_type == SOCK_STREAM && (sk->sk_state == TCP_CLOSE || sk->sk_state == TCP_CLOSE_WAIT)))
    {
      ret = -ENOTCONN;
      break;
    }
  }
  spin_lock(&wiz_desc->lock);
  wiz_desc->int_status[s] &= ~Sn_IR_SENDOK;
  spin_unlock(&wiz_desc->lock);

  return ret;
}

static int wait_for_send(int s, struct sock *sk, int flag)
{
  if (s) {
    if (likely(wiz_desc->first_send & (1<<s))) {
      long timeo;
      int ret;
      timeo = sock_sndtimeo(wiz_desc->gSock[s], flag);
      ret = wiz_wait_for_sendok(s, sk, timeo);
      if (ret < 0) return ret;
    } else {
      spin_lock(&wiz_desc->first_send);
      set_bit(s, &wiz_desc->first_send);
      spin_unlock(&wiz_desc->first_send);
    }
  }
  return 0;
}

/* Packet Transmission Function. It writes the packet into Tx FIFO, and transmits packets by sending commands. */
static inline int w5300_send_data(int s, u8 *buf, ssize_t len, int swap_enable, int flag)
{
  int i;
  u16 send_data;

  /* Writing packets in to Tx FIFO */
  if (swap_enable) { 
    for (i=0; i<len; i+=2) {
      send_data = buf[i];
      send_data = (send_data<<8) | buf[i+1];
      w5300_write(Sn_TX_FIFO(s), send_data);
    }
  } else {
    for (i=0; i<len; i+=2) {
      send_data = buf[i+1];
      send_data = (send_data<<8) | buf[i];
      w5300_write(Sn_TX_FIFO(s), send_data);
    }
  }

  if (flag & IPPROTO_TCP) {
    /* Check previos packet is sent or not */
    if (wait_for_send(s, wiz_desc->gSock[s], flag) < 0)
      return -ENOTCONN;
    /* Notifying packet length, and transmitting packets by sending SEND command. */
    w5300_write(Sn_TX_WRSR(s),(u16)(len>>16));
    w5300_write(Sn_TX_WRSR2(s),(u16)len);
    w5300_write_sockcmd(s, Sn_CR_SEND);
  } else { /* Maybe UDP protocol */
    /* Notifying packet length, and transmitting packets by sending SEND command. */
    w5300_write(Sn_TX_WRSR(s),(u16)(len>>16));
    w5300_write(Sn_TX_WRSR2(s),(u16)len);
    w5300_write_sockcmd(s, Sn_CR_SEND);
    
    /* Check previos packet is sent or not */
    if (wait_for_send(s, wiz_desc->gSock[s], flag) < 0)
      return -ENOTCONN;
  }

  return len;
}

/* Notifying packet size in the Tx FIFO. */
static inline int w5300_get_txsize(int s)
{
  u32 val;
  val = w5300_read(Sn_TX_FSR(s));
  val = (val << 16) + w5300_read(Sn_TX_FSR2(s));
  return val;
}

/* Setting MAC address of W5300 */
static inline void w5300_set_macaddr(u8 *addr)
{
  w5300_write(SHAR, (u16)(addr[0]<<8)|(u16)addr[1]);
  w5300_write(SHAR2, (u16)(addr[2]<<8)|(u16)addr[3]);
  w5300_write(SHAR4, (u16)(addr[4]<<8)|(u16)addr[5]);
}

/* Setting IP address of W5300 */
static inline void w5300_set_ipaddr(u32 addr)
{
  w5300_write(SIPR, (u16)(addr>>16));
  w5300_write(SIPR2, (u16)(addr&0xFFFF));
}

/* Setting network mask of W5300 */
static inline void w5300_set_netmask(u32 netmask)
{
  w5300_write(SUBR, (u16)(netmask>>16));
  w5300_write(SUBR2, (u16)(netmask&0xFFFF));
}

static inline u16 w5300_get_port(int s)
{
  return w5300_read(Sn_PORTR(s));
}

/* Setting port of W5300 */
static inline void w5300_set_port(int s, u16 port)
{
  w5300_write(Sn_PORTR(s), port);
}

/* Setting destination address of W5300 */
static inline void w5300_set_dipaddr(int s, u32 addr)
{
  w5300_write(Sn_DIPR(s), (u16)(addr>>16));
  w5300_write(Sn_DIPR2(s), (u16)(addr&0xFFFF));
}

/* Setting destination port of W5300 */
static inline void w5300_set_dport(int s, u16 port)
{
  w5300_write(Sn_DPORTR(s), port);
}

/* Setting gateway address of W5300 */
static inline void w5300_set_gwaddr(u32 addr)
{
  w5300_write(GAR, (u16)(addr>>16));
  w5300_write(GAR2, (u16)(addr&0xFFFF));
}

/* Opening channels of W5300 */
static inline int w5300_open(int s, int type)
{
  static unsigned short local_port = 3010;

  spin_lock(&wiz_desc->lock);
  wiz_desc->int_status[s] = 0;
  clear_bit(s, &wiz_desc->first_send); 
  spin_unlock(&wiz_desc->lock);
  
  /* Which type will be used for open?*/
  switch (type) {
  case Sn_MR_UDP:
    w5300_write(Sn_MR(s), Sn_MR_UDP);
    break;
  case Sn_MR_TCP:
    //w5300_write(Sn_MR(s), Sn_MR_ALIGN | Sn_MR_TCP | Sn_MR_ND); // ALIGN Mode
    w5300_write(Sn_MR(s), Sn_MR_TCP | Sn_MR_ND); // Non-ALIGN Mode
    break;
  case Sn_MR_MACRAW:
  case Sn_MR_MACRAW_MF:
    if (s != 0) {
      printk("Not Supported\n");
      return -EFAULT;
    }

    w5300_write(Sn_MR(s), type);
    break;
  default:
    printk("W5300: Unknown socket type (%d)\n", type);
    return -EFAULT;
  }
  w5300_write(Sn_PORTR(s), local_port);
  spin_lock(&wiz_desc->lock);
  ++local_port;
  if (local_port > 3020) local_port = 3010;
  spin_unlock(&wiz_desc->lock);

  w5300_write_sockcmd(s, Sn_CR_OPEN);

  DPRINTK("sock:%d SOCK_STATUS = 0x%x , Protocol = 0x%x\n", 
      s, (u8)w5300_read(Sn_SSR(s)), w5300_read(Sn_PROTOR(s)));	

  return 0;
}

/* Closing channel of W5300 */
static inline void w5300_close(int s)
{
  w5300_write(Sn_IR(s), 0x00FF);
  w5300_write_sockcmd(s, Sn_CR_DISCON);
  w5300_write_sockcmd(s, Sn_CR_CLOSE);

  /* Check close state */
  while ((w5300_read(Sn_SSR(s))&0xFF) != SOCK_CLOSED) udelay(1);
}

/* Activating the interrupt of related channel */
static inline void w5300_interrupt_enable(int s)
{
  u16 mask;
  mask = w5300_read(IMR);
  mask |= (0x01 << s);
  w5300_write(IMR, mask);
}

/* De-activating the interrupt of related channel */
static inline void w5300_interrupt_disable(int s)
{
  u16 mask;
  mask = w5300_read(IMR);
  mask &= ~(0x01 << s);
  w5300_write(IMR, mask);
}

/* Initializing the information of ‘PF_WIZNET’socket */
static inline int w5300_sock_alloc(struct sock *sk)
{
  int s;
  for (s=1; s<MAX_SOCK_NUM; ++s)
  {
    if (!wiz_desc->gSock[s])
      break;
  }
  if ((sk == NULL) || (s >= MAX_SOCK_NUM))
    return -1;

  wiz_desc->gSock[s] = sk;
  w5300_interrupt_enable(s);
    
  return s;
}

/* Closing the PF_WIZNET socket */
static inline void w5300_sock_release(int s)
{
  w5300_interrupt_disable(s);
  w5300_close(s);
  wiz_desc->gSock[s] = NULL;
}

static inline void w5300_connect(int s, u32 daddr, u16 dport)
{
  w5300_set_dport(s, dport);
  w5300_set_dipaddr(s, daddr);

  w5300_write_sockcmd(s, Sn_CR_CONNECT);
}

static inline void w5300_listen(int s)
{
  w5300_write_sockcmd(s, Sn_CR_LISTEN);
}

static inline void w5300_discon(int s)
{
  w5300_write_sockcmd(s, Sn_CR_DISCON);
}
#endif // _W5300_H_
