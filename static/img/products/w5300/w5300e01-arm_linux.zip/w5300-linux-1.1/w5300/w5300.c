/* wizsock.c: A Linux Ethernet & H/W TCP/IP driver for the W5300 chip. */
/*
  Copyright (C) 2008-2009 WIZnet Co.,Ltd.

  This software may be used and distributed according to the terms of
  the GNU General Public License (GPL), incorporated herein by reference.
  Drivers based on or derived from this code fall under the GPL and must
  retain the authorship, copyright and license notice.  This file is not
  a complete program and may only be used when the entire operating
  system is licensed under the GPL.

  TO DO LIST:
  * Support Multi-Platform
  * Support various version of Linux Kernel
  * Support Multi-cast
*/

#include <linux/init.h>
#include <linux/module.h>
#include <linux/moduleparam.h>
#include <linux/kernel.h>
#include <linux/etherdevice.h>
#include <net/tcp_states.h>
#include <asm/arch/irqs.h>

#include "w5300.h"
#include "wizsock.h" 

#define DEV_NAME    "w5300"
#define DRV_VERSION "1.1"
#define DRV_RELDATE "Mar 2, 2009"

static const char driver_info[] =
KERN_INFO DEV_NAME ": H/W TCP/IP & Ethernet driver v" DRV_VERSION "(" DRV_RELDATE ")\n";

MODULE_AUTHOR("Brian Kim <thkim@wiznet.co.kr>");
MODULE_DESCRIPTION("WIZnet W5300 H/W TCP/IP & Ethernet driver");
MODULE_VERSION(DRV_VERSION);
MODULE_LICENSE("GPL");

/* FIXME: Setting irq number / Configurable as module parameter */
static int w5300_irq = IRQ_EINT0;
module_param(w5300_irq, int, 0);
MODULE_PARM_DESC(w5300_irq, "W5300: interrupt irq number");

/* FIXME: Setting basic MAC address / It should be set according to the system. */
const u8 w5300_defmac[MAX_SOCK_NUM] = {0x00, 0x08, 0xDC, 0xA0, 0x00, 0x01};
/* FIXME: Configuring the size of basic RX/TX FIFO / It should be configured according to the system */
const u8 w5300_rxbuf_conf[MAX_SOCK_NUM] = {32, 8, 8, 8, 8, 0, 0, 0};
const u8 w5300_txbuf_conf[MAX_SOCK_NUM] = {32, 8, 8, 8, 8, 0, 0, 0};

/* Global variables to manage the information of W5300 */
struct wiz_private *wiz_desc;

/* W5300 initialization function */
static int wiz_reset(struct wiz_private *wp)
{
  struct net_device *dev = wp->dev;
  u32 txbuf_total=0, i;
  u16 mem_cfg=0;

  DPRINTK("%s: w5300 chip reset\n", __FUNCTION__);

  /* W5300 is initialized by sending RESET command. */
  w5300_write(MR, MR_RST);
  mdelay(5);

  /* Mode Register Setting
   * Ping uses S/W stack of the Linux kernel. Set the Ping Block.*/
  w5300_write(MR, MR_WDF(1)|MR_PB);

  /* Setting MAC address */
  w5300_set_macaddr(dev->dev_addr);

  /* Setting the size of Rx/Tx FIFO */
  for (i=0; i<MAX_SOCK_NUM; ++i)
  {
    if (wp->rxbuf_conf[i] > 64) {
      printk(KERN_ERR "Illegal Channel(%d) RX memory size.\n", i);
      return -EINVAL;
    }
    if (wp->txbuf_conf[i] > 64) {
      printk(KERN_ERR "Illegal Channel(%d) TX memory size.\n", i);
      return -EINVAL;
    }
    txbuf_total += wp->txbuf_conf[i];  
  }

  if (txbuf_total%8) {
      printk(KERN_ERR "Illegal memory size register setting.\n");
      return -EINVAL;
  }
  w5300_write(RMSR0, (u16)(wp->rxbuf_conf[0]<<8)|(u16)wp->rxbuf_conf[1]);
  w5300_write(RMSR2, (u16)(wp->rxbuf_conf[2]<<8)|(u16)wp->rxbuf_conf[3]);
  w5300_write(RMSR4, (u16)(wp->rxbuf_conf[4]<<8)|(u16)wp->rxbuf_conf[5]);
  w5300_write(RMSR6, (u16)(wp->rxbuf_conf[6]<<8)|(u16)wp->rxbuf_conf[7]);
  w5300_write(TMSR0, (u16)(wp->txbuf_conf[0]<<8)|(u16)wp->txbuf_conf[1]);
  w5300_write(TMSR2, (u16)(wp->txbuf_conf[2]<<8)|(u16)wp->txbuf_conf[3]);
  w5300_write(TMSR4, (u16)(wp->txbuf_conf[4]<<8)|(u16)wp->txbuf_conf[5]);
  w5300_write(TMSR6, (u16)(wp->txbuf_conf[6]<<8)|(u16)wp->txbuf_conf[7]);

  /* Setting FIFO Memory Type (TX&RX) */
  for (i=0; i<txbuf_total/8; ++i)
  {
    mem_cfg <<= 1;
    mem_cfg |= 1;
  }
  w5300_write(MTYPER, mem_cfg);

  /* Masking all interrupts */
  w5300_write(IMR, 0x0000);

  return 0;
}

/* Processing interrupts when using hardware TCP/IP  */
static void wiz_hwirq_event(struct wiz_private *wp, int s)
{
  struct sock *sk = wp->gSock[s];

  if (sk) {
    /* Processing interrupts by reading Sn_SSR register according to socket status */
    switch (w5300_read(Sn_SSR(s)) & 0xFF) {
    case SOCK_ESTABLISHED:
      sk->sk_state = TCP_ESTABLISHED;
      wake_up_interruptible(sk->sk_sleep);
      break;
    case SOCK_CLOSED:
      sk->sk_state = TCP_CLOSE;
      w5300_discon(s);
      wake_up_interruptible(sk->sk_sleep);
      break;
    case SOCK_CLOSE_WAIT:
      sk->sk_state = TCP_CLOSE_WAIT;
      w5300_discon(s);
      wake_up_interruptible(sk->sk_sleep);
      break;
    }
  }
}

/* Interrupt Handler(ISR) */
static irqreturn_t wiz_interrupt(int irq, void *dev_instance)
{
  struct net_device *dev = dev_instance;
  struct wiz_private *wp = netdev_priv(dev);
  unsigned long isr, ssr;
  int s;

  isr = w5300_read(IR);
  
  /* Completing all interrupts at a time. */
  while (isr) { 
    /* global interrupt is cleared. If so, the logic of /INT is changed from low to high. */ 
    w5300_write(IR, isr);

    /* Finding the channel to create the interrupt */
    s = find_first_bit(&isr, sizeof(u16));

    ssr = w5300_read(Sn_IR(s));
    /* socket interrupt is cleared. */
    w5300_write(Sn_IR(s), ssr);
    spin_lock(&wp->lock);
    wp->int_status[s] |= ssr;
    spin_unlock(&wp->lock);
  
    DPRINTK("%s: ISR = %X, SSR = %X, s = %X\n", __FUNCTION__, isr, ssr, s);

    /* Process Method according to interrupt type
     * All other interrupts except for RECV, are processed at the ‘wiz_hwirq_event()'. */
    if (ssr & Sn_IR_CON) {
      DPRINTK("%s: socket(%d) ISR_CON\n", __FUNCTION__, s);
      wiz_hwirq_event(wp, s);
    }
    if (ssr & Sn_IR_TIMEOUT) {
      DPRINTK("%s: socket(%d) ISR_TIMEOUT\n", __FUNCTION__, s);
      wiz_hwirq_event(wp, s);
    }
    if (ssr & Sn_IR_DISCON) {
      DPRINTK("%s: socket(%d) ISR_DISCON\n", __FUNCTION__, s);
      wiz_hwirq_event(wp, s);
    }
    if (ssr & Sn_IR_RECV)
    {
      if (s) {
	/* Waking the process that is waiting for RECV. */
        if (wp->gSock[s]) wake_up_interruptible(wp->gSock[s]->sk_sleep);
      } else { /* Receiving Process at the MAC_RAW mode */
        /* De-activation of interrupt */
        w5300_interrupt_disable(0);
        /* Receiving by polling method */
        netif_rx_schedule(dev, &wp->napi);
      }
    }

    /* Is there any interrupt to be processed? */
    isr = w5300_read(IR);
  }
   
  return IRQ_HANDLED;
}

/* As like 'ifconfig wiz0 up', it's called by activating W5300 network device. */
static int wiz_open(struct net_device *dev)
{
  struct wiz_private *wp = netdev_priv(dev);
  int ret;

  /* Activating napi
   * napi is the function to convert the RECV interrupt to polling method.*/
  napi_enable(&wp->napi);

  /* Registering interrupt handler */
  ret = request_irq(dev->irq, wiz_interrupt, IRQF_IRQPOLL, dev->name, dev);
  if (ret < 0) {
    printk(KERN_ERR "request_irq() error!\n");
    return ret;
  }

  /* Activating the interrupt of channel 0 that is used for MACRAW. */
  w5300_interrupt_enable(0);

  /* Sending OPEN command to use channel 0 as MACRAW mode. */
  w5300_open(0, Sn_MR_MACRAW_MF);

  DPRINTK("%s: sock status = 0x%X, protocol = 0x%X, IMR = 0x%X, irq = %X\n",
          __FUNCTION__, (u8)w5300_read(Sn_SSR(0)), w5300_read(Sn_PROTOR(0)), w5300_read(IMR), dev->irq );

  /* Starting network device interface */
  netif_start_queue(dev);
  return 0;
}

/* As like 'ifconfig wiz0 down', it's called by de-activating W5300 network device. */
static int wiz_close(struct net_device *dev)
{
  struct wiz_private *wp = netdev_priv(dev);

  DPRINTK("%s\n", __FUNCTION__);

  /* De-activating napi */
  napi_disable(&wp->napi);
  /* Interrupt masking of all channels */
  w5300_write(IMR, 0x0000);  
  /* Network device interface stop */ 
  netif_stop_queue(dev);
  /* Closing the MAC_RAW of channel 0 */
  w5300_write(Sn_CR(0), Sn_CR_CLOSE);
  /* Closing registered IRQ */
  free_irq(dev->irq, dev);

  return 0;
}

/* Function to transmit data at the MACRAW mode */
static int wiz_start_xmit(struct sk_buff *skb, struct net_device *dev)
{ 
  struct wiz_private *wp = netdev_priv(dev);
  int ret;

  DPRINTK("%s: MAC_RAW SEND\n", __FUNCTION__);

  /* Writing the data of socket buffer coming from upper stack to the W5300 */
  ret = w5300_send_data(0, skb->data, skb->len, 1, 0);

  /* Statistical Process */
  if (ret <0) {
    wp->stats.tx_dropped++;
  } else {
    wp->stats.tx_bytes += skb->len;
    wp->stats.tx_packets++;
    dev->trans_start = jiffies;
  }
  /* Closing the socket buffer with the completion of data transmission. */
  dev_kfree_skb(skb);

  return 0;
}

/* Returning statistical information of W5300 */
static struct net_device_stats *wiz_get_stats(struct net_device *dev)
{
  struct wiz_private *wp = netdev_priv(dev);
  DPRINTK("%s: get status\n", __FUNCTION__);
  return &wp->stats;
}

/* It is called when multi-cast list or flag is changed. */
static void wiz_set_multicast(struct net_device *dev)
{
  DPRINTK("%s: multicast\n", __FUNCTION__);
  if (dev->flags & IFF_PROMISC)
    w5300_open(0, Sn_MR_MACRAW);    /* Recv all packet */
  else
    w5300_open(0, Sn_MR_MACRAW_MF); /* Recv our packet(broadcast, multicast) */
}

/* The Function to change MAC address of W5300. It can be used at the utility as like 'ifconfig' */
static int wiz_set_macaddress(struct net_device *dev, void *addr)
{
  struct wiz_private *wp = netdev_priv(dev);
  struct sockaddr *sock_addr = addr;

  DPRINTK("%s: set mac address\n", __FUNCTION__);

  spin_lock(&wp->lock); 
  /* Changing MAC address of W5300 */ 
  w5300_set_macaddr(sock_addr->sa_data);
  /* Changing MAC address of material structure to manage W5300 */ 
  memcpy(dev->dev_addr, sock_addr->sa_data, dev->addr_len);
  spin_unlock(&wp->lock); 

  return 0;
}

/* It is called when timeout occurs at the packet transmission. */
static void wiz_tx_timeout(struct net_device *dev)
{
  struct wiz_private *wp = netdev_priv(dev);
  unsigned long flags;

  printk(KERN_WARNING "%s: Transmit timeout\n", dev->name);

  spin_lock_irqsave(&wp->lock, flags);
  /* Initializing W5300 */
  wiz_reset(wp);
  /* Waking up network interface */
  netif_wake_queue(dev);
  spin_unlock_irqrestore(&wp->lock, flags);

  return;
}

/*
 * Polling Function to process only receiving at the MACRAW mode.
 * De-activating the interrupt when recv interrupt occurs,
 * and processing the RECEIVE with this Function
 * Activating the interrupt after completing RECEIVE process
 * As recv interrupt often occurs at short intervals, 
 * there will system load in case that interrupt handler process the RECEIVE.
 */
static int wiz_rx_poll(struct napi_struct *napi, int budget)
{
  struct sk_buff *skb;
  struct wiz_private *wp = container_of(napi, struct wiz_private, napi);
  struct net_device *dev = wp->dev;
  u16 rxbuf_len, pktlen;
  u32 crc;
  int npackets = 0;
  
  /* Processing the RECEIVE during Rx FIFO is containing any packet */
  while (w5300_get_rxsize(0) > 0) {

    /* The first 2byte is the information about packet lenth. */
    w5300_recv_data(0, (u8*)&pktlen, 2, 0);
    DPRINTK("%s: pktlen = %d\n", __FUNCTION__, pktlen);

    /* Allotting the socket buffer in which packet will be contained
     * Ethernet packet is of 14byte. In order to make it multiplied by 2 (16),
     * the buffer allocation should be 2bytes bigger than the packet. */
    skb = dev_alloc_skb(pktlen+2);
    if (!skb) {
      u8 *temp;
      printk("%s: Memory squeeze, dropping packet.\n", dev->name);
      temp = (u8*)kmalloc(pktlen+4, GFP_KERNEL);
      wp->stats.rx_dropped++;
      w5300_recv_data(0, temp, pktlen+4, 1);
      kfree(temp);
      return -ENOMEM;
    }

    /* Initializing the socket buffer */
    skb->dev = dev;
    skb_reserve(skb, 2);
    skb_put(skb, pktlen);

    /* Reading packets from W5300 Rx FIFO into socket buffer. */
    w5300_recv_data(0, (u8*)skb->data, pktlen, 1);

    /* Reading and discarding 4byte CRC. */ 
    w5300_recv_data(0, (u8*)&crc, 4, 0);

    /* The packet type is Ethernet. */
    skb->protocol = eth_type_trans(skb, dev);

    /* Passing packets to uppder stack (kernel). */
    netif_receive_skb(skb);

    /* Processing statistical information */
    wp->stats.rx_packets++;
    wp->stats.rx_bytes += pktlen;
    wp->dev->last_rx = jiffies;
    rxbuf_len -= pktlen;
    npackets++;

    /* Completing RECEIVE process after looping back as many as configured budget. */
    if (npackets >= budget) break;
  }

  /* If packet number is smaller than budget when getting out of loopback,
   * the RECEIVE process is completed. */
  if (npackets < budget) {
    unsigned long flags;
    /* Re-activating the interrupt after finishing polling. */
    spin_lock_irqsave(&wp->lock, flags);
    w5300_interrupt_enable(0);
    /* RECEIVE is completed. */
    __netif_rx_complete(dev, napi);
    spin_unlock_irqrestore(&wp->lock, flags);
  }
  return npackets;
}

/* Initialization Function of W5300 driver */
static int wiz_init(void)
{
  struct net_device *dev;
  struct wiz_private *wp;
  int s;

  DPRINTK("%s\n", __FUNCTION__);
  /* Allocatting struct net_device structure which is managing W5300 */
  dev = alloc_etherdev(sizeof(struct wiz_private)); 
  if (!dev) return -ENOMEM;

  /* Initializing net_device structure */
  wp = netdev_priv(dev);
  wp->dev = dev;
  wp->regs = (void __iomem *)W5300_REG_BASE; /* The basic address of W5300 register */
  spin_lock_init(&wp->lock);

  /* Initialization of Rx/Tx FIFO size */
  memcpy(wp->rxbuf_conf, w5300_rxbuf_conf, MAX_SOCK_NUM*sizeof(u8));
  memcpy(wp->txbuf_conf, w5300_txbuf_conf, MAX_SOCK_NUM*sizeof(u8));
  memset(wp->int_status, 0, MAX_SOCK_NUM*sizeof(u16)); /* Initialization of interrupt status */

  /* W5300 manages socket information for the Hardware TCP/IP function.
   * It contains the address information of struct sock allocated to each channel,
   * uses them when accessing related socket. */
  for (s=0; s<MAX_SOCK_NUM; ++s)
    wp->gSock[s] = NULL;

  dev->base_addr = (unsigned long)wp->regs;
  dev->addr_len = 6; /* MAC address length. */
  memcpy(dev->dev_addr, w5300_defmac, dev->addr_len);
  /* Registering network interface related Functions.
   * These Functions are called when controlling W5300 with the utility such as ifconfig. */
  dev->open = wiz_open;
  dev->stop = wiz_close;
  dev->hard_start_xmit = wiz_start_xmit;
  dev->get_stats = wiz_get_stats;
  dev->set_multicast_list = wiz_set_multicast;
  dev->set_mac_address = wiz_set_macaddress;
  dev->tx_timeout = wiz_tx_timeout;

  /* Setting napi. Enabling to process max 16 packets at a time. */
  netif_napi_add(dev, &wp->napi, wiz_rx_poll, 16);

  dev->watchdog_timeo = 2*HZ;

  /* FIXME: Setting interrupt IRQ(Interrupt ReQuest) number of W5300. */
  dev->irq = w5300_irq; 

  wiz_desc = wp;

  /* Re-defining the network interface of W5300. 
   * The prefix of existing Ethernet network interface is eth.
   * As W5300 includes Ethernet, but supports special network function,
   * it uses wiz as interface name. */
  strcpy(dev->name, "wiz%d");

  /* Registering net_device structure */
  if (register_netdev(dev)) {
    printk(KERN_ERR "%s: register_netdev() failed\n", DEV_NAME);
    kfree(dev);
    return -EINVAL;
  }

  /* Initialization of W5300 chip */
  return wiz_reset(wp);
}

extern int wiz_sock_init(void);

/* The Function to be called when loading W5300 driver
 * Printing out driver information, and processing the initialization */
static int __init wiz_module_init(void)
{
  printk(driver_info);

  /* Initializing PF_WIZNET sockets. */
  wiz_sock_init(); 

  /* Initializing W5300 driver & chip */
  return wiz_init();
}

extern int wiz_sock_exit(void);

/* The Function to be called for unloading W5300 driver. */
static void __exit wiz_module_exit(void)
{
  struct net_device *dev = wiz_desc->dev;
  /* Closing the W5300 related net_device. */
  unregister_netdev(dev); 
  /* Closing PF_WIZNET related socket */
  wiz_sock_exit(); 
}

module_init(wiz_module_init);
module_exit(wiz_module_exit);
