========================================
	WIZnet W5300 Driver for Linux v2.6.x
========================================

This driver is made by WIZnet. 
The testing is completed at the Linux kernel V2.6.24.4 which is ported to S3C2410(ARM9).
In order to use this driver, the linux kernel source should be ported on your system.
Some architecture dependant routine can be modified.
The compile process is as below.

STEP 1: 
  - Acquire Linux kernel source of your system.
  * The official site of Linux kernel is http://kernel.org

STEP 2:
  - Port the Linux kernel source to your system.

STEP 3:
  - Compile the Linux kernel source 

STEP 4:
  - Open Makefile of the driver by using editor program.
  - Modify KERNELPATH into the routine where Linux kernel source is installed.

STEP 5:
  - run 'make'
  - If 'wiznet.ko'is created, driver compile is completed.
  - Modify archtecture dependant part, re-compile and use it.
