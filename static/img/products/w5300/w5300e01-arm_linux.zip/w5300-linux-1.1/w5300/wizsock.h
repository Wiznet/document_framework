#ifndef _WIZSOCK_H_
#define _WIZSOCK_H_
#include <net/sock.h> 
#include <asm/semaphore.h>
#include <linux/inetdevice.h>

#include "w5300.h"

/* UDP Header Information */
struct wiz_udphdr {
  u32 addr;
  u16 port;
  u16 size;
};

/* wiz_sock to be used for H/W TCP/IP */
struct wiz_sock {
  struct sock sk;
  int s; /* Channel information related to a socket */
  int remain_pkt;
};

/* Function to covert struct sock into wiz_sock */
static inline struct wiz_sock *wiz_sk(const struct sock *sk)
{
  return (struct wiz_sock*)sk;
}

#endif /* _WIZSOCK_H_ */
