/* wizsock.c: A Linux Ethernet & H/W TCP/IP driver for the W5300 chip. */
/*
  Copyright (C) 2008-2009 WIZnet Co.,Ltd.

  This software may be used and distributed according to the terms of
  the GNU General Public License (GPL), incorporated herein by reference.
  Drivers based on or derived from this code fall under the GPL and must
  retain the authorship, copyright and license notice.  This file is not
  a complete program and may only be used when the entire operating
  system is licensed under the GPL.
*/

#include <linux/net.h>
#include <linux/errno.h>
#include <linux/kernel.h>
#include <linux/in.h>
#include <net/tcp_states.h>
#include <net/route.h>

#include "wizsock.h"

#include <net/inet_common.h>
#include <linux/sockios.h>
#include <asm/uaccess.h>


/* If PF_WIZNET is not defined, PF_BLUETOOTH is re-defined as PF_WIZNET. 
 * In this case, PF_BLUETOOTH is not in use. */
#ifndef PF_WIZNET
#define PF_WIZNET PF_BLUETOOTH
#endif

/* TCP Mode RECEIVE Function. */
static int w5300_tcp_recv(struct wiz_sock *wiz, u8 *buf, ssize_t len)
{
  /* Is TCP align mode? */
  if (w5300_read(Sn_MR(wiz->s)) & Sn_MR_ALIGN) {
    w5300_recv_data(wiz->s, buf, len, 0);
    return len;
  } else { 
    u16 pkt_len;
    u16 temp;

    /* For small application bufer */
    if (likely(!wiz->remain_pkt)) {
      /* Reading packet size. */
      w5300_recv_data(wiz->s, (u8*)&pkt_len, 2, 0);
      if (unlikely(pkt_len > len)) {
	wiz->remain_pkt = pkt_len-len;
	pkt_len = len;
      }
    } else {
      if (wiz->remain_pkt > len) {
	pkt_len = len;
	wiz->remain_pkt -= len;
      } else {
	pkt_len = wiz->remain_pkt;
	wiz->remain_pkt = 0;
      }
    }

    /* Is packet size odd numbered? */
    if (pkt_len & 0x01) {
      --pkt_len;
      w5300_recv_data(wiz->s, buf, pkt_len, 1);
      buf += pkt_len;
      w5300_recv_data(wiz->s, (u8*)&temp, 2, 0);
      *buf = (u8)(temp);
      ++pkt_len;
    } else { /* In case that packet size is even numbered. */
      w5300_recv_data(wiz->s, buf, pkt_len, 1);
    }
    return pkt_len;
  }
}

/* According to ALIGN mode, receiving length can be set. */
static int w5300_tcp_recvlen(int s, ssize_t len)
{
  int recv_len = len;
  if (w5300_read(Sn_MR(s)) & Sn_MR_ALIGN) {
    recv_len = w5300_get_rxsize(s);
    if (recv_len > len) recv_len = len;
  }
  return recv_len;
}

/* The Function waiting until packet is received */
static int wiz_wait_for_recv(int s, struct sock *sk, long timeo)
{
  DECLARE_WAITQUEUE(wait, current);
  int recv_len;

  /* Sleeping current process. */
  __set_current_state(TASK_INTERRUPTIBLE);
  add_wait_queue(sk->sk_sleep, &wait);

  /* Waiting until data comes into RX FIFO */
  while (!(recv_len = w5300_get_rxsize(s))) {
    release_sock(sk);
    timeo = schedule_timeout(timeo);
    lock_sock(sk);

    if (signal_pending(current) || !timeo) {
      recv_len = sock_intr_errno(timeo);
      break;
    }

    set_current_state(TASK_INTERRUPTIBLE);

    if (unlikely( sk->sk_type == SOCK_STREAM &&
		  (sk->sk_state == TCP_CLOSE ||
		   sk->sk_state == TCP_CLOSE_WAIT))) {
      recv_len = -ENOTCONN;
      break;
    }
  }
  /* Waking up process */
  __set_current_state(TASK_RUNNING);
  remove_wait_queue(sk->sk_sleep, &wait);

  return recv_len;
}

/* Processing connect at the UDP mode  */
static int wiz_udp_connect(struct socket *sock, struct sockaddr * uaddr, int addr_len, int flags)		       
{
  struct sockaddr_in *usin = (struct sockaddr_in *) uaddr;
  struct sock *sk=sock->sk;
  struct wiz_sock *wiz = wiz_sk(sk);

  if (addr_len < sizeof(*usin)) 
    return -EINVAL;

  if (uaddr->sa_family == AF_UNSPEC)
    return -EAFNOSUPPORT;
  /* Setting Destination address and port */
  w5300_set_dipaddr(wiz->s, htonl(usin->sin_addr.s_addr));
  w5300_set_dport(wiz->s, htons(usin->sin_port));

  sk->sk_state = TCP_ESTABLISHED;

  return 0;
}

/* UDP Mode RECV Function */
static int wiz_udp_recvmsg(struct kiocb *iocb, struct socket *sock, struct msghdr *msg, size_t size, int flags)
{
  struct sock *sk = sock->sk;
  struct wiz_sock *wiz = wiz_sk(sk);
  struct sockaddr_in *sin = (struct sockaddr_in *)msg->msg_name;
  struct wiz_udphdr udphdr;
  u32 addr;
  int len;
  int ret;
  long timeo;

  lock_sock(sk);

  timeo = sock_sndtimeo(sk, flags & O_NONBLOCK);

  ret = wiz_wait_for_recv(wiz->s, sk, timeo);
  if (unlikely(ret < 0)) goto out;

  /* Reading UDP header information */
  w5300_recv_data(wiz->s, (u8*)&udphdr.addr, 4, 0);
  w5300_recv_data(wiz->s, (u8*)&udphdr.port, 2, 0);
  w5300_recv_data(wiz->s, (u8*)&udphdr.size, 2, 0);
  addr = ((udphdr.addr & 0xFFFF) << 16) | (udphdr.addr >> 16);

  /* Setting struct sockaddr */
  if (sin) {
    sin->sin_family = AF_INET;
    sin->sin_port = udphdr.port;
    sin->sin_addr.s_addr = addr;
    memset(sin->sin_zero, 0, sizeof(sin->sin_zero));
  }
  msg->msg_namelen = sizeof(*sin);
  len = udphdr.size;

  /* Checking validity of address */
  if (unlikely(!access_ok(VERIFY_WRITE, (unsigned char *)msg->msg_iov->iov_base, len))) {
      ret = -EFAULT;
      goto out;
  }

  /* Reading packet from Rx FIFO */
  ret = w5300_recv_data(wiz->s, (unsigned char *)msg->msg_iov->iov_base, len, 1);

out:
  release_sock(sk);
  return ret;
}

/* The Function waiting for CONNECT request */
static long wiz_wait_for_connect(struct sock *sk, long timeo)
{
  DECLARE_WAITQUEUE(wait, current);

  /* Sleeping current process */
  __set_current_state(TASK_INTERRUPTIBLE);
  add_wait_queue(sk->sk_sleep, &wait);

  /* Waiting for completion of CONNECT */
  while (!(sk->sk_state & TCP_ESTABLISHED)) {
    release_sock(sk);
    timeo = schedule_timeout(timeo);
    lock_sock(sk);
    if (signal_pending(current) || !timeo)
      break;
    set_current_state(TASK_INTERRUPTIBLE);
  }

  /* Sleeping the process. */
  __set_current_state(TASK_RUNNING);
  remove_wait_queue(sk->sk_sleep, &wait);
  return timeo;
}

/* connect() Function of PF_WIZNET. */
static int wiz_tcp_connect(struct socket *sock, struct sockaddr * uaddr, 
			   int addr_len, int flags)		       
{
  struct sock *sk = sock->sk;
  struct sockaddr_in *usin = (struct sockaddr_in *)uaddr;
  struct wiz_sock *wiz = wiz_sk(sk);
  int err=0;
  long timeo;

  lock_sock(sk);

  if (uaddr->sa_family == AF_UNSPEC) {
    sock->state = err ? SS_DISCONNECTING : SS_UNCONNECTED;
    goto out;
  }

  switch (sock->state) {
  default:
    err = -EINVAL;
    goto out;
  case SS_CONNECTED:
    err = -EISCONN;
    goto out;
  case SS_CONNECTING:
    err = -EALREADY;
    /* Fall out of switch with err, set for this state */
    break;
  case SS_UNCONNECTED:
    err = -EISCONN;
    if (sk->sk_state != TCP_CLOSE)
      goto out;

    /* W5300 chip connect */
    w5300_connect(wiz->s, htonl(usin->sin_addr.s_addr), htons(usin->sin_port));

    sock->state = SS_CONNECTING;

    /* 
     * Just entered SS_CONNECTING state; the only
     * difference is that return value in non-blocking
     * case is EINPROGRESS, rather than EALREADY.
     */
    err = -EINPROGRESS;
    break;
  }

  /* Waiting for completing CONNECT */
  timeo = sock_sndtimeo(sk, flags & O_NONBLOCK);
  if ((1 << sk->sk_state) & (TCPF_SYN_SENT | TCPF_SYN_RECV)) {
    /* Error code is set above */
    if (!timeo || !wiz_wait_for_connect(sk, timeo))
      goto out;

    if (signal_pending(current)) {
      err = sock_intr_errno(timeo);
      goto out;
    }
  }

  sk->sk_state = TCP_ESTABLISHED;
  sock->state = SS_CONNECTED;
  err = 0;

out:
  release_sock(sk);
  return err;
}

/* listen() Function of PF_WIZNET */
static int wiz_tcp_listen(struct socket *sock, int backlog)
{
  struct sock *sk = sock->sk;
  struct wiz_sock *wiz = wiz_sk(sk);
  unsigned char old_state;
  int err;

  lock_sock(sk);

  err = -EINVAL;
  if (sock->state != SS_UNCONNECTED || sock->type != SOCK_STREAM)
    goto out;

  old_state = sk->sk_state;
  if (!((1 << old_state) & (TCPF_CLOSE | TCPF_LISTEN)))
    goto out;

  /* Really, if the socket is already in listen state
   * we can only allow the backlog to be adjusted.
   */
  if (old_state != TCP_LISTEN) {
    w5300_listen(wiz->s); /* LISTEN related activities of W5300 chip */
  }
  sk->sk_state = TCP_LISTEN;
  sk->sk_max_ack_backlog = backlog;
  err = 0;

out:
  release_sock(sk);
  return err;
}

/* accept() Function of PF_WIZNET */
static int wiz_tcp_accept(struct socket *sock, struct socket *newsock, int flags)
{
  struct sock *sk = sock->sk;
  int err = 0;
  long timeo;

  DPRINTK("%s\n", __FUNCTION__);
  lock_sock(sk);

  if (sk->sk_state != TCP_LISTEN)
    goto out;

  /* Waiting for completion of CONNECT */
  timeo = sock_sndtimeo(sk, flags&O_NONBLOCK);
  if (!timeo || !wiz_wait_for_connect(sk, timeo))
    goto out;

  if (signal_pending(current)) {
    err = sock_intr_errno(timeo);
    goto out;
  }

  sock_graft(sk, newsock);
  newsock->state = SS_CONNECTED;
  err = 0;
out:
  release_sock(sk);
  return err;
}

/* bidn() Function of PF_WIZNET */
static int wiz_tcp_bind(struct socket *sock, struct sockaddr *uaddr, int addr_len)
{
  struct sockaddr_in *addr = (struct sockaddr_in *)uaddr;
  struct sock *sk = sock->sk;
  struct wiz_sock *wiz = wiz_sk(sk);
  unsigned short snum;
  int chk_addr_ret;
  int err;

  err = -EINVAL;
  if (addr_len < sizeof(struct sockaddr_in))
    goto out;

  chk_addr_ret = inet_addr_type(addr->sin_addr.s_addr);

  err = -EADDRNOTAVAIL;
  if (addr->sin_addr.s_addr != INADDR_ANY &&
      chk_addr_ret != RTN_LOCAL &&
      chk_addr_ret != RTN_MULTICAST &&
      chk_addr_ret != RTN_BROADCAST)
    goto out;

  snum = ntohs(addr->sin_port);
  err = -EACCES;
  if (snum && snum < PROT_SOCK && !capable(CAP_NET_BIND_SERVICE))
    goto out;

  /*      We keep a pair of addresses. rcv_saddr is the one
   *      used by hash lookups, and saddr is used for transmit.
   *
   *      In the BSD API these are the same except where it
   *      would be illegal to use them (multicast/broadcast) in
   *      which case the sending device address is used.
   */
  lock_sock(sk);

  /* Check these errors (active socket, double bind). */
  err = -EINVAL;
  if (sk->sk_state != TCP_CLOSE )
    goto out_release_sock;

  if (addr->sin_addr.s_addr)
    sk->sk_userlocks |= SOCK_BINDADDR_LOCK;
  if (snum)
    sk->sk_userlocks |= SOCK_BINDPORT_LOCK;

  if (snum)
    w5300_set_port(wiz->s, snum); /* Setting port of W5300 chip */
  sk_dst_reset(sk);
  err = 0;
out_release_sock:
  release_sock(sk);
out:
  return err;
}

/* recv() Function of PF_WIZNET */
static int wiz_tcp_recvmsg(struct kiocb *iocb, struct socket *sock, struct msghdr *msg, size_t len, int flags)
{
  struct sock *sk = sock->sk;
  struct wiz_sock *wiz = wiz_sk(sk);
  int rx_len=0;
  long timeo;
  int ret;

  DPRINTK("%s: recv request len = %d\n", __FUNCTION__, len);

  lock_sock(sk);

  if (flags & (MSG_OOB)) {
    ret = -EOPNOTSUPP;
    goto out;
  }

  timeo = sock_sndtimeo(sk, flags & O_NONBLOCK);

  /* Waiting until packets coming into Rx FIFO */
  ret = wiz_wait_for_recv(wiz->s, sk, timeo);
  if (unlikely(ret < 0)) goto out;

  /* Setting receiving size  */
  rx_len = w5300_tcp_recvlen(wiz->s, len);

  /* Checking validity of address */
  if (unlikely(!access_ok(VERIFY_WRITE, (unsigned char *)msg->msg_iov->iov_base, rx_len))) {
    ret = -EFAULT;
    goto out;
  }

  /* Copying packets from Rx FIFO into application */
  ret = w5300_tcp_recv(wiz, (unsigned char *)msg->msg_iov->iov_base, rx_len);

out:
  release_sock(sk);
  return ret;
}

/* close() function of PF_WIZNET */
static int wiz_sock_release(struct socket *sock)
{
  struct sock *sk = sock->sk;
  struct wiz_sock *wiz = wiz_sk(sk);

  if (sk) {
    long timeout = 0;
    /* Closing related process of W5300 */
    w5300_sock_release(wiz->s);

    if (sock_flag(sk, SOCK_LINGER) && !(current->flags & PF_EXITING))
      timeout = sk->sk_lingertime;
    sock->sk = NULL;
    release_sock(sk);
    sock_put(sk);
  }
  return 0;
}

static int wiz_sock_getname(struct socket *sock, struct sockaddr *uaddr, int *uaddr_len, int peer)
{
  *uaddr_len = sizeof(struct sockaddr);
  return 0;
}

/* Configure W5300 H/W socket address information(ip, netmask, gateway) */
static int wiz_ioctl(struct socket *sock, unsigned int cmd, unsigned long arg)
{
  int ret = inet_ioctl(sock, cmd, arg);

  if (ret == 0) {

    switch (cmd) {
      /* For configure gateway address of W5300 */
      case SIOCADDRT:
        {
          struct rtentry rt;
          struct rtentry *rtp = NULL;
          u32 gwaddr;
          if (copy_from_user(&rt, (void __user *)arg, sizeof(rt)))
            return -EFAULT;
          rtp = &rt;
          gwaddr = ((struct sockaddr_in *)&rtp->rt_gateway)->sin_addr.s_addr;
          /* Configure gateway address of W5300 */
          w5300_set_gwaddr(htonl(gwaddr));
        }
        break;
        /* For configure ip address&netmask of W5300 */
      case SIOCSIFADDR:
      case SIOCSIFNETMASK:
        {
          struct ifreq ifr;
          struct sockaddr_in *sin = (struct sockaddr_in *)&ifr.ifr_addr;
          struct in_device *in_dev;
          struct in_ifaddr **ifap = NULL;
          struct net_device *dev = wiz_desc->dev;
          struct in_ifaddr *ifa = NULL;
          int found=0;

          if (copy_from_user(&ifr, (void __user *)arg, sizeof(struct ifreq)))
            return -EFAULT;

          if (sin->sin_family != AF_INET)
            return -EINVAL;

          /* Find network interface of W5300 */
          if ((in_dev = __in_dev_get_rtnl(dev)) != NULL) {
            for (ifap = &in_dev->ifa_list; (ifa = *ifap) != NULL
                ;ifap = &ifa->ifa_next)
            {
              if (!strcmp("wiz0", ifa->ifa_label))
              { 
                /* found */
                found=1;
                break;
              }
            }
          }

          if (found) {
            /* Configure ip address&netmask of W5300 */
            if (cmd == SIOCSIFADDR) w5300_set_ipaddr(htonl(sin->sin_addr.s_addr));
            else if (cmd == SIOCSIFNETMASK) w5300_set_netmask(htonl(sin->sin_addr.s_addr));
          }
        }
        break;
    }
  }

  return ret;
}

static int wiz_sock_shutdown(struct socket *sock, int how)
{
  return 0;
}

static int wiz_setsockopt(struct socket *sock, int level, int optname, char __user *optval, int optlen)
{
  int err=0;
  struct sock *sk=sock->sk;
  struct wiz_sock *wiz = wiz_sk(sk);

  lock_sock(sk);
  if (optname == IP_ADD_MEMBERSHIP) {
    u32 mc_ipaddr;
    u8 mc_macaddr[MAX_ADDR_LEN];
    u16 mc_port;
    struct ip_mreqn mreq;
    err = -EINVAL;
    if (optlen < sizeof(struct ip_mreq))
      goto ret;
    err = -EFAULT;
    if (copy_from_user(&mreq, optval, sizeof(mreq)))
      goto ret;

    /* Multicast IP address */
    mc_ipaddr = htonl(mreq.imr_multiaddr.s_addr);
    /* Multicast MAC address */
    mc_macaddr[0] = 0x01;
    mc_macaddr[1] = 0x00;
    mc_macaddr[2] = 0x5e;
    mc_macaddr[3] = (u8)((mc_ipaddr&0x7fffff)>>16);
    mc_macaddr[4] = (u8)((mc_ipaddr&0x7fffff)>>8);
    mc_macaddr[5] = (u8)(mc_ipaddr&0x7fffff);
    /* Multicase port number */
    mc_port = w5300_get_port(wiz->s);

    /* Congifure Multicast infomation for W5300 */
    w5300_set_macaddr(mc_macaddr);
    w5300_set_dipaddr(wiz->s, mc_ipaddr);
    w5300_set_dport(wiz->s, mc_port);

    /* W5300 H/W channel reopen */
    w5300_write(Sn_MR(wiz->s), Sn_MR_UDP|Sn_MR_MULTI);
    w5300_write_sockcmd(wiz->s, Sn_CR_OPEN);
  }
  err = 0;
ret:
  release_sock(sk);
  return err;
}

/* Packet Transmission Function */
static int wiz_sock_send(struct wiz_sock *wiz, unsigned char *snd_ptr, int req_len, int nowait)
{
  int r;
  int buf_len, snd_len=0;
  int flags = nowait;
  long timeo;
  unsigned int wait_count = 0;

  /* verify_area is done by net/socket.c */
  DPRINTK("%s: s(%d),len(%d)\n", __FUNCTION__, wiz->s, req_len);
  timeo = sock_sndtimeo(&wiz->sk, flags);      

  /* Transmission is repeated as many as the size of transmission request */
  while (req_len > 0) {

    if (signal_pending(current)) {
      return sock_intr_errno(timeo);
    }

    /* Checking connection status */
    if ((wiz->sk.sk_protocol == IPPROTO_TCP) && 
	unlikely(wiz->sk.sk_state != TCP_ESTABLISHED) ) {
      if (wiz->sk.sk_state != TCP_CLOSE_WAIT) {
	printk("%s: TCP_CLOSE_WAIT error!\n", __FUNCTION__);
	return -EINVAL;
      }
      printk("%s: TCP_ESTABLISHED error!\n", __FUNCTION__);
      return -EINVAL;
    }

    /* Reading empty space of Tx FIFO */
    buf_len = w5300_get_txsize(wiz->s);
    DPRINTK("%s: s(%d),buf(%d),req(%d)\n", __FUNCTION__, wiz->s, buf_len, req_len);

    if (buf_len < req_len && nowait) {
      printk("%s: buffer len error!\n", __FUNCTION__);
      return -EAGAIN;
    }
    /* Configuring size of transmission */
    if (buf_len > req_len) buf_len = req_len;
    if (buf_len > 0) {
      /* Transmitting packets by writing into Tx FIFO of W5300 */
      r = w5300_send_data(wiz->s, snd_ptr, buf_len, 1, nowait|wiz->sk.sk_protocol);
      if (unlikely(r<0)) return r;
      req_len -= r;
      snd_ptr += r;
      snd_len += r;

      wait_count = 0;
    } else {
      if(wait_count > 1000000) {
	printk("%d: send buffer is not free!\n", wiz->s);
	return -EAGAIN;
      }
      ++wait_count;
    }
  }
  return snd_len;
}

/* sendto() Function of PF_WIZNET */
static int wiz_udp_sendmsg(struct kiocb *iocb, struct socket *sock, struct msghdr *msg, size_t len)
{
  struct sock *sk = sock->sk;
  struct wiz_sock *wiz = wiz_sk(sk);
  int connected = 0;
  int ret;

  lock_sock(sk);

  /* Size checking */
  if (len < 0 ||len > 0xFFFF) {
    ret = -EMSGSIZE;
    goto out;
  }

  /* flag checking, mirror BSD error message compatibility */
  if (msg->msg_flags&MSG_OOB) {
    ret = -EOPNOTSUPP;
    goto out;
  }

  /* Reading address */
  if (msg->msg_name) {
    struct sockaddr_in *usin = (struct sockaddr_in*)msg->msg_name;
    if ((msg->msg_namelen < sizeof(*usin)) || (usin->sin_addr.s_addr == 0)) {
      ret = -EINVAL;
      goto out;
    }

    /* Configuring destination IP and port in the W5300 */
    w5300_set_dipaddr(wiz->s, usin->sin_addr.s_addr);
    w5300_set_dport(wiz->s, usin->sin_port);
  } else {
    if (sk->sk_state != TCP_ESTABLISHED) {
      ret = -EDESTADDRREQ;
      goto out;
    }
		
    /* Open fast path for connected socket.
     * Route will not be used, if at least one option is set.
     */
    connected = 1;
  }
  /* Checking validity of address */
  if (unlikely(!access_ok(VERIFY_READ, (unsigned char *)msg->msg_iov->iov_base, len))) {
    ret = -EFAULT;
    goto out;
  }

  /* Transmitting packets by copying from application into Tx FIFO */
  ret = wiz_sock_send(wiz, (unsigned char *)msg->msg_iov->iov_base, len, msg->msg_flags&MSG_DONTWAIT);

out:
  release_sock(sk);
  return ret;
}

/* send() Function of PF_WIZNET */
static int wiz_tcp_sendmsg(struct kiocb *iocb, struct socket *sock, struct msghdr *msg, size_t len)
{
  struct sock *sk = sock->sk;
  struct wiz_sock *wiz = wiz_sk(sk);
  int ret;

  lock_sock(sk);

  /* Checking size */
  if (len < 0 || len > 0xFFFF) {
    printk("%s: lenth error!\n", __FUNCTION__);
    ret = -EMSGSIZE;
    goto out;
  }

  if (unlikely(!access_ok(VERIFY_READ, (unsigned char *)msg->msg_iov->iov_base, len))) {
    ret = -EFAULT;
    goto out;
  }

  ret = wiz_sock_send(wiz, (unsigned char *)msg->msg_iov->iov_base, len, msg->msg_flags&MSG_DONTWAIT);

out:
  release_sock(sk);
  return ret;
}

/* Registering TCP related socket Function of PF_WIZNET */
static const struct proto_ops wiz_tcp_ops = {
  .family   = PF_WIZNET,
  .owner    = THIS_MODULE,
  .release  = wiz_sock_release,
  .bind     = wiz_tcp_bind,
  .connect  = wiz_tcp_connect,
  .socketpair = sock_no_socketpair,
  .accept   = wiz_tcp_accept,
  .getname  = wiz_sock_getname, 
  .poll     = datagram_poll,
  .ioctl    = wiz_ioctl,
  .listen   = wiz_tcp_listen,
  .shutdown = wiz_sock_shutdown,
  .sendmsg  = wiz_tcp_sendmsg,
  .recvmsg  = wiz_tcp_recvmsg,
  .mmap     = sock_no_mmap,
  .sendpage = sock_no_sendpage,
};

/* Registering UDP related socket Function of PF_WIZNET */
static const struct proto_ops wiz_udp_ops = {
  .family   = PF_WIZNET,
  .release  = wiz_sock_release,
  .bind     = wiz_tcp_bind,
  .connect  = wiz_udp_connect,
  .socketpair =	sock_no_socketpair,
  .accept   = sock_no_accept,
  .getname  = wiz_sock_getname, 
  .poll     = datagram_poll,
  .ioctl    = wiz_ioctl,
  .listen   = sock_no_listen,
  .shutdown = wiz_sock_shutdown,
  .setsockopt = wiz_setsockopt,
  .sendmsg  = wiz_udp_sendmsg,
  .recvmsg  = wiz_udp_recvmsg,
  .mmap     = sock_no_mmap,
  .sendpage = sock_no_sendpage,
};

/* Destruction of Socket */
static void wiz_sock_destruct(struct sock *sk)
{
  __skb_queue_purge(&sk->sk_receive_queue);
  __skb_queue_purge(&sk->sk_error_queue);

  if (sk->sk_type == SOCK_STREAM && sk->sk_state != TCP_CLOSE) {
    return;
  }
  if (!sock_flag(sk, SOCK_DEAD)) {
    return;
  }

  BUG_TRAP(!atomic_read(&sk->sk_rmem_alloc));
  BUG_TRAP(!atomic_read(&sk->sk_wmem_alloc));
  BUG_TRAP(!sk->sk_wmem_queued);
  BUG_TRAP(!sk->sk_forward_alloc);

  dst_release(sk->sk_dst_cache);
  sk_refcnt_debug_dec(sk);
}

/* Protocol structure of PF_WIZNET */
static struct proto wiz_sk_proto = {
  .name     = "W5300",
  .owner    = THIS_MODULE,
  .obj_size = sizeof(struct wiz_sock),
};

/* Socket Creation Function. It is called when calling socket() Function from application */
static int wiz_create_socket(struct net *net, struct socket *sock, int protocol)
{
  struct wiz_sock *wiz = NULL;
  struct sock *sk;
  int family = PF_WIZNET;
  int r, err = 0;

  /* Socket Creation */
  sk = sk_alloc(net, PF_WIZNET, GFP_KERNEL, &wiz_sk_proto);
  if (sk == NULL) {
    printk("sk allocation failed! \n");
    goto do_oom;
  }
  wiz = wiz_sk(sk);

  /* Registering handler of related protocol */
  switch (sock->type) {
  case SOCK_DGRAM:
    sock->ops = &wiz_udp_ops;
    protocol = IPPROTO_UDP;
    break;
  case SOCK_STREAM:
    sock->ops = &wiz_tcp_ops;
    protocol = IPPROTO_TCP;
    break;
  default:
    err = -EPROTONOSUPPORT;
    goto free_and_exit;
  }

  /* Configuring socket information created in ‘struct wiz_private’and getting a channel assigned. */
  r = w5300_sock_alloc(sk);
  if (r < 0) {
    err = -ENOMEM;
    goto free_and_exit;
  }
  wiz->s = r; /* Configuring assigned channel. */
  DPRINTK("%s: channel = %X, wiz = %X\n", __FUNCTION__, wiz->s, wiz);
  wiz->remain_pkt = 0;

  /* Performing OPEN command to w5300 */
  w5300_open(wiz->s, sock->type);

  /* Initializing ‘struct sock’ */
  sock_init_data(sock,sk);
  sock->state = SS_UNCONNECTED;
  sk->sk_rcvbuf *= 8;
  sk->sk_family = family;
  sk->sk_protocol = protocol;
  sk->sk_type = sock->type;
  sk->sk_state = TCP_CLOSE;
	
  sk->sk_destruct = wiz_sock_destruct;

  return 0;

 free_and_exit:
  if (sk)
    sk_free(sk);
  return err;
 do_oom:
  return -ENOBUFS;
}

/* PF_WIZNET network family. */
struct net_proto_family wiz_family_ops = {
  .family = PF_WIZNET,
  .create = wiz_create_socket,
  .owner  = THIS_MODULE, 
};

/* Initialization of PF_WIZNET network family */
int wiz_sock_init(void)
{
  printk(KERN_INFO "WIZnet PF_WIZNET protocol register\n");

  /* beacause get info default gateway address */
  ((struct proto_ops*)(&inet_dgram_ops))->ioctl = wiz_ioctl;
  ((struct proto_ops*)(&inet_stream_ops))->ioctl = wiz_ioctl;

  /* Registering Function of PF_WIZNET network family */
  return sock_register(&wiz_family_ops);
}

/* Closing Function of PF_WIZNET network family */
void wiz_sock_exit(void)
{
  /* Closing registered PF_WIZNET network family */
  sock_unregister(PF_WIZNET);
}
