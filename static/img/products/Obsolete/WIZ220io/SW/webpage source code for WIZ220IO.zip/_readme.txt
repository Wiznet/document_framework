-. ain.htm : Analog Input Page. 

-. aout.htm : Analog Output Page.

-. din.htm : Digital Input Page

-. dout.htm : Digital Output Page.(DO_0~DO_7 and UART output)

-. index.htm : Default Page.

-. left.htm : Menu Page.

-. logo.gif : WIZnet Logo Image.

-. ROMFILEMaker.exe : Rom Image Maker program.

-. wizweb.rom : ROMFILEMaker.exe output file. It is used to 'webpage upload function' in the Configuration tool.