Note:
1.Copy the folder named W60X_QFlash to Keil -> Flash.
2.Compile the project of W60X_QFlash and generate QFLASH file.
3.Add FLM file of QFLASH.