#ifndef _TIME_H_
#define _TIME_H_
#include "stm32f10x.h"

void TIM3_Init(u16 arr,u16 psc);




#endif


