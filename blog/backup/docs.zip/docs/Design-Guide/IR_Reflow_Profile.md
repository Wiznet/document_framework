---
id: ir_reflow_profile
title: IR Reflow Profile
date: 2020-04-02
---

## Reflow Profile

![ir_reflow](/img/design_guide/reflow_profile/ir_reflow_profile.png)

-----

## Document

* [IR Reflow Profile -English](/img/design_guide/reflow_profile/ir_reflow_profile.pdf)
