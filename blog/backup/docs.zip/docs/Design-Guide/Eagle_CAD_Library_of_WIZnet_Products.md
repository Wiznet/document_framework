---
id: eagle_cad_library_of_wiznet_products
title: Eagle CAD Library of WIZnet Products
date: 2020-04-03
---

  - [W5500](/img/design_guide/w5500.zip)

![W5500](/img/design_guide/cad_library/w5500.png)

-----

  - [WIZ550io V1.0](/img/design_guide/wiz550io_v1.0.zip)

![WIZ550io V1.0](/img/design_guide/cad_library/wiz550io_v1_0.png)

-----

  - [WIZ550io V1.1](/img/design_guide/wiz550io_v1.1.zip)

![WIZ550io V1.1](/img/design_guide/cad_library/wiz550io_v1_1.png)

-----

  - [WizFi250](/img/design_guide/wizfi250.zip)

![WizFi250](/img/design_guide/cad_library/wizfi250.png)

-----

  - [WizFi250 IFBD](/img/design_guide/wizfi250-ifbd.zip)

![WizFi250 IFBD](/img/design_guide/cad_library/wizfi250_ifbd.png)
