---
id: education_data
title: Education Data
date: 2020-04-08
---

**Download the Education Data**  
This files has GitHub link for source code in it.

### Korean

  - [Basic Tutorial.pdf](/img/products/wiz750sr/educationdata/wiznet_serialtoethernet_boot_camp_20180516.pdf)  
  - [How to fix the firmware.pdf](/img/products/wiz750sr/educationdata/wiznet_serialtoethernet_deep-dive_training_20180620.pdf)  

-----
