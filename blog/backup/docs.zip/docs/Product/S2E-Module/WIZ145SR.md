---
id: wiz145sr
title: WIZ145SR
date: 2020-04-16
---

[WIZ145SR](http://www.wiznet.io/product-item/wiz145sr/)
