---
id: tutorial_eng
title: Tutorial(Eng)
date: 2020-04-16
---



# AT command Tutorial

[Exam 1. Example of data communication in Static IP and TCP Server
mode](/products/wiz550s2e/wiz550s2e_tutorial_en/exam1)  
[Exam 2. Example of retrieving web page of www.google.com in Dynamic IP
and TCP Client mode](/products/wiz550s2e/wiz550s2e_tutorial_en/exam2)  
[Exam 3. Example of data communication with more than two servers in
Dynamic IP](/products/wiz550s2e/wiz550s2e_tutorial_en/exam3)  
[Exam 4. Example of data communication with more than two devices in
Static IP](/products/wiz550s2e/wiz550s2e_tutorial_en/exam4)

# Server\<-\>Client connection Tutorial for RS422/485

Refer to YouTube Tutorial.
Watch:(https://www.youtube.com/watch?v=riv355petPY)
