---
id: tutorial_kor
title: Tutorial(Kor)
date: 2020-04-16
---



# AT command 사용 튜토리얼

[예제1. 고정 IP 환경에서 TCP 서버로 데이터 통신을 하는
예제](/products/wiz550s2e/wiz550s2e_tutorial_kr/exam1)  
[예제2. 유동 IP 환경에서 www.google.com의 웹 페이지를 받아오는
예제](/products/wiz550s2e/wiz550s2e_tutorial_kr/exam2)  
[예제3. 유동 IP 환경에서 둘 이상의 TCP 서버와 데이터 통신을 하는
예제](/products/wiz550s2e/wiz550s2e_tutorial_kr/exam3)  
[예제4. 고정 IP 환경에서 둘 이상의 장치와 UDP 데이터 통신을 하는
예제](/products/wiz550s2e/wiz550s2e_tutorial_kr/exam4)

# RS422/485 사용을 위한 Server\<-\>Client 연결 튜토리얼

Refer to YouTube Tutorial.
Watch:(https://www.youtube.com/watch?v=riv355petPY)
