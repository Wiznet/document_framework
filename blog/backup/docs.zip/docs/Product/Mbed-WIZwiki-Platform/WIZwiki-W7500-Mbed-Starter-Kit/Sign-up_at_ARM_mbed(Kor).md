---
id: sign_up_at_arm_mbed_kor
title: mbed 회원 가입하기
date: 2020-04-08
---

mbed.org 에 접속하면 아래와 같은 화면이 나온다. 화면에서 빨간색 표시된 부분 (Developer Site)을 클릭해서
🌎[mbed 개발자 사이트](https://developer.mbed.org)로 이동한다.

![](/img/products/wizwiki_w7500_starter_kit_temp/tutorial_kr/100_mbed_org.png)

빨간색 표시된 부분 (Login or signup)을 클릭한다.

![](/img/products/wizwiki_w7500_starter_kit_temp/tutorial_kr/101_login_signup.png)

회원 가입이 안 되어 있는 사용자는 신규 mbed 회원 가입을 한다.

![](/img/products/wizwiki_mbed_kit/kit_kr/tutorial_kr/101a_login_screen.png)

회원 가입 완료되면 위 화면의 로그인 창으로 로그인을 한다.
