---
id: eco-shield
title: Shield Ethernet
date: 2020-04-07
---

![WIZwiki-W7500ECO Shield Ethernet](/img/products/wizwiki-w7500eco/wizwiki-w7500eco_shield_-_ethernet_top_.png)

-----

## WIZwiki-W7500ECO Shield Ethernet Pinout

![WIZwiki-W7500ECO Shield Ethernet Pinout](/img/products/wizwiki-w7500eco/wizwiki-w7500eco_shield_pinout.png)

### WIZwiki-W7500ECO Shield Ethernet Callout

![WIZwiki-W7500ECO Shield Ethernet Callout](/img/products/wizwiki-w7500eco/wizwiki-w7500eco_shield_callout.png)

### Schematic

- **Schematic Version 1.0**

[WIZwiki-W7500ECO Shield Ethernet V1.0 Schematic](/img/products/wizwiki-w7500eco/wizwiki_w7500_eco_shield_ethernet_v1.0.pdf)

## Part list

### Dimension

* WIZwiki-W7500ECO Shield Ethernet V1.0 Dimension

![WIZwiki-W7500ECO Shield Ethernet Dimension](/img/products/wizwiki-w7500eco/wizwiki_w7500_eco_shield_ethernet_v1.0_dim_01.png)