---
id: wizfi310_evb_if_dimension
title: WizFi310 EVB & IF Dimension
date: 2020-05-13
---

## WizFi310 EVB

### Hardware dimension

![](/img/products/wizfi310/wizfi310evbdimension/wizfi310_module.png)

### External pin description

![WizFi310 EVB
Dimension](/img/products/wizfi310/wizfi310evbdimension/wizfi310_evb_demension.png)
