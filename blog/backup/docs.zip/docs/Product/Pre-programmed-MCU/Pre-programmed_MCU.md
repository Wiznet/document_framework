---
id: pre_programmed_mcu
title: Pre-programmed MCU
date: 2020-04-07
---

## Overview

WIZnet MCU products which **S2E firmware is programmed on**

-----

## Product Family

  - [W7500(P)-S2E](W7500P-S2E/w7500p-s2e-[EN]): W7500 / W7500P
    pre-programmed MCU products (S2E Firmware)
    
 

-----