---
id: wiz830mj
title: WIZ830MJ
date: 2020-04-16
---

[WIZ830MJ](http://www.wiznet.io/product-item/wiz830mj/)
