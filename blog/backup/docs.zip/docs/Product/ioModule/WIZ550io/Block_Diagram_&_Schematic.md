---
id: block_diagram_schematic
title: Block Diagram & Schematic
date: 2020-04-15
---

![](/img/products/wiz550io/wiz550io_blockdiagram_140207.png)

## Schematic

  - Revision 1.0 [WIZ550io Rev1.0 Schematic](/img/products/wiz550io/wiz550io-r1.0_0830_.pdf)
  - Revision 1.1 [WIZ550io Rev1.1 Schematic](/img/products/wiz550io/wiz550io_v1_1_20140117.pdf)
  - Revision 1.2/1.3 [WIZ550io Rev1.2/1.3 Schematic](/img/products/wiz550io/wiz550io_v1_2_schematic.pdf)

## PCB

  - Revision 1.2 [WIZ550io Rev1.2 PCB(Altium)](/img/products/wiz550io/wiz550io_v1.2.zip)
  - Revision 1.3 [WIZ550io Rev1.3 PCB(Altium)](/img/products/wiz550io/wiz550io_v1.3.zip)

## Partlist

  - Revision 1.0 Partlist [WIZ550io Rev1.0 Partlist](/img/products/wiz550io/wiz550io_v1_0_0830_pl.pdf)
  - Revision 1.1 Partlist [WIZ550io Rev1.1 Partlist](/img/products/wiz550io/wiz550io_ver1.1_pl_140128_.pdf)
  - Revision 1.2 Partlist [WIZ550io Rev1.2 Partlist](/img/products/wiz550io/wiz550io_ver1.2_pl.pdf)
