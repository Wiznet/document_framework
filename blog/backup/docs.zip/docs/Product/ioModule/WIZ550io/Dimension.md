---
id: dimension
title: Dimension
date: 2020-04-15
---

WIZ550io Ver1.0

![](/img/products/wiz550io/wiz550io_v1.0_dimension.jpg)

WIZ550io Ver1.1

54mm(W) x 26mm(L) x 24mm(H) (±0.5)
![](/img/products/wiz550io/wiz550io_v1.1_dimension.png)

WIZ550io Ver1.2

54mm(W) x 26mm(L) x 24mm(H) (±0.5)

Same to Ver1.1 and Ver1.2 PCB all size and hole size. There is little
change in all parts placement.

\* TOP ![](/img/products/wiz550io/wiz550io_topview.png)

\* BOTTOM ![](/img/products/wiz550io/wiz550io_bottomview.png)

\* Drill ![](/img/products/wiz550io/wiz550io_drillview.png)
