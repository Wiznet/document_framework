---
id: datasheet_kor
title: Datasheet(Kor)
date: 2020-04-13
---

## Overview

본 페이지는 WIZ550web와 WIZ550web Baseboard 에 대한 하드웨어 관련 정보를 제공하기 위한 것으로

  - 기본적인 하드웨어 스펙
  - 전기적 특성 및 I/O 특성
  - 레퍼런스 회로도
  - 모듈의 Dimension 정보

가 포함된다.

향후 하드웨어 사양이나 외형에 변경이 있을 경우에는 변경 내역란이 추가 될 수 있다.

-----

## Hardware Specification

### WIZ550web

  - MCU : STM32F103RCT6 (256KB Flash, 48KB SRAM)
  - TCP/IP Controller : W5500
  - RJ45(Integrated Transformer) : J1B1211CCD
  - External Flash Memory : AT45DB081D
  - EEPROM : 24AA64T-I/OT
  - 2.54mm Pin Header x 2

### WIZ550web Pinout

![WIZ550WEB\_Pinout](/img/products/wiz550web/wiz550web_rev1.1_20160721.png)

### Pin Description

| Ref No. | Pin No. | Symbol    | Type    | Description                    |
| ------- | ------- | --------- | ------- | ------------------------------ |
| J1      | **1**   | **D0**    | **I/O** | Digital 0 I/O                  |
| :::     | **2**   | **D1**    | **I/O** | Digital 1 I/O                  |
| :::     | **3**   | **D2**    | **I/O** | Digital 2 I/O                  |
| :::     | **4**   | **D3**    | **I/O** | Digital 3 I/O                  |
| :::     | **5**   | **D4**    | **I/O** | Digital 4 I/O                  |
| :::     | **6**   | **D5**    | **I/O** | Digital 5 I/O                  |
| :::     | **7**   | **D6**    | **I/O** | Digital 6 I/O                  |
| :::     | **8**   | **D7**    | **I/O** | Digital 7 I/O                  |
| :::     | **9**   | **D8**    | **I/O** | Digital 8 I/O                  |
| :::     | **10**  | **D9**    | **I/O** | Digital 9 I/O                  |
| :::     | **11**  | **D10**   | **I/O** | Digital 10 I/O                 |
| :::     | **12**  | **D11**   | **I/O** | Digital 11 I/O                 |
| :::     | **13**  | **D12**   | **I/O** | Digital 12 I/O                 |
| :::     | **14**  | **D13**   | **I/O** | Digital 13 I/O                 |
| :::     | **15**  | **D14**   | **I/O** | Digital 14 I/O                 |
| :::     | **16**  | **D15**   | **I/O** | Digital 15 I/O                 |
| :::     | **17**  | **NRST**  | **I**   | System Reset Input, Active Low |
| :::     | **18**  | **BOOT0** | **I**   | BOOT0 Input, Active High       |

| Ref No. | Pin No. | Symbol         | Type  | Description                      |
| ------- | ------- | -------------- | ----- | -------------------------------- |
| J2      | **1**   | **3V3D**       | **P** | Supply DC +3.3V , Digital Power  |
| :::     | **2**   | **3V3D**       | **P** | Supply DC +3.3V , Digital Power  |
| :::     | **3**   | **3V3A**       | **P** | Supply DC +3.3V , Analog Power   |
| :::     | **4**   | **VBAT**       | **P** | Supply DC +3.3V , Low Power Mode |
| :::     | **5**   | **A0**         | **I** | Analog 0 Input                   |
| :::     | **6**   | **A1**         | **I** | Analog 1 Input                   |
| :::     | **7**   | **A2**         | **I** | Analog 2 Input                   |
| :::     | **8**   | **A3**         | **I** | Analog 3 Input                   |
| :::     | **9**   | **UART2\_RX**  | **I** | Receiver input for UART2         |
| :::     | **10**  | **UART2\_TX**  | **O** | Transmitter output for UART2     |
| :::     | **11**  | **UART2\_RTS** | **O** | Request To Send output for UART2 |
| :::     | **12**  | **UART2\_CTS** | **I** | Clear To Send input for UART2    |
| :::     | **13**  | **UART1\_RX**  | **I** | Receiver input for UART1         |
| :::     | **14**  | **UART1\_TX**  | **O** | Transmitter output for UART1     |
| :::     | **15**  | **UART1\_RTS** | **O** | Request To Send output for UART1 |
| :::     | **16**  | **UART1\_CTS** | **I** | Clear To Send input for UART1    |
| :::     | **17**  | **GND**        | **P** | Digital Power Ground             |
| :::     | **18**  | **GND**        | **P** | Digital Power Ground             |
| :::     | **19**  | **GNDA**       | **P** | Analog Power Ground              |

-----

## WIZ550WEB Baseboard

  - DC 9\~24V Power Input
  - Digital Output 8EA (Relay - HR91C-05)
  - Digital Input 8EA (Photocouplers - TLP290-4)
  - Analog Input 4EA
  - RS-232C
  - RS-422

### WIZ550web Baseboard Pinout

![WIZ550web Baseboard
Pinout](/img/products/wiz550web/wiz550web_base_pinout_20160720.png)

### WIZ550web Baseboard Callout

![WIZ550web Baseboard
Callout](/img/products/wiz550web/wiz550web_base_20160720.png)

### Digital Output Port

WIZ550web Baseboard에는 8개(D0\~D7)의 릴레이 출력단이 있다. 기본 적인 내부 회로는 아래 사진과 같고
Jumper를 통해 릴레이의 NC(Normal close), NO(Normal Open)를 설정할수 있다. ![WIZ550WEB
Digital Output
Port](/img/products/wiz550web/wiz550web_bb_output.png) 동작 상태는
아래 표와 같다.

| 입력 값 | 릴레이 상태  | NC 출력 값   | NO 출력 값   |
| ---- | ------- | --------- | --------- |
| 0    | **OFF** | **Close** | **Open**  |
| 1    | **ON**  | **Open**  | **Close** |
출력 포트의 전압에 따른 허용 전류는 아래 표와 같다.

| NO | **5A 28VDC** | **10A 125VAC** | **5A 250VAC** |
| -- | ------------ | -------------- | ------------- |
| NC | **3A 28VAC** | **5A 125VDC**  | **3A 250VDC** |

### Digital Input Port

WIZ550web Baseboard에는 8개(D8\~D15)의 포토커플러를 통한 디지털 입력단이 있다. 기본적인 내부 회로는 아래
사진과 같다. 입력에는 극성이 없고 입력 두신호의 전위차로 ON/OFF를 구별한다. ![WIZ550WEB Digital Input
Port](/img/products/wiz550web/wiz550web_bb_input.png) 입력의 전기적
특성은 아래와 같다.

| 1.4V 이하 | **Low**                        |
| ------- | ------------------------------ |
| 2.1V 이상 | **High**                       |
| 최대 전압   | **24V**                        |
| 극성      | **없음. 입력되는 두 신호의 전위차로 On/Off** |

Digital Input 8개중에 4개(D8\~D11)는 Baseboard 내부의 택트 스위치와 같이 연결 되어 있고, 이 연결은
J23\~J26 Jumper로 선택 할 수 있다. ![WIZ550WEB Digital Input
Jumper](/img/products/wiz550web/wiz550web_bb_input_jumper.png)

### Analog Input Port

WIZ550web Baseboard에는 4개(A0\~A3)의 아날로그 입력단이 있다. 기본적이 내부 회로도는 아래 사진과 같다.
간단하게 0\~12V입력이 가능하고 내부 회로를 통과해 WIZ550WEB으로 입력 된다. ![WIZ550WEB Analog
Input Port](/img/products/wiz550web/wiz550web_bb_analog.png)

Analog Input은 4개중에 2개(A0,A1)는 Baseboard 내부의 가변저항(10K)과 온도센서(TC1047AVNB)에
같이 연결이 되어 있거, 이 연결은 J26, J28 Jumper로 선택 할 수 있다. ![WIZ550WEB Analog Input
Jumper](/img/products/wiz550web/wiz550web_bb_analog_jumper.png)

-----

# AC/DC Characteristics

## WIZ550web

### General Operating Conditions

| Symbol | Parameter                                   | Pins        | Min     | Typ     | Max         | Unit  |
| ------ | ------------------------------------------- | ----------- | ------- | ------- | ----------- | ----- |
| V*DD*  | **Standard operating voltage**              | **3V3D**    | **2**   | **3.3** | **3.6**     | **V** |
| V*DDA* | **Analog operation voltage (ADC not used)** | **3V3A**    | **2.0** | **3.3** | **3.6**     | **V** |
| :::    | **Analog operation voltage (ADC used)**     | **3V3A**    | **2.4** | **3.3** | **3.6**     | **V** |
| V*BAT* | **Backup operating voltage**                | **VBAT**    | **0.8** | **3.3** | **3.6**     | **V** |
| V*IN*  | **I/O Digital input voltage**               | **D0\~D15** | **0**   | **-**   | **VDD+0.3** | **V** |
| :::    | **I/O Analog input voltage**                | **A0\~A3**  | **0**   | **-**   | **VDD+0.3** | **V** |
| :::    | **BOOT0**                                   | **BOOT0**   | **0**   | **-**   | **5.5**     | **V** |
| :::    | **NRST**                                    | **NRST**    | **0**   | **-**   | **VDD+0.3** | **V** |

### I/O Static Characteristic

| Symbol      | Parameter                                            | Pins        | Min      | Typ   | Max     | Unit   |
| ----------- | ---------------------------------------------------- | ----------- | -------- | ----- | ------- | ------ |
| V*IL*       | **Low level input voltage**                          | **D0\~D15** | **-0.5** | **-** | **0.7** | **V**  |
| V*IH*       | **High level input voltage**                         | **D0\~D15** | **2.0**  | **-** | **VDD** | **V**  |
| V*IO*       | **Output current sunk by any I/O and control pin**   | **D0\~D15** | **-**    | **-** | **25**  | **mA** |
| :::         | **Output current source by any I/O and control pin** | **D0\~D15** | **-**    | **-** | **-25** | **mA** |
| V*IL*(NRST) | **NRST Input low level voltage**                     | **NRST**    | **-0.5** | **-** | **0.8** | **V**  |
| V*IH*(NRST) | **NRST Input high level voltage**                    | **NRST**    | **2**    | **-** | **3.3** | **V**  |

-----

# Reference Schematic & Parts

## Schematic

<table>
<thead>
<tr class="header">
<th>항목</th>
<th>Version</th>
<th>Schematic</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td>WIZ550web</td>
<td><strong>1.1 / 1.2</strong></td>
<td><a href="/img/products/wiz550web/wiz550webds_kr/wiz550web_v1.1_20151217.pdf">Download</a></td>
</tr>
<tr class="even">
<td>WIZ550web Baseboard</td>
<td><strong>1.0</strong></td>
<td><a href="/img/products/wiz550web/wiz550webds_kr/wiz550web-bb_v100_140925.pdf">Download</a></td>
</tr>
</tbody>
</table>

## Parts Datasheet

| Parts         | Descripsion                                   | Datasheet                                                                    |
| ------------- | --------------------------------------------- | ---------------------------------------------------------------------------- |
| STM32F103RCT6 | **ARM 32-bit Cortex™-M3 CPU Core**            | [STM32F103RCT6](/img/products/wiz550web/wiz550webds_kr/stm32f103rct6_256kb.pdf) |
| W5500         | **WIZnet TCP/IP Chip**                        | [W5500](../../iEthernet/W5500/datasheet) |
| AT45DB081D-SU | **8-Megabit Serial Flash Memory**             | [AT45DB081D-SU](/img/products/wiz550web/wiz550webds_kr/at45db081d-su.pdf)       |
| 24AA64T-I/OT  | **64K I2C™ Serial EEPROM**                    | [24AA64T-I/OT](/img/products/wiz550web/wiz550webds_kr/24aa64t-i_ot.pdf)         |
| J1B1211CCD    | **Transformer + RJ45 + LED, Industrial**      | [J1B1211CCD](/img/products/wiz550web/wiz550webds_kr/j1b1211ccd.pdf)             |
| HR91C-05      | **1 pole, 3-10A Relay, 1c(SPDT)**             | [HR91C-05](/img/products/wiz550web/wiz550webds_kr/hr91c-05.pdf)                 |
| SP3485EN      | **Low Power Half-Duplex RS-485 Transceivers** | [SP3485EN](/img/products/wiz550web/wiz550webds_kr/sp3485en.pdf)                 |
| SP3232EBEY    | **True +3.0V to +5.5V RS-232 Transceivers**   | [SP3232EBEY](/img/products/wiz550web/wiz550webds_kr/sp3232ebey.pdf)             |
| TC1047AVNB    | **Temperature to Voltage Sensor**             | [TC1047AVNB](/img/products/wiz550web/wiz550webds_kr/tc1047avnb.pdf)             |
| LM358APWR     | **Dual Operational Amplifiers**               | [LM358APWR](/img/products/wiz550web/wiz550webds_kr/lm358apwr.pdf)               |
| TLP290-4      | **4-Channel Transistor-Output Photocouplers** | [TLP290-4](/img/products/wiz550web/wiz550webds_kr/tlp290-4.pdf)                 |
| AOZ1210AI     | **EZBuck 2A Simple Buck Regulator**           | [AOZ1210AI](/img/products/wiz550web/wiz550webds_kr/aoz1210ai.pdf)               |

-----

## WIZ550web V1.1/V1.2

74.95mm(W) x 30mm(L) x 24mm(H) (±0.5)
![](/img/products/wiz550web/wiz550web_v1.2_dimension.png)

## WIZ550web Baseboard

145mm(W) x 85mm(L) x 28mm(H) (±0.5) ![WIZ550WEB Baseboard
Dimension](/img/products/wiz550web/wiz550webds_kr/wiz550web-bb_v100_dimension.png)
