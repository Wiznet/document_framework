---
id: ref_schematic
title: Reference Schematic
date: 2020-04-03
---

-----


## External Transformer Type

[Go to github](https://github.com/Wiznet/Hardware-Files-of-WIZnet/tree/master/02_iEthernet/W5100S/Reference%20Schematic)
![](/img/products/w5100s/ref_sch/w5100s_ref_schematic_v110_use_trans.jpg)

-----


## RJ45 with Transformer Type

[Go to github](https://github.com/Wiznet/Hardware-Files-of-WIZnet/tree/master/02_iEthernet/W5100S/Reference%20Schematic)
![](/img/products/w5100s/ref_sch/w5100s_ref_schematic_v110_use_trans.jpg)

-----
