---
id: esd_test_document
title: ESD Test Document
date: 2020-04-07
---

![W5500 Confirmation of ESD Test document](/img/products/w5500/application/kect-1607-00353_1_w5500_48lqfp_0722.png)
=======

[W5500 Confirmation of ESD Test document(PDF)](/img/products/w5500/kect-1607-00353_1_w5500_48lqfp_0722.pdf)
![W5500 Confirmation of ESD Test document](/img/products/w5500/application/kect-1607-00353_1_w5500_48lqfp_0722.png)

