
W5500 EVB firmware project based on LPCXpresso IDE. For more details
about LPCXpresso IDE, please refer to
![](/img/link.png) [NXP LPCXpresso platform
page](http://www.lpcware.com/lpcxpresso).

**LPCXpresso IDE Install & Activation Guide**
![](/img/link.png) [How to Install and
Activate LPCXpresso IDE](/osh/lpcxpresso/start)

**Download the Libraries and Application example source code for
W5500-EVB** ![](/img/github.png) https://github.com/Wiznet/W5500_EVB
