---
id: document
title: Document
date: 2020-04-03
---


**Download the latest version**

Korean : [W6100 DataSheet v1.0.4](/img/products/w6100/w6100_ds_v104k.pdf)  
English : [W6100 DataSheet v1.0.4](/img/products/w6100/w6100_ds_v104e.pdf)  

-----


testing
