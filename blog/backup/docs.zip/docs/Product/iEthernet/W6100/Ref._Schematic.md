---
id: ref_schematic
title: Ref. Schematic
date: 2020-04-03
---

-----

## External Transformer Type

[Go to
github](https://github.com/Wiznet/Hardware-Files-of-WIZnet/tree/master/02_iEthernet/W6100/Reference%20Schematic)

![](/img/products/w6100/w6100_ref_schematic_v110_use_trans.jpg)

-----

## RJ45 with Transformer Type

[Go to
github](https://github.com/Wiznet/Hardware-Files-of-WIZnet/tree/master/02_iEthernet/W6100/Reference%20Schematic)

![](/img/products/w6100/w6100_ref_schematic_v110_use_mag.jpg)

-----
