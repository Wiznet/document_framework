## IP Configuration

-----

## IP configuration in PC

-----

If IP address of your PC and WIZ550io are different, you
need to configure your PC network setting.

  - Click on the Start Menu and open the Control Panel.
  - Enter to'Network and Internet' and enter to Network and Sharing Center.
  - Click'Change adapter settings at left side.



  - Double click Local Area Connection icon and click Properties and
enter IPv4 Properties.


  - Then, set your IP address and subnet mask as same as WIZ550io's IP
address and subnet mask. 
  - Or, you can add IP address by setting
Advanced. Click Advanced.. button.



  - Click Add... button and add IP address and subnet mask.
