---
id: http_client
title: HTTP Client
date: 2020-04-03
---

## Before Compile

1.  Download source file from <https://github.com/amcewen/HttpClient>.
2.  Extract and Copy all files into "Arduino/libraries/Ethernet/".

## Change code

Change "SimpleHttpExample.ino" file in the
"Ethernet/example/SimpleHttpExample/" as follow :

-----

![](/img/osh/ioshield-a/cap_2013-08-28_15-14-38-205.png)

-----

![](/img/osh/ioshield-a/cap_2013-08-28_15-14-53-503.png)

-----

## Result

During the run the program, You can see the log message via Serial
Monitor as follow: ![](/img/osh/ioshield-a/cap_2013-08-28_15-18-49-520.png)