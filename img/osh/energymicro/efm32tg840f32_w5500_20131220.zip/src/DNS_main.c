/*
 *****************************************************************************
 * @file
 * @brief   Main of DNS Test
 * @details Example DNS Client
 * @author  WIZnet co, LTD.
 *****************************************************************************
 */

#include "em_chip.h"
#include "em_cmu.h"
#include "em_int.h"
#include "em_gpio.h"
#include "em_leuart.h"
#include "em_usart.h"

#include "bsp_tg840.h"
#include "spi.h"
#include "Ethernet/socket.h"
#include "Internet/DNS/dns.h"

volatile uint32_t msTicks; /* counts 1ms timeTicks */
uint32_t prevTick;

/***************************************
 * SOCKET NUMBER DEFINION for Examples *
 ***************************************/
#define SOCK_DNS        0

/**********************************************
 * Shared Buffer Definition for LOOPBACK TEST *
 **********************************************/
uint8_t gDATABUF[DATA_BUF_SIZE];

/**************************************************************************//**
 * @brief Default Network Inforamtion
 *****************************************************************************/
/* SHOULD BE available Network for communicating to a real DNS server */
wiz_NetInfo gWIZNETINFO = { .mac = {0x00, 0x08, 0xdc,0x00, 0xab, 0xcd},
                            .ip = {192, 168, 1, 123},
                            .sn = {255,255,255,0},
                            .gw = {192, 168, 1, 1},
                            .dns = {8,8,8,8},            // Google public DNS Server
                            .dhcp = NETINFO_STATIC };

uint8_t DNS_2nd[4]    = {168,126,63,1};      //secondary DNS server IP
uint8_t Domain_name[] = "www.google.com";    // for example domain name
uint8_t Domain_IP[4]  = {0, };               // Translated IP address by DNS

/**************************************************************************//**
 * @brief SysTick_Handler
 * Interrupt Service Routine for system tick counter
 *****************************************************************************/
void SysTick_Handler(void)
{
  msTicks++;       /* increment counter necessary in Delay()*/

  ////////////////////////////////////////////////////////
  // SHOULD BE Added DNS Timer Handler your 1s tick timer
  if(msTicks % 1000 == 0)  DNS_time_handler();
  ////////////////////////////////////////////////////////
}


/******************************************************************************
 * @brief  Network Init
 * Intialize the network information to be used in WIZCHIP 
 *****************************************************************************/
void network_init(void)
{
#if DEBUG_MODE != DEBUG_NO  
  uint8_t tmpstr[6];
#endif  
  ctlnetwork(CN_SET_NETINFO, (void*)&gWIZNETINFO);
  ctlnetwork(CN_GET_NETINFO, (void*)&gWIZNETINFO);

#if DEBUG_MODE != DEBUG_NO  
  // Display Network Information
  ctlwizchip(CW_GET_ID,(void*)tmpstr);
  printf("\r\n=== %s NET CONF ===\r\n",(char*)tmpstr);
  printf("MAC: %02X:%02X:%02X:%02X:%02X:%02X\r\n",gWIZNETINFO.mac[0],gWIZNETINFO.mac[1],gWIZNETINFO.mac[2],
            gWIZNETINFO.mac[3],gWIZNETINFO.mac[4],gWIZNETINFO.mac[5]);
  printf("SIP: %d.%d.%d.%d\r\n", gWIZNETINFO.ip[0],gWIZNETINFO.ip[1],gWIZNETINFO.ip[2],gWIZNETINFO.ip[3]);
  printf("GAR: %d.%d.%d.%d\r\n", gWIZNETINFO.gw[0],gWIZNETINFO.gw[1],gWIZNETINFO.gw[2],gWIZNETINFO.gw[3]);
  printf("SUB: %d.%d.%d.%d\r\n", gWIZNETINFO.sn[0],gWIZNETINFO.sn[1],gWIZNETINFO.sn[2],gWIZNETINFO.sn[3]);
  printf("DNS: %d.%d.%d.%d\r\n", gWIZNETINFO.dns[0],gWIZNETINFO.dns[1],gWIZNETINFO.dns[2],gWIZNETINFO.dns[3]);
  printf("======================\r\n");
#endif  
}

/******************************************************************************
 * @brief  Main function
 * Main is called from _program_start, see assembly startup file
 *****************************************************************************/
int main(void)
{
  uint8_t tmp;
  int8_t  ret;
  uint8_t memsize[2][8] = {{2,2,2,2,2,2,2,2},{2,2,2,2,2,2,2,2}};
  uint32_t led_msTick = 1000;

  /* Initialize chip */
  CHIP_Init();
 
#if DEBUG_MODE == DEBUG_SWO  
  setupSWO();  
#endif
  
  initCMU();
  
  GPIO_PinModeSet(LED_PORT, LED_PIN, gpioModePushPull, 0);
  
  if (SysTick_Config(CMU_ClockFreqGet(cmuClock_CORE) / 1000)) while (1) ;  
  
#if DEBUG_MODE == DEBUG_LEUART
  initLEUART(14400);
#endif

  initSPI();

#if DEBUG_MODE != DEBUG_NO
  printf("HF Clock = %d\r\n",CMU_ClockFreqGet(cmuClock_HF));
  printf("CORE Clock = %d\r\n",CMU_ClockFreqGet(cmuClock_CORE));
  printf("CORELE Clock = %d\r\n",CMU_ClockFreqGet(cmuClock_CORELE));
  printf("HFPER Clock = %d\r\n",CMU_ClockFreqGet(cmuClock_HFPER));
#endif
  
#if _WIZCHIP_IO_MODE_ == _WIZCHIP_IO_MODE_SPI_VDM_  
  reg_wizchip_cs_cbfunc(spiCSlow, spiCShigh);
#else
  reg_wizchip_cs_cbfunc(spiCSlow, spiCSlow);
#endif    
  reg_wizchip_spi_cbfunc(spiRecvByte,spiSendByte);
  /* No comment the below statement when SPI shared with the other devices */
  //reg_wizchip_cris_cbfunc((void (*)())INT_Disable,(void (*)()) INT_Enable);
  
  /* WIZCHIP SOCKET Buffer initialize */
  if(ctlwizchip(CW_INIT_WIZCHIP,(void*)memsize) == -1)
  {
     #if DEBUG_MODE != DEBUG_NO    
       printf("WIZCHIP Initialized fail.\r\n");
     #endif
     while(1);
  }
  
   /* PHY link status check */
   do
   {
     if(ctlwizchip(CW_GET_PHYLINK, (void*)&tmp) == -1)
     {
     #if DEBUG_MODE != DEBUG_NO
        printf("Unknown PHY Link stauts.\r\n");
     #endif
     }
   }while(tmp == PHY_LINK_OFF);

   /* Network initialization */
   network_init();
   
   /*******************************/
   /* WIZnet W5500 Code Examples  */
   /* DNS client test     */
   /*******************************/
   /* Main loop */
#if DEBUG_MODE != DEBUG_NO  
   printf("\r\n=== DNS Client Example ===============\r\n");
   printf("> DNS 1st : %d.%d.%d.%d\r\n", gWIZNETINFO.dns[0], gWIZNETINFO.dns[1], gWIZNETINFO.dns[2], gWIZNETINFO.dns[3]);
   printf("> DNS 2nd : %d.%d.%d.%d\r\n", DNS_2nd[0], DNS_2nd[1], DNS_2nd[2], DNS_2nd[3]);
   printf("======================================\r\n");
   printf("> Example Domain Name : %s\r\n", Domain_name);
#endif   
   /* DNS client initialization */
   DNS_init(SOCK_DNS, gDATABUF);
   
   /* DNS procssing */
   if ((ret = DNS_run(gWIZNETINFO.dns, Domain_name, Domain_IP)) > 0) // try to 1st DNS
   {
   #if DEBUG_MODE != DEBUG_NO
      printf("> 1st DNS Reponsed\r\n");
   #endif
   }
   else if ((ret != -1) && ((ret = DNS_run(DNS_2nd, Domain_name, Domain_IP))>0))     // retry to 2nd DNS
   {
   #if DEBUG_MODE != DEBUG_NO
      printf("> 2nd DNS Reponsed\r\n");
   #endif
   }
   else if(ret == -1)
   {
   #if DEBUG_MODE != DEBUG_NO
      printf("> MAX_DOMAIN_NAME is too small. Should be redefined it.\r\n");
   #endif
      led_msTick = 100;
   }
   else
   {
   #if DEBUG_MODE != DEBUG_NO
      printf("> DNS Failed\r\n");
   #endif
      led_msTick = 100;
   }
      
   if(ret > 0)
   {
   #if DEBUG_MODE != DEBUG_NO
      printf("> Translated %s to %d.%d.%d.%d\r\n",Domain_name,Domain_IP[0],Domain_IP[1],Domain_IP[2],Domain_IP[3]);
   #endif
      //
      // TO DO
      //
   }

  prevTick = msTicks;
  while(1)
  {
    /* User LED Toggle every 1s */
    if((msTicks - prevTick) > led_msTick)
    {
      prevTick = msTicks;
      if ( GPIO_PinOutGet(LED_PORT, LED_PIN) )
        GPIO_PinOutClear(LED_PORT, LED_PIN);
      else
        GPIO_PinOutSet(LED_PORT, LED_PIN);
    }
  }
}
