/*
 *****************************************************************************
 * @file
 * @brief   Main of Loopback Test 
 * @details Loopback(Receive and Send back) TCP & UDP server
 * @author  WIZnet co, LTD.
 *****************************************************************************
 */

#include "em_chip.h"
#include "em_cmu.h"
#include "em_int.h"
#include "em_gpio.h"
//#include "em_system.h"
#include "em_leuart.h"
#include "em_usart.h"

#include "bsp_tg840.h"
#include "spi.h"
#include "Ethernet/socket.h"
#include "loopback.h"

volatile uint32_t msTicks; /* counts 1ms timeTicks */
uint32_t prevTick;

/***************************************
 * SOCKET NUMBER DEFINION for Examples *
 ***************************************/
#define SOCK_TCPS        0
#define SOCK_UDPS        1

/**********************************************
 * Shared Buffer Definition for LOOPBACK TEST *
 **********************************************/
uint8_t gDATABUF[DATA_BUF_SIZE];

/**************************************************************************//**
 * @brief Default Network Inforamtion
 *****************************************************************************/
wiz_NetInfo gWIZNETINFO = { .mac = {0x00, 0x08, 0xdc,0x00, 0xab, 0xcd},
                            .ip = {192, 168, 1, 123},
                            .sn = {255,255,255,0},
                            .gw = {192, 168, 1, 1},
                            .dns = {0,0,0,0},
                            .dhcp = NETINFO_STATIC };


/**************************************************************************//**
 * @brief SysTick_Handler
 * Interrupt Service Routine for system tick counter
 *****************************************************************************/
void SysTick_Handler(void)
{
  msTicks++;       /* increment counter necessary in Delay()*/
}


/******************************************************************************
 * @brief  Network Init
 * Intialize the network information to be used in WIZCHIP 
 *****************************************************************************/
void network_init(void)
{
#if DEBUG_MODE != DEBUG_NO  
  uint8_t tmpstr[6];
#endif  
  ctlnetwork(CN_SET_NETINFO, (void*)&gWIZNETINFO);
  ctlnetwork(CN_GET_NETINFO, (void*)&gWIZNETINFO);

#if DEBUG_MODE != DEBUG_NO  
  // Display Network Information
  ctlwizchip(CW_GET_ID,(void*)tmpstr);
  printf("\r\n=== %s NET CONF ===\r\n",(char*)tmpstr);
  printf("MAC: %02X:%02X:%02X:%02X:%02X:%02X\r\n",gWIZNETINFO.mac[0],gWIZNETINFO.mac[1],gWIZNETINFO.mac[2],
            gWIZNETINFO.mac[3],gWIZNETINFO.mac[4],gWIZNETINFO.mac[5]);
  printf("SIP: %d.%d.%d.%d\r\n", gWIZNETINFO.ip[0],gWIZNETINFO.ip[1],gWIZNETINFO.ip[2],gWIZNETINFO.ip[3]);
  printf("GAR: %d.%d.%d.%d\r\n", gWIZNETINFO.gw[0],gWIZNETINFO.gw[1],gWIZNETINFO.gw[2],gWIZNETINFO.gw[3]);
  printf("SUB: %d.%d.%d.%d\r\n", gWIZNETINFO.sn[0],gWIZNETINFO.sn[1],gWIZNETINFO.sn[2],gWIZNETINFO.sn[3]);
  printf("DNS: %d.%d.%d.%d\r\n", gWIZNETINFO.dns[0],gWIZNETINFO.dns[1],gWIZNETINFO.dns[2],gWIZNETINFO.dns[3]);
  printf("======================\r\n");
#endif  
}

/******************************************************************************
 * @brief  Main function
 * Main is called from _program_start, see assembly startup file
 *****************************************************************************/
int main(void)
{
  uint8_t tmp;
  int32_t ret;
  uint8_t memsize[2][8] = {{2,2,2,2,2,2,2,2},{2,2,2,2,2,2,2,2}};
  /* Initialize chip */
  CHIP_Init();
 
#if DEBUG_MODE == DEBUG_SWO  
  setupSWO();  
#endif
  
  initCMU();
  
  GPIO_PinModeSet(LED_PORT, LED_PIN, gpioModePushPull, 0);
  
  if (SysTick_Config(CMU_ClockFreqGet(cmuClock_CORE) / 1000)) while (1) ;  
  
#if DEBUG_MODE == DEBUG_LEUART
  initLEUART(14400);
#endif

  initSPI();

#if DEBUG_MODE != DEBUG_NO
  printf("HF Clock = %d\r\n",CMU_ClockFreqGet(cmuClock_HF));
  printf("CORE Clock = %d\r\n",CMU_ClockFreqGet(cmuClock_CORE));
  printf("CORELE Clock = %d\r\n",CMU_ClockFreqGet(cmuClock_CORELE));
  printf("HFPER Clock = %d\r\n",CMU_ClockFreqGet(cmuClock_HFPER));
#endif
  
#if _WIZCHIP_IO_MODE_ == _WIZCHIP_IO_MODE_SPI_VDM_  
  reg_wizchip_cs_cbfunc(spiCSlow, spiCShigh);
#else
  reg_wizchip_cs_cbfunc(spiCSlow, spiCSlow);
#endif    
  reg_wizchip_spi_cbfunc(spiRecvByte,spiSendByte);
  /* No comment the below statement when SPI shared with the other devices */
  //reg_wizchip_cris_cbfunc((void (*)())INT_Disable,(void (*)()) INT_Enable);
  
  /* WIZCHIP SOCKET Buffer initialize */
  if(ctlwizchip(CW_INIT_WIZCHIP,(void*)memsize) == -1)
  {
     #if DEBUG_MODE != DEBUG_NO    
       printf("WIZCHIP Initialized fail.\r\n");
     #endif
     while(1);
  }
  
  /* PHY link status check */
  do
  {
     if(ctlwizchip(CW_GET_PHYLINK, (void*)&tmp) == -1)
     {
     #if DEBUG_MODE != DEBUG_NO
        printf("Unknown PHY Link stauts.\r\n");
     #endif
     }
  }while(tmp == PHY_LINK_OFF);

  /* Network initialization */
  network_init();
  
  /*******************************/
  /* WIZnet W5500 Code Examples  */
  /* TCPS/UDPS Loopback test     */
  /*******************************/
  /* Main loop */
  prevTick = msTicks;
  while(1)
  {
    /* Loopback Test */
    // TCP server loopback test
    if( (ret=loopback_tcps(SOCK_TCPS, gDATABUF, 5000)) < 0) 
    {
    #if DEBUG_MODE != DEBUG_NO
      printf("SOCKET ERROR : %ld\r\n", ret);
    #endif
    }
    // UDP server loopback test
    if( (ret=loopback_udps(SOCK_UDPS, gDATABUF, 3000)) < 0) 
    {
      (void)ret;
    #if DEBUG_MODE != DEBUG_NO
      printf("SOCKET ERROR : %ld\r\n", ret);
    #endif
    }
    /* User LED Toggle every 1s */
    if((msTicks - prevTick) > 1000)
    {
      prevTick = msTicks;
      if ( GPIO_PinOutGet(LED_PORT, LED_PIN) )
        GPIO_PinOutClear(LED_PORT, LED_PIN);
      else
        GPIO_PinOutSet(LED_PORT, LED_PIN);
    }
  }
}
