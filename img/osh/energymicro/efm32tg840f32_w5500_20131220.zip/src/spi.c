/*
 *****************************************************************************
 * @file
 * @brief SPI receiver/transmitter (USART)
 *   Peripheral SPI API
 * @author WIZnet co, LTD.
 *
 *****************************************************************************
 */
#include "em_cmu.h"
#include "em_gpio.h"
#include "em_usart.h"
#include "spi.h"

/*******************************************************//**
 * @brief  Initializes SPI interface for access WIZCHIP.
 *******************************************************/
void initSPI(void)
{
  USART_InitSync_TypeDef init = 
    { usartEnable,       /* Enable RX/TX when init completed. */
      16000000,          /* Use current configured reference clock for configuring baudrate. */
       2000000,          /* 1 Mbits/s. */
      usartDatabits8,    /* 8 databits. */
      true,              /* Master mode. */
      true,              /* Send most significant bit first. */
      usartClockMode0    /* Clock idle low, sample on rising edge. */
    };

  init.refFreq = CMU_ClockFreqGet(cmuClock_CORE);
  init.baudrate = init.refFreq/4;

  /* Enable module clocks */

  /* To avoid false start, configure output US1_TX as high on PD0 */
  /* GPIO pins used, please refer to DVK user guide. */
  /* Configure SPI pins */
  GPIO_PinModeSet(SPI_MOSI_PORT, SPI_MOSI_PIN, gpioModePushPull, 1);
  GPIO_PinModeSet(SPI_MISO_PORT, SPI_MISO_PIN, gpioModeInput, 0);
  GPIO_PinModeSet(SPI_CLK_PORT, SPI_CLK_PIN, gpioModePushPull, 0);
  /* Keep CS high to not activate slave */
  GPIO_PinModeSet(SPI_CS_PORT, SPI_CS_PIN, gpioModePushPull, 1);

  /* Reset USART just in case */
  USART_Reset(SPI_USART);

  /* Enable clock for USART1 */
  CMU_ClockEnable(SPI_CLK, true);

  /* Configure to use SPI master with manual CS */
  /* For now, configure SPI for worst case 32MHz clock in order to work for all */
  /* configurations. */
  USART_InitSync(SPI_USART, &init);  
  
  /* Module USART1 is configured to location 1 */
  SPI_USART->ROUTE = (SPI_USART->ROUTE & ~_USART_ROUTE_LOCATION_MASK) |
                      SPI_USART_ROUTE_LOCATION;

  /* Enable signals TX, RX, CLK, CS */
  SPI_USART->ROUTE |= USART_ROUTE_TXPEN | USART_ROUTE_RXPEN |
                       USART_ROUTE_CLKPEN;
}


void spiCSlow(void)
{
  GPIO_PinOutClear(SPI_CS_PORT, SPI_CS_PIN);  
}

void spiCShigh(void)
{
  GPIO_PinOutSet(SPI_CS_PORT, SPI_CS_PIN);  
}

void spiSendByte(uint8_t sendbyte)
{
  USART_Tx(SPI_USART,sendbyte);
  /* Wait for transmition to finished */
  while (!(SPI_USART->STATUS & USART_STATUS_TXC)) ;

  /* Return the datat read from SPI buffer */
  USART_Rx(SPI_USART);
}

uint8_t spiRecvByte(void)
{
  USART_Tx(SPI_USART,0x00);
  /* Wait for transmition to finished */
  while (!(SPI_USART->STATUS & USART_STATUS_TXC)) ;

  /* Return the datat read from SPI buffer */
  return USART_Rx(SPI_USART);
}

