/*
 *****************************************************************************
 * @file
 * @brief   Main of DHCP
 * @details Example DHCP Client
 * @author  WIZnet co, LTD.
 *****************************************************************************
 */

#include "em_chip.h"
#include "em_cmu.h"
#include "em_int.h"
#include "em_gpio.h"
#include "em_leuart.h"
#include "em_usart.h"

#include "bsp_tg840.h"
#include "spi.h"
#include "Ethernet/socket.h"
#include "Internet/DHCP/dhcp.h"

volatile uint32_t msTicks; /* counts 1ms timeTicks */
uint32_t prevTick;

/***************************************
 * SOCKET NUMBER DEFINION for Examples *
 ***************************************/
#define SOCK_DHCP          0
#define MY_MAX_DHCP_RETRY  5

/**********************************************
 * Shared Buffer Definition for LOOPBACK TEST *
 **********************************************/
uint8_t gDATABUF[DATA_BUF_SIZE];

/**************************************************************************//**
 * @brief Default Network Inforamtion
 *****************************************************************************/
wiz_NetInfo gWIZNETINFO = 
        {
            .mac = {0x00, 0x08, 0xdc,0x00, 0xab, 0xcd},
            .ip = {192, 168, 1, 123},
            .sn = {255,255,255,0},
            .gw = {192, 168, 1, 1},
            .dns = {0,0,0,0},
            .dhcp = NETINFO_DHCP
        };


/**************************************************************************//**
 * @brief SysTick_Handler
 * Interrupt Service Routine for system tick counter
 *****************************************************************************/
void SysTick_Handler(void)
{
  msTicks++;       /* increment counter necessary in Delay()*/
  
  ////////////////////////////////////////////////////////
  // SHOULD BE Added DHCP Timer Handler your 1s tick timer
  if(msTicks % 1000 == 0)  DHCP_time_handler();
  ////////////////////////////////////////////////////////
}


/******************************************************************************
 * @brief  Network Init
 * Intialize the network information to be used in WIZCHIP 
 *****************************************************************************/
void network_init(void)
{
   ctlnetwork(CN_SET_NETINFO, (void*)&gWIZNETINFO);
#if DEBUG_MODE != DEBUG_NO  
   {
      uint8_t tmpstr[6];
      // Display Network Information
      ctlwizchip(CW_GET_ID,(void*)tmpstr);
      ctlnetwork(CN_GET_NETINFO, (void*)&gWIZNETINFO);
      printf("\r\n=== %s NET CONF ===\r\n",(char*)tmpstr);
      printf("MAC: %02X:%02X:%02X:%02X:%02X:%02X\r\n",gWIZNETINFO.mac[0],gWIZNETINFO.mac[1],gWIZNETINFO.mac[2],
               gWIZNETINFO.mac[3],gWIZNETINFO.mac[4],gWIZNETINFO.mac[5]);
      printf("SIP: %d.%d.%d.%d\r\n", gWIZNETINFO.ip[0],gWIZNETINFO.ip[1],gWIZNETINFO.ip[2],gWIZNETINFO.ip[3]);
      printf("GAR: %d.%d.%d.%d\r\n", gWIZNETINFO.gw[0],gWIZNETINFO.gw[1],gWIZNETINFO.gw[2],gWIZNETINFO.gw[3]);
      printf("SUB: %d.%d.%d.%d\r\n", gWIZNETINFO.sn[0],gWIZNETINFO.sn[1],gWIZNETINFO.sn[2],gWIZNETINFO.sn[3]);
      printf("DNS: %d.%d.%d.%d\r\n", gWIZNETINFO.dns[0],gWIZNETINFO.dns[1],gWIZNETINFO.dns[2],gWIZNETINFO.dns[3]);
      printf("======================\r\n");
   }
#endif  
}

/*******************************************************
 * @ brief Call back for ip assing & ip update from DHCP
 *******************************************************/
void my_ip_assign(void)
{
   getIPfromDHCP(gWIZNETINFO.ip);
   getGWfromDHCP(gWIZNETINFO.gw);
   getSNfromDHCP(gWIZNETINFO.sn);
   getDNSfromDHCP(gWIZNETINFO.dns);
   gWIZNETINFO.dhcp = NETINFO_DHCP;
   /* Network initialization */
   network_init();      // apply from dhcp
#if DEBUG_MODE != DEBUG_NO
   printf("DHCP LEASED TIME : %d Sec.\r\n", getDHCPLeasetime());            
#endif
}

/************************************
 * @ brief Call back for ip Conflict
 ************************************/
void my_ip_conflict(void)
{
#if DEBUG_MODE != DEBUG_NO
   printf("CONFLICT IP from DHCP\r\n");
#endif   
   //halt or reset or any...
   while(1); // this example is halt.
}

/******************************************************************************
 * @brief  Main function
 * Main is called from _program_start, see assembly startup file
 *****************************************************************************/
int main(void)
{
  uint8_t tmp;
  uint8_t memsize[2][8] = {{2,2,2,2,2,2,2,2},{2,2,2,2,2,2,2,2}};
  uint8_t my_dhcp_retry = 0;

  /* Initialize chip */
  CHIP_Init();
 
#if DEBUG_MODE == DEBUG_SWO  
  setupSWO();  
#endif
  
  initCMU();
  
  GPIO_PinModeSet(LED_PORT, LED_PIN, gpioModePushPull, 0);
  
  if (SysTick_Config(CMU_ClockFreqGet(cmuClock_CORE) / 1000)) while (1) ;  
  
#if DEBUG_MODE == DEBUG_LEUART
  initLEUART(14400);
#endif

  initSPI();

#if DEBUG_MODE != DEBUG_NO
  printf("HF Clock = %d\r\n",CMU_ClockFreqGet(cmuClock_HF));
  printf("CORE Clock = %d\r\n",CMU_ClockFreqGet(cmuClock_CORE));
  printf("CORELE Clock = %d\r\n",CMU_ClockFreqGet(cmuClock_CORELE));
  printf("HFPER Clock = %d\r\n",CMU_ClockFreqGet(cmuClock_HFPER));
#endif
  
#if _WIZCHIP_IO_MODE_ == _WIZCHIP_IO_MODE_SPI_VDM_  
  reg_wizchip_cs_cbfunc(spiCSlow, spiCShigh);
#else
  reg_wizchip_cs_cbfunc(spiCSlow, spiCSlow);
#endif    
  reg_wizchip_spi_cbfunc(spiRecvByte,spiSendByte);
  
  /* No comment the below statement when SPI shared with the other devices */
  //reg_wizchip_cris_cbfunc((void (*)())INT_Disable,(void (*)()) INT_Enable);
  
  /* WIZCHIP SOCKET Buffer initialize */
  if(ctlwizchip(CW_INIT_WIZCHIP,(void*)memsize) == -1)
  {
     #if DEBUG_MODE != DEBUG_NO    
       printf("WIZCHIP Initialized fail.\r\n");
     #endif
     while(1);
  }
  
  /* PHY link status check */
  do
  {
     if(ctlwizchip(CW_GET_PHYLINK, (void*)&tmp) == -1)
     {
     #if DEBUG_MODE != DEBUG_NO
        printf("Unknown PHY Link stauts.\r\n");
     #endif
     }
  }while(tmp == PHY_LINK_OFF);

  /*******************************/
  /* WIZnet W5500 Code Examples  */
  /* DHCP test                   */
  /*******************************/
  /* Main loop */
  
  // must be set the default mac before DHCP started.
  setSHAR(gWIZNETINFO.mac);   
  
  DHCP_init(SOCK_DHCP, gDATABUF);
  // if you want defiffent action instead defalut ip assign,update, conflict, 
  // if cbfunc == 0, act as default.
  reg_dhcp_cbfunc(my_ip_assign,my_ip_assign,my_ip_conflict);  
  
  prevTick = msTicks;
  
  while(1)
  {
      switch(DHCP_run())
      {
      case DHCP_IP_ASSIGN:
      case DHCP_IP_CHANGED:
         /* If this block empty, act with default_ip_assign & default_ip_update  */
         //
         // This example calls the registered 'my_ip_assign' in the two case.
         //
         // Add to ...
         //
         break;
      case DHCP_IP_LEASED:
         //
         // TO DO YOUR NETWORK APPs.
         //
         break;
      case DHCP_FAILED:
         /* ===== Example pseudo code =====  */
         // The below code can be replaced your code or omitted.
         // if omitted, retry to process DHCP
         my_dhcp_retry++;
         if(my_dhcp_retry > MY_MAX_DHCP_RETRY)
         {
         #if DEBUG_MODE != DEBUG_NO
            printf(">> DHCP %d Failed\r\n",my_dhcp_retry);
         #endif
            my_dhcp_retry = 0;
            DHCP_stop();      // if restart, recall DHCP_init()
            network_init();   // apply the default static network
         }
         break;
      default:
         break;
      }
      /* User LED Toggle every 1s */
      if((msTicks - prevTick) > 1000)
      {
      prevTick = msTicks;
      if ( GPIO_PinOutGet(LED_PORT, LED_PIN) )
        GPIO_PinOutClear(LED_PORT, LED_PIN);
      else
        GPIO_PinOutSet(LED_PORT, LED_PIN);
      }
   }
}
