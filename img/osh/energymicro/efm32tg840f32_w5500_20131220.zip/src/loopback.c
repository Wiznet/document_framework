/*
 *****************************************************************************
 * @file
 * @brief Loopback TCP server & UDP (USART)
 *   For example using WIZCHIP's ioLibrary BSD version
 * @author WIZnet co, LTD.
 *
 *****************************************************************************
 */
#include "bsp_tg840.h"
#include "Ethernet/socket.h"

/*****************************************************************************
 * @brief Loopback TCP Server Test Example Code using ioLibrary_BSD			 
 *****************************************************************************/
int32_t loopback_tcps(uint8_t sn, uint8_t* buf, uint16_t port)
{
   int32_t ret;
   uint16_t size = 0, sentsize=0;
   switch(getSn_SR(sn))
   {
      case SOCK_ESTABLISHED :
         if(getSn_IR(sn) & Sn_IR_CON)
         {
         #if DEBUG_MODE != DEBUG_NO
            printf("%d:Connected\r\n",sn);
         #endif
            setSn_IR(sn,Sn_IR_CON);
         }
         if((size = getSn_RX_RSR(sn)) > 0)
         {
            if(size > DATA_BUF_SIZE) size = DATA_BUF_SIZE;
            ret = recv(sn,buf,size);
            if(ret <= 0) return ret;
            sentsize = 0;
            while(size != sentsize)
            {
               ret = send(sn,buf+sentsize,size-sentsize);
               if(ret < 0)
               {
                  close(sn);
                  return ret;
               }
               sentsize += ret; // Don't care SOCKERR_BUSY, because it is zero.
            }
         }
         break;
      case SOCK_CLOSE_WAIT :
         #if DEBUG_MODE != DEBUG_NO        
           printf("%d:CloseWait\r\n",sn);
         #endif
         if((ret=disconnect(sn)) != SOCK_OK) return ret;
         #if DEBUG_MODE != DEBUG_NO
           printf("%d:Closed\r\n",sn);
         #endif
         break;
      case SOCK_INIT :
         #if DEBUG_MODE != DEBUG_NO
    	   printf("%d:Listen, port [%d]\r\n",sn, port);
         #endif
         if( (ret = listen(sn)) != SOCK_OK) return ret;
         break;
      case SOCK_CLOSED:
         if((ret=socket(sn,Sn_MR_TCP,port,0x00)) != sn)
            return ret;
         #if DEBUG_MODE != DEBUG_NO
           printf("%d:Loopback TCP Server(%d) Start\r\n",sn,port);         
         #endif
         break;
      default:
         break;
   }
   return 1;
}

/*****************************************************************************
 * @brief Loopback UDP Test Example Code using ioLibrary_BSD			 
 *****************************************************************************/
int32_t loopback_udps(uint8_t sn, uint8_t* buf, uint16_t port)
{
   int32_t  ret;
   uint16_t size, sentsize;
   uint8_t  destip[4];
   uint16_t destport;
   //uint8_t  packinfo = 0;
   switch(getSn_SR(sn))
   {
      case SOCK_UDP :
         if((size = getSn_RX_RSR(sn)) > 0)
         {
            if(size > DATA_BUF_SIZE) size = DATA_BUF_SIZE;
            ret = recvfrom(sn,buf,size,destip,(uint16_t*)&destport);
            if(ret <= 0)
            {
            #if DEBUG_MODE != DEBUG_NO
               printf("%d: recvfrom error. %ld\r\n",sn,ret);
            #endif
               return ret;
            }
            size = (uint16_t) ret;
            sentsize = 0;
            while(sentsize != size)
            {
               ret = sendto(sn,buf+sentsize,size-sentsize,destip,destport);
               if(ret < 0)
               {
               #if DEBUG_MODE != DEBUG_NO
                  printf("%d: sendto error. %ld\r\n",sn,ret);
               #endif
                  return ret;
               }
               sentsize += ret; // Don't care SOCKERR_BUSY, because it is zero.
            }
         }
         break;
      case SOCK_CLOSED:
         #if DEBUG_MODE != DEBUG_NO
           printf("%d:Loopback UDP(%d) Start\r\n",sn,port);
         #endif
         if((ret=socket(sn,Sn_MR_UDP,port,0x00)) != sn)
            return ret;
         break;
      default :
         break;
   }
   return 1;
}

