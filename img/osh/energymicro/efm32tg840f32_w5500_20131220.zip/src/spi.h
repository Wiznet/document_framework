/*
 *****************************************************************************
 * @file
 * @brief SPI receiver/transmitter (USART)
 *   Peripheral SPI API
 * @author WIZnet co, LTD.
 *
 *****************************************************************************
 */
#ifndef __SPI_H__
#define __SPI_H__

/* USART used for SPI access */
#define SPI_USART                 USART1
#define SPI_USART_ROUTE_LOCATION  USART_ROUTE_LOCATION_LOC1
#define SPI_CLK                   cmuClock_USART1

/* GPIO pins used for SPI communication. */
#define SPI_MOSI_PIN        0
#define SPI_MOSI_PORT       gpioPortD
#define SPI_MISO_PIN        1
#define SPI_MISO_PORT       gpioPortD
#define SPI_CLK_PIN         2
#define SPI_CLK_PORT        gpioPortD
#define SPI_CS_PIN          3
#define SPI_CS_PORT         gpioPortD

void    initSPI(void);
void    spiCSlow(void);
void    spiCShigh(void);
void    spiSendByte(uint8_t sendbyte);
uint8_t spiRecvByte(void);


#endif