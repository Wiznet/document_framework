/*
 *****************************************************************************
 * @file
 * @brief   Tiny Gecko BSP 
 * @details Assign PORT & PIN, Initialize Tiny Gecko.
 * @author  WIZnet co, LTD.
 *****************************************************************************
 */
#include "em_cmu.h"
#include "bsp_tg840.h"


#if DEBUG_MODE == DEBUG_LEUART
void initLEUART(uint32_t baud)
{
  /* Reseting and initializing LEUART1 */
  LEUART_Init_TypeDef leuartInit = LEUART_INIT_DEFAULT;
  leuartInit.baudrate = baud;
  
  LEUART_Reset(LEUART_USED);
  LEUART_Init(LEUART_USED, &leuartInit);

  /* Route LEUART1 TX pin to DMA location 0 */
  LEUART_USED->ROUTE = LEUART_ROUTE_TXPEN |
                       LEUART_LOCATION;

  /* Enable GPIO for LEUART1. TX is on D4 */
  GPIO_PinModeSet(LEUART_TX_PORT,                /* GPIO port */
                  LEUART_TX_PIN,                        /* GPIO port number */
                  gpioModePushPull,         /* Pin mode is set to push pull */
                  1);                       /* High idle state */
}

// Overriding for Retarget stdin & stdout to UART
int putchar(int outchar)
{
  LEUART_Tx(LEUART_USED, outchar);
  return outchar;
}


int getchar(void)
{
 return LEUART_Rx(LEUART_USED);
}

#elif DEBUG_MODE == DEBUG_SWO
void setupSWO(void)
{
  /* Enable GPIO Clock. */
  CMU->HFPERCLKEN0 |= CMU_HFPERCLKEN0_GPIO;
  /* Enable Serial wire output pin */
  GPIO->ROUTE |= GPIO_ROUTE_SWOPEN;
#if defined(_EFM32_GIANT_FAMILY) || defined(_EFM32_WONDER_FAMILY) || defined(_EFM32_LEOPARD_FAMILY)
  /* Set location 0 */
  GPIO->ROUTE = (GPIO->ROUTE & ~(_GPIO_ROUTE_SWLOCATION_MASK)) | GPIO_ROUTE_SWLOCATION_LOC0;

  /* Enable output on pin - GPIO Port F, Pin 2 */
  GPIO->P[5].MODEL &= ~(_GPIO_P_MODEL_MODE2_MASK);
  GPIO->P[5].MODEL |= GPIO_P_MODEL_MODE2_PUSHPULL;
#else
  /* Set location 1 */
  GPIO->ROUTE = (GPIO->ROUTE & ~(_GPIO_ROUTE_SWLOCATION_MASK)) | GPIO_ROUTE_SWLOCATION_LOC1;
  /* Enable output on pin */
  GPIO->P[2].MODEH &= ~(_GPIO_P_MODEH_MODE15_MASK);
  GPIO->P[2].MODEH |= GPIO_P_MODEH_MODE15_PUSHPULL;
#endif
  /* Enable debug clock AUXHFRCO */
  CMU->OSCENCMD = CMU_OSCENCMD_AUXHFRCOEN;

  while(!(CMU->STATUS & CMU_STATUS_AUXHFRCORDY));

  /* Enable trace in core debug */
  CoreDebug->DHCSR |= 1;
  CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;

  /* Enable PC and IRQ sampling output */
  DWT->CTRL = 0x400113FF;
  /* Set TPIU prescaler to 16. */
  TPI->ACPR = 0xf;
  /* Set protocol to NRZ */
  TPI->SPPR = 2;
  /* Disable continuous formatting */
  TPI->FFCR = 0x100;
  /* Unlock ITM and output data */
  ITM->LAR = 0xC5ACCE55;
  ITM->TCR = 0x10009;
}
#endif

void initCMU(void)
{
  CMU_OscillatorEnable(cmuOsc_HFXO,true,true);

  CMU_OscillatorEnable(cmuOsc_LFXO,true,true);
  
  CMU_ClockSelectSet(cmuClock_HF,cmuSelect_HFXO);
  //CMU_ClockDivSet(cmuClock_HFPER, cmuClkDiv_2);
  CMU_ClockEnable(cmuClock_HFPER, true);

#if DEBUG_MODE != DEBUG_SWO  
  CMU_ClockSelectSet(cmuClock_LFB, cmuSelect_LFXO);//cmuSelect_CORELEDIV2);
  CMU_ClockEnable(cmuClock_CORELE, true);     /* Enable CORELE clock */
  CMU_ClockEnable(cmuClock_LEUART0, true);
#endif
  
  CMU_ClockEnable(cmuClock_GPIO, true);
  
}