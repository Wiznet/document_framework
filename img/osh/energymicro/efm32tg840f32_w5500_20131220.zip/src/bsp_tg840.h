/*
 *****************************************************************************
 * @file
 * @brief   Tiny Gecko BSP 
 * @details Assign PORT & PIN, Initialize Tiny Gecko.
 * @author  WIZnet co, LTD.
 *****************************************************************************
 */

#ifndef _BSP_TG840_H_
#define _BSP_TG840_H_

#include "em_gpio.h"
#include "em_leuart.h"
#include "em_usart.h"

/* DEBUG MODE */
#define DEBUG_NO        0
#define DEBUG_SWO       1
#define DEBUG_LEUART    2

#if defined(NDEBUG)
  #define DEBUG_MODE      DEBUG_NO
#else
  #include <stdio.h>
  #define DEBUG_MODE      DEBUG_SWO
  //#define DEBUG_MODE      DEBUG_LEUART
#endif

#define LEUART_USED     LEUART0
#define LEUART_TX_PORT  gpioPortD
#define LEUART_TX_PIN   4
#define LEUART_LOCATION LEUART_ROUTE_LOCATION_LOC0

/* GPIO pins used for USER LED. */
#define LED_PORT gpioPortD
#define LED_PIN  7

/* MAX DATA BUFFER SIZE */
#define DATA_BUF_SIZE   2048    // It is depend on Target System Memory

#if DEBUG_MODE != DEBUG_NO
  #if DEBUG_MODE == DEBUG_SWO
    void setupSWO(void);
  #elif DEBUG_MODE == DEBUG_LEUART
    void initLEUART(uint32_t baud);
  #endif
#endif

void initCMU(void);
    
#endif