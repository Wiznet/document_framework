/*
 *****************************************************************************
 * @file
 * @brief Loopback TCP server & UDP (USART)
 *   For example using WIZCHIP's ioLibrary BSD version
 * @author WIZnet co, LTD.
 *
 *****************************************************************************
 */
#ifndef __LOOPBACK_H__
#define __LOOPBACK_H__

int32_t loopback_tcps(uint8_t sn, uint8_t* buf, uint16_t port);
int32_t loopback_udps(uint8_t sn, uint8_t* buf, uint16_t port);

#endif