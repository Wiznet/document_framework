var searchData=
[
  ['basic_20i_2fo_20function',['Basic I/O function',['../group___basic___i_o__function.html',1,'']]],
  ['bus',['BUS',['../struct_____w_i_z_c_h_i_p.html#ab064e89493e9a83682779b47fd02168b',1,'__WIZCHIP']]]
];
