var struct_____w_i_z_c_h_i_p =
[
    [ "_CRIS", "struct_____w_i_z_c_h_i_p_1_1___c_r_i_s.html", "struct_____w_i_z_c_h_i_p_1_1___c_r_i_s" ],
    [ "_CS", "struct_____w_i_z_c_h_i_p_1_1___c_s.html", "struct_____w_i_z_c_h_i_p_1_1___c_s" ],
    [ "if_mode", "struct_____w_i_z_c_h_i_p.html#a32fec318d5bfa58b3ebd8493959a1b31", null ],
    [ "id", "struct_____w_i_z_c_h_i_p.html#a4b13df261e52fc02dc773a1eb70572b4", null ],
    [ "CRIS", "struct_____w_i_z_c_h_i_p.html#ae94e8a795064229659a267844aff02a6", null ],
    [ "CS", "struct_____w_i_z_c_h_i_p.html#a402f9b854611a764645391a1c83d1e5c", null ],
    [ "_read_byte", "struct_____w_i_z_c_h_i_p.html#a9e521ef1d076f988754da162a97f48ea", null ],
    [ "_write_byte", "struct_____w_i_z_c_h_i_p.html#af7a3e66e7c1c735fd3d0e882b252c6e5", null ],
    [ "BUS", "struct_____w_i_z_c_h_i_p.html#ab064e89493e9a83682779b47fd02168b", null ],
    [ "SPI", "struct_____w_i_z_c_h_i_p.html#a689f95ea6b39ac6481f0078358039d1a", null ],
    [ "IF", "struct_____w_i_z_c_h_i_p.html#a21eb19d5a7b7833ab9496cc74daa08a5", null ]
];