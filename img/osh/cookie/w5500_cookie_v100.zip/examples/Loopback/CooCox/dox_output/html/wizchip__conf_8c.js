var wizchip__conf_8c =
[
    [ "wizchip_cris_enter", "wizchip__conf_8c.html#a0670b3769d0093cff1d4539d0067c0f3", null ],
    [ "wizchip_cris_exit", "wizchip__conf_8c.html#a558a7118b574e41fd9edb3de0bbbd4f0", null ],
    [ "wizchip_cs_select", "wizchip__conf_8c.html#a244d1c94f43c6c4a6c0e5b17357e1f5c", null ],
    [ "wizchip_cs_deselect", "wizchip__conf_8c.html#aeed928f8cddb547702ee3937fadcb727", null ],
    [ "wizchip_bus_readbyte", "wizchip__conf_8c.html#ae6c3296f0b6471c9fb26399bd4bfaf40", null ],
    [ "wizchip_bus_writebyte", "wizchip__conf_8c.html#a72e190dec22638a14f5a6df75335f5b7", null ],
    [ "wizchip_spi_readbyte", "wizchip__conf_8c.html#aa2207654c49a9f57887feaf9921a05a9", null ],
    [ "wizchip_spi_writebyte", "wizchip__conf_8c.html#a4e493cf7e22451f15725d15891ad9b23", null ],
    [ "reg_wizchip_cris_cbfunc", "wizchip__conf_8c.html#a658e320e9c986ecab81857a8716b8b87", null ],
    [ "reg_wizchip_cs_cbfunc", "wizchip__conf_8c.html#a63208f3ad63e6290be0ed33705baa27e", null ],
    [ "reg_wizchip_bus_cbfunc", "wizchip__conf_8c.html#ae6ad00c6e026b8bf0d65d1db94f3a8bf", null ],
    [ "reg_wizchip_spi_cbfunc", "wizchip__conf_8c.html#ab8b1906597683424d5f599e6fd720386", null ],
    [ "WIZCHIP", "wizchip__conf_8c.html#ad0efd19f6465f2071d41dbf2a9090133", null ]
];