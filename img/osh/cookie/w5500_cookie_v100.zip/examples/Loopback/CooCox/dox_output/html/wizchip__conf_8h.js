var wizchip__conf_8h =
[
    [ "__WIZCHIP", "struct_____w_i_z_c_h_i_p.html", "struct_____w_i_z_c_h_i_p" ],
    [ "_CRIS", "struct_____w_i_z_c_h_i_p_1_1___c_r_i_s.html", "struct_____w_i_z_c_h_i_p_1_1___c_r_i_s" ],
    [ "_CS", "struct_____w_i_z_c_h_i_p_1_1___c_s.html", "struct_____w_i_z_c_h_i_p_1_1___c_s" ],
    [ "_WIZCHIP_", "wizchip__conf_8h.html#a716142232d6577dcb49c4a3f27c89fdd", null ],
    [ "_WIZCHIP_IO_BASE_", "wizchip__conf_8h.html#a96368b8e55bcca9d9b15b8b695331443", null ],
    [ "_WIZCHIP_IO_MODE_NONE_", "wizchip__conf_8h.html#a92092941e58af1e46aeca604a1d52017", null ],
    [ "_WIZCHIP_IO_MODE_BUS_", "wizchip__conf_8h.html#ab278798369281104991526236f5e1a40", null ],
    [ "_WIZCHIP_IO_MODE_SPI_", "wizchip__conf_8h.html#a6179151fb8739a740799328f4f2beaa8", null ],
    [ "_WIZCHIP_IO_MODE_BUS_DIR_", "wizchip__conf_8h.html#a640a909820498d82446aa1dc7f4307eb", null ],
    [ "_WIZCHIP_IO_MODE_BUS_INDIR_", "wizchip__conf_8h.html#a1acac79a10d2550d4387bd9506f8843f", null ],
    [ "_WIZCHIP_IO_MODE_SPI_VDM_", "wizchip__conf_8h.html#a87fae122f24f057f386f1e12b9a91eab", null ],
    [ "_WIZCHIP_IO_MODE_SPI_FDM_", "wizchip__conf_8h.html#a85505e996758563e203995e79522b035", null ],
    [ "_WIZCHIP_ID_", "wizchip__conf_8h.html#a205bfecb2fd9a65b896384de0e957e4b", null ],
    [ "_WIZCHIP_IO_MODE_", "wizchip__conf_8h.html#a564c20a8415e89b641b600bf4542e94c", null ],
    [ "_WIZCHIP_SOCK_NUM_", "wizchip__conf_8h.html#a70a4c5d01d3afb9fab3b6070ac27c857", null ],
    [ "_WIZCHIP", "wizchip__conf_8h.html#ac69f15a66bab10650b3834c758643066", null ],
    [ "reg_wizchip_cris_cbfunc", "wizchip__conf_8h.html#a658e320e9c986ecab81857a8716b8b87", null ],
    [ "reg_wizchip_cs_cbfunc", "wizchip__conf_8h.html#a63208f3ad63e6290be0ed33705baa27e", null ],
    [ "reg_wizchip_bus_cbfunc", "wizchip__conf_8h.html#ae6ad00c6e026b8bf0d65d1db94f3a8bf", null ],
    [ "reg_wizchip_spi_cbfunc", "wizchip__conf_8h.html#ab8b1906597683424d5f599e6fd720386", null ],
    [ "WIZCHIP", "wizchip__conf_8h.html#ad0efd19f6465f2071d41dbf2a9090133", null ]
];