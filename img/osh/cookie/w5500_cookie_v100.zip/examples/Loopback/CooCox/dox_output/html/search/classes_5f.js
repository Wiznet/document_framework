var searchData=
[
  ['_5f_5fwizchip',['__WIZCHIP',['../struct_____w_i_z_c_h_i_p.html',1,'']]],
  ['_5fcris',['_CRIS',['../struct_____w_i_z_c_h_i_p_1_1___c_r_i_s.html',1,'__WIZCHIP']]],
  ['_5fcs',['_CS',['../struct_____w_i_z_c_h_i_p_1_1___c_s.html',1,'__WIZCHIP']]]
];
