var searchData=
[
  ['spi',['SPI',['../struct_____w_i_z_c_h_i_p.html#a689f95ea6b39ac6481f0078358039d1a',1,'__WIZCHIP']]]
];
