var group___common__register__group =
[
    [ "MR", "group___common__register__group.html#ga9ecbd9f86f95534f1bcf71015d5ae81a", null ],
    [ "GAR", "group___common__register__group.html#ga4949d98617f16809c74f2382ebe9e2c8", null ],
    [ "SUBR", "group___common__register__group.html#ga49fe7cfa44021aa3ad5ba1f15f7809eb", null ],
    [ "SHAR", "group___common__register__group.html#ga2786df906e3569b2b578ecebfaabde15", null ],
    [ "SIPR", "group___common__register__group.html#gac1017606925e844389f81ccc7fc7799b", null ],
    [ "INTLEVEL", "group___common__register__group.html#ga44cf25d713df4e47aa2e2129a80d2d81", null ],
    [ "IR", "group___common__register__group.html#ga68e22635ff207d8ca10459833856bd75", null ],
    [ "IMR", "group___common__register__group.html#ga30fd4faef73fc23b1f09a0bd643455c1", null ],
    [ "SIR", "group___common__register__group.html#ga3afb7d25f6248e33771faa1bff574d4a", null ],
    [ "SIMR", "group___common__register__group.html#gaf08cda69b65a0f84ca02edfb131ac82a", null ],
    [ "RTR", "group___common__register__group.html#ga8f14d04b8bcaf04226f4fe5c112b60aa", null ],
    [ "RCR", "group___common__register__group.html#ga37adcf98d04632a70fc1e3aff01be01e", null ],
    [ "PTIMER", "group___common__register__group.html#ga29dd564a4c90f2efa7cc7ee03ddba7d5", null ],
    [ "PMAGIC", "group___common__register__group.html#ga162ee07110c2c639f7fa2de585d65e23", null ],
    [ "PHAR", "group___common__register__group.html#ga3ed5558b8cfbba78bf63fb2b8c907c38", null ],
    [ "PSID", "group___common__register__group.html#ga0220d54b2e7b00e196a7010a1cb25a58", null ],
    [ "PMRU", "group___common__register__group.html#ga5d3d5eb120bed5e04464780d82ca5f2e", null ],
    [ "UIPR", "group___common__register__group.html#ga6ce7e2945cd7d83c6f8c7f97bd9c27b0", null ],
    [ "UPORTR", "group___common__register__group.html#gaab2aaf717d74299303b89630ee2c7ecb", null ],
    [ "PHYCFGR", "group___common__register__group.html#ga7cc24f47ca8dcb311ade3a0bcbd74eaf", null ],
    [ "VERSIONR", "group___common__register__group.html#ga4e029565150c3aca3ba16b2ae3ea8b4e", null ]
];