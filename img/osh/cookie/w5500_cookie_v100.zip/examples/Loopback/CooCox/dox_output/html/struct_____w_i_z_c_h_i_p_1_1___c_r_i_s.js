var struct_____w_i_z_c_h_i_p_1_1___c_r_i_s =
[
    [ "_enter", "struct_____w_i_z_c_h_i_p_1_1___c_r_i_s.html#a4b960e85f7703705795f4965252c8fb7", null ],
    [ "_exit", "struct_____w_i_z_c_h_i_p_1_1___c_r_i_s.html#af41262773a26ab77f20c2559830e6fbb", null ]
];