var globals_dup =
[
    [ "_", "globals.html", null ],
    [ "g", "globals_0x67.html", null ],
    [ "i", "globals_0x69.html", null ],
    [ "m", "globals_0x6d.html", null ],
    [ "p", "globals_0x70.html", null ],
    [ "r", "globals_0x72.html", null ],
    [ "s", "globals_0x73.html", null ],
    [ "u", "globals_0x75.html", null ],
    [ "v", "globals_0x76.html", null ],
    [ "w", "globals_0x77.html", null ]
];