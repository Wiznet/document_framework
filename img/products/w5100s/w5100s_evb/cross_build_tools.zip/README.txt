This folder contains the original versions of the build tools 
packed within the Sourcery CodeBench Lite 2013.05-23 archive
for Windows:

  arm-2013.05-23-arm-none-eabi-i686-mingw32.tar.bz2

Please use them only if you accept the terms of the 
Sourcery CodeBench Lite License Agreement, attached.

In addition, an echo.exe program was added, to avoid the
initial discovery error that occurs on Windows.
  
