#include <stdio.h>
#include "HAL_Config.h"
#include "wizchip_conf.h"
#include "inttypes.h"
#include "stm32f10x_gpio.h"
#include "stm32f10x_exti.h"
#include "W5100SRelFunctions.h"
#include "serialCommand.h"
#include "PPPoE.h"

//#define SERVER
//#define CLIENT
#define PPPOE

wiz_NetInfo gWIZNETINFO = { .mac = {0x00,0x08,0xdc,0x78,0x91,0x72},
							.ip = {192,168,127,91},
							.sn = {255, 255, 255, 0},
							.gw = {192, 168, 11, 1},
							.dns = {168, 126, 63, 1},
							.dhcp = NETINFO_STATIC};

#define ETH_MAX_BUF_SIZE	2048

unsigned char ethBuf0[ETH_MAX_BUF_SIZE];
unsigned char ethBuf1[ETH_MAX_BUF_SIZE];
unsigned char ethBuf2[ETH_MAX_BUF_SIZE];
unsigned char ethBuf3[ETH_MAX_BUF_SIZE];

uint8_t bLoopback = 1;
uint8_t bRandomPacket = 0;
uint8_t bAnyPacket = 0;
uint16_t pack_size = 0;

uint8_t pppoe_id[] = "wiznet";
uint8_t pppoe_id_len = 6;
uint8_t pppoe_pw[] = "wiznet1206";
uint8_t pppoe_pw_len = 10;
uint8_t pppoe_ip[4] = {0,};
uint16_t pppoe_retry_count = 0;
extern uint16_t g_pppoe_retry_count;

void print_network_information(void);

int main(void)
{
	volatile int i;
	volatile int j,k;

	uint8_t dest_ip[4]={192,168,77,97};
	uint8_t tmp;
	int32_t ret = 0;
	uint8_t memsize[2][8] = {{2,2,2,2,2,2,2,2},{2,2,2,2,2,2,2,2}};
	uint16_t size;
	uint8_t str[15];

	gpioInitialize();
//	W5100SModeSelect(); //PPPoE
	usartInitialize();
	timerInitialize();
	printf("System start.\r\n");




#if _WIZCHIP_IO_MODE_ & _WIZCHIP_IO_MODE_SPI_
	/* SPI method callback registration */
	reg_wizchip_spi_cbfunc(spiReadByte, spiWriteByte);
	/* CS function register */
	reg_wizchip_cs_cbfunc(csEnable,csDisable);
#else
	/* Indirect bus method callback registration */
	//reg_wizchip_bus_cbfunc(busReadByte, busWriteByte);
#endif

#if _WIZCHIP_IO_MODE_ == _WIZCHIP_IO_MODE_BUS_INDIR_
	FSMCInitialize();
#else
	spiInitailize();
#endif
	resetAssert();
	delay(10);
	resetDeassert();
	delay(10);
	W5100SInitialze();
	printf("\r\nCHIP Version: %02x\r\n", getVER());
//
//	//FSMCHighSpeed();
//	delay(10);
//	printf(" PHYMODE:%02x\r\n",getPHYSR0());
//	printf(" CHIP Version: %02x\r\n", getVER());
	wizchip_setnetinfo(&gWIZNETINFO);

	printf("Register value after W5100S initialize!\r\n");
	register_read();
	print_network_information();

	//PPPoE
	setIMR(IR_PPPoE);
	while(1)
	{
		ret = ppp_start(ethBuf0);//ppp start function
		if(ret == PPP_SUCCESS || pppoe_retry_count > PPP_MAX_RETRY_COUNT) break;	// PPPoE Connected or connect failed by over retry count
   	}
	if(ret == PPP_SUCCESS)//1 : success
	{
		printf("\r\n<<<< PPPoE Success >>>>\r\n");
		printf("Assigned IP address : %.3u.%.3u.%.3u.%.3u\r\n", pppoe_ip[0], pppoe_ip[1], pppoe_ip[2], pppoe_ip[3]);

	   	printf( "\r\n==================================================\r\n");
	   	printf( "    AFTER PPPoE, Net Configuration Information        \r\n");
	   	printf( "==================================================\r\n");


	   	getSHAR(str);
	   	printf( "MAC address  : %x:%x:%x:%x:%x:%x\r\n", str[0], str[1], str[2], str[3], str[4], str[5] );
	   	getSUBR(str);
	   	printf( "SUBNET MASK  : %.3u.%.3u.%.3u.%.3u\r\n", str[0], str[1], str[2], str[3] );
	   	getGAR(str);
	   	printf( "G/W IP ADDRESS : %.3u.%.3u.%.3u.%.3u\r\n",str[0], str[1], str[2], str[3]);
	   	getSIPR(str);
	   	printf( "SOURCE IP ADDRESS : %.3u.%.3u.%.3u.%.3u\r\n\r\n", str[0], str[1], str[2], str[3]);
	}

	while(1)
    {
//		loopback_tcps(0,ethBuf0,50000);
		//PPPoE
#if	defined(SERVER)
		setTMSR(SERVER_TMSR);
		setRMSR(SERVER_RMSR);
//		loopback_tcps(0, ethBuf0, 30000);
//		loopback_tcps(1, ethBuf1, 30001);
//		loopback_udps(2, ethBuf2, 30002);
//		loopback_udps(3, ethBuf3, 30003);
//		loopback_tcps(2, ethBuf2, 30002);
//		loopback_tcps(3, ethBuf3, 30003);

		PatternTest(0, dest_ip, 30000, ethBuf0, ethBuf4, 1);
		PatternTest(1, dest_ip, 30001, ethBuf1, ethBuf5, 1);
		PatternTest(2, dest_ip, 30002, ethBuf2, ethBuf6, 1);
		PatternTest(3, dest_ip, 30003, ethBuf3, ethBuf7, 1);

#elif defined(CLIENT)
		setTMSR(CLIENT_TMSR);
		setRMSR(CLIENT_RMSR);

//		loopback_tcpc(0, ethBuf0, dest_ip, 30000);
//		loopback_tcpc(1, ethBuf1, dest_ip, 30001);
//		loopback_tcpc(2, ethBuf2, dest_ip, 30002);
//		loopback_tcpc(3, ethBuf3, dest_ip, 30003);

		PatternTest(0, dest_ip, 30000, ethBuf0, ethBuf4, 0);
		PatternTest(1, dest_ip, 30001, ethBuf1, ethBuf5, 0);
		PatternTest(2, dest_ip, 30002, ethBuf2, ethBuf6, 0);
		PatternTest(3, dest_ip, 30003, ethBuf3, ethBuf7, 0);

//		PatternTest(0, dest_ip, 5000, ethBuf0, 0, 0);
//		setIMR(0x40);
//		PatternTest_udp(0, dest_ip, 50000, ethBuf0, 0, 0);

#elif defined(PPPOE)
	    		/*******************************/
		/* WIZnet W5500 Code Examples  */
		/* TCPS/UDPS Loopback test     */
		/*******************************/


		// Loopback Test
		// TCP server loopback test
		if( (ret = loopback_tcps(1, ethBuf0, 5000)) < 0) {
			printf("SOCKET ERROR : %ld\r\n", ret);
		}

		// UDP server loopback test
		if( (ret = loopback_udps(2, ethBuf0, 3000)) < 0) {
			printf("SOCKET ERROR : %ld\r\n", ret);
		}

		if(getIR()&&IR_PPPoE)
			printf("PPPoE Interrupt!\r\n");
#else

#endif
    }
}

void delay(unsigned int count)
{
	int temp;
	temp = count + TIM2_gettimer();
	while(temp > TIM2_gettimer()){}
}

void print_network_information(void)
{
	wizchip_getnetinfo(&gWIZNETINFO);
	printf("Mac address: %02x:%02x:%02x:%02x:%02x:%02x\n\r",gWIZNETINFO.mac[0],gWIZNETINFO.mac[1],gWIZNETINFO.mac[2],gWIZNETINFO.mac[3],gWIZNETINFO.mac[4],gWIZNETINFO.mac[5]);
	printf("IP address : %d.%d.%d.%d\n\r",gWIZNETINFO.ip[0],gWIZNETINFO.ip[1],gWIZNETINFO.ip[2],gWIZNETINFO.ip[3]);
	printf("SM Mask	   : %d.%d.%d.%d\n\r",gWIZNETINFO.sn[0],gWIZNETINFO.sn[1],gWIZNETINFO.sn[2],gWIZNETINFO.sn[3]);
	printf("Gate way   : %d.%d.%d.%d\n\r",gWIZNETINFO.gw[0],gWIZNETINFO.gw[1],gWIZNETINFO.gw[2],gWIZNETINFO.gw[3]);
	printf("DNS Server : %d.%d.%d.%d\n\r",gWIZNETINFO.dns[0],gWIZNETINFO.dns[1],gWIZNETINFO.dns[2],gWIZNETINFO.dns[3]);
}
