#include <stdio.h>
#include "loopback.h"
#include "socket.h"
#include "wizchip_conf.h"
#if LOOPBACK_MODE == LOOPBACK_MAIN_NOBLCOK
#define _LOOPBACK_DEBUG_



#define packet_size 1024

int32_t loopback_tcps(uint8_t sn, uint8_t* buf, uint16_t port)
{
   int32_t ret,i;
   uint16_t size = 0, sentsize=0;
#ifdef _LOOPBACK_DEBUG_
   uint8_t destip[4];
   uint16_t destport;
#endif

   switch(getSn_SR(sn))
   {
      case SOCK_ESTABLISHED :
         if(getSn_IR(sn) & Sn_IR_CON)
         {
#ifdef _LOOPBACK_DEBUG_
			getSn_DIPR(sn, destip);
			destport = getSn_DPORT(sn);

			printf("%d:Connected - %d.%d.%d.%d : %d\r\n",sn, destip[0], destip[1], destip[2], destip[3], destport);
#endif
			setSn_IR(sn,Sn_IR_CON);
         }

		 if((size = getSn_RX_RSR(sn)) > 0) // Don't need to check SOCKERR_BUSY because it doesn't not occur.
         {
			if(size > DATA_BUF_SIZE) size = DATA_BUF_SIZE;
			ret = recv(sn, buf, size);

			if(ret <= 0) {
				printf("RECV ERR : %d\r\n", ret);
				while(1);
				return ret;      // check SOCKERR_BUSY & SOCKERR_XXX. For showing the occurrence of SOCKERR_BUSY.
			}
			sentsize = 0;

			while(size != sentsize)
			{
				printf(".");
				ret = send(sn, buf+sentsize, size-sentsize);
				if(ret < 0)
				{
					printf("SEND ERR : %d\r\n", ret);
					while(1);
					close(sn);
					return ret;
				}
				sentsize += ret; // Don't care SOCKERR_BUSY, because it is zero.
			}
         }

		 //else printf("*");
         break;
      case SOCK_CLOSE_WAIT :
#ifdef _LOOPBACK_DEBUG_
         printf("%d:CloseWait\r\n",sn);
#endif
         if((ret = disconnect(sn)) != SOCK_OK) return ret;
#ifdef _LOOPBACK_DEBUG_
         printf("%d:Socket Closed\r\n", sn);
#endif
         break;
      case SOCK_INIT :
#ifdef _LOOPBACK_DEBUG_
    	 printf("%d:Listen, TCP server loopback, port [%d]\r\n", sn, port);
#endif
         if( (ret = listen(sn)) != SOCK_OK) return ret;
         break;
      case SOCK_CLOSED:
          if(getSn_IR(sn) &0x08) {
          printf("Sn_IR : %x\r\n", getSn_IR(sn));}

#ifdef _LOOPBACK_DEBUG_
         printf("%d:Socket closed!\r\n",sn);
         //register_read();
         //socket_register_read(sn);
#endif
         if((ret = socket(sn, Sn_MR_TCP, port, /*0x20*/0)) != sn) return ret;
         //socket_register_read(sn);
#ifdef _LOOPBACK_DEBUG_
         printf("%d:Socket opened!\r\n",sn);
#endif
         break;
      default:
         break;
   }
   return 1;
}


//long  total_send_size =  0;

int32_t loopback_tcpc(uint8_t sn, uint8_t* buf, uint8_t* destip, uint16_t destport)
{
   int32_t ret; // return value for SOCK_ERRORs
   uint16_t size = 0, sentsize=0;
   uint16_t any_port = 	50000;

   // Socket Status Transitions
   // Check the W5500 Socket n status register (Sn_SR, The 'Sn_SR' controlled by Sn_CR command or Packet send/recv status)
   switch(getSn_SR(sn))
   {
      case SOCK_ESTABLISHED :
         if(getSn_IR(sn) & Sn_IR_CON)	// Socket n interrupt register mask; TCP CON interrupt = connection with peer is successful
         {
#ifdef _LOOPBACK_DEBUG_
			printf("%d:Connected to - %d.%d.%d.%d : %d\r\n",sn, destip[0], destip[1], destip[2], destip[3], destport);
#endif
			setSn_IR(sn, Sn_IR_CON);  // this interrupt should be write the bit cleared to '1
			printf("%d:connect interrupt clear\r\n", sn);
//			ret=send(sn, buf, 2048*4);
			ret=send(sn, buf, 2048);
			//total_send_size += ret;
			printf("%d: ret value : %d\r\n",sn, ret);

         }


         //send
		 if((size = getSn_RX_RSR(sn)) > 0) // Don't need to check SOCKERR_BUSY because it doesn't not occur.
         {
			if(size > DATA_BUF_SIZE) size = DATA_BUF_SIZE;
			ret = recv(sn, buf, size);

			if(ret <= 0) {
				printf("RECV ERR : %d\r\n", ret);
				while(1);
				return ret;      // check SOCKERR_BUSY & SOCKERR_XXX. For showing the occurrence of SOCKERR_BUSY.
			}
			sentsize = 0;

			while(size != sentsize)
			{
				printf(".");
				ret = send(sn, buf+sentsize, size-sentsize);

				if(ret < 0)
				{
					printf("SEND ERR : %d\r\n", ret);
					while(1);
					close(sn);
					return ret;
				}
				sentsize += ret; // Don't care SOCKERR_BUSY, because it is zero.
			}
         }
		 else printf("*");
         break;

      case SOCK_CLOSE_WAIT :
#ifdef _LOOPBACK_DEBUG_
         //printf("%d:CloseWait\r\n",sn);
#endif
         if((ret=disconnect(sn)) != SOCK_OK) return ret;
#ifdef _LOOPBACK_DEBUG_
         printf("%d:Socket Closed\r\n", sn);
#endif
         break;

      case SOCK_INIT :
#ifdef _LOOPBACK_DEBUG_
    	 printf("%d:Try to connect to the %d.%d.%d.%d : %d\r\n", sn, destip[0], destip[1], destip[2], destip[3], destport);
#endif
    	 if( (ret = connect(sn, destip, destport)) != SOCK_OK) return ret;	//	Try to TCP connect to the TCP server (destination)
         break;

      case SOCK_CLOSED:
    	  close(sn);
    	  if((ret=socket(sn, Sn_MR_TCP, any_port++, 0x00)) != sn) return ret; // TCP socket open with 'any_port' port number
#ifdef _LOOPBACK_DEBUG_
    	 //printf("%d:TCP client loopback start\r\n",sn);
         //printf("%d:Socket opened\r\n",sn);
#endif
         break;
      default:
         break;
   }
   return 1;
}


int32_t loopback_udps(uint8_t sn, uint8_t* buf, uint16_t port)
{
   int32_t  ret;
   uint16_t size, sentsize;
   uint8_t  destip[4];
   uint16_t destport;

   switch(getSn_SR(sn))
   {
      case SOCK_UDP :
         if((size = getSn_RX_RSR(sn)) > 0)
         {
            if(size > DATA_BUF_SIZE) size = DATA_BUF_SIZE;
            ret = recvfrom(sn, buf, size, destip, (uint16_t*)&destport);
            //printf("%d:recv from %d.%d.%d.%d : %d\r\n", sn, destip[0], destip[1], destip[2], destip[3], destport);


            if(ret <= 0)
            {
#ifdef _LOOPBACK_DEBUG_
               printf("%d: recvfrom error. %ld\r\n",sn,ret);
#endif
               return ret;
            }
            size = (uint16_t) ret;
            sentsize = 0;
            while(sentsize != size)
            {
               ret = sendto(sn, buf+sentsize, size-sentsize, destip, destport);
               if(ret < 0)
               {
#ifdef _LOOPBACK_DEBUG_
                  printf("%d: sendto error. %ld\r\n",sn,ret);
#endif
                  return ret;
               }
               sentsize += ret; // Don't care SOCKERR_BUSY, because it is zero.
            }
         }
         break;
      case SOCK_CLOSED:
#ifdef _LOOPBACK_DEBUG_
         //printf("%d:UDP loopback start\r\n",sn);
#endif
         if((ret = socket(sn, Sn_MR_UDP, port, 0x00)) != sn)
            return ret;
#ifdef _LOOPBACK_DEBUG_
         printf("%d:Opened, UDP loopback, port [%d]\r\n", sn, port);
#endif
         break;
      default :
         break;
   }
   return 1;
}


int32_t RandomPacketGen(uint8_t* buf, uint16_t size)
{
   int32_t  ret;

   if(size > 1514 ) size = 1514;
   switch(getSn_SR(0))
   {
      case SOCK_MACRAW :
		   ret = sendto(0, buf, size, 0, 0);
		   if(ret < 0)
		   {
#ifdef _LOOPBACK_DEBUG_
			  printf("%d: sendto error. %ld\r\n",0,ret);
#endif
			  return ret;
		   }
		   break;
      case SOCK_CLOSED:
#ifdef _LOOPBACK_DEBUG_
         //printf("%d:UDP loopback start\r\n",sn);
#endif
         if((ret = socket(0, Sn_MR_MACRAW, 0, 0x00)) != 0)
            return ret;
#ifdef _LOOPBACK_DEBUG_
         printf("%d:Opened with MacRAW, Random(Any) Packet Generator\r\n", 0);
#endif
         break;
      default :
         break;
   }
   return 1;
}


void register_read(void)
{
	int i;
	printf("----register read----\r\n");
	printf("Address | ");
	for(i = 0 ; i < 16 ; i++)
	  printf("%02x ",i);
	printf("\r\n---------------------------------------------------------");
	for(i = 0 ; i < 0x0090 ; i++)
	{
	  if(i%16 == 0) printf("\r\n  %04x  | ", i);
	  printf("%02x ",WIZCHIP_READ(i));
	}
	printf("\r\n");
}

void socket_register_read(uint8_t sn)
{
	int i;
	printf("----Socket %d register read----\r\n", sn);
	printf("Address | ");
	for(i = 0 ; i < 16 ; i++)
	  printf("%02x ",i);
	printf("\r\n---------------------------------------------------------");
	for(i = 0x400+(sn*(0x100)) ; i < 0x400+(sn*(0x100)+0x35) ; i++)
	{
	  if(i%16 == 0) printf("\r\n0x%04x  | ", i);
	  printf("%02x ",WIZCHIP_READ(i));
	}
	printf("\r\n");
}



// WXYZ : SEQNUM 4092(Z+n)
void GenTestPattern(uint8_t sn, uint8_t* buf, uint32_t len)
{
        static uint32_t seqnum = 0;
        static uint32_t total_gen_pattern_size = 0;
        static volatile uint8_t idx[4]  = {0,};
        uint16_t volatile i = 0;

        while(len > 0)
        {
        	switch(total_gen_pattern_size % packet_size)
        	{
        	case 0:
        		buf[i] = (uint8_t)(seqnum >> 24);
        		break;
        	case 1:
                buf[i] = (uint8_t)(seqnum >> 16);
        		break;
        	case 2:
                buf[i] = (uint8_t)(seqnum >> 8);
        		break;
        	case 3:
        		buf[i] = (uint8_t)seqnum;
                idx[sn] = buf[i];
//        		printf("SEND : SEQ(%08X), idx[sn](%02X)\r\n",seqnum,idx[sn]);
                //printf("SEND idx[sn] : %02X\r\n",idx[sn]);
                seqnum++;
//                if(seqnum>1024) {
//                	close(0);
//                	while(1);
//                }
                break;
        	default:
                buf[i] = idx[sn]++;
                break;
               }
        	i++; len--;
        	total_gen_pattern_size++;
        }
}

uint8_t CheckTestPattern(uint8_t sn, uint8_t* buf, uint32_t len)
{
        static uint32_t seqnum = 0;
        static uint32_t total_check_pattern_size = 0;
        static volatile uint8_t  idx[4]  = {0,};
        volatile uint16_t i = 0;
        uint16_t j = 0;
        uint8_t ret=0;
        while(len > 0)
        {
        	switch(total_check_pattern_size % packet_size)
        	{
        	case 0:
        		if((uint8_t)(seqnum >> 24) != buf[i]) ret = 1;
        		break;
        	case 1:
        		if((uint8_t)(seqnum >> 16) != buf[i]) ret = 1;
        		break;
        	case 2:
        		if((uint8_t)(seqnum >> 8) != buf[i])  ret = 1;
        		break;
        	case 3:
        		idx[sn] = (uint8_t)seqnum;
        		if(idx[sn] != buf[i]) ret = 1;
        		else
        		{
//        			printf("RECV : SEQ(%08X), idx[sn](%02X)\r\n",seqnum, idx[sn]);
        			seqnum++;
        		}
        		break;
        	default:
                if(buf[i] != idx[sn])
                {
                       printf("Error PATTERN : Valid(0x%02X) != Invalid[%d](0x%02X)\r\n",idx[sn],i%packet_size,buf[i]);
                       printf("%02X ",buf[i]);
                       for(j=1; j < len; j++)
                       {
                     	  if(i % 16 != 0) printf("%02X ",buf[i]);
                     	  else      printf("%02X \r\n",buf[i]);
                       }
                       return 2;
                }
        		idx[sn]++;
        		break;
            }
            if(ret == 1)
            {
				printf("Error SEQNUM : Valid(0x%08X) != Invalid[%d](0x%02X)\r\n",seqnum,i%packet_size,buf[i]);
				return 1;
            }
            total_check_pattern_size++;
            len--; i++;
        }
        return 0;  // SUCCESS

}


int8_t send_TestPattern(uint8_t sn, uint8_t* buf)
{
        static uint32_t total_send_size = 0;
        static uint16_t remaind_send_size = 0;
        static uint16_t total_sent_size = 0;
        uint16_t sent_size;

        if(remaind_send_size == 0)
        {
               remaind_send_size = getSn_TX_FSR(sn);
               if(remaind_send_size !=0)
            	   GenTestPattern(sn, buf, remaind_send_size);
               total_sent_size = 0;
        }
        if(remaind_send_size > 0)
        {
               sent_size = send(sn, buf+total_sent_size,remaind_send_size);
//               printf("sent_size : %d\r\n", sent_size);
            if(sent_size < 0) return -1;
            total_sent_size += sent_size;
            remaind_send_size -= sent_size;
        }
        return 0;
}

int8_t send_TestPattern_udp(uint8_t sn, uint8_t* buf, uint8_t* destip, uint16_t destport)
{
        static uint32_t total_send_size = 0;
        static uint16_t remaind_send_size = 0;
        static uint16_t total_sent_size = 0;
        uint16_t sent_size;

        if(remaind_send_size == 0)
        {
               remaind_send_size = getSn_TX_FSR(sn);
               if(remaind_send_size !=0)
            	   GenTestPattern(sn, buf, remaind_send_size);
               total_sent_size = 0;
        }
        if(remaind_send_size > 0)
        {
               sent_size = sendto(sn, buf+total_sent_size,1024, destip, destport);
//        	sent_size = sendto(sn, buf+total_sent_size,remaind_send_size, destip, destport);
//               printf("sent_size : %d\r\n", sent_size);
            if(sent_size < 0) return -1;
            total_sent_size += sent_size;
            remaind_send_size -= sent_size;
        }
        return 0;
}

int8_t recv_TestPattern(uint8_t sn, uint8_t* buf)
{
        uint16_t recv_size = 0;
        recv_size = getSn_RX_RSR(sn);
        if(recv_size > 0)
        {
               recv_size = recv(sn,buf,recv_size);
//               printf("recv_size : %d\r\n", recv_size);
               if(recv_size > 0)
               {
                       if(CheckTestPattern(sn, buf,recv_size) != 0)
                              return -1;
               }
        }
        return 0;
}

int8_t recv_TestPattern_udp(uint8_t sn, uint8_t* buf, uint16_t destport, uint8_t* destip)
{
        uint16_t recv_size = 0;
        recv_size = getSn_RX_RSR(sn);
        if(recv_size > 0)
        {
               recv_size = recvfrom(sn,buf,recv_size, destip, (uint16_t*)&destport);
//               printf("recv_size : %d\r\n", recv_size);
               if(recv_size > 0)
               {
                       if(CheckTestPattern(sn, buf,recv_size) != 0)
                              return -1;
               }
        }
        return 0;
}

void PatternTest(uint8_t sn, uint8_t* destip, uint16_t port, uint8_t* sendbuf, uint8_t* recvbuf, uint8_t bserver)
{
	static uint16_t any_port = 50000;
        switch(getSn_SR(sn))
        {
        case SOCK_ESTABLISHED:
               if(getSn_IR(sn) & Sn_IR_CON)
               {
                       printf("Conenected OK\r\n");
                       setSn_IR(sn, Sn_IR_CON);
               }
               if((sendbuf != 0) && (send_TestPattern(sn,sendbuf) < 0))
               {
                       close(sn);
                       printf("Err Send Test Pattern\r\n");
                       while(1);
               }
               if((recvbuf != 0)&& (recv_TestPattern(sn,recvbuf) < 0))
               {
                       close(sn);
                       printf("Err Recv Test Pattern");
                       while(1);
               }
               break;
        case SOCK_CLOSE_WAIT:
               close(sn);
               break;
        case SOCK_INIT:
               if(bserver)
                       listen(sn);
               else
                       connect(sn,destip,port);
               break;
        case SOCK_CLOSED:
        	if(bserver)
               socket(sn,Sn_MR_TCP,port,0x00);
        	else
        	{
        		socket(sn,Sn_MR_TCP,any_port++,0x00);
        		printf("clinet socker open! \r\n");
        	}
        	break;
        }
}


void PatternTest_udp(uint8_t sn, uint8_t* destip, uint16_t port, uint8_t* sendbuf, uint8_t* recvbuf, uint8_t bserver)
{
	static uint16_t any_port = 50000;
        switch(getSn_SR(sn))
        {
        case SOCK_UDP:
               if((sendbuf != 0) && (send_TestPattern_udp(sn,sendbuf, destip, port) < 0))
               {
                       close(sn);
                       printf("Err Send Test Pattern\r\n");
                       while(1);
               }
               if((recvbuf != 0)&& (recv_TestPattern_udp(sn,recvbuf, destip, port) < 0))
               {
                       close(sn);
                       printf("Err Recv Test Pattern");
                       while(1);
               }
               break;

        case SOCK_CLOSED:
        		socket(sn,Sn_MR_UDP,any_port++,0x00);
        		printf("udp socker open! \r\n");
        	break;
        }
}
#endif
