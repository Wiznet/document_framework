
#ifndef __SSP_H__
#define __SSP_H__

void SPI_Init();
void W5500_Init();

#endif
