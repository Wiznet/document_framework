﻿
Public Class frmSchPwd

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        frmMain.isSchOk = False
        txtSchPwd.Focus()
        Me.Close()

    End Sub

    Private Sub btnConfirm_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnConfirm.Click

        Dim pwd As String = txtSchPwd.Text.Trim
        If pwd.Length = 8 Then
            frmMain.SchPwd = pwd
        ElseIf pwd.Length < 8 Then
            Dim i As Integer
            For i = 0 To 8 - pwd.Length - 1
                pwd += " "
            Next

            frmMain.SchPwd = pwd
        End If
        If chkSavePwd.Checked Then My.Settings.schPwd = pwd.Trim
        frmMain.isSchOk = True
        txtSchPwd.Focus()
        Me.Close()

    End Sub

    Private Sub chkShowChar_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkShowChar.CheckedChanged
        If chkShowChar.Checked Then
            txtSchPwd.PasswordChar = ""
        Else
            txtSchPwd.PasswordChar = "*"
        End If
    End Sub

    Private Sub frmSchPwd_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'If My.Settings.schPwd.Length > 0 Then
        txtSchPwd.Text = My.Settings.schPwd
        'End If
        chkShowChar.Checked = True
        txtSchPwd.Focus()


    End Sub

    Private Sub lLblDelPwd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles lLblDelPwd.Click
        My.Settings.schPwd = ""
    End Sub


End Class