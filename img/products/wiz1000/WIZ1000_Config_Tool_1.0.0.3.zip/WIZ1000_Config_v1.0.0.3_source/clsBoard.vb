﻿
Imports System.Runtime.InteropServices
<StructLayout(LayoutKind.Sequential)> _
Public Class clsBoard

    <MarshalAs(UnmanagedType.ByValArray, SizeConst:=4)> _
    Friend opMode(3) As Byte

    <MarshalAs(UnmanagedType.ByValArray, SizeConst:=6)> _
    Friend Mac(5) As Byte

    Friend bServer As Byte

    <MarshalAs(UnmanagedType.ByValArray, SizeConst:=4)> _
    Friend LIp(3) As Byte

    <MarshalAs(UnmanagedType.ByValArray, SizeConst:=4)> _
    Friend Subnet(3) As Byte

    <MarshalAs(UnmanagedType.ByValArray, SizeConst:=4)> _
    Friend Gw(3) As Byte

    <MarshalAs(UnmanagedType.ByValArray, SizeConst:=2)> _
    Friend LPort(1) As Byte

    <MarshalAs(UnmanagedType.ByValArray, SizeConst:=4)> _
    Friend sIp(3) As Byte

    <MarshalAs(UnmanagedType.ByValArray, SizeConst:=2)> _
    Friend sPort(1) As Byte

    Friend BaudRate As Byte
    Friend DataBit As Byte
    Friend Parity As Byte
    Friend StopBit As Byte
    Friend FlowControl As Byte

    Friend dChar As Byte

    <MarshalAs(UnmanagedType.ByValArray, SizeConst:=2)> _
    Friend dSize(1) As Byte

    <MarshalAs(UnmanagedType.ByValArray, SizeConst:=2)> _
    Friend dTime(1) As Byte

    <MarshalAs(UnmanagedType.ByValArray, SizeConst:=2)> _
    Friend iTime(1) As Byte

    Friend DebugOff As Byte

    <MarshalAs(UnmanagedType.ByValArray, SizeConst:=2)> _
    Friend AppVer(1) As Byte

    Friend DHCP As Byte
    Friend UDP As Byte
    Friend Connect As Byte
    Friend dnsFlag As Byte

    <MarshalAs(UnmanagedType.ByValArray, SizeConst:=4)> _
    Friend dnsIP(3) As Byte

    <MarshalAs(UnmanagedType.ByValArray, SizeConst:=32)> _
    Friend dnsDomain(31) As Byte

    Friend sCfg As Byte

    <MarshalAs(UnmanagedType.ByValArray, SizeConst:=3)> _
    Friend sCfgStr(2) As Byte

    <MarshalAs(UnmanagedType.ByValArray, SizeConst:=32)> _
    Friend poeId() As Byte

    <MarshalAs(UnmanagedType.ByValArray, SizeConst:=32)> _
    Friend poePwd(31) As Byte

    Friend isTcpPwd As Byte

    <MarshalAs(UnmanagedType.ByValArray, SizeConst:=8)> _
    Friend TcpPwd(7) As Byte

    <MarshalAs(UnmanagedType.ByValArray, SizeConst:=2)> _
    Friend telnetPort(1) As Byte

    <MarshalAs(UnmanagedType.ByValArray, SizeConst:=8)> _
    Friend telnetPwd(7) As Byte

    <MarshalAs(UnmanagedType.ByValArray, SizeConst:=8)> _
    Friend schPwd(7) As Byte

    <MarshalAs(UnmanagedType.ByValArray, SizeConst:=2)> _
    Friend kaInterval(1) As Byte

    <MarshalAs(UnmanagedType.ByValArray, SizeConst:=4)> _
    Friend udpPeerIp(3) As Byte
    'total 187 bytes
End Class
''' <summary>
''' converter class, convert structure to byte array
''' </summary>
''' <remarks></remarks>
Public Class TypeConverter
    Private dLen As Integer
    Property Length() As Integer
        Get
            Return dLen
        End Get
        Set(ByVal value As Integer)
            dLen = value
        End Set
    End Property

    Public Function GetBoardInfoFromBytes(ByVal b() As Byte) As clsBoard
        Dim bd As clsBoard = New clsBoard
        Dim ptPoint As IntPtr = Marshal.AllocHGlobal(dLen)
        'If b.Length <> dLen Then
        'Marshal.Copy(b, 0, ptPoint, b.Length)
        'Else
        Marshal.Copy(b, 0, ptPoint, dLen)
        'End If

        bd = DirectCast(Marshal.PtrToStructure(ptPoint, GetType(clsBoard)), clsBoard)
        Marshal.FreeHGlobal(ptPoint)
        Return (bd)
    End Function
    Public Function BoardInfoToBytes(ByVal boardInfo As clsBoard) As Byte()
        Dim ptPoint As IntPtr = Marshal.AllocHGlobal(dLen)
        Marshal.StructureToPtr(boardInfo, ptPoint, True)
        Dim b(dLen) As Byte
        Marshal.Copy(ptPoint, b, 0, dLen)
        Marshal.FreeHGlobal(ptPoint)
        Return b

    End Function

End Class
