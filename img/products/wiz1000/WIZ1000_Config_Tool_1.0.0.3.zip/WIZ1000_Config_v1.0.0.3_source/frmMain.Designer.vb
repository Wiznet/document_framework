<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmMain))
        Me.tabCtrl = New System.Windows.Forms.TabControl()
        Me.TabPgNetwork = New System.Windows.Forms.TabPage()
        Me.chkShowPoePwd = New System.Windows.Forms.CheckBox()
        Me.txtPPwd = New System.Windows.Forms.TextBox()
        Me.txtPID = New System.Windows.Forms.TextBox()
        Me.txtDomain = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.txtDnsIP = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.chkDNS = New System.Windows.Forms.CheckBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.txtUdpIP = New System.Windows.Forms.TextBox()
        Me.chkUDP = New System.Windows.Forms.CheckBox()
        Me.rbMixed = New System.Windows.Forms.RadioButton()
        Me.rbServer = New System.Windows.Forms.RadioButton()
        Me.rbClient = New System.Windows.Forms.RadioButton()
        Me.txtSPort = New System.Windows.Forms.TextBox()
        Me.txtLPort = New System.Windows.Forms.TextBox()
        Me.txtSIP = New System.Windows.Forms.TextBox()
        Me.txtGwIP = New System.Windows.Forms.TextBox()
        Me.txtSubnetMask = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtLIP = New System.Windows.Forms.TextBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.rbIpPppoe = New System.Windows.Forms.RadioButton()
        Me.rbIpDhcp = New System.Windows.Forms.RadioButton()
        Me.rbIpStatic = New System.Windows.Forms.RadioButton()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.tabPgSerial = New System.Windows.Forms.TabPage()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.txtChar = New System.Windows.Forms.TextBox()
        Me.txtSize = New System.Windows.Forms.TextBox()
        Me.txtTimer = New System.Windows.Forms.TextBox()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.cboFlow = New System.Windows.Forms.ComboBox()
        Me.cboStopBit = New System.Windows.Forms.ComboBox()
        Me.cboParity = New System.Windows.Forms.ComboBox()
        Me.cboDataBit = New System.Windows.Forms.ComboBox()
        Me.cboBaud = New System.Windows.Forms.ComboBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.tabPgOptions = New System.Windows.Forms.TabPage()
        Me.GroupBox9 = New System.Windows.Forms.GroupBox()
        Me.chkShowChar3 = New System.Windows.Forms.CheckBox()
        Me.txtTelnetPwd = New System.Windows.Forms.TextBox()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.txtTelnetPort = New System.Windows.Forms.TextBox()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.GroupBox8 = New System.Windows.Forms.GroupBox()
        Me.chkShowChar2 = New System.Windows.Forms.CheckBox()
        Me.txtConnPwd = New System.Windows.Forms.TextBox()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.chkConnPwd = New System.Windows.Forms.CheckBox()
        Me.GroupBox7 = New System.Windows.Forms.GroupBox()
        Me.chkShowChar1 = New System.Windows.Forms.CheckBox()
        Me.txtSearchPwd = New System.Windows.Forms.TextBox()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.GroupBox6 = New System.Windows.Forms.GroupBox()
        Me.txtTrigger3 = New System.Windows.Forms.TextBox()
        Me.txtTrigger2 = New System.Windows.Forms.TextBox()
        Me.txtTrigger1 = New System.Windows.Forms.TextBox()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.chkTrigger = New System.Windows.Forms.CheckBox()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.txtKeepAliveInterval = New System.Windows.Forms.TextBox()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.txtInactiveTimer = New System.Windows.Forms.TextBox()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.tabPgTelnet = New System.Windows.Forms.TabPage()
        Me.GroupBox12 = New System.Windows.Forms.GroupBox()
        Me.rtbMsg = New System.Windows.Forms.RichTextBox()
        Me.gbCommand = New System.Windows.Forms.GroupBox()
        Me.btnWont = New System.Windows.Forms.Button()
        Me.cboPurge = New System.Windows.Forms.ComboBox()
        Me.cboMoMask = New System.Windows.Forms.ComboBox()
        Me.cboLnMask = New System.Windows.Forms.ComboBox()
        Me.cboTControl = New System.Windows.Forms.ComboBox()
        Me.cboTStopbit = New System.Windows.Forms.ComboBox()
        Me.cboTParity = New System.Windows.Forms.ComboBox()
        Me.cboTDSize = New System.Windows.Forms.ComboBox()
        Me.cboTBaud = New System.Windows.Forms.ComboBox()
        Me.btnPurge = New System.Windows.Forms.Button()
        Me.btnMoStMask = New System.Windows.Forms.Button()
        Me.btnLnStMask = New System.Windows.Forms.Button()
        Me.btnControl = New System.Windows.Forms.Button()
        Me.btnParity = New System.Windows.Forms.Button()
        Me.btnStopBit = New System.Windows.Forms.Button()
        Me.btnDataSize = New System.Windows.Forms.Button()
        Me.btnSetBaud = New System.Windows.Forms.Button()
        Me.btnWill = New System.Windows.Forms.Button()
        Me.gbLogin = New System.Windows.Forms.GroupBox()
        Me.chkShowChar = New System.Windows.Forms.CheckBox()
        Me.txtPassword = New System.Windows.Forms.TextBox()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.btnLogin = New System.Windows.Forms.Button()
        Me.gbConnect = New System.Windows.Forms.GroupBox()
        Me.txtTPort = New System.Windows.Forms.TextBox()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.btnConnect = New System.Windows.Forms.Button()
        Me.txtTIP = New System.Windows.Forms.TextBox()
        Me.BottomToolStripPanel = New System.Windows.Forms.ToolStripPanel()
        Me.TopToolStripPanel = New System.Windows.Forms.ToolStripPanel()
        Me.RightToolStripPanel = New System.Windows.Forms.ToolStripPanel()
        Me.LeftToolStripPanel = New System.Windows.Forms.ToolStripPanel()
        Me.ContentPanel = New System.Windows.Forms.ToolStripContentPanel()
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.tsBtnSearch = New System.Windows.Forms.ToolStripButton()
        Me.tsBtnSetting = New System.Windows.Forms.ToolStripButton()
        Me.tsBtnUpload = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.tsbPing = New System.Windows.Forms.ToolStripButton()
        Me.tsbFire = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.tsBtnExit = New System.Windows.Forms.ToolStripButton()
        Me.GroupBox10 = New System.Windows.Forms.GroupBox()
        Me.lvBoard = New System.Windows.Forms.ListView()
        Me.ColumnHeader1 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader2 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ofdFw = New System.Windows.Forms.OpenFileDialog()
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.tsLblStatus = New System.Windows.Forms.ToolStripStatusLabel()
        Me.GroupBox11 = New System.Windows.Forms.GroupBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.lblStatus = New System.Windows.Forms.Label()
        Me.chkDebug = New System.Windows.Forms.CheckBox()
        Me.lblFwVer = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GroupBox13 = New System.Windows.Forms.GroupBox()
        Me.txtDirectIP = New System.Windows.Forms.TextBox()
        Me.chkDirectIP = New System.Windows.Forms.CheckBox()
        Me.tabCtrl.SuspendLayout()
        Me.TabPgNetwork.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.tabPgSerial.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.tabPgOptions.SuspendLayout()
        Me.GroupBox9.SuspendLayout()
        Me.GroupBox8.SuspendLayout()
        Me.GroupBox7.SuspendLayout()
        Me.GroupBox6.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.tabPgTelnet.SuspendLayout()
        Me.GroupBox12.SuspendLayout()
        Me.gbCommand.SuspendLayout()
        Me.gbLogin.SuspendLayout()
        Me.gbConnect.SuspendLayout()
        Me.ToolStrip1.SuspendLayout()
        Me.GroupBox10.SuspendLayout()
        Me.StatusStrip1.SuspendLayout()
        Me.GroupBox11.SuspendLayout()
        Me.GroupBox13.SuspendLayout()
        Me.SuspendLayout()
        '
        'tabCtrl
        '
        Me.tabCtrl.Controls.Add(Me.TabPgNetwork)
        Me.tabCtrl.Controls.Add(Me.tabPgSerial)
        Me.tabCtrl.Controls.Add(Me.tabPgOptions)
        Me.tabCtrl.Controls.Add(Me.tabPgTelnet)
        Me.tabCtrl.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.tabCtrl.Location = New System.Drawing.Point(220, 66)
        Me.tabCtrl.Name = "tabCtrl"
        Me.tabCtrl.SelectedIndex = 0
        Me.tabCtrl.Size = New System.Drawing.Size(416, 410)
        Me.tabCtrl.TabIndex = 6
        '
        'TabPgNetwork
        '
        Me.TabPgNetwork.Controls.Add(Me.chkShowPoePwd)
        Me.TabPgNetwork.Controls.Add(Me.txtPPwd)
        Me.TabPgNetwork.Controls.Add(Me.txtPID)
        Me.TabPgNetwork.Controls.Add(Me.txtDomain)
        Me.TabPgNetwork.Controls.Add(Me.Label13)
        Me.TabPgNetwork.Controls.Add(Me.txtDnsIP)
        Me.TabPgNetwork.Controls.Add(Me.Label12)
        Me.TabPgNetwork.Controls.Add(Me.chkDNS)
        Me.TabPgNetwork.Controls.Add(Me.GroupBox2)
        Me.TabPgNetwork.Controls.Add(Me.txtSPort)
        Me.TabPgNetwork.Controls.Add(Me.txtLPort)
        Me.TabPgNetwork.Controls.Add(Me.txtSIP)
        Me.TabPgNetwork.Controls.Add(Me.txtGwIP)
        Me.TabPgNetwork.Controls.Add(Me.txtSubnetMask)
        Me.TabPgNetwork.Controls.Add(Me.Label10)
        Me.TabPgNetwork.Controls.Add(Me.Label9)
        Me.TabPgNetwork.Controls.Add(Me.Label8)
        Me.TabPgNetwork.Controls.Add(Me.Label7)
        Me.TabPgNetwork.Controls.Add(Me.Label6)
        Me.TabPgNetwork.Controls.Add(Me.Label5)
        Me.TabPgNetwork.Controls.Add(Me.Label4)
        Me.TabPgNetwork.Controls.Add(Me.txtLIP)
        Me.TabPgNetwork.Controls.Add(Me.GroupBox1)
        Me.TabPgNetwork.Controls.Add(Me.Label2)
        Me.TabPgNetwork.Location = New System.Drawing.Point(4, 24)
        Me.TabPgNetwork.Name = "TabPgNetwork"
        Me.TabPgNetwork.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPgNetwork.Size = New System.Drawing.Size(408, 382)
        Me.TabPgNetwork.TabIndex = 0
        Me.TabPgNetwork.Text = "Network"
        Me.TabPgNetwork.ToolTipText = "Network Configuration"
        Me.TabPgNetwork.UseVisualStyleBackColor = True
        '
        'chkShowPoePwd
        '
        Me.chkShowPoePwd.AutoSize = True
        Me.chkShowPoePwd.Location = New System.Drawing.Point(284, 180)
        Me.chkShowPoePwd.Name = "chkShowPoePwd"
        Me.chkShowPoePwd.Size = New System.Drawing.Size(109, 19)
        Me.chkShowPoePwd.TabIndex = 25
        Me.chkShowPoePwd.Text = "Show Character"
        Me.chkShowPoePwd.UseVisualStyleBackColor = True
        '
        'txtPPwd
        '
        Me.txtPPwd.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPPwd.Location = New System.Drawing.Point(136, 176)
        Me.txtPPwd.MaxLength = 32
        Me.txtPPwd.Name = "txtPPwd"
        Me.txtPPwd.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txtPPwd.Size = New System.Drawing.Size(134, 23)
        Me.txtPPwd.TabIndex = 24
        Me.txtPPwd.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtPID
        '
        Me.txtPID.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPID.Location = New System.Drawing.Point(136, 149)
        Me.txtPID.MaxLength = 32
        Me.txtPID.Name = "txtPID"
        Me.txtPID.Size = New System.Drawing.Size(134, 23)
        Me.txtPID.TabIndex = 23
        Me.txtPID.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtDomain
        '
        Me.txtDomain.Enabled = False
        Me.txtDomain.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDomain.Location = New System.Drawing.Point(115, 349)
        Me.txtDomain.MaxLength = 32
        Me.txtDomain.Name = "txtDomain"
        Me.txtDomain.Size = New System.Drawing.Size(273, 23)
        Me.txtDomain.TabIndex = 22
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(19, 352)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(87, 15)
        Me.Label13.TabIndex = 21
        Me.Label13.Text = "Domain Name:"
        '
        'txtDnsIP
        '
        Me.txtDnsIP.Enabled = False
        Me.txtDnsIP.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDnsIP.Location = New System.Drawing.Point(254, 322)
        Me.txtDnsIP.Name = "txtDnsIP"
        Me.txtDnsIP.Size = New System.Drawing.Size(134, 23)
        Me.txtDnsIP.TabIndex = 20
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(107, 326)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(126, 15)
        Me.Label12.TabIndex = 19
        Me.Label12.Text = "DNS Server IP Address:"
        '
        'chkDNS
        '
        Me.chkDNS.AutoSize = True
        Me.chkDNS.Location = New System.Drawing.Point(21, 324)
        Me.chkDNS.Name = "chkDNS"
        Me.chkDNS.Size = New System.Drawing.Size(71, 19)
        Me.chkDNS.TabIndex = 18
        Me.chkDNS.Text = "Use DNS"
        Me.chkDNS.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.Label11)
        Me.GroupBox2.Controls.Add(Me.txtUdpIP)
        Me.GroupBox2.Controls.Add(Me.chkUDP)
        Me.GroupBox2.Controls.Add(Me.rbMixed)
        Me.GroupBox2.Controls.Add(Me.rbServer)
        Me.GroupBox2.Controls.Add(Me.rbClient)
        Me.GroupBox2.Location = New System.Drawing.Point(6, 230)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(393, 80)
        Me.GroupBox2.TabIndex = 17
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Operation Mode"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(94, 49)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(135, 15)
        Me.Label11.TabIndex = 5
        Me.Label11.Text = "Remote Peer IP Address:"
        '
        'txtUdpIP
        '
        Me.txtUdpIP.Enabled = False
        Me.txtUdpIP.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtUdpIP.Location = New System.Drawing.Point(248, 49)
        Me.txtUdpIP.Name = "txtUdpIP"
        Me.txtUdpIP.Size = New System.Drawing.Size(134, 23)
        Me.txtUdpIP.TabIndex = 4
        '
        'chkUDP
        '
        Me.chkUDP.AutoSize = True
        Me.chkUDP.Location = New System.Drawing.Point(15, 48)
        Me.chkUDP.Name = "chkUDP"
        Me.chkUDP.Size = New System.Drawing.Size(49, 19)
        Me.chkUDP.TabIndex = 3
        Me.chkUDP.Text = "UDP"
        Me.chkUDP.UseVisualStyleBackColor = True
        '
        'rbMixed
        '
        Me.rbMixed.AutoSize = True
        Me.rbMixed.Location = New System.Drawing.Point(210, 24)
        Me.rbMixed.Name = "rbMixed"
        Me.rbMixed.Size = New System.Drawing.Size(172, 19)
        Me.rbMixed.TabIndex = 2
        Me.rbMixed.TabStop = True
        Me.rbMixed.Text = "TCP Mixed (Server && Client)"
        Me.rbMixed.UseVisualStyleBackColor = True
        '
        'rbServer
        '
        Me.rbServer.AutoSize = True
        Me.rbServer.Location = New System.Drawing.Point(120, 24)
        Me.rbServer.Name = "rbServer"
        Me.rbServer.Size = New System.Drawing.Size(82, 19)
        Me.rbServer.TabIndex = 1
        Me.rbServer.TabStop = True
        Me.rbServer.Text = "TCP Server"
        Me.rbServer.UseVisualStyleBackColor = True
        '
        'rbClient
        '
        Me.rbClient.AutoSize = True
        Me.rbClient.Location = New System.Drawing.Point(15, 24)
        Me.rbClient.Name = "rbClient"
        Me.rbClient.Size = New System.Drawing.Size(81, 19)
        Me.rbClient.TabIndex = 0
        Me.rbClient.TabStop = True
        Me.rbClient.Text = "TCP Client"
        Me.rbClient.UseVisualStyleBackColor = True
        '
        'txtSPort
        '
        Me.txtSPort.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSPort.Location = New System.Drawing.Point(319, 203)
        Me.txtSPort.Name = "txtSPort"
        Me.txtSPort.Size = New System.Drawing.Size(69, 23)
        Me.txtSPort.TabIndex = 16
        Me.txtSPort.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtLPort
        '
        Me.txtLPort.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtLPort.Location = New System.Drawing.Point(319, 68)
        Me.txtLPort.Name = "txtLPort"
        Me.txtLPort.Size = New System.Drawing.Size(69, 23)
        Me.txtLPort.TabIndex = 15
        Me.txtLPort.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtSIP
        '
        Me.txtSIP.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSIP.Location = New System.Drawing.Point(136, 203)
        Me.txtSIP.Name = "txtSIP"
        Me.txtSIP.Size = New System.Drawing.Size(134, 23)
        Me.txtSIP.TabIndex = 14
        Me.txtSIP.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtGwIP
        '
        Me.txtGwIP.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtGwIP.Location = New System.Drawing.Point(136, 122)
        Me.txtGwIP.Name = "txtGwIP"
        Me.txtGwIP.Size = New System.Drawing.Size(134, 23)
        Me.txtGwIP.TabIndex = 11
        Me.txtGwIP.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtSubnetMask
        '
        Me.txtSubnetMask.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSubnetMask.Location = New System.Drawing.Point(136, 95)
        Me.txtSubnetMask.Name = "txtSubnetMask"
        Me.txtSubnetMask.Size = New System.Drawing.Size(134, 23)
        Me.txtSubnetMask.TabIndex = 10
        Me.txtSubnetMask.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(282, 206)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(32, 15)
        Me.Label10.TabIndex = 9
        Me.Label10.Text = "Port:"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(19, 206)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(100, 15)
        Me.Label9.TabIndex = 8
        Me.Label9.Text = "Server IP Address:"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(21, 179)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(97, 15)
        Me.Label8.TabIndex = 7
        Me.Label8.Text = "PPPoE Password:"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(67, 152)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(58, 15)
        Me.Label7.TabIndex = 6
        Me.Label7.Text = "PPPoE ID:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(29, 125)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(96, 15)
        Me.Label6.TabIndex = 5
        Me.Label6.Text = "Default Gateway:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(47, 98)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(78, 15)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Subnet Mask:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(282, 71)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(32, 15)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Port:"
        '
        'txtLIP
        '
        Me.txtLIP.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtLIP.Location = New System.Drawing.Point(136, 68)
        Me.txtLIP.Name = "txtLIP"
        Me.txtLIP.Size = New System.Drawing.Size(134, 23)
        Me.txtLIP.TabIndex = 2
        Me.txtLIP.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.rbIpPppoe)
        Me.GroupBox1.Controls.Add(Me.rbIpDhcp)
        Me.GroupBox1.Controls.Add(Me.rbIpStatic)
        Me.GroupBox1.Location = New System.Drawing.Point(6, 6)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(393, 51)
        Me.GroupBox1.TabIndex = 1
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "IP Configuration Method"
        '
        'rbIpPppoe
        '
        Me.rbIpPppoe.AutoSize = True
        Me.rbIpPppoe.Location = New System.Drawing.Point(307, 23)
        Me.rbIpPppoe.Name = "rbIpPppoe"
        Me.rbIpPppoe.Size = New System.Drawing.Size(73, 19)
        Me.rbIpPppoe.TabIndex = 2
        Me.rbIpPppoe.TabStop = True
        Me.rbIpPppoe.Text = "PPPoE(&E)"
        Me.rbIpPppoe.UseVisualStyleBackColor = True
        '
        'rbIpDhcp
        '
        Me.rbIpDhcp.AutoSize = True
        Me.rbIpDhcp.Location = New System.Drawing.Point(172, 23)
        Me.rbIpDhcp.Name = "rbIpDhcp"
        Me.rbIpDhcp.Size = New System.Drawing.Size(74, 19)
        Me.rbIpDhcp.TabIndex = 1
        Me.rbIpDhcp.TabStop = True
        Me.rbIpDhcp.Text = "DHCP(&H)"
        Me.rbIpDhcp.UseVisualStyleBackColor = True
        '
        'rbIpStatic
        '
        Me.rbIpStatic.AutoSize = True
        Me.rbIpStatic.Location = New System.Drawing.Point(15, 23)
        Me.rbIpStatic.Name = "rbIpStatic"
        Me.rbIpStatic.Size = New System.Drawing.Size(70, 19)
        Me.rbIpStatic.TabIndex = 0
        Me.rbIpStatic.TabStop = True
        Me.rbIpStatic.Text = "Static(&A)"
        Me.rbIpStatic.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(24, 71)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(96, 15)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "Local IP Address:"
        '
        'tabPgSerial
        '
        Me.tabPgSerial.Controls.Add(Me.GroupBox4)
        Me.tabPgSerial.Controls.Add(Me.GroupBox3)
        Me.tabPgSerial.Location = New System.Drawing.Point(4, 24)
        Me.tabPgSerial.Name = "tabPgSerial"
        Me.tabPgSerial.Padding = New System.Windows.Forms.Padding(3)
        Me.tabPgSerial.Size = New System.Drawing.Size(408, 382)
        Me.tabPgSerial.TabIndex = 1
        Me.tabPgSerial.Text = "Serial"
        Me.tabPgSerial.ToolTipText = "Serial Configuration"
        Me.tabPgSerial.UseVisualStyleBackColor = True
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.Label24)
        Me.GroupBox4.Controls.Add(Me.Label23)
        Me.GroupBox4.Controls.Add(Me.Label22)
        Me.GroupBox4.Controls.Add(Me.txtChar)
        Me.GroupBox4.Controls.Add(Me.txtSize)
        Me.GroupBox4.Controls.Add(Me.txtTimer)
        Me.GroupBox4.Controls.Add(Me.Label21)
        Me.GroupBox4.Controls.Add(Me.Label20)
        Me.GroupBox4.Controls.Add(Me.Label19)
        Me.GroupBox4.Location = New System.Drawing.Point(22, 234)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(354, 126)
        Me.GroupBox4.TabIndex = 11
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Serial Data Packing Condition"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.ForeColor = System.Drawing.Color.Red
        Me.Label24.Location = New System.Drawing.Point(231, 92)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(95, 15)
        Me.Label24.TabIndex = 8
        Me.Label24.Text = "(Hexacode Only)"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.ForeColor = System.Drawing.Color.Red
        Me.Label23.Location = New System.Drawing.Point(231, 59)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(78, 15)
        Me.Label23.TabIndex = 7
        Me.Label23.Text = "(0~255 Bytes)"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.ForeColor = System.Drawing.Color.Red
        Me.Label22.Location = New System.Drawing.Point(231, 26)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(75, 15)
        Me.Label22.TabIndex = 6
        Me.Label22.Text = "(0~65535ms)"
        '
        'txtChar
        '
        Me.txtChar.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtChar.Location = New System.Drawing.Point(145, 89)
        Me.txtChar.Margin = New System.Windows.Forms.Padding(3, 6, 3, 6)
        Me.txtChar.MaxLength = 2
        Me.txtChar.Name = "txtChar"
        Me.txtChar.Size = New System.Drawing.Size(80, 23)
        Me.txtChar.TabIndex = 5
        Me.txtChar.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtSize
        '
        Me.txtSize.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSize.Location = New System.Drawing.Point(145, 56)
        Me.txtSize.Margin = New System.Windows.Forms.Padding(3, 6, 3, 6)
        Me.txtSize.MaxLength = 3
        Me.txtSize.Name = "txtSize"
        Me.txtSize.Size = New System.Drawing.Size(80, 23)
        Me.txtSize.TabIndex = 4
        Me.txtSize.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtTimer
        '
        Me.txtTimer.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTimer.Location = New System.Drawing.Point(145, 23)
        Me.txtTimer.Margin = New System.Windows.Forms.Padding(3, 6, 3, 6)
        Me.txtTimer.MaxLength = 5
        Me.txtTimer.Name = "txtTimer"
        Me.txtTimer.Size = New System.Drawing.Size(80, 23)
        Me.txtTimer.TabIndex = 3
        Me.txtTimer.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(56, 92)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(77, 15)
        Me.Label21.TabIndex = 2
        Me.Label21.Text = "Character(&C):"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(87, 59)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(45, 15)
        Me.Label20.TabIndex = 1
        Me.Label20.Text = "Size(&Z):"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(79, 26)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(56, 15)
        Me.Label19.TabIndex = 0
        Me.Label19.Text = "Timer(&T):"
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.cboFlow)
        Me.GroupBox3.Controls.Add(Me.cboStopBit)
        Me.GroupBox3.Controls.Add(Me.cboParity)
        Me.GroupBox3.Controls.Add(Me.cboDataBit)
        Me.GroupBox3.Controls.Add(Me.cboBaud)
        Me.GroupBox3.Controls.Add(Me.Label18)
        Me.GroupBox3.Controls.Add(Me.Label17)
        Me.GroupBox3.Controls.Add(Me.Label16)
        Me.GroupBox3.Controls.Add(Me.Label15)
        Me.GroupBox3.Controls.Add(Me.Label14)
        Me.GroupBox3.Location = New System.Drawing.Point(21, 26)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(355, 184)
        Me.GroupBox3.TabIndex = 10
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "COM Port Configuration"
        '
        'cboFlow
        '
        Me.cboFlow.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboFlow.FormattingEnabled = True
        Me.cboFlow.Location = New System.Drawing.Point(146, 153)
        Me.cboFlow.Margin = New System.Windows.Forms.Padding(3, 6, 3, 6)
        Me.cboFlow.Name = "cboFlow"
        Me.cboFlow.Size = New System.Drawing.Size(160, 23)
        Me.cboFlow.TabIndex = 19
        '
        'cboStopBit
        '
        Me.cboStopBit.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboStopBit.FormattingEnabled = True
        Me.cboStopBit.Location = New System.Drawing.Point(146, 121)
        Me.cboStopBit.Margin = New System.Windows.Forms.Padding(3, 6, 3, 6)
        Me.cboStopBit.Name = "cboStopBit"
        Me.cboStopBit.Size = New System.Drawing.Size(160, 23)
        Me.cboStopBit.TabIndex = 18
        '
        'cboParity
        '
        Me.cboParity.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboParity.FormattingEnabled = True
        Me.cboParity.Location = New System.Drawing.Point(146, 87)
        Me.cboParity.Margin = New System.Windows.Forms.Padding(3, 6, 3, 6)
        Me.cboParity.Name = "cboParity"
        Me.cboParity.Size = New System.Drawing.Size(160, 23)
        Me.cboParity.TabIndex = 17
        '
        'cboDataBit
        '
        Me.cboDataBit.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboDataBit.FormattingEnabled = True
        Me.cboDataBit.Location = New System.Drawing.Point(146, 55)
        Me.cboDataBit.Margin = New System.Windows.Forms.Padding(3, 6, 3, 6)
        Me.cboDataBit.Name = "cboDataBit"
        Me.cboDataBit.Size = New System.Drawing.Size(160, 23)
        Me.cboDataBit.TabIndex = 16
        '
        'cboBaud
        '
        Me.cboBaud.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboBaud.FormattingEnabled = True
        Me.cboBaud.Location = New System.Drawing.Point(146, 23)
        Me.cboBaud.Margin = New System.Windows.Forms.Padding(3, 6, 3, 6)
        Me.cboBaud.Name = "cboBaud"
        Me.cboBaud.Size = New System.Drawing.Size(160, 23)
        Me.cboBaud.TabIndex = 15
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(43, 156)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(92, 15)
        Me.Label18.TabIndex = 14
        Me.Label18.Text = "Flow Control(&F):"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(70, 124)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(65, 15)
        Me.Label17.TabIndex = 13
        Me.Label17.Text = "Stop Bit(&S):"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(81, 90)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(55, 15)
        Me.Label16.TabIndex = 12
        Me.Label16.Text = "Parity(&P):"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(70, 58)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(67, 15)
        Me.Label15.TabIndex = 11
        Me.Label15.Text = "Data Bit(&D):"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(55, 26)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(78, 15)
        Me.Label14.TabIndex = 10
        Me.Label14.Text = "Baud Rate(&R):"
        '
        'tabPgOptions
        '
        Me.tabPgOptions.Controls.Add(Me.GroupBox9)
        Me.tabPgOptions.Controls.Add(Me.GroupBox8)
        Me.tabPgOptions.Controls.Add(Me.GroupBox7)
        Me.tabPgOptions.Controls.Add(Me.GroupBox6)
        Me.tabPgOptions.Controls.Add(Me.GroupBox5)
        Me.tabPgOptions.Location = New System.Drawing.Point(4, 24)
        Me.tabPgOptions.Name = "tabPgOptions"
        Me.tabPgOptions.Padding = New System.Windows.Forms.Padding(3)
        Me.tabPgOptions.Size = New System.Drawing.Size(408, 382)
        Me.tabPgOptions.TabIndex = 2
        Me.tabPgOptions.Text = "Options"
        Me.tabPgOptions.ToolTipText = "Other Options"
        Me.tabPgOptions.UseVisualStyleBackColor = True
        '
        'GroupBox9
        '
        Me.GroupBox9.Controls.Add(Me.chkShowChar3)
        Me.GroupBox9.Controls.Add(Me.txtTelnetPwd)
        Me.GroupBox9.Controls.Add(Me.Label36)
        Me.GroupBox9.Controls.Add(Me.txtTelnetPort)
        Me.GroupBox9.Controls.Add(Me.Label35)
        Me.GroupBox9.Location = New System.Drawing.Point(6, 321)
        Me.GroupBox9.Name = "GroupBox9"
        Me.GroupBox9.Size = New System.Drawing.Size(395, 55)
        Me.GroupBox9.TabIndex = 4
        Me.GroupBox9.TabStop = False
        Me.GroupBox9.Text = "Telnet Options"
        '
        'chkShowChar3
        '
        Me.chkShowChar3.AutoSize = True
        Me.chkShowChar3.Location = New System.Drawing.Point(291, 26)
        Me.chkShowChar3.Name = "chkShowChar3"
        Me.chkShowChar3.Size = New System.Drawing.Size(83, 19)
        Me.chkShowChar3.TabIndex = 4
        Me.chkShowChar3.Text = "Show Char"
        Me.chkShowChar3.UseVisualStyleBackColor = True
        '
        'txtTelnetPwd
        '
        Me.txtTelnetPwd.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTelnetPwd.Location = New System.Drawing.Point(176, 23)
        Me.txtTelnetPwd.MaxLength = 8
        Me.txtTelnetPwd.Name = "txtTelnetPwd"
        Me.txtTelnetPwd.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txtTelnetPwd.Size = New System.Drawing.Size(100, 23)
        Me.txtTelnetPwd.TabIndex = 3
        Me.txtTelnetPwd.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Location = New System.Drawing.Point(104, 27)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(60, 15)
        Me.Label36.TabIndex = 2
        Me.Label36.Text = "Password:"
        '
        'txtTelnetPort
        '
        Me.txtTelnetPort.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTelnetPort.Location = New System.Drawing.Point(50, 23)
        Me.txtTelnetPort.Name = "txtTelnetPort"
        Me.txtTelnetPort.Size = New System.Drawing.Size(48, 23)
        Me.txtTelnetPort.TabIndex = 1
        Me.txtTelnetPort.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Location = New System.Drawing.Point(13, 26)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(32, 15)
        Me.Label35.TabIndex = 0
        Me.Label35.Text = "Port:"
        '
        'GroupBox8
        '
        Me.GroupBox8.Controls.Add(Me.chkShowChar2)
        Me.GroupBox8.Controls.Add(Me.txtConnPwd)
        Me.GroupBox8.Controls.Add(Me.Label34)
        Me.GroupBox8.Controls.Add(Me.chkConnPwd)
        Me.GroupBox8.Location = New System.Drawing.Point(6, 260)
        Me.GroupBox8.Name = "GroupBox8"
        Me.GroupBox8.Size = New System.Drawing.Size(396, 55)
        Me.GroupBox8.TabIndex = 3
        Me.GroupBox8.TabStop = False
        Me.GroupBox8.Text = "Connection Password (TCP Server Mode Only)"
        '
        'chkShowChar2
        '
        Me.chkShowChar2.AutoSize = True
        Me.chkShowChar2.Location = New System.Drawing.Point(291, 24)
        Me.chkShowChar2.Name = "chkShowChar2"
        Me.chkShowChar2.Size = New System.Drawing.Size(83, 19)
        Me.chkShowChar2.TabIndex = 3
        Me.chkShowChar2.Text = "Show Char"
        Me.chkShowChar2.UseVisualStyleBackColor = True
        '
        'txtConnPwd
        '
        Me.txtConnPwd.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtConnPwd.Location = New System.Drawing.Point(156, 22)
        Me.txtConnPwd.MaxLength = 8
        Me.txtConnPwd.Name = "txtConnPwd"
        Me.txtConnPwd.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txtConnPwd.Size = New System.Drawing.Size(120, 23)
        Me.txtConnPwd.TabIndex = 2
        Me.txtConnPwd.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Location = New System.Drawing.Point(84, 25)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(60, 15)
        Me.Label34.TabIndex = 1
        Me.Label34.Text = "Password:"
        '
        'chkConnPwd
        '
        Me.chkConnPwd.AutoSize = True
        Me.chkConnPwd.Location = New System.Drawing.Point(15, 24)
        Me.chkConnPwd.Name = "chkConnPwd"
        Me.chkConnPwd.Size = New System.Drawing.Size(61, 19)
        Me.chkConnPwd.TabIndex = 0
        Me.chkConnPwd.Text = "Enable"
        Me.chkConnPwd.UseVisualStyleBackColor = True
        '
        'GroupBox7
        '
        Me.GroupBox7.Controls.Add(Me.chkShowChar1)
        Me.GroupBox7.Controls.Add(Me.txtSearchPwd)
        Me.GroupBox7.Controls.Add(Me.Label33)
        Me.GroupBox7.Location = New System.Drawing.Point(6, 199)
        Me.GroupBox7.Name = "GroupBox7"
        Me.GroupBox7.Size = New System.Drawing.Size(395, 55)
        Me.GroupBox7.TabIndex = 2
        Me.GroupBox7.TabStop = False
        Me.GroupBox7.Text = "Search Password"
        '
        'chkShowChar1
        '
        Me.chkShowChar1.AutoSize = True
        Me.chkShowChar1.Location = New System.Drawing.Point(291, 23)
        Me.chkShowChar1.Name = "chkShowChar1"
        Me.chkShowChar1.Size = New System.Drawing.Size(83, 19)
        Me.chkShowChar1.TabIndex = 2
        Me.chkShowChar1.Text = "Show Char"
        Me.chkShowChar1.UseVisualStyleBackColor = True
        '
        'txtSearchPwd
        '
        Me.txtSearchPwd.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSearchPwd.Location = New System.Drawing.Point(85, 21)
        Me.txtSearchPwd.MaxLength = 8
        Me.txtSearchPwd.Name = "txtSearchPwd"
        Me.txtSearchPwd.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txtSearchPwd.Size = New System.Drawing.Size(191, 23)
        Me.txtSearchPwd.TabIndex = 1
        Me.txtSearchPwd.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Location = New System.Drawing.Point(13, 24)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(60, 15)
        Me.Label33.TabIndex = 0
        Me.Label33.Text = "Password:"
        '
        'GroupBox6
        '
        Me.GroupBox6.Controls.Add(Me.txtTrigger3)
        Me.GroupBox6.Controls.Add(Me.txtTrigger2)
        Me.GroupBox6.Controls.Add(Me.txtTrigger1)
        Me.GroupBox6.Controls.Add(Me.Label32)
        Me.GroupBox6.Controls.Add(Me.Label31)
        Me.GroupBox6.Controls.Add(Me.chkTrigger)
        Me.GroupBox6.Location = New System.Drawing.Point(6, 138)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Size = New System.Drawing.Size(396, 55)
        Me.GroupBox6.TabIndex = 1
        Me.GroupBox6.TabStop = False
        Me.GroupBox6.Text = "Serial Configuration Mode Switch Code"
        '
        'txtTrigger3
        '
        Me.txtTrigger3.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTrigger3.Location = New System.Drawing.Point(250, 22)
        Me.txtTrigger3.MaxLength = 2
        Me.txtTrigger3.Name = "txtTrigger3"
        Me.txtTrigger3.Size = New System.Drawing.Size(26, 23)
        Me.txtTrigger3.TabIndex = 12
        Me.txtTrigger3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtTrigger2
        '
        Me.txtTrigger2.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTrigger2.Location = New System.Drawing.Point(218, 22)
        Me.txtTrigger2.MaxLength = 2
        Me.txtTrigger2.Name = "txtTrigger2"
        Me.txtTrigger2.Size = New System.Drawing.Size(26, 23)
        Me.txtTrigger2.TabIndex = 11
        Me.txtTrigger2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtTrigger1
        '
        Me.txtTrigger1.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTrigger1.Location = New System.Drawing.Point(186, 22)
        Me.txtTrigger1.MaxLength = 2
        Me.txtTrigger1.Name = "txtTrigger1"
        Me.txtTrigger1.Size = New System.Drawing.Size(26, 23)
        Me.txtTrigger1.TabIndex = 10
        Me.txtTrigger1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.ForeColor = System.Drawing.Color.Red
        Me.Label32.Location = New System.Drawing.Point(282, 26)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(95, 15)
        Me.Label32.TabIndex = 9
        Me.Label32.Text = "(Hexacode Only)"
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Location = New System.Drawing.Point(97, 25)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(79, 15)
        Me.Label31.TabIndex = 1
        Me.Label31.Text = "Trigger Code:"
        '
        'chkTrigger
        '
        Me.chkTrigger.AutoSize = True
        Me.chkTrigger.Location = New System.Drawing.Point(15, 25)
        Me.chkTrigger.Name = "chkTrigger"
        Me.chkTrigger.Size = New System.Drawing.Size(61, 19)
        Me.chkTrigger.TabIndex = 0
        Me.chkTrigger.Text = "Enable"
        Me.chkTrigger.UseVisualStyleBackColor = True
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.Label30)
        Me.GroupBox5.Controls.Add(Me.Label29)
        Me.GroupBox5.Controls.Add(Me.txtKeepAliveInterval)
        Me.GroupBox5.Controls.Add(Me.Label28)
        Me.GroupBox5.Controls.Add(Me.Label27)
        Me.GroupBox5.Controls.Add(Me.Label26)
        Me.GroupBox5.Controls.Add(Me.txtInactiveTimer)
        Me.GroupBox5.Controls.Add(Me.Label25)
        Me.GroupBox5.Location = New System.Drawing.Point(6, 6)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(396, 126)
        Me.GroupBox5.TabIndex = 0
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Timer Interval"
        '
        'Label30
        '
        Me.Label30.ForeColor = System.Drawing.SystemColors.Highlight
        Me.Label30.Location = New System.Drawing.Point(31, 86)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(298, 36)
        Me.Label30.TabIndex = 7
        Me.Label30.Text = "* The interval of send keep alive packet when no data    transmission."
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.ForeColor = System.Drawing.Color.Red
        Me.Label29.Location = New System.Drawing.Point(228, 65)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(106, 15)
        Me.Label29.TabIndex = 6
        Me.Label29.Text = "(0~65535 Seconds)"
        '
        'txtKeepAliveInterval
        '
        Me.txtKeepAliveInterval.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtKeepAliveInterval.Location = New System.Drawing.Point(132, 62)
        Me.txtKeepAliveInterval.Name = "txtKeepAliveInterval"
        Me.txtKeepAliveInterval.Size = New System.Drawing.Size(90, 23)
        Me.txtKeepAliveInterval.TabIndex = 5
        Me.txtKeepAliveInterval.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Location = New System.Drawing.Point(13, 65)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(107, 15)
        Me.Label28.TabIndex = 4
        Me.Label28.Text = "Keep Alive Interval:"
        '
        'Label27
        '
        Me.Label27.ForeColor = System.Drawing.SystemColors.Highlight
        Me.Label27.Location = New System.Drawing.Point(31, 38)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(347, 30)
        Me.Label27.TabIndex = 3
        Me.Label27.Text = "*The connection holding period when no data transmission."
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.ForeColor = System.Drawing.Color.Red
        Me.Label26.Location = New System.Drawing.Point(228, 17)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(106, 15)
        Me.Label26.TabIndex = 2
        Me.Label26.Text = "(0~65535 Seconds)"
        '
        'txtInactiveTimer
        '
        Me.txtInactiveTimer.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtInactiveTimer.Location = New System.Drawing.Point(132, 14)
        Me.txtInactiveTimer.Name = "txtInactiveTimer"
        Me.txtInactiveTimer.Size = New System.Drawing.Size(90, 23)
        Me.txtInactiveTimer.TabIndex = 1
        Me.txtInactiveTimer.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(31, 17)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(92, 15)
        Me.Label25.TabIndex = 0
        Me.Label25.Text = "Inactivity Timer:"
        '
        'tabPgTelnet
        '
        Me.tabPgTelnet.AutoScroll = True
        Me.tabPgTelnet.Controls.Add(Me.GroupBox12)
        Me.tabPgTelnet.Controls.Add(Me.gbCommand)
        Me.tabPgTelnet.Controls.Add(Me.gbLogin)
        Me.tabPgTelnet.Controls.Add(Me.gbConnect)
        Me.tabPgTelnet.Location = New System.Drawing.Point(4, 24)
        Me.tabPgTelnet.Name = "tabPgTelnet"
        Me.tabPgTelnet.Padding = New System.Windows.Forms.Padding(3)
        Me.tabPgTelnet.Size = New System.Drawing.Size(408, 382)
        Me.tabPgTelnet.TabIndex = 3
        Me.tabPgTelnet.Text = "Telnet"
        Me.tabPgTelnet.ToolTipText = "Telnet COM Port Options (RFC2217)"
        Me.tabPgTelnet.UseVisualStyleBackColor = True
        '
        'GroupBox12
        '
        Me.GroupBox12.Controls.Add(Me.rtbMsg)
        Me.GroupBox12.Location = New System.Drawing.Point(6, 308)
        Me.GroupBox12.Name = "GroupBox12"
        Me.GroupBox12.Size = New System.Drawing.Size(378, 205)
        Me.GroupBox12.TabIndex = 21
        Me.GroupBox12.TabStop = False
        Me.GroupBox12.Text = "Messages"
        '
        'rtbMsg
        '
        Me.rtbMsg.BackColor = System.Drawing.Color.Black
        Me.rtbMsg.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.rtbMsg.Dock = System.Windows.Forms.DockStyle.Fill
        Me.rtbMsg.ForeColor = System.Drawing.SystemColors.Window
        Me.rtbMsg.Location = New System.Drawing.Point(3, 19)
        Me.rtbMsg.Name = "rtbMsg"
        Me.rtbMsg.ReadOnly = True
        Me.rtbMsg.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.ForcedVertical
        Me.rtbMsg.ShowSelectionMargin = True
        Me.rtbMsg.Size = New System.Drawing.Size(372, 183)
        Me.rtbMsg.TabIndex = 13
        Me.rtbMsg.Text = ""
        '
        'gbCommand
        '
        Me.gbCommand.Controls.Add(Me.btnWont)
        Me.gbCommand.Controls.Add(Me.cboPurge)
        Me.gbCommand.Controls.Add(Me.cboMoMask)
        Me.gbCommand.Controls.Add(Me.cboLnMask)
        Me.gbCommand.Controls.Add(Me.cboTControl)
        Me.gbCommand.Controls.Add(Me.cboTStopbit)
        Me.gbCommand.Controls.Add(Me.cboTParity)
        Me.gbCommand.Controls.Add(Me.cboTDSize)
        Me.gbCommand.Controls.Add(Me.cboTBaud)
        Me.gbCommand.Controls.Add(Me.btnPurge)
        Me.gbCommand.Controls.Add(Me.btnMoStMask)
        Me.gbCommand.Controls.Add(Me.btnLnStMask)
        Me.gbCommand.Controls.Add(Me.btnControl)
        Me.gbCommand.Controls.Add(Me.btnParity)
        Me.gbCommand.Controls.Add(Me.btnStopBit)
        Me.gbCommand.Controls.Add(Me.btnDataSize)
        Me.gbCommand.Controls.Add(Me.btnSetBaud)
        Me.gbCommand.Controls.Add(Me.btnWill)
        Me.gbCommand.Location = New System.Drawing.Point(6, 129)
        Me.gbCommand.Name = "gbCommand"
        Me.gbCommand.Size = New System.Drawing.Size(378, 173)
        Me.gbCommand.TabIndex = 20
        Me.gbCommand.TabStop = False
        Me.gbCommand.Text = "Commands"
        '
        'btnWont
        '
        Me.btnWont.Location = New System.Drawing.Point(248, 20)
        Me.btnWont.Name = "btnWont"
        Me.btnWont.Size = New System.Drawing.Size(84, 23)
        Me.btnWont.TabIndex = 25
        Me.btnWont.Text = "Over!"
        Me.btnWont.UseVisualStyleBackColor = True
        '
        'cboPurge
        '
        Me.cboPurge.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboPurge.FormattingEnabled = True
        Me.cboPurge.Location = New System.Drawing.Point(198, 141)
        Me.cboPurge.Name = "cboPurge"
        Me.cboPurge.Size = New System.Drawing.Size(80, 23)
        Me.cboPurge.TabIndex = 24
        '
        'cboMoMask
        '
        Me.cboMoMask.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboMoMask.FormattingEnabled = True
        Me.cboMoMask.Location = New System.Drawing.Point(198, 112)
        Me.cboMoMask.Name = "cboMoMask"
        Me.cboMoMask.Size = New System.Drawing.Size(80, 23)
        Me.cboMoMask.TabIndex = 23
        '
        'cboLnMask
        '
        Me.cboLnMask.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboLnMask.FormattingEnabled = True
        Me.cboLnMask.Location = New System.Drawing.Point(198, 83)
        Me.cboLnMask.Name = "cboLnMask"
        Me.cboLnMask.Size = New System.Drawing.Size(80, 23)
        Me.cboLnMask.TabIndex = 22
        '
        'cboTControl
        '
        Me.cboTControl.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboTControl.FormattingEnabled = True
        Me.cboTControl.Location = New System.Drawing.Point(198, 54)
        Me.cboTControl.Name = "cboTControl"
        Me.cboTControl.Size = New System.Drawing.Size(80, 23)
        Me.cboTControl.TabIndex = 21
        '
        'cboTStopbit
        '
        Me.cboTStopbit.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboTStopbit.FormattingEnabled = True
        Me.cboTStopbit.Location = New System.Drawing.Point(9, 140)
        Me.cboTStopbit.Name = "cboTStopbit"
        Me.cboTStopbit.Size = New System.Drawing.Size(80, 23)
        Me.cboTStopbit.TabIndex = 20
        '
        'cboTParity
        '
        Me.cboTParity.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboTParity.FormattingEnabled = True
        Me.cboTParity.Location = New System.Drawing.Point(9, 111)
        Me.cboTParity.Name = "cboTParity"
        Me.cboTParity.Size = New System.Drawing.Size(80, 23)
        Me.cboTParity.TabIndex = 19
        '
        'cboTDSize
        '
        Me.cboTDSize.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboTDSize.FormattingEnabled = True
        Me.cboTDSize.Location = New System.Drawing.Point(9, 82)
        Me.cboTDSize.Name = "cboTDSize"
        Me.cboTDSize.Size = New System.Drawing.Size(80, 23)
        Me.cboTDSize.TabIndex = 18
        '
        'cboTBaud
        '
        Me.cboTBaud.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboTBaud.FormattingEnabled = True
        Me.cboTBaud.Location = New System.Drawing.Point(9, 53)
        Me.cboTBaud.Name = "cboTBaud"
        Me.cboTBaud.Size = New System.Drawing.Size(80, 23)
        Me.cboTBaud.TabIndex = 17
        '
        'btnPurge
        '
        Me.btnPurge.Location = New System.Drawing.Point(284, 141)
        Me.btnPurge.Name = "btnPurge"
        Me.btnPurge.Size = New System.Drawing.Size(84, 23)
        Me.btnPurge.TabIndex = 16
        Me.btnPurge.Text = "Set Purge"
        Me.btnPurge.UseVisualStyleBackColor = True
        '
        'btnMoStMask
        '
        Me.btnMoStMask.Location = New System.Drawing.Point(284, 112)
        Me.btnMoStMask.Name = "btnMoStMask"
        Me.btnMoStMask.Size = New System.Drawing.Size(84, 23)
        Me.btnMoStMask.TabIndex = 15
        Me.btnMoStMask.Text = "Set moMask"
        Me.btnMoStMask.UseVisualStyleBackColor = True
        '
        'btnLnStMask
        '
        Me.btnLnStMask.Location = New System.Drawing.Point(284, 83)
        Me.btnLnStMask.Name = "btnLnStMask"
        Me.btnLnStMask.Size = New System.Drawing.Size(84, 23)
        Me.btnLnStMask.TabIndex = 14
        Me.btnLnStMask.Text = "Set LnMask"
        Me.btnLnStMask.UseVisualStyleBackColor = True
        '
        'btnControl
        '
        Me.btnControl.Location = New System.Drawing.Point(284, 54)
        Me.btnControl.Name = "btnControl"
        Me.btnControl.Size = New System.Drawing.Size(84, 23)
        Me.btnControl.TabIndex = 10
        Me.btnControl.Text = "Set Control"
        Me.btnControl.UseVisualStyleBackColor = True
        '
        'btnParity
        '
        Me.btnParity.Location = New System.Drawing.Point(98, 111)
        Me.btnParity.Name = "btnParity"
        Me.btnParity.Size = New System.Drawing.Size(84, 23)
        Me.btnParity.TabIndex = 8
        Me.btnParity.Text = "Set Parity"
        Me.btnParity.UseVisualStyleBackColor = True
        '
        'btnStopBit
        '
        Me.btnStopBit.Location = New System.Drawing.Point(98, 140)
        Me.btnStopBit.Name = "btnStopBit"
        Me.btnStopBit.Size = New System.Drawing.Size(84, 23)
        Me.btnStopBit.TabIndex = 6
        Me.btnStopBit.Text = "Set StopBit"
        Me.btnStopBit.UseVisualStyleBackColor = True
        '
        'btnDataSize
        '
        Me.btnDataSize.Location = New System.Drawing.Point(98, 82)
        Me.btnDataSize.Name = "btnDataSize"
        Me.btnDataSize.Size = New System.Drawing.Size(84, 23)
        Me.btnDataSize.TabIndex = 4
        Me.btnDataSize.Text = "Set DSize"
        Me.btnDataSize.UseVisualStyleBackColor = True
        '
        'btnSetBaud
        '
        Me.btnSetBaud.Location = New System.Drawing.Point(98, 53)
        Me.btnSetBaud.Name = "btnSetBaud"
        Me.btnSetBaud.Size = New System.Drawing.Size(84, 23)
        Me.btnSetBaud.TabIndex = 2
        Me.btnSetBaud.Text = "Set Baud"
        Me.btnSetBaud.UseVisualStyleBackColor = True
        '
        'btnWill
        '
        Me.btnWill.Location = New System.Drawing.Point(57, 20)
        Me.btnWill.Name = "btnWill"
        Me.btnWill.Size = New System.Drawing.Size(84, 23)
        Me.btnWill.TabIndex = 0
        Me.btnWill.Text = "Start!"
        Me.btnWill.UseVisualStyleBackColor = True
        '
        'gbLogin
        '
        Me.gbLogin.Controls.Add(Me.chkShowChar)
        Me.gbLogin.Controls.Add(Me.txtPassword)
        Me.gbLogin.Controls.Add(Me.Label39)
        Me.gbLogin.Controls.Add(Me.btnLogin)
        Me.gbLogin.Location = New System.Drawing.Point(6, 69)
        Me.gbLogin.Name = "gbLogin"
        Me.gbLogin.Size = New System.Drawing.Size(378, 54)
        Me.gbLogin.TabIndex = 19
        Me.gbLogin.TabStop = False
        Me.gbLogin.Text = "Login"
        '
        'chkShowChar
        '
        Me.chkShowChar.AutoSize = True
        Me.chkShowChar.Location = New System.Drawing.Point(167, 23)
        Me.chkShowChar.Name = "chkShowChar"
        Me.chkShowChar.Size = New System.Drawing.Size(112, 19)
        Me.chkShowChar.TabIndex = 21
        Me.chkShowChar.Text = "Show characters"
        Me.chkShowChar.UseVisualStyleBackColor = True
        '
        'txtPassword
        '
        Me.txtPassword.Location = New System.Drawing.Point(76, 21)
        Me.txtPassword.Name = "txtPassword"
        Me.txtPassword.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txtPassword.Size = New System.Drawing.Size(83, 23)
        Me.txtPassword.TabIndex = 20
        Me.txtPassword.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.Location = New System.Drawing.Point(6, 24)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(60, 15)
        Me.Label39.TabIndex = 19
        Me.Label39.Text = "Password:"
        '
        'btnLogin
        '
        Me.btnLogin.Location = New System.Drawing.Point(287, 18)
        Me.btnLogin.Name = "btnLogin"
        Me.btnLogin.Size = New System.Drawing.Size(81, 24)
        Me.btnLogin.TabIndex = 18
        Me.btnLogin.Text = "Login"
        Me.btnLogin.UseVisualStyleBackColor = True
        '
        'gbConnect
        '
        Me.gbConnect.Controls.Add(Me.txtTPort)
        Me.gbConnect.Controls.Add(Me.Label37)
        Me.gbConnect.Controls.Add(Me.Label38)
        Me.gbConnect.Controls.Add(Me.btnConnect)
        Me.gbConnect.Controls.Add(Me.txtTIP)
        Me.gbConnect.Location = New System.Drawing.Point(6, 6)
        Me.gbConnect.Name = "gbConnect"
        Me.gbConnect.Size = New System.Drawing.Size(378, 57)
        Me.gbConnect.TabIndex = 18
        Me.gbConnect.TabStop = False
        Me.gbConnect.Text = "Connect"
        '
        'txtTPort
        '
        Me.txtTPort.Location = New System.Drawing.Point(226, 22)
        Me.txtTPort.Name = "txtTPort"
        Me.txtTPort.Size = New System.Drawing.Size(52, 23)
        Me.txtTPort.TabIndex = 15
        Me.txtTPort.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.Location = New System.Drawing.Point(188, 25)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(32, 15)
        Me.Label37.TabIndex = 14
        Me.Label37.Text = "Port:"
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.Location = New System.Drawing.Point(6, 25)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(65, 15)
        Me.Label38.TabIndex = 13
        Me.Label38.Text = "IP Address:"
        '
        'btnConnect
        '
        Me.btnConnect.Location = New System.Drawing.Point(287, 20)
        Me.btnConnect.Name = "btnConnect"
        Me.btnConnect.Size = New System.Drawing.Size(81, 25)
        Me.btnConnect.TabIndex = 16
        Me.btnConnect.Text = "Connect"
        Me.btnConnect.UseVisualStyleBackColor = True
        '
        'txtTIP
        '
        Me.txtTIP.Location = New System.Drawing.Point(76, 22)
        Me.txtTIP.Name = "txtTIP"
        Me.txtTIP.Size = New System.Drawing.Size(108, 23)
        Me.txtTIP.TabIndex = 12
        Me.txtTIP.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'BottomToolStripPanel
        '
        Me.BottomToolStripPanel.Location = New System.Drawing.Point(0, 0)
        Me.BottomToolStripPanel.Name = "BottomToolStripPanel"
        Me.BottomToolStripPanel.Orientation = System.Windows.Forms.Orientation.Horizontal
        Me.BottomToolStripPanel.RowMargin = New System.Windows.Forms.Padding(3, 0, 0, 0)
        Me.BottomToolStripPanel.Size = New System.Drawing.Size(0, 0)
        '
        'TopToolStripPanel
        '
        Me.TopToolStripPanel.Location = New System.Drawing.Point(0, 0)
        Me.TopToolStripPanel.Name = "TopToolStripPanel"
        Me.TopToolStripPanel.Orientation = System.Windows.Forms.Orientation.Horizontal
        Me.TopToolStripPanel.RowMargin = New System.Windows.Forms.Padding(3, 0, 0, 0)
        Me.TopToolStripPanel.Size = New System.Drawing.Size(0, 0)
        '
        'RightToolStripPanel
        '
        Me.RightToolStripPanel.Location = New System.Drawing.Point(0, 0)
        Me.RightToolStripPanel.Name = "RightToolStripPanel"
        Me.RightToolStripPanel.Orientation = System.Windows.Forms.Orientation.Horizontal
        Me.RightToolStripPanel.RowMargin = New System.Windows.Forms.Padding(3, 0, 0, 0)
        Me.RightToolStripPanel.Size = New System.Drawing.Size(0, 0)
        '
        'LeftToolStripPanel
        '
        Me.LeftToolStripPanel.Location = New System.Drawing.Point(0, 0)
        Me.LeftToolStripPanel.Name = "LeftToolStripPanel"
        Me.LeftToolStripPanel.Orientation = System.Windows.Forms.Orientation.Horizontal
        Me.LeftToolStripPanel.RowMargin = New System.Windows.Forms.Padding(3, 0, 0, 0)
        Me.LeftToolStripPanel.Size = New System.Drawing.Size(0, 0)
        '
        'ContentPanel
        '
        Me.ContentPanel.Size = New System.Drawing.Size(150, 175)
        '
        'ToolStrip1
        '
        Me.ToolStrip1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ToolStrip1.Dock = System.Windows.Forms.DockStyle.None
        Me.ToolStrip1.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.ToolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.tsBtnSearch, Me.tsBtnSetting, Me.tsBtnUpload, Me.ToolStripSeparator1, Me.tsbPing, Me.tsbFire, Me.ToolStripSeparator2, Me.tsBtnExit})
        Me.ToolStrip1.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.HorizontalStackWithOverflow
        Me.ToolStrip1.Location = New System.Drawing.Point(336, 484)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Padding = New System.Windows.Forms.Padding(0)
        Me.ToolStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional
        Me.ToolStrip1.Size = New System.Drawing.Size(294, 61)
        Me.ToolStrip1.TabIndex = 7
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'tsBtnSearch
        '
        Me.tsBtnSearch.Image = CType(resources.GetObject("tsBtnSearch.Image"), System.Drawing.Image)
        Me.tsBtnSearch.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.tsBtnSearch.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsBtnSearch.Name = "tsBtnSearch"
        Me.tsBtnSearch.Size = New System.Drawing.Size(46, 58)
        Me.tsBtnSearch.Text = "Search"
        Me.tsBtnSearch.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.tsBtnSearch.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.tsBtnSearch.ToolTipText = "Search for WIZ1000"
        '
        'tsBtnSetting
        '
        Me.tsBtnSetting.AutoSize = False
        Me.tsBtnSetting.Image = CType(resources.GetObject("tsBtnSetting.Image"), System.Drawing.Image)
        Me.tsBtnSetting.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.tsBtnSetting.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsBtnSetting.Name = "tsBtnSetting"
        Me.tsBtnSetting.Size = New System.Drawing.Size(49, 58)
        Me.tsBtnSetting.Text = "Setting"
        Me.tsBtnSetting.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.tsBtnSetting.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.tsBtnSetting.ToolTipText = "Setting parameters"
        '
        'tsBtnUpload
        '
        Me.tsBtnUpload.AutoSize = False
        Me.tsBtnUpload.Image = CType(resources.GetObject("tsBtnUpload.Image"), System.Drawing.Image)
        Me.tsBtnUpload.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.tsBtnUpload.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsBtnUpload.Name = "tsBtnUpload"
        Me.tsBtnUpload.Size = New System.Drawing.Size(49, 58)
        Me.tsBtnUpload.Text = "Upload"
        Me.tsBtnUpload.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.tsBtnUpload.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.tsBtnUpload.ToolTipText = "Upgrade firmware"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(6, 61)
        '
        'tsbPing
        '
        Me.tsbPing.Image = CType(resources.GetObject("tsbPing.Image"), System.Drawing.Image)
        Me.tsbPing.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.tsbPing.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbPing.Name = "tsbPing"
        Me.tsbPing.Size = New System.Drawing.Size(36, 58)
        Me.tsbPing.Text = "Ping"
        Me.tsbPing.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.tsbPing.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.tsbPing.ToolTipText = "Ping"
        '
        'tsbFire
        '
        Me.tsbFire.Image = CType(resources.GetObject("tsbFire.Image"), System.Drawing.Image)
        Me.tsbFire.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.tsbFire.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbFire.Name = "tsbFire"
        Me.tsbFire.Size = New System.Drawing.Size(51, 58)
        Me.tsbFire.Text = "Firewall"
        Me.tsbFire.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.tsbFire.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.tsbFire.ToolTipText = "System firewall settings"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(6, 61)
        '
        'tsBtnExit
        '
        Me.tsBtnExit.AutoSize = False
        Me.tsBtnExit.Image = CType(resources.GetObject("tsBtnExit.Image"), System.Drawing.Image)
        Me.tsBtnExit.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.tsBtnExit.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsBtnExit.Name = "tsBtnExit"
        Me.tsBtnExit.Size = New System.Drawing.Size(49, 58)
        Me.tsBtnExit.Text = "Exit"
        Me.tsBtnExit.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.tsBtnExit.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'GroupBox10
        '
        Me.GroupBox10.Controls.Add(Me.lvBoard)
        Me.GroupBox10.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox10.Location = New System.Drawing.Point(12, 66)
        Me.GroupBox10.Name = "GroupBox10"
        Me.GroupBox10.Size = New System.Drawing.Size(197, 410)
        Me.GroupBox10.TabIndex = 10
        Me.GroupBox10.TabStop = False
        Me.GroupBox10.Text = "Search Results"
        '
        'lvBoard
        '
        Me.lvBoard.Activation = System.Windows.Forms.ItemActivation.OneClick
        Me.lvBoard.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader1, Me.ColumnHeader2})
        Me.lvBoard.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lvBoard.FullRowSelect = True
        Me.lvBoard.GridLines = True
        Me.lvBoard.HideSelection = False
        Me.lvBoard.Location = New System.Drawing.Point(10, 22)
        Me.lvBoard.MultiSelect = False
        Me.lvBoard.Name = "lvBoard"
        Me.lvBoard.Size = New System.Drawing.Size(177, 374)
        Me.lvBoard.Sorting = System.Windows.Forms.SortOrder.Ascending
        Me.lvBoard.TabIndex = 0
        Me.lvBoard.UseCompatibleStateImageBehavior = False
        Me.lvBoard.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader1
        '
        Me.ColumnHeader1.Text = "No"
        Me.ColumnHeader1.Width = 32
        '
        'ColumnHeader2
        '
        Me.ColumnHeader2.Text = "MAC Address"
        Me.ColumnHeader2.Width = 141
        '
        'ofdFw
        '
        Me.ofdFw.Filter = "Bin files|*.bin|All files|*.*"
        '
        'StatusStrip1
        '
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.tsLblStatus})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 550)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(645, 22)
        Me.StatusStrip1.TabIndex = 11
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'tsLblStatus
        '
        Me.tsLblStatus.ForeColor = System.Drawing.SystemColors.ActiveCaption
        Me.tsLblStatus.Margin = New System.Windows.Forms.Padding(6, 3, 0, 2)
        Me.tsLblStatus.Name = "tsLblStatus"
        Me.tsLblStatus.Size = New System.Drawing.Size(161, 17)
        Me.tsLblStatus.Text = "WIZ1000 Configuration Tool"
        '
        'GroupBox11
        '
        Me.GroupBox11.Controls.Add(Me.Label3)
        Me.GroupBox11.Controls.Add(Me.lblStatus)
        Me.GroupBox11.Controls.Add(Me.chkDebug)
        Me.GroupBox11.Controls.Add(Me.lblFwVer)
        Me.GroupBox11.Controls.Add(Me.Label1)
        Me.GroupBox11.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox11.Location = New System.Drawing.Point(12, 11)
        Me.GroupBox11.Name = "GroupBox11"
        Me.GroupBox11.Size = New System.Drawing.Size(624, 48)
        Me.GroupBox11.TabIndex = 12
        Me.GroupBox11.TabStop = False
        Me.GroupBox11.Text = "WIZ1000"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(451, 21)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(42, 15)
        Me.Label3.TabIndex = 9
        Me.Label3.Text = "Status:"
        '
        'lblStatus
        '
        Me.lblStatus.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.lblStatus.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblStatus.Location = New System.Drawing.Point(505, 16)
        Me.lblStatus.Name = "lblStatus"
        Me.lblStatus.Padding = New System.Windows.Forms.Padding(5, 3, 5, 3)
        Me.lblStatus.Size = New System.Drawing.Size(106, 23)
        Me.lblStatus.TabIndex = 8
        Me.lblStatus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'chkDebug
        '
        Me.chkDebug.AutoSize = True
        Me.chkDebug.Location = New System.Drawing.Point(232, 20)
        Me.chkDebug.Name = "chkDebug"
        Me.chkDebug.Size = New System.Drawing.Size(179, 19)
        Me.chkDebug.TabIndex = 7
        Me.chkDebug.Text = "Enable Serial Debug Mode(&B)"
        Me.chkDebug.UseVisualStyleBackColor = True
        '
        'lblFwVer
        '
        Me.lblFwVer.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.lblFwVer.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblFwVer.Location = New System.Drawing.Point(122, 16)
        Me.lblFwVer.Margin = New System.Windows.Forms.Padding(3)
        Me.lblFwVer.Name = "lblFwVer"
        Me.lblFwVer.Padding = New System.Windows.Forms.Padding(5, 3, 5, 3)
        Me.lblFwVer.Size = New System.Drawing.Size(75, 23)
        Me.lblFwVer.TabIndex = 6
        Me.lblFwVer.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(8, 21)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(101, 15)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "Firmware Version:"
        '
        'GroupBox13
        '
        Me.GroupBox13.Controls.Add(Me.txtDirectIP)
        Me.GroupBox13.Controls.Add(Me.chkDirectIP)
        Me.GroupBox13.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.GroupBox13.Location = New System.Drawing.Point(12, 479)
        Me.GroupBox13.Name = "GroupBox13"
        Me.GroupBox13.Size = New System.Drawing.Size(197, 66)
        Me.GroupBox13.TabIndex = 13
        Me.GroupBox13.TabStop = False
        Me.GroupBox13.Visible = False
        '
        'txtDirectIP
        '
        Me.txtDirectIP.Enabled = False
        Me.txtDirectIP.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDirectIP.Location = New System.Drawing.Point(24, 39)
        Me.txtDirectIP.Name = "txtDirectIP"
        Me.txtDirectIP.Size = New System.Drawing.Size(145, 23)
        Me.txtDirectIP.TabIndex = 11
        Me.txtDirectIP.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'chkDirectIP
        '
        Me.chkDirectIP.AutoSize = True
        Me.chkDirectIP.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.chkDirectIP.Location = New System.Drawing.Point(6, 17)
        Me.chkDirectIP.Name = "chkDirectIP"
        Me.chkDirectIP.Size = New System.Drawing.Size(153, 19)
        Me.chkDirectIP.TabIndex = 10
        Me.chkDirectIP.Text = "Direct IP Address Search"
        Me.chkDirectIP.UseVisualStyleBackColor = True
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(645, 572)
        Me.Controls.Add(Me.GroupBox13)
        Me.Controls.Add(Me.GroupBox11)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.GroupBox10)
        Me.Controls.Add(Me.ToolStrip1)
        Me.Controls.Add(Me.tabCtrl)
        Me.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "frmMain"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "frmMain"
        Me.tabCtrl.ResumeLayout(False)
        Me.TabPgNetwork.ResumeLayout(False)
        Me.TabPgNetwork.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.tabPgSerial.ResumeLayout(False)
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.tabPgOptions.ResumeLayout(False)
        Me.GroupBox9.ResumeLayout(False)
        Me.GroupBox9.PerformLayout()
        Me.GroupBox8.ResumeLayout(False)
        Me.GroupBox8.PerformLayout()
        Me.GroupBox7.ResumeLayout(False)
        Me.GroupBox7.PerformLayout()
        Me.GroupBox6.ResumeLayout(False)
        Me.GroupBox6.PerformLayout()
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        Me.tabPgTelnet.ResumeLayout(False)
        Me.GroupBox12.ResumeLayout(False)
        Me.gbCommand.ResumeLayout(False)
        Me.gbLogin.ResumeLayout(False)
        Me.gbLogin.PerformLayout()
        Me.gbConnect.ResumeLayout(False)
        Me.gbConnect.PerformLayout()
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.GroupBox10.ResumeLayout(False)
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        Me.GroupBox11.ResumeLayout(False)
        Me.GroupBox11.PerformLayout()
        Me.GroupBox13.ResumeLayout(False)
        Me.GroupBox13.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents tabCtrl As System.Windows.Forms.TabControl
    Friend WithEvents TabPgNetwork As System.Windows.Forms.TabPage
    Friend WithEvents tabPgSerial As System.Windows.Forms.TabPage
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents tabPgOptions As System.Windows.Forms.TabPage
    Friend WithEvents tabPgTelnet As System.Windows.Forms.TabPage
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents rbIpDhcp As System.Windows.Forms.RadioButton
    Friend WithEvents rbIpStatic As System.Windows.Forms.RadioButton
    Friend WithEvents rbIpPppoe As System.Windows.Forms.RadioButton
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtLIP As System.Windows.Forms.TextBox
    Friend WithEvents txtSIP As System.Windows.Forms.TextBox
    Friend WithEvents txtGwIP As System.Windows.Forms.TextBox
    Friend WithEvents txtSubnetMask As System.Windows.Forms.TextBox
    Friend WithEvents txtSPort As System.Windows.Forms.TextBox
    Friend WithEvents txtLPort As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents rbMixed As System.Windows.Forms.RadioButton
    Friend WithEvents rbServer As System.Windows.Forms.RadioButton
    Friend WithEvents rbClient As System.Windows.Forms.RadioButton
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents txtUdpIP As System.Windows.Forms.TextBox
    Friend WithEvents chkUDP As System.Windows.Forms.CheckBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents chkDNS As System.Windows.Forms.CheckBox
    Friend WithEvents txtDomain As System.Windows.Forms.TextBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents txtDnsIP As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents cboFlow As System.Windows.Forms.ComboBox
    Friend WithEvents cboStopBit As System.Windows.Forms.ComboBox
    Friend WithEvents cboParity As System.Windows.Forms.ComboBox
    Friend WithEvents cboDataBit As System.Windows.Forms.ComboBox
    Friend WithEvents cboBaud As System.Windows.Forms.ComboBox
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents txtChar As System.Windows.Forms.TextBox
    Friend WithEvents txtSize As System.Windows.Forms.TextBox
    Friend WithEvents txtTimer As System.Windows.Forms.TextBox
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents txtInactiveTimer As System.Windows.Forms.TextBox
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents txtKeepAliveInterval As System.Windows.Forms.TextBox
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents GroupBox7 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox6 As System.Windows.Forms.GroupBox
    Friend WithEvents txtTrigger3 As System.Windows.Forms.TextBox
    Friend WithEvents txtTrigger2 As System.Windows.Forms.TextBox
    Friend WithEvents txtTrigger1 As System.Windows.Forms.TextBox
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents chkTrigger As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox9 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox8 As System.Windows.Forms.GroupBox
    Friend WithEvents chkShowChar1 As System.Windows.Forms.CheckBox
    Friend WithEvents txtSearchPwd As System.Windows.Forms.TextBox
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents chkConnPwd As System.Windows.Forms.CheckBox
    Friend WithEvents chkShowChar3 As System.Windows.Forms.CheckBox
    Friend WithEvents txtTelnetPwd As System.Windows.Forms.TextBox
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents txtTelnetPort As System.Windows.Forms.TextBox
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents chkShowChar2 As System.Windows.Forms.CheckBox
    Friend WithEvents txtConnPwd As System.Windows.Forms.TextBox
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents BottomToolStripPanel As System.Windows.Forms.ToolStripPanel
    Friend WithEvents TopToolStripPanel As System.Windows.Forms.ToolStripPanel
    Friend WithEvents RightToolStripPanel As System.Windows.Forms.ToolStripPanel
    Friend WithEvents LeftToolStripPanel As System.Windows.Forms.ToolStripPanel
    Friend WithEvents ContentPanel As System.Windows.Forms.ToolStripContentPanel
    Friend WithEvents ToolStrip1 As System.Windows.Forms.ToolStrip
    Friend WithEvents tsBtnSearch As System.Windows.Forms.ToolStripButton
    Friend WithEvents tsBtnSetting As System.Windows.Forms.ToolStripButton
    Friend WithEvents tsBtnUpload As System.Windows.Forms.ToolStripButton
    Friend WithEvents tsBtnExit As System.Windows.Forms.ToolStripButton
    Friend WithEvents GroupBox10 As System.Windows.Forms.GroupBox
    Friend WithEvents lvBoard As System.Windows.Forms.ListView
    Friend WithEvents ColumnHeader1 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader2 As System.Windows.Forms.ColumnHeader
    Friend WithEvents txtPPwd As System.Windows.Forms.TextBox
    Friend WithEvents txtPID As System.Windows.Forms.TextBox
    Friend WithEvents chkShowPoePwd As System.Windows.Forms.CheckBox
    Friend WithEvents ofdFw As System.Windows.Forms.OpenFileDialog
    Friend WithEvents GroupBox12 As System.Windows.Forms.GroupBox
    Friend WithEvents gbCommand As System.Windows.Forms.GroupBox
    Friend WithEvents btnWont As System.Windows.Forms.Button
    Friend WithEvents cboPurge As System.Windows.Forms.ComboBox
    Friend WithEvents cboMoMask As System.Windows.Forms.ComboBox
    Friend WithEvents cboLnMask As System.Windows.Forms.ComboBox
    Friend WithEvents cboTControl As System.Windows.Forms.ComboBox
    Friend WithEvents cboTStopbit As System.Windows.Forms.ComboBox
    Friend WithEvents cboTParity As System.Windows.Forms.ComboBox
    Friend WithEvents cboTDSize As System.Windows.Forms.ComboBox
    Friend WithEvents cboTBaud As System.Windows.Forms.ComboBox
    Friend WithEvents btnPurge As System.Windows.Forms.Button
    Friend WithEvents btnMoStMask As System.Windows.Forms.Button
    Friend WithEvents btnLnStMask As System.Windows.Forms.Button
    Friend WithEvents btnControl As System.Windows.Forms.Button
    Friend WithEvents btnParity As System.Windows.Forms.Button
    Friend WithEvents btnStopBit As System.Windows.Forms.Button
    Friend WithEvents btnDataSize As System.Windows.Forms.Button
    Friend WithEvents btnSetBaud As System.Windows.Forms.Button
    Friend WithEvents btnWill As System.Windows.Forms.Button
    Friend WithEvents gbLogin As System.Windows.Forms.GroupBox
    Friend WithEvents chkShowChar As System.Windows.Forms.CheckBox
    Friend WithEvents txtPassword As System.Windows.Forms.TextBox
    Friend WithEvents Label39 As System.Windows.Forms.Label
    Friend WithEvents btnLogin As System.Windows.Forms.Button
    Friend WithEvents gbConnect As System.Windows.Forms.GroupBox
    Friend WithEvents txtTPort As System.Windows.Forms.TextBox
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents btnConnect As System.Windows.Forms.Button
    Friend WithEvents txtTIP As System.Windows.Forms.TextBox
    Friend WithEvents rtbMsg As System.Windows.Forms.RichTextBox
    Friend WithEvents StatusStrip1 As System.Windows.Forms.StatusStrip
    Friend WithEvents tsLblStatus As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents GroupBox11 As System.Windows.Forms.GroupBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents lblStatus As System.Windows.Forms.Label
    Friend WithEvents chkDebug As System.Windows.Forms.CheckBox
    Friend WithEvents lblFwVer As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents GroupBox13 As System.Windows.Forms.GroupBox
    Friend WithEvents txtDirectIP As System.Windows.Forms.TextBox
    Friend WithEvents chkDirectIP As System.Windows.Forms.CheckBox
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents tsbPing As System.Windows.Forms.ToolStripButton
    Friend WithEvents tsbFire As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator

End Class
