﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmSchPwd
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.btnConfirm = New System.Windows.Forms.Button()
        Me.lLblDelPwd = New System.Windows.Forms.LinkLabel()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.chkSavePwd = New System.Windows.Forms.CheckBox()
        Me.chkShowChar = New System.Windows.Forms.CheckBox()
        Me.txtSchPwd = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Panel1.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel1.Controls.Add(Me.GroupBox1)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Panel1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(323, 185)
        Me.Panel1.TabIndex = 9
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.btnExit)
        Me.GroupBox1.Controls.Add(Me.btnConfirm)
        Me.GroupBox1.Controls.Add(Me.lLblDelPwd)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.chkSavePwd)
        Me.GroupBox1.Controls.Add(Me.chkShowChar)
        Me.GroupBox1.Controls.Add(Me.txtSchPwd)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Location = New System.Drawing.Point(11, 11)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(299, 161)
        Me.GroupBox1.TabIndex = 8
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Input Search Password"
        '
        'btnExit
        '
        Me.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnExit.Location = New System.Drawing.Point(180, 113)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(90, 29)
        Me.btnExit.TabIndex = 5
        Me.btnExit.Text = "Exit(&E)"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'btnConfirm
        '
        Me.btnConfirm.Location = New System.Drawing.Point(29, 113)
        Me.btnConfirm.Name = "btnConfirm"
        Me.btnConfirm.Size = New System.Drawing.Size(90, 29)
        Me.btnConfirm.TabIndex = 4
        Me.btnConfirm.Text = "Confirm(&C)"
        Me.btnConfirm.UseVisualStyleBackColor = True
        '
        'lLblDelPwd
        '
        Me.lLblDelPwd.AutoSize = True
        Me.lLblDelPwd.Location = New System.Drawing.Point(197, 81)
        Me.lLblDelPwd.Name = "lLblDelPwd"
        Me.lLblDelPwd.Size = New System.Drawing.Size(40, 15)
        Me.lLblDelPwd.TabIndex = 3
        Me.lLblDelPwd.TabStop = True
        Me.lLblDelPwd.Text = "Delete"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.ForeColor = System.Drawing.Color.Red
        Me.Label2.Location = New System.Drawing.Point(199, 36)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(80, 15)
        Me.Label2.TabIndex = 7
        Me.Label2.Text = "(Max. 8 bytes)"
        '
        'chkSavePwd
        '
        Me.chkSavePwd.AutoSize = True
        Me.chkSavePwd.Location = New System.Drawing.Point(80, 81)
        Me.chkSavePwd.Name = "chkSavePwd"
        Me.chkSavePwd.Size = New System.Drawing.Size(103, 19)
        Me.chkSavePwd.TabIndex = 2
        Me.chkSavePwd.Text = "Sa&ve password"
        Me.chkSavePwd.UseVisualStyleBackColor = True
        '
        'chkShowChar
        '
        Me.chkShowChar.AutoSize = True
        Me.chkShowChar.Location = New System.Drawing.Point(80, 60)
        Me.chkShowChar.Name = "chkShowChar"
        Me.chkShowChar.Size = New System.Drawing.Size(107, 19)
        Me.chkShowChar.TabIndex = 1
        Me.chkShowChar.Text = "&Show character"
        Me.chkShowChar.UseVisualStyleBackColor = True
        '
        'txtSchPwd
        '
        Me.txtSchPwd.Font = New System.Drawing.Font("Segoe UI", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSchPwd.Location = New System.Drawing.Point(80, 33)
        Me.txtSchPwd.MaxLength = 8
        Me.txtSchPwd.Name = "txtSchPwd"
        Me.txtSchPwd.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txtSchPwd.Size = New System.Drawing.Size(113, 22)
        Me.txtSchPwd.TabIndex = 0
        Me.txtSchPwd.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(8, 36)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(60, 15)
        Me.Label1.TabIndex = 6
        Me.Label1.Text = "&Password:"
        '
        'frmSchPwd
        '
        Me.AcceptButton = Me.btnConfirm
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.btnExit
        Me.ClientSize = New System.Drawing.Size(323, 185)
        Me.Controls.Add(Me.Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.HelpButton = True
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmSchPwd"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "frmSchPwd"
        Me.Panel1.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents chkShowChar As System.Windows.Forms.CheckBox
    Friend WithEvents txtSchPwd As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents btnConfirm As System.Windows.Forms.Button
    Friend WithEvents lLblDelPwd As System.Windows.Forms.LinkLabel
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents chkSavePwd As System.Windows.Forms.CheckBox
    Friend WithEvents btnExit As System.Windows.Forms.Button
End Class
