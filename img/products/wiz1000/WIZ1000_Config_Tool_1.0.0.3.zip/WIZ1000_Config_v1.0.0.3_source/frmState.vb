﻿Public Class frmState
    Dim tStep As Integer = 1 'timer step

    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        frmMain.Enabled = True
        Timer1.Stop()

        Me.Close()

    End Sub

    Private Sub frmState_Activated(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Activated
        'set position of frmstate
        Dim locX As Integer = frmMain.Location.X + (frmMain.Width - Me.Width) / 2
        Dim locY As Integer = frmMain.Location.Y + (frmMain.Height - Me.Height) / 2
        Dim locP As Point = New Point
        locP.X = locX
        locP.Y = locY
        Me.Location = locP
    End Sub

   
    Private Sub frmState_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        ' pBar.Value = 30

        Select Case frmMain.ctState
            Case "sching"
                lblMsg.Text = "Searching"
                tStep = 4
                pBar.Maximum = 100
                btnClose.Text = "Cancel(&C)"
                Timer1.Start()
            Case "setting"
                lblMsg.Text = "Setting"
                tStep = 4
                pBar.Maximum = 100
                btnClose.Text = "Cancel(&C)"
                Timer1.Start()
            Case "fwup"
                lblMsg.Text = "Firmware uploading"
                btnClose.Enabled = False
                tStep = 1
                'pbar.Value=
        End Select


    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        If pBar.Value < pBar.Maximum Then pBar.Value += tStep

        If pBar.Value = pBar.Maximum Then
            Select Case frmMain.ctState
                Case "schover"
                    btnClose.Text = "Close(&C)"
                    lblMsg.Text = "Search over (Find: " & frmMain.lvBoard.Items.Count & ")"
                Case "setover"
                    btnClose.Text = "Close(&C)"
                    lblMsg.Text = "Setting [" & frmMain.lvBoard.SelectedItems(0).SubItems(1).Text & "] over."
                Case "fwover"
                    lblMsg.Text = "Firmware of [" & frmMain.lvBoard.SelectedItems(0).SubItems(1).Text & "] upgraded successfully."
            End Select
            Timer1.Stop()

        End If

    End Sub

End Class