Imports System
Imports System.Net
Imports System.Net.Sockets
Imports System.Text
Imports System.Text.RegularExpressions
Imports System.Collections
Imports System.Runtime.InteropServices
Public Class frmMain

#Region "global parameters"
    Friend ctState As String
    'sching, schover, setting, setover, fwup, fwover

    Friend ConfigMsgLen = 187

    Friend isSchOk As Boolean = False
    Friend SchPwd As String = ""
    Friend SchCmd As String = "FIND"
    Friend SetCmd As String = "SETT"
    Friend UpCmd As String = "FIRS"

#End Region
#Region "private Parameters"
    Private sckUDP As Socket
    Private sckTcpDir As Socket
    'Private sckUp As Socket 'firmware upload, TCP
    Private sckTelnet As Socket 'telnet, TCP

    Private UdpPort As Integer = 5003 'broadcast searching
    Private DirPort As Integer = 5004 'direct ip searching
    Private fwUpPort As Integer = 5005 'firmware upload port

    Private remEp As IPEndPoint 'udp ip end point
    Private tcpRemEp As IPEndPoint 'tcp ip end point
    Private telnetRemEp As IPEndPoint
    Private uIdx As Integer 'updated board index
    Private fwUploadErr As Boolean = 0
    Private fwUploadBtnClkFlg As Boolean = 0
    Private sndBytes As Integer = 0

    Private tConv As New TypeConverter

    Private selectedItem As New ListViewItem
    Private Structure myDataItem
        Dim Name As String
        Dim rVal As Byte
        Public Sub New(ByVal _name As String, ByVal _value As Byte)
            Name = _name
            rVal = _value

        End Sub
        Public Overrides Function ToString() As String
            Return Me.Name
        End Function
    End Structure
#End Region
#Region "Telnet Com Port Options"
    Private Const IAC = 255
    Private Const WILL = 251
    Private Const WONT = 252
    Private Const SB = 250
    Private Const DDO = 253
    Private Const DONT = 254
    Private Const SE = 240
    Private Const NOP = 241
    'Com Port Options
    Private Const COM_PORT_OPTION = 44
    'client to sever, if server to client, the value should be added 100 !!!
    Private Const SET_BAUDRATE = 1
    Private Const SET_DATASIZE = 2
    Private Const SET_PARITY = 3
    Private Const SET_STOPSIZE = 4
    Private Const SET_CONTROL = 5
    Private Const NOTIFY_LINESTATE = 6
    Private Const NOTIFY_MODEMSTATE = 7
    Private Const FLOWCONTROL_SUSPEND = 8
    Private Const FLOWCONTROL_RESUME = 9
    Private Const SET_LINESTATE_MASK = 10
    Private Const SET_MODEMSTATE_MASK = 11
    Private Const PURGE_DATA = 12
    'shared private variable
    Private isConRequestSent As Boolean = False
    Private isRtsRequestSent As Boolean = False
    Private isCtsRequestSent As Boolean = False

    Private Function Num_to_Cmd(ByVal number As Byte) As String
        Select Case number
            Case 255
                Return "IAC"
            Case 251
                Return "WILL"
            Case 252
                Return "WON'T"
            Case 250
                Return "SB"
            Case 253
                Return "DO"
            Case 254
                Return "DON'T"
            Case 240
                Return "SE"
            Case 241
                Return "NOP"
            Case 44
                Return "COM-PORT-OPTION"
            Case 1, 101
                Return "SET-BAUDRATE"
            Case 2, 102
                Return "SET-DATASIZE"
            Case 3, 103
                Return "SET-PARITY"
            Case 4, 104
                Return "SET-STOPSIZE"
            Case 5, 105
                Return "SET-CONTROL"
            Case 6, 106
                Return "NOTIFY-LINESTATE"
            Case 7, 107
                Return "NOTIFY-MODEMSTATE"
            Case 8, 108
                Return "FLOWCONTROL-SUSPEND"
            Case 9, 109
                Return "FLOWCONTROL-RESUME"
            Case 10, 110
                Return "SET-LINESTATE-MASK"
            Case 11, 111
                Return "SET-MODEMSTATE-MASK"
            Case 12, 112
                Return "PURGE-DATA"

            Case Else
                Return number.ToString

        End Select
    End Function
    'IAC WILL COM-PORT-OPTION
    ''' <summary>
    ''' Client Send Negociation: Will Com port option
    ''' </summary>
    ''' <param name="cmd"></param>
    ''' <returns>3 bytes to send</returns>
    ''' <remarks></remarks>
    Private Function Build_Send_Nego(ByVal cmd As Byte) As Byte()
        Dim b(2) As Byte
        b(0) = IAC
        b(1) = cmd
        b(2) = COM_PORT_OPTION
        Return b
    End Function
    '++++++++++++++++++++++++++++++++++++++
    '+   Com Port Configuration Commands  +
    '++++++++++++++++++++++++++++++++++++++
    ''' <summary>
    ''' convert a 32bit integer to a 4 bytes array
    ''' </summary>
    ''' <param name="i"></param>
    ''' <returns>4 bytes array</returns>
    ''' <remarks></remarks>
    Private Function Int32To4Bytes(ByVal i As UInt32) As Byte()
        Dim b(3) As Byte
        b(0) = CType(i >> 24, Byte)
        b(1) = CType((i >> 16) And &HFF, Byte)
        b(2) = CType((i >> 8) And &HFF, Byte)
        b(3) = CType((i >> 0) And &HFF, Byte)
        Return b
    End Function
    ''' <summary>
    ''' convert a 4 bytes array to a 32bit integer
    ''' </summary>
    ''' <param name="b"></param>
    ''' <returns>a 32bit integer</returns>
    ''' <remarks></remarks>
    Private Function BytesToUInt32(ByVal b() As Byte, ByVal index As Int16, ByVal len As Int16) As UInt32
        Dim i As Int16
        Dim ret As UInt32
        For i = index To index + len - 1
            ret += b(i) * 2 ^ ((index + len - 1 - i) * 8)
        Next
        Return ret

    End Function

    'IAC SB COM-PORT-OPTION SET-BAUD <value(4)> IAC SE
    ''' <summary>
    ''' Build the byte() to set baud rate
    ''' </summary>
    ''' <param name="baud">if baud=0, it means to query the baud rate of other side</param>
    ''' <returns>a 10 bytes array</returns>
    ''' <remarks></remarks>
    Private Function Build_Set_Baud(ByVal baud As UInt32) As Byte()
        Dim b(10 - 1) As Byte
        Dim bBaud() As Byte = Int32To4Bytes(baud)
        b(0) = IAC
        b(1) = SB
        b(2) = COM_PORT_OPTION
        b(3) = SET_BAUDRATE
        b(4) = bBaud(0) ' CType(baud >> 24, Byte)
        Debug.Print(b(4))
        b(5) = bBaud(1) ' CType((baud >> 16) And &HFF, Byte)
        Debug.Print(b(5))
        b(6) = bBaud(2) ' CType((baud >> 8) And &HFF, Byte)
        Debug.Print(b(6))
        b(7) = bBaud(3) ' CType(baud And &HFF, Byte)
        Debug.Print(b(7))
        b(8) = IAC
        b(9) = SE
        Return b
    End Function
    'IAC SB COM-PORT-OPTION SET-DATASIZE <value> IAC SE
    ''''''''''''''''''''''''''''''''''''''''''''''''''''
    'Value       Data Bit Size
    '0           Request Current Data Bit Size
    '1           Available for Future Use
    '2           Available for Future Use
    '3           Available for Future Use
    '4           Available for Future Use
    '5           5
    '6           6
    '7           7
    '8           8
    '9-127       Available for Future Use
    ''' <summary>
    ''' Building the sending byte array to Set DataSize
    ''' </summary>
    ''' <param name="size"></param>
    ''' <returns>7 bytes to send</returns>
    ''' <remarks>if size=0, it means to query the datasize of other side</remarks>
    Private Function Build_Set_DataSize(ByVal size As Byte) As Byte()
        Dim b(6) As Byte
        b(0) = IAC
        b(1) = SB
        b(2) = COM_PORT_OPTION
        b(3) = SET_DATASIZE
        b(4) = size
        b(5) = IAC
        b(6) = SE
        Return b
    End Function
    'IAC SB COM-PORT-OPTION SET-PARITY <value> IAC SE
    'Value      Parity [1]
    '0           Request Current Data Size
    '1           NONE
    '2           ODD
    '3           EVEN
    '4           MARK
    '5           SPACE
    '6-127       Available for Future Use
    ''' <summary>
    ''' 
    ''' </summary>
    ''' <param name="size"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function Build_Set_Parity(ByVal size As Byte) As Byte()
        Dim b(6) As Byte
        b(0) = IAC
        b(1) = SB
        b(2) = COM_PORT_OPTION
        b(3) = SET_PARITY
        b(4) = size
        b(5) = IAC
        b(6) = SE
        Return b
    End Function
    'IAC SB COM-PORT-OPTION SET-STOPSIZE <value> IAC SE
    'Value      Stop Bit Size
    '0           Request Current Data Size
    '1           1
    '2           2
    '3           1.5
    '4-127       Available for Future Use
    ''' <summary>
    ''' 
    ''' </summary>
    ''' <param name="size"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function Build_Set_StopSize(ByVal size As Byte) As Byte()
        Dim b(6) As Byte
        b(0) = IAC
        b(1) = SB
        b(2) = COM_PORT_OPTION
        b(3) = SET_STOPSIZE
        b(4) = size
        b(5) = IAC
        b(6) = SE
        Return b
    End Function

    '+++++++++++++++++++++++++++++++++++++
    '+ Special Com Port Control Commands +
    '+++++++++++++++++++++++++++++++++++++

    'IAC SB COM-PORT-OPTION SET-CONTROL <value> IAC SE
    'Value      Control Commands
    '0           Request Com Port Flow Control Setting (outbound/both)
    '1           Use No Flow Control (outbound/both)
    '2           Use XON/XOFF Flow Control (outbound/both)
    '3           Use HARDWARE Flow Control (outbound/both)
    '4           Request BREAK State
    '5           Set BREAK State ON
    '6           Set BREAK State OFF
    '7           Request DTR Signal State
    '8           Set DTR Signal State ON
    '9           Set DTR Signal State OFF
    '10           Request RTS Signal State
    '11           Set RTS Signal State ON
    '12           Set RTS Signal State OFF
    '13           Request Com Port Flow Control Setting (inbound)
    '14           Use No Flow Control (inbound)
    '15           Use XON/XOFF Flow Control (inbound)
    '16           Use HARDWARE Flow Control (inbound)
    '17           Use DCD Flow Control (outbound/both)
    '18           Use DTR Flow Control (inbound)
    '19           Use DSR Flow Control (outbound/both)
    '20-127       Available for Future Use
    ''' <summary>
    ''' 
    ''' </summary>
    ''' <param name="value"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function Build_Set_Control(ByVal value As Byte) As Byte()
        Dim b(6) As Byte
        b(0) = IAC
        b(1) = SB
        b(2) = COM_PORT_OPTION
        b(3) = SET_CONTROL
        b(4) = value
        b(5) = IAC
        b(6) = SE
        Return b
    End Function
    'IAC SB COM-PORT-OPTION SET-LINESTATE-MASK <value> IAC SE
    'Bit Position     Value     Meaning
    '7              128         Time-out Error
    '6               64         Transfer Shift Register Empty
    '5               32         Transfer Holding Register Empty
    '4               16         Break-detect Error
    '3                8         Framing Error
    '2                4         Parity Error
    '1                2         Overrun Error
    '0                1         Data Ready
    ''' <summary>
    ''' 
    ''' </summary>
    ''' <param name="value"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function Build_Set_LineStateMask(ByVal value As Byte) As Byte()
        Dim b(6) As Byte
        b(0) = IAC
        b(1) = SB
        b(2) = COM_PORT_OPTION
        b(3) = SET_LINESTATE_MASK
        b(4) = value
        b(5) = IAC
        b(6) = SE
        Return b
    End Function
    'IAC SB COM-PORT-OPTION SET-MODEMSTATE-MASK <value> IAC SE
    'Bit Position     Value     Meaning
    '7              128        Receive Line Signal Detect (also known as Carrier Detect)
    '6               64        Ring Indicator
    '5               32        Data-Set-Ready Signal State
    '4               16        Clear-To-Send Signal State
    '3                8        Delta Receive Line Signal Detect
    '2                4        Trailing-edge Ring Detector
    '1                2        Delta Data-Set-Ready
    '0                1        Delta Clear-To-Send
    ''' <summary>
    ''' 
    ''' </summary>
    ''' <param name="value"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function Build_Set_ModemStateMask(ByVal value As Byte) As Byte()
        Dim b(6) As Byte
        b(0) = IAC
        b(1) = SB
        b(2) = COM_PORT_OPTION
        b(3) = SET_MODEMSTATE_MASK
        b(4) = value
        b(5) = IAC
        b(6) = SE
        Return b
    End Function

    'IAC SB COM-PORT-OPTION PURGE-DATA <value> IAC SE
    'Value      Purge Data Buffer
    '0           Available for Future Use
    '1           Purge access server receive data buffer
    '2           Purge access server transmit data buffer
    '3           Purge both the access server receive data
    '            buffer and the access server transmit data
    '            buffer
    '4-127       Available for Future Use
    ''' <summary>
    ''' 
    ''' </summary>
    ''' <param name="value"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function Build_Set_PurgeData(ByVal value As Byte) As Byte()
        Dim b(6) As Byte
        b(0) = IAC
        b(1) = SB
        b(2) = COM_PORT_OPTION
        b(3) = PURGE_DATA
        b(4) = value
        b(5) = IAC
        b(6) = SE
        Return b
    End Function
#End Region
#Region "Delegate function"
    Private Delegate Sub SetTextCallback(ByVal ctrl As Control, ByVal [text] As String)
    Private Sub SetText(ByVal ctrl As Control, ByVal text As String)
        If ctrl.InvokeRequired Then
            Dim d As New SetTextCallback(AddressOf SetText)
            Me.Invoke(d, New Object() {[ctrl], [text]})
        Else
            ctrl.Text = text
        End If
    End Sub
    Private Delegate Sub lvAddItemCallback(ByVal lv As ListView, ByVal [itm] As ListViewItem)
    Private Sub lvAdd(ByVal lv As ListView, ByVal itm As ListViewItem)
        If lv.InvokeRequired Then
            Dim d As New lvAddItemCallback(AddressOf lvAdd)
            Me.Invoke(d, New Object() {[lv], [itm]})
        Else
            If itm.Text = "" Then itm.Text = lv.Items.Count
            lv.Items.Add(itm)
            lv.Items(uIdx).Selected = True

        End If

    End Sub
    Private Delegate Sub SetRtbTxtCallback(ByVal rtb As RichTextBox, ByVal [text] As String, ByVal isAppend As Boolean)
    Private Sub SetRtbTxt(ByVal rtb As RichTextBox, ByVal text As String, ByVal isAppend As Boolean)
        If rtb.InvokeRequired Then
            Dim d As New SetRtbTxtCallback(AddressOf SetRtbTxt)
            Me.Invoke(d, New Object() {[rtb], [text], [isAppend]})
        Else
            If isAppend Then
                rtb.AppendText(text)
                'rtb.Select(rtb.TextLength, 0)
                rtb.ScrollToCaret()

            Else
                rtb.Text = text
            End If
        End If
    End Sub
    Private Delegate Sub SetCtrlStateCallback(ByVal ctrl As Control, ByVal enabled As Boolean)
    Private Sub setCtrlState(ByVal ctrl As Control, ByVal enabled As Boolean)
        If ctrl.InvokeRequired Then
            Dim d As New SetCtrlStateCallback(AddressOf setCtrlState)
            Me.Invoke(d, New Object() {[ctrl], [enabled]})
        Else
            ctrl.Enabled = enabled

        End If
    End Sub
#End Region
#Region "Board processing"
    ''' <summary>
    ''' get the operation mode from byte array from socket
    ''' </summary>
    ''' <param name="dat"></param>
    ''' <returns>4 bytes character</returns>
    ''' <remarks></remarks>
    Private Function GetOpMode(ByVal dat() As Byte) As String
        Dim ret As String = Encoding.ASCII.GetString(dat, 0, 4)
        Return ret
    End Function
    ''' <summary>
    ''' get mac address string from board info msg
    ''' </summary>
    ''' <param name="bd"></param>
    ''' <returns>mac address string</returns>
    ''' <remarks></remarks>
    Private Function GetMacAddr(ByVal bd As clsBoard) As String
        Dim ret As String = ""
        Dim i As Integer = 0
        For i = 0 To 4
            ret += bd.Mac(i).ToString("X2") & ":"
        Next
        ret += bd.Mac(5).ToString("X2")
        Return ret
    End Function
    Private Function GetIPStr(ByVal b() As Byte) As String
        Dim ret As String = ""
        Dim i As Integer = 0
        For i = 0 To 2
            ret += b(i).ToString & "."
        Next
        ret += b(3).ToString
        Return ret

    End Function
    Private Function GetIpBytes(ByVal IP As String) As Byte()
        Dim i As Integer = 0
        Dim ret(3) As Byte
        If IP.Length > 0 Then
            Dim s() As String = IP.Split(".")
            If s.Length = 4 Then
                For i = 0 To s.Length - 1
                    ret(i) = CInt(s(i))
                Next
            Else
                MessageBox.Show("Invalid IP Address.", "IP address error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If

        End If

        Return ret

    End Function

    Private Function IpValidation(ByVal txt As TextBox) As Boolean
        Dim ret As Boolean = False
        Dim sPattern As String = "^(?:(?:25[0-5]|2[0-4]\d|[01]\d\d|\d?\d)(?(?=\.?\d)\.)){4}$"
        Dim oRegex As New Regex(sPattern, RegexOptions.Singleline)
        If Not oRegex.IsMatch(txt.Text) Then
            MessageBox.Show("It looks like that you input an invalid IP Address." & vbCrLf & "Please input it again.", "Invalid IP Address", MessageBoxButtons.OK, MessageBoxIcon.Error)
            ret = False
            txt.Focus()
            txt.SelectAll()
        Else
            ret = True
        End If
        Return ret

    End Function
    Private Sub StrToBytes(ByVal str As String, ByVal b() As Byte)
        Dim n As Integer = b.Length
        If str.Length < n Then
            Dim i As Integer
            For i = 0 To n - str.Length - 1
                str += " "
            Next

        End If
        Encoding.Default.GetBytes(str, 0, n, b, 0)

    End Sub
    Private Function GetUInt16(ByVal b() As Byte) As String
        Dim ret As UInt16 = b(0) * 256 + b(1)
        Return ret

    End Function
    Private Function GetUintBytes(ByVal num As UInt16) As Byte()
        Dim ret(1) As Byte
        ret(0) = num \ 256
        ret(1) = num Mod 256
        Return ret

    End Function
    Private Sub AddOneBoard(ByVal bd As clsBoard)
        Dim Mac As String = GetMacAddr(bd)
    

        Dim itm As New ListViewItem

        'itm.Text = bdCnt
        Dim sItm As New ListViewItem.ListViewSubItem
        sItm.Text = Mac
        itm.SubItems.Add(Mac)
        itm.Tag = bd
        lvAdd(lvBoard, itm) 'add the mac to listview


        'End If


    End Sub
    Private Sub UpdateOneBoard(ByVal bd As clsBoard)
        Dim mac As String = GetMacAddr(bd)


        Dim itm As New ListViewItem
        itm.Text = uIdx


        itm.SubItems.Add(mac)

        itm.Tag = bd
        lvAdd(lvBoard, itm)


    End Sub
#End Region
#Region "Socket Functions"
    Private Class StateObject
        'work socket
        Public wSck As Socket = Nothing
        'size of receive buffer
        Public Const bufSize As Integer = 2048
        'receive buffer
        Public buf(bufSize - 1) As Byte
    End Class
    Private Sub Connect(ByVal sck As Socket)
        Select Case sck.ProtocolType
            Case ProtocolType.Tcp
                'sck = New Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp)
                'begin connect
                sck.BeginConnect(tcpRemEp, New AsyncCallback(AddressOf ConnectCallback), sck)
            Case ProtocolType.Udp
                'begin receive
                Receive(sck)

            Case Else
                MessageBox.Show(Me, "Undefined protocol type!", Me.Text)

        End Select

    End Sub
    Private Sub ConnectCallback(ByVal ar As IAsyncResult)
        If ar.IsCompleted Then
            'retrieve the socket from the state object
            Dim client As Socket = CType(ar.AsyncState, Socket)
            Try
                'complete the connection
                client.EndConnect(ar)


                Receive(client)

            Catch ex As Exception
                MessageBox.Show(ex.Message, Me.Text, MessageBoxButtons.OK)

            End Try
        End If

    End Sub
    Private Sub TelnetConnectCallback(ByVal ar As IAsyncResult)
        If ar.IsCompleted Then
            'retrieve the socket from the state object
            Dim client As Socket = CType(ar.AsyncState, Socket)
            Try
                'complete the connection
                client.EndConnect(ar)
                SetText(btnConnect, "Disconnect")
                'enable groupbox
                setCtrlState(gbLogin, True)
                setCtrlState(gbCommand, True)

                Receive(client)

            Catch ex As Exception
                MessageBox.Show(ex.Message, Me.Text, MessageBoxButtons.OK)

            End Try
        End If

    End Sub
    Private Sub DisconnectCallback(ByVal ar As IAsyncResult)
        If ar.IsCompleted Then
            Dim client As Socket = CType(ar.AsyncState, Socket)
            Try
                client.EndDisconnect(ar)
                'client.Shutdown(SocketShutdown.Both)
                ' client.Close()

            Catch ex As Exception

            End Try
        End If
    End Sub
    Private Sub Receive(ByVal sck As Socket)
        'create the state object
        Dim state As New StateObject
        state.wSck = sck
        Select Case sck.ProtocolType
            Case ProtocolType.Tcp
                sck.BeginReceive(state.buf, 0, StateObject.bufSize, 0, New AsyncCallback(AddressOf ReceiveCallback), state)
            Case ProtocolType.Udp
                sck.BeginReceiveFrom(state.buf, 0, StateObject.bufSize, SocketFlags.None, remEp, New AsyncCallback(AddressOf ReceiveCallback), state)

        End Select
    End Sub
    Private Sub ReceiveCallback(ByVal ar As IAsyncResult)
        If ar.IsCompleted Then
            Dim state As StateObject = CType(ar.AsyncState, StateObject)
            Dim sck As Socket = state.wSck

            Dim bytesRead As Integer = 0
            Select Case sck.ProtocolType
                Case ProtocolType.Tcp 'TCP, only telnet receive data
                    Try
                        bytesRead = sck.EndReceive(ar)
                    Catch ex As Exception

                    End Try

                    If bytesRead > 0 Then
                        'do telnet processing
                        Dim tmpDat(bytesRead - 1) As Byte
                        Array.ConstrainedCopy(state.buf, 0, tmpDat, 0, bytesRead)
                        If bytesRead > 30 Then
                            Dim msg As String = Encoding.ASCII.GetString(tmpDat, 0, bytesRead)
                            SetRtbTxt(rtbMsg, msg, True)
                        Else

                            Dim i As Integer
                            Dim msg As String = ""
                            Select Case bytesRead
                                Case 3
                                    For i = 0 To bytesRead - 1
                                        msg += Num_to_Cmd(tmpDat(i)) & " "
                                    Next
                                    msg += vbCrLf

                                Case 7
                                    For i = 0 To 3
                                        msg += Num_to_Cmd(tmpDat(i)) & " "
                                    Next
                                    Select Case tmpDat(3)
                                        Case SET_PARITY
                                            Select Case tmpDat(4)
                                                Case 1
                                                    msg += "NONE"
                                                Case 2
                                                    msg += "ODD"
                                                Case 3
                                                    msg += "EVEN"
                                                Case 4
                                                    msg += "MARK"
                                                Case 5
                                                    msg += "SPACE"

                                            End Select
                                        Case SET_STOPSIZE
                                            Select Case tmpDat(4)
                                                Case 1
                                                    msg += "1"
                                                Case 2
                                                    msg += "2"
                                                Case 3
                                                    msg += "1.5"
                                            End Select
                                        Case SET_CONTROL
                                            Select Case tmpDat(4)
                                                Case 0
                                                    If isRtsRequestSent Then
                                                        msg += "RTS==OFF"
                                                    Else
                                                        msg += "CTS==OFF"
                                                    End If

                                                Case 1
                                                    If isConRequestSent Then
                                                        msg += "NONE"
                                                    ElseIf isRtsRequestSent Then
                                                        msg += "RTS==ON"
                                                    Else
                                                        msg += "CTS==ON"
                                                    End If

                                                Case 2
                                                    msg += "XON/XOFF"
                                                Case 3
                                                    msg += "HARDWARE"
                                            End Select
                                        Case SET_DATASIZE
                                            msg += tmpDat(4).ToString

                                    End Select
                                    msg += " "
                                    For i = 5 To 6
                                        msg += Num_to_Cmd(tmpDat(i)) & " "
                                    Next
                                    msg += vbCrLf

                                Case 10
                                    For i = 0 To 3
                                        msg += Num_to_Cmd(tmpDat(i)) & " "
                                    Next
                                    msg += BytesToUInt32(tmpDat, 4, 4).ToString & " "

                                    For i = 8 To 9
                                        msg += Num_to_Cmd(tmpDat(i)) & " "
                                    Next
                                    msg += vbCrLf

                            End Select
                            msg = "<<" & msg

                            SetRtbTxt(rtbMsg, msg, True)

                        End If
                 
                    End If
                    Try
                        sck.BeginReceive(state.buf, 0, StateObject.bufSize, 0, New AsyncCallback(AddressOf ReceiveCallback), state)
                    Catch ex As Exception

                    End Try


                Case ProtocolType.Udp 'UDP, searching & setting results

                    bytesRead = sck.EndReceiveFrom(ar, remEp)
                    If bytesRead > 0 Then
                        'udp data processing
                        Dim dat(bytesRead - 1) As Byte
                        Array.ConstrainedCopy(state.buf, 0, dat, 0, bytesRead)
                        Dim tConverter As New TypeConverter

                        tConverter.Length = bytesRead 'set the length
                        Dim bd As clsBoard = New clsBoard
                        bd = tConverter.GetBoardInfoFromBytes(dat)

                        'Debug.Print(GetMacAddr(Board))
                        'Debug.Print(GetOpMode(dat))
                        If Encoding.Default.GetString(bd.opMode) = "IMIN" Then

                            Call AddOneBoard(bd)

                            ctState = "schover"


                        ElseIf Encoding.Default.GetString(bd.opMode) = "SETC" Then
                            Call UpdateOneBoard(bd)
                            Debug.Print("setc")
                            ctState = "setover"

                        End If
                        'receive again
                        sck.BeginReceiveFrom(state.buf, 0, StateObject.bufSize, SocketFlags.None, remEp, New AsyncCallback(AddressOf ReceiveCallback), state)

                    End If
            End Select
        End If

    End Sub
    Private Sub Send(ByVal sck As Socket, ByVal dat() As Byte)
        Try
            Select Case sck.ProtocolType
                Case ProtocolType.Tcp
                    'begin sending the data
                    sck.BeginSend(dat, 0, dat.Length, SocketFlags.None, New AsyncCallback(AddressOf SendCallback), sck)
                

                Case ProtocolType.Udp
                    sck.BeginSendTo(dat, 0, dat.Length, SocketFlags.None, remEp, New AsyncCallback(AddressOf SendCallback), sck)
            End Select
        Catch ex As Exception
            Debug.Print(ex.ToString)

            If fwUploadBtnClkFlg Then fwUploadErr = 1

        End Try


    End Sub
    Private Sub SendCallback(ByVal ar As IAsyncResult)
        If ar.IsCompleted Then
            Dim sck As Socket = CType(ar.AsyncState, Socket)

            Try
                Dim bytesSent As Integer = 0
                Select Case sck.ProtocolType
                    Case ProtocolType.Tcp
                        bytesSent = sck.EndSend(ar)

                        sndBytes += bytesSent



                    Case ProtocolType.Udp
                        bytesSent = sck.EndSendTo(ar)
                End Select
       
            Catch ex As Exception
                Debug.Print(ex.ToString)

                'MessageBox.Show(Me, ex.Message, Me.Text)
                'MessageBox.Show("Firmware upload error ocurrs!", "Uplaod Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                If fwUploadBtnClkFlg Then fwUploadErr = 1
            End Try
        Else
            MsgBox("ar is not completed")
        End If

    End Sub

#End Region

    Private Sub frmMain_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        If sckTelnet.Connected Then
            sckTelnet.BeginDisconnect(False, New AsyncCallback(AddressOf DisconnectCallback), sckTelnet)

        End If

    End Sub


    Private Sub frmMain_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Me.Text = "WIZ1000 Configuration Tool Ver " & Application.ProductVersion
        tConv.Length = ConfigMsgLen 'board configuration message length,must to be set
        Dim lIp As IPAddress = Nothing
        For Each ip As IPAddress In Dns.GetHostEntry(Dns.GetHostName).AddressList
            If ip.AddressFamily = AddressFamily.InterNetwork Then
                lIp = ip
            End If
        Next
        Dim LocalEp As IPEndPoint = New IPEndPoint(lIp, 0)

        sckUDP = New Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp)
        sckUDP.EnableBroadcast = True

        sckUDP.Bind(LocalEp)
        'telnet socket
        sckTelnet = New Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp)

        'add combobox data
        With cboBaud
            .Items.Add(New myDataItem("1200", &HA0))
            .Items.Add(New myDataItem("2400", &HD0))
            .Items.Add(New myDataItem("4800", &HE8))
            .Items.Add(New myDataItem("9600", &HF4))
            .Items.Add(New myDataItem("19200", &HFA))
            .Items.Add(New myDataItem("38400", &HFD))
            .Items.Add(New myDataItem("57600", &HFE))
            .Items.Add(New myDataItem("115200", &HFF))
            .Items.Add(New myDataItem("230400", &HBB))

        End With

        With cboDataBit
            .Items.Add(New myDataItem("7", &H7))
            .Items.Add(New myDataItem("8", &H8))
        End With
        cboStopBit.Items.Add(New myDataItem("1", &H1))

        With cboParity
            .Items.Add(New myDataItem("NONE", &H0))
            .Items.Add(New myDataItem("ODD", &H1))
            .Items.Add(New myDataItem("EVEN", &H2))
        End With

        With cboFlow
            .Items.Add(New myDataItem("NONE", &H0))
            .Items.Add(New myDataItem("XON/XOFF", &H1))
            .Items.Add(New myDataItem("CTS/RTS", &H2))
        End With


        'telnet part
        If chkShowChar.Checked = True Then
            txtPassword.PasswordChar = ""
        Else
            txtPassword.PasswordChar = "*"
        End If
        'disable groupbox while disconnected
        gbLogin.Enabled = False
        gbCommand.Enabled = False
        'add data to combobox
        'Baud rate
        cboTBaud.Items.Add(0) 'Request current baud rate
        cboTBaud.Items.Add(1200)
        cboTBaud.Items.Add(2400)
        cboTBaud.Items.Add(4800)
        cboTBaud.Items.Add(9600)
        cboTBaud.Items.Add(19200)
        cboTBaud.Items.Add(38400)
        cboTBaud.Items.Add(57600)
        cboTBaud.Items.Add(115200)
        cboTBaud.Items.Add(230400)
        cboTBaud.SelectedIndex = 0

        'Data size
        cboTDSize.Items.Add(0) 'Reqeust current data bit size
        'cbotDSize.Items.Add(1) 'Avalilable for future use
        'cbotDSize.Items.Add(2) 'Avalilable for future use
        'cbotDSize.Items.Add(3) 'Avalilable for future use
        'cbotDSize.Items.Add(4) 'Avalilable for future use
        cboTDSize.Items.Add(5)
        cboTDSize.Items.Add(6)
        cboTDSize.Items.Add(7)
        cboTDSize.Items.Add(8)


        'parity
        cboTParity.Items.Add(0) 'Request current data size
        cboTParity.Items.Add("NONE") 'NONE
        cboTParity.Items.Add("ODD") 'ODD
        cboTParity.Items.Add("EVEN") 'EVEN
        cboTParity.Items.Add("MARK") 'Mark
        cboTParity.Items.Add("SPACE") 'SPACE
        '6~127 Available for future use
        cboTParity.SelectedIndex = 0
        cboTDSize.SelectedIndex = 0

        'Stop size
        cboTStopbit.Items.Add(0) 'Request current data size
        cboTStopbit.Items.Add(1) '1
        cboTStopbit.Items.Add(2) '2
        cboTStopbit.Items.Add("1.5") '1.5
        '4~127 Available for future use
        cboTStopbit.SelectedIndex = 0

        'control
        cboTControl.Items.Add(0) 'Request current control status
        cboTControl.Items.Add("NONE") ' Use no flow control
        cboTControl.Items.Add("XON/XOFF") 'Use Xon/Xoff flow control
        cboTControl.Items.Add("HARDWARE") 'Use Hardware flow control

        Dim i As Int16
        For i = 4 To 22
            cboTControl.Items.Add(i)
        Next
        cboTControl.SelectedIndex = 0

        'line state mask
        For i = 7 To 0 Step -1
            cboLnMask.Items.Add(2 ^ i)
        Next

        'modem state mask
        For i = 7 To 0 Step -1
            cboMoMask.Items.Add(2 ^ i)
        Next

        'purge data
        For i = 0 To 3
            cboPurge.Items.Add(i)

        Next

    End Sub


#Region "search, setting and upload firmware"
    'search
    Private Sub tsBtnSearch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsBtnSearch.Click
        'check tab control page, if in telnet page, then change to network tab page
        If tabCtrl.SelectedTab Is tabPgTelnet Then
            tabCtrl.SelectTab(0)

        End If

        ctState = "sching"
        uIdx = 0
        If lvBoard.Items.Count > 0 Then
            lvBoard.Items.Clear()

        End If

        If chkDirectIP.Checked Then
            If IpValidation(txtDirectIP) Then
                remEp = New IPEndPoint(IPAddress.Parse(txtDirectIP.Text.Trim), UdpPort)
                frmSchPwd.ShowDialog(Me)
            End If

        Else
            remEp = New IPEndPoint(IPAddress.Broadcast, UdpPort)
            frmSchPwd.ShowDialog(Me)
        End If

        Dim b() As Byte = Encoding.ASCII.GetBytes(SchCmd & SchPwd)

        If isSchOk Then

            'show frmstate
            frmState.Show(Me)
            Me.Enabled = False

            Connect(sckUDP)

            sckUDP.SendTo(b, 0, b.Length, SocketFlags.None, remEp)

        End If
    End Sub
    'setting
    Private Sub tsBtnSetting_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsBtnSetting.Click

        'if one board is selected
        If lvBoard.SelectedItems.Count > 0 Then
            'check tab control page, if in telnet page, then change to network tab page
            If tabCtrl.SelectedTab Is tabPgTelnet Then
                tabCtrl.SelectTab(0)

            End If
            ctState = "setting"

            Dim bd As clsBoard = New clsBoard
            Dim itm As New ListViewItem
            itm = lvBoard.SelectedItems(0)
            bd = itm.Tag ' colBoards.Item(itm.SubItems.Item(1).Text)
            uIdx = lvBoard.SelectedItems(0).Index
            lvBoard.Items.Remove(lvBoard.SelectedItems(0))

            'set option
            bd.opMode = Encoding.ASCII.GetBytes("SETT")
            'debug mode
            If chkDebug.Checked Then
                bd.DebugOff = 0
            Else
                bd.DebugOff = 1
            End If
            'connect status
            bd.Connect = 0
            'IP configuration method
            If rbIpDhcp.Checked Then
                bd.DHCP = 1

            End If
            If rbIpPppoe.Checked Then
                bd.DHCP = 2
            End If
            If rbIpStatic.Checked Then
                bd.DHCP = 0
            End If
            'ip addres...
            bd.LIp = GetIpBytes(txtLIP.Text)
            bd.LPort = GetUintBytes(CInt(txtLPort.Text))
            bd.Subnet = GetIpBytes(txtSubnetMask.Text)
            bd.Gw = GetIpBytes(txtGwIP.Text)
            'bd.poeId = Encoding.Default.GetBytes(txtPID.Text.Trim)
            StrToBytes(txtPID.Text.Trim, bd.poeId)
            'bd.poePwd = Encoding.Default.GetBytes(txtPPwd.Text.Trim)
            StrToBytes(txtPPwd.Text.Trim, bd.poePwd)

            bd.sIp = GetIpBytes(txtSIP.Text)
            bd.sPort = GetUintBytes(CInt(txtSPort.Text))
            'operation mode
            If rbClient.Checked Then
                bd.bServer = 0
            End If
            If rbMixed.Checked Then bd.bServer = 1
            If rbServer.Checked Then bd.bServer = 2
            If chkUDP.Checked Then
                bd.UDP = 1
            Else
                bd.UDP = 0
            End If

            bd.udpPeerIp = GetIpBytes(txtUdpIP.Text)
            'dns
            If chkDNS.Checked Then
                bd.dnsFlag = 1
            Else
                bd.dnsFlag = 0
            End If
            bd.dnsIP = GetIpBytes(txtDnsIP.Text)
            StrToBytes(txtDomain.Text.Trim, bd.dnsDomain)

            'com port options
            bd.BaudRate = CType(cboBaud.SelectedItem, myDataItem).rVal
            bd.DataBit = CInt(cboDataBit.Text)
            bd.StopBit = CInt(cboStopBit.Text)
            bd.Parity = cboParity.SelectedIndex
            'added in ver 1.3
            bd.FlowControl = cboFlow.SelectedIndex

            'data packing conditions
            bd.dTime = GetUintBytes(CInt(txtTimer.Text))
            bd.dSize = GetUintBytes(CInt(txtSize.Text))
            bd.dChar = CInt("&H" & txtChar.Text)
            'options
            bd.iTime = GetUintBytes(CInt(txtInactiveTimer.Text))
            bd.kaInterval = GetUintBytes(CInt(txtKeepAliveInterval.Text))
            If chkTrigger.Checked Then
                bd.sCfg = 1
            Else
                bd.sCfg = 0
            End If

            bd.sCfgStr(0) = CInt("&H" & txtTrigger1.Text)
            bd.sCfgStr(1) = CInt("&H" & txtTrigger2.Text)
            bd.sCfgStr(2) = CInt("&H" & txtTrigger3.Text)

            'bd.schPwd = Encoding.Default.GetBytes(txtSearchPwd.Text.Trim)
            StrToBytes(txtSearchPwd.Text, bd.schPwd)
            If chkConnPwd.Checked Then
                bd.isTcpPwd = 1
            Else
                bd.isTcpPwd = 0
            End If

            StrToBytes(txtConnPwd.Text.Trim, bd.TcpPwd)

            bd.telnetPort = GetUintBytes(CInt(txtTelnetPort.Text.Trim))
            StrToBytes(txtTelnetPwd.Text.Trim, bd.telnetPwd)

            'change bd to bytes and send to remote board
            tConv.Length = ConfigMsgLen
            Dim b() As Byte = tConv.BoardInfoToBytes(bd)

            If chkDirectIP.Checked Then
                If IpValidation(txtDirectIP) Then
                    remEp = New IPEndPoint(IPAddress.Parse(txtDirectIP.Text.Trim), UdpPort)

                End If
            Else
                remEp = New IPEndPoint(IPAddress.Broadcast, UdpPort)
            End If
            frmState.Show(Me)
            Me.Enabled = False
            sckUDP.SendTo(b, 0, b.Length, SocketFlags.None, remEp)
        Else
            MessageBox.Show("Please select the board you want to configure from the search results.", "Board Selection", MessageBoxButtons.OK, MessageBoxIcon.Information)

        End If


    End Sub
    'upload firmware
    Private Sub tsBtnUpload_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsBtnUpload.Click

        If lvBoard.SelectedItems.Count > 0 Then
            'ping the remote wiz1000 to check the network status before uploading firmware; 2010. 03. 22
            Dim objPingHost As New clsPing
            Dim lngPingReply As Long = 0
            objPingHost.TimeOut = 5000              ' 5000 msec  Time Out
            objPingHost.DataSize = 32               ' 32 bytes Package Size
            objPingHost.Host = Trim(txtLIP.Text)    ' Host to Ping
            lngPingReply = objPingHost.Ping
            If lngPingReply = clsPing.PING_ERROR Then
                'show error message
                MessageBox.Show("The destination: " & Trim(txtLIP.Text) & " is unreachable." & vbCrLf & _
                               "Please check if the device is in the same subnet with the PC!" & vbCrLf & vbCrLf & _
                               "---------------------------------------------------" & vbCrLf & _
                               "Ping Response Message: " & objPingHost.GetLastError.Description, "Uploading error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End If
            'end of ping
            sndBytes = 0
            'set state
            ctState = "fwup"
            'open file
            Dim sFile As String = ""
            ofdFw.FileName = ""
            ofdFw.ShowDialog()

            sFile = ofdFw.FileName
            If sFile.Length > 0 Then
                Dim bd As clsBoard = New clsBoard
                bd = lvBoard.SelectedItems(0).Tag
                'set option
                bd.opMode = Encoding.ASCII.GetBytes("FIRS")
                'change bd to bytes and send to remote board
                tConv.Length = ConfigMsgLen
                Dim b() As Byte = tConv.BoardInfoToBytes(bd)
                Dim ipAddr As String = GetIPStr(bd.LIp)

                If chkDirectIP.Checked Then
                    If IpValidation(txtDirectIP) Then
                        remEp = New IPEndPoint(IPAddress.Parse(txtDirectIP.Text.Trim), UdpPort)
                    End If
                Else
                    remEp = New IPEndPoint(IPAddress.Parse(ipAddr), UdpPort)
                End If
                sckUDP.SendTo(b, 0, b.Length, SocketFlags.None, remEp)
                Threading.Thread.Sleep(300)

                'file info.
                Dim fLen As Integer = 0
                Dim fStrm As IO.FileStream = New IO.FileStream(sFile, IO.FileMode.Open, IO.FileAccess.Read)
                fLen = fStrm.Length
                Dim fInfo(3) As Byte 'file info buffer
                fInfo(0) = (fLen And &HFF000000) / &H1000000
                fInfo(1) = (fLen And &HFF0000) / &H10000
                fInfo(2) = (fLen And &HFF00) / &H100
                fInfo(3) = (fLen And &HFF)
                frmState.lblMsg.Text = "Connecting...<" & ipAddr & ">"""
                'connect
                tcpRemEp = New IPEndPoint(IPAddress.Parse(ipAddr), 5005)
                'define
                Dim sckUp As Socket
                sckUp = New Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp)
                'Connect(sckUp)
                Try
                    sckUp.BeginConnect(tcpRemEp, New AsyncCallback(AddressOf ConnectCallback), sckUp)
                Catch ex As Exception
                    frmState.lblMsg.Text = "Connection error occurs!"
                End Try

                frmState.lblMsg.Text = "Connected <" & ipAddr & ">"
                Application.DoEvents()

                ' Threading.Thread.Sleep(300)
                'If sckUp.Connected Then
                'send file info
                Send(sckUp, fInfo)
                Threading.Thread.Sleep(300)

                'set state
                frmState.Show(Me)
                Me.Enabled = False
                frmState.pBar.Maximum = fLen
                frmState.pBar.Value = 0
                frmState.lblMsg.Text = "Uploading..."
                If fLen > 1024 Then
                    Dim n As Integer = fLen \ 1024
                    Dim rBytes As Integer = fLen Mod 1024
                    Dim i As Integer
                    Dim fDat(1023) As Byte 'send firmware file buffer
                    For i = 0 To n - 1
                        Application.DoEvents()
                        fStrm.Seek(i * 1024, IO.SeekOrigin.Begin)
                        fStrm.Read(fDat, 0, 1024)

                        Send(sckUp, fDat)

                        If frmState.pBar.Value < frmState.pBar.Maximum Then frmState.pBar.Value = i * 1024
                        Threading.Thread.Sleep(600)
                        frmState.lblMsg.Text = "Upload (" & frmState.pBar.Value.ToString("0,000") & "/" & fLen.ToString("0,000") & " Bytes)"
                    Next
                    ReDim fDat(rBytes - 1)
                    fStrm.Seek(n * 1024, IO.SeekOrigin.Begin)
                    fStrm.Read(fDat, 0, rBytes)

                    Send(sckUp, fDat)

                    frmState.lblMsg.Text = "Upload (" & fLen & "/" & fLen & ")"
                    frmState.pBar.Value = fLen
                    Threading.Thread.Sleep(500)

                Else
                    Dim fDat(fLen - 1) As Byte
                    fStrm.Read(fDat, 0, fLen)
                    Send(sckUp, fDat)
                    frmState.pBar.Value = fLen
                    frmState.lblMsg.Text = "Firmware upgraded successfully!"

                End If
                fStrm.Close()
                fStrm.Dispose()

                frmState.lblMsg.Text = "Disconnect <" & ipAddr & ">"
                Try
                    sckUp.BeginDisconnect(True, New AsyncCallback(AddressOf DisconnectCallback), sckUp)
                Catch ex As Exception
                    frmState.lblMsg.Text = "Disconnect error occurs!"
                End Try
                'check if send over
                If sndBytes <> fLen + 4 Then
                    'stopwatch start, wait for 1 minute
                    frmState.lblMsg.Text = "Firmware upload error occurs!"
                    frmState.btnClose.Enabled = True
                    Me.Enabled = True
                Else
                    frmState.lblMsg.Text = "Firmware upgraded successfully!"
                    frmState.btnClose.Enabled = True
                    Me.Enabled = True
                End If
            End If
        Else
            MessageBox.Show("Please select the board you want to upgrade from the search results.", "Board Selection", MessageBoxButtons.OK, MessageBoxIcon.Information)
        End If
    End Sub
    'ping
    Private Sub tsbPing_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsbPing.Click
        frmPing.ShowDialog(Me)
    End Sub
    'firewall settings of Windows
    Private Sub tsbFire_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsbFire.Click
        Shell("rundll32.exe shell32.dll, Control_RunDLL FireWall.cpl", vbNormalFocus)
    End Sub
#End Region

    Private Sub chkUDP_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkUDP.CheckedChanged
        If chkUDP.Checked = True Then
            rbClient.Enabled = False
            rbServer.Enabled = False
            rbMixed.Enabled = False
            txtUdpIP.Enabled = True
            'txtUdpIP.Focus()
        Else
            rbClient.Enabled = True
            rbServer.Enabled = True
            rbMixed.Enabled = True
            txtUdpIP.Enabled = False
        End If
    End Sub

    Private Sub rbIpStatic_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rbIpStatic.CheckedChanged
        If rbIpStatic.Checked = True Then
            txtLIP.Enabled = True
            txtSubnetMask.Enabled = True
            txtGwIP.Enabled = True
            txtPID.Enabled = False
            txtPPwd.Enabled = False
            'txtLIP.Focus()

        End If
    End Sub

    Private Sub rbIpDhcp_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rbIpDhcp.CheckedChanged
        If rbIpDhcp.Checked = True Then
            txtLIP.Enabled = False
            txtSubnetMask.Enabled = False
            txtGwIP.Enabled = False
            txtPID.Enabled = False
            txtPPwd.Enabled = False
        End If
    End Sub

   
    Private Sub rbIpPppoe_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rbIpPppoe.CheckedChanged
        If rbIpPppoe.Checked = True Then
            txtLIP.Enabled = False
            txtSubnetMask.Enabled = False
            txtGwIP.Enabled = False
            txtPID.Enabled = True
            txtPPwd.Enabled = True
            'txtPID.Focus()
        End If
    End Sub

    Private Sub chkShowPoePwd_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkShowPoePwd.CheckedChanged
        If chkShowPoePwd.Checked Then
            txtPPwd.PasswordChar = ""
        Else
            txtPPwd.PasswordChar = "*"
        End If
    End Sub

    Private Sub chkDNS_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkDNS.CheckedChanged
        If chkDNS.Checked Then
            txtDnsIP.Enabled = True
            txtDnsIP.Focus()
            txtDomain.Enabled = True
        Else
            txtDnsIP.Enabled = False
            txtDomain.Enabled = False
        End If
    End Sub

    Private Sub chkTrigger_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkTrigger.CheckedChanged
        If chkTrigger.Checked Then
            txtTrigger1.Enabled = True
            txtTrigger2.Enabled = True
            txtTrigger3.Enabled = True
        Else
            txtTrigger1.Enabled = False
            txtTrigger2.Enabled = False
            txtTrigger3.Enabled = False
        End If
    End Sub

    Private Sub chkConnPwd_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkConnPwd.CheckedChanged
        If chkConnPwd.Checked Then
            txtConnPwd.Enabled = True
        Else
            txtConnPwd.Enabled = False
        End If
    End Sub

    Private Sub chkShowChar1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkShowChar1.CheckedChanged
        If chkShowChar1.Checked Then
            txtSearchPwd.PasswordChar = ""
        Else
            txtSearchPwd.PasswordChar = "*"
        End If

    End Sub

    Private Sub chkShowChar2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkShowChar2.CheckedChanged
        If chkShowChar2.Checked Then
            txtConnPwd.PasswordChar = ""
        Else
            txtConnPwd.PasswordChar = "*"
        End If
    End Sub

    Private Sub chkShowChar3_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkShowChar3.CheckedChanged
        If chkShowChar3.Checked Then
            txtTelnetPwd.PasswordChar = ""
        Else
            txtTelnetPwd.PasswordChar = "*"
        End If
    End Sub

    Private Sub chkDirectIP_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkDirectIP.CheckedChanged
        If chkDirectIP.Checked Then
            txtDirectIP.Enabled = True
            txtDirectIP.Focus()
        Else
            txtDirectIP.Enabled = False
        End If
    End Sub
    'check for invalid IP address for each textbox
    Private Sub txtDirectIP_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtLIP.LostFocus, txtSubnetMask.LostFocus, txtGwIP.LostFocus, txtSIP.LostFocus

        If sender.Text.Length > 0 Then
            Dim sPattern As String = "^(?:(?:25[0-5]|2[0-4]\d|[01]\d\d|\d?\d)(?(?=\.?\d)\.)){4}$"
            Dim oRegex As New Regex(sPattern, RegexOptions.Singleline)
            If Not oRegex.IsMatch(sender.Text) Then
                MessageBox.Show("It looks like that you input an invalid IP Address." & vbCrLf & "Please input it again.", "Invalid IP Address", MessageBoxButtons.OK, MessageBoxIcon.Error)

                sender.Focus()
                sender.SelectAll()
                'Else
                'MessageBox.Show("Please input a valid IP address.", "IP address input error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If
     

        End If
    End Sub

 
    'check for invalid port number.
    Private Sub txtLPort_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtLPort.TextChanged, txtSPort.TextChanged, txtTelnetPort.TextChanged, txtKeepAliveInterval.TextChanged, txtInactiveTimer.TextChanged, txtTimer.TextChanged
        If sender.text.trim.length > 0 Then
            
            Dim sPattern As String = "^\d{1,5}$" '"^[1-9]{1}$|^[1-9]{1}[0-9]{1}$|^65535$"
            Dim oRegex As New Regex(sPattern, RegexOptions.Singleline)
            If Not oRegex.IsMatch(sender.text) Then

                MessageBox.Show("It looks like that you input an invalid Number: " & sender.text & vbCrLf & "Please input it again, and between 1 and 65535", "Invalid Number", MessageBoxButtons.OK, MessageBoxIcon.Error)

                sender.Focus()
                sender.SelectAll()
            Else

                sender.text = CInt(sender.text.trim)
                sender.selectall()
                sender.SelectionStart = sender.text.length
                If CInt(sender.text) > 65535 Then
                    MessageBox.Show("Please input a number less than 65536.", "Invalid Number", MessageBoxButtons.OK, MessageBoxIcon.Error)
                End If
            End If
        End If

    End Sub



    Private Sub txtChar_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtChar.LostFocus, txtTrigger1.LostFocus, txtTrigger2.LostFocus, txtTrigger3.LostFocus
        '^([0-9a-fA-F]){8}$
        If sender.text.trim.length > 0 Then


            Dim sPattern As String = "^([0-9a-fA-F]){2}$" '"^[1-9]{1}$|^[1-9]{1}[0-9]{1}$|^65535$"
            Dim oRegex As New Regex(sPattern, RegexOptions.Singleline)
            If Not oRegex.IsMatch(sender.text) Then

                MessageBox.Show("It looks like that you input an invalid Hexacode: " & sender.text & vbCrLf & "Please try it again.", "Invalid Hexacode", MessageBoxButtons.OK, MessageBoxIcon.Error)
                If sender.enabled = True Then
                    sender.Focus()
                    sender.SelectAll()
                End If

            End If
        End If
    End Sub



    Private Sub lvBoard_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles lvBoard.MouseUp
        If lvBoard.SelectedItems.Count = 0 Then
            If lvBoard.FocusedItem IsNot Nothing Then
                Dim item As ListViewItem = lvBoard.GetItemAt(e.X, e.Y)
                If item Is Nothing Then
                    lvBoard.FocusedItem.Selected = True
                End If

            End If
        End If
    End Sub

   

    Private Sub lvBoard_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles lvBoard.SelectedIndexChanged

        Dim itm As New ListViewItem
        If lvBoard.SelectedItems.Count > 0 Then
            itm = lvBoard.SelectedItems(0)
            Dim bd As clsBoard = New clsBoard

            bd = itm.Tag

            'set ip addr and port for telnet
            txtTIP.Text = GetIPStr(bd.LIp)
            txtTPort.Text = GetUInt16(bd.telnetPort)



            lblFwVer.Text = bd.AppVer(0).ToString & "." & bd.AppVer(1).ToString
            If bd.DebugOff = 0 Then
                chkDebug.Checked = True
            Else
                chkDebug.Checked = 0
            End If
            If bd.Connect = 1 Then
                lblStatus.Text = "Coneected"
            Else
                lblStatus.Text = "Disconnected"
            End If
            If bd.DHCP = 1 Then
                rbIpDhcp.Checked = True
                txtLIP.Enabled = False
                txtSubnetMask.Enabled = False
                txtGwIP.Enabled = False
                txtPID.Enabled = False
                txtPPwd.Enabled = False

            ElseIf bd.DHCP = 2 Then
                rbIpPppoe.Checked = True
                txtLIP.Enabled = False
                txtSubnetMask.Enabled = False
                txtGwIP.Enabled = False
                txtPID.Enabled = True
                txtPPwd.Enabled = True

            ElseIf bd.DHCP = 0 Then
                rbIpStatic.Checked = True
                txtLIP.Enabled = True
                txtSubnetMask.Enabled = True
                txtGwIP.Enabled = True
                txtPID.Enabled = False
                txtPPwd.Enabled = False

            End If

            txtLIP.Text = GetIPStr(bd.LIp)
            txtLPort.Text = GetUInt16(bd.LPort)
            txtSubnetMask.Text = GetIPStr(bd.Subnet)
            txtGwIP.Text = GetIPStr(bd.Gw)
            txtPID.Text = Encoding.Default.GetString(bd.poeId).Trim
            txtPPwd.Text = Encoding.Default.GetString(bd.poePwd).Trim
            txtSIP.Text = GetIPStr(bd.sIp)
            txtSPort.Text = GetUInt16(bd.sPort)

            Select Case bd.bServer
                Case 0
                    rbClient.Checked = True
                Case 1
                    rbMixed.Checked = True
                Case 2
                    rbServer.Checked = True

            End Select
            If bd.UDP = 1 Then
                chkUDP.Checked = True

                txtUdpIP.Enabled = True
            Else
                chkUDP.Checked = False

                txtUdpIP.Enabled = False

            End If
            txtUdpIP.Text = GetIPStr(bd.udpPeerIp)

            'dns
            If bd.dnsFlag = 1 Then
                chkDNS.Checked = True
                txtDnsIP.Enabled = True
                txtDomain.Enabled = True
            Else
                chkDNS.Checked = False
                txtDnsIP.Enabled = False
                txtDomain.Enabled = False
            End If
            txtDnsIP.Text = GetIPStr(bd.dnsIP)
            txtDomain.Text = Encoding.Default.GetString(bd.dnsDomain)
            'COM port
            With cboBaud
                Select Case bd.BaudRate
                    Case &HBB
                        .SelectedIndex = 8
                    Case &HFF
                        .SelectedIndex = 7
                    Case &HFE
                        .SelectedIndex = 6
                    Case &HFD
                        .SelectedIndex = 5
                    Case &HFA
                        .SelectedIndex = 4
                    Case &HF4
                        .SelectedIndex = 3
                    Case &HE8
                        .SelectedIndex = 2
                    Case &HD0
                        .SelectedIndex = 1
                    Case &HA0
                        .SelectedIndex = 0

                End Select
            End With
            cboDataBit.Text = bd.DataBit.ToString
            cboStopBit.Text = bd.StopBit.ToString

            If bd.Parity < 3 Then
                cboParity.SelectedIndex = bd.Parity
            End If
            If bd.FlowControl < 3 Then
                cboFlow.SelectedIndex = bd.FlowControl
            End If
            'data packing conditions
            txtTimer.Text = GetUInt16(bd.dTime)
            txtSize.Text = GetUInt16(bd.dSize)
            txtChar.Text = bd.dChar.ToString("X2")
            'options 
            txtInactiveTimer.Text = GetUInt16(bd.iTime)
            txtKeepAliveInterval.Text = GetUInt16(bd.kaInterval)

            If bd.sCfg = 1 Then
                chkTrigger.Checked = True
                txtTrigger1.Enabled = True
                txtTrigger2.Enabled = True
                txtTrigger3.Enabled = True
            Else
                chkTrigger.Checked = False
                txtTrigger1.Enabled = False
                txtTrigger2.Enabled = False
                txtTrigger3.Enabled = False
            End If
            txtTrigger1.Text = bd.sCfgStr(0).ToString("X2")
            txtTrigger2.Text = bd.sCfgStr(1).ToString("X2")
            txtTrigger3.Text = bd.sCfgStr(2).ToString("X2")

            txtSearchPwd.Text = Encoding.Default.GetString(bd.schPwd).Trim
            If bd.isTcpPwd = 1 Then
                chkConnPwd.Checked = True
                txtConnPwd.Enabled = True
            Else
                chkConnPwd.Checked = False
                txtConnPwd.Enabled = False
            End If

            txtConnPwd.Text = Encoding.Default.GetString(bd.TcpPwd).Trim
            txtTelnetPort.Text = GetUInt16(bd.telnetPort)
            txtTelnetPwd.Text = Encoding.Default.GetString(bd.telnetPwd).Trim

        End If
    End Sub
   

    Private Sub tsBtnSearch_MouseEnter(ByVal sender As Object, ByVal e As System.EventArgs) Handles tsBtnSearch.MouseEnter, tsBtnSetting.MouseEnter, tsBtnExit.MouseEnter, tsBtnUpload.MouseEnter
        tsLblStatus.Text = sender.tooltiptext

    End Sub

    Private Sub frmMain_MouseEnter(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.MouseEnter
        tsLblStatus.Text = "WIZ1000 Configuration Tool"
    End Sub

    Private Sub btnConnect_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnConnect.Click
        If IpValidation(txtTIP) Then
            Dim ipAddr As String = txtTIP.Text.Trim
            Dim port = Convert.ToInt32(txtTPort.Text.Trim)
            If btnConnect.Text = "Connect" Then
                If port > 0 Then
                    Dim tRemEp As New IPEndPoint(IPAddress.Parse(ipAddr), port)
                    sckTelnet = New Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp)
                    sckTelnet.BeginConnect(tRemEp, New AsyncCallback(AddressOf TelnetConnectCallback), sckTelnet)

                End If
            Else
                btnConnect.Text = "Connect"
                gbLogin.Enabled = False
                gbCommand.Enabled = False
                sckTelnet.BeginDisconnect(True, New AsyncCallback(AddressOf DisconnectCallback), sckTelnet)

            End If
        End If
       
    End Sub

    Private Sub chkShowChar_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkShowChar.CheckedChanged
        If chkShowChar.Checked Then
            txtPassword.PasswordChar = ""
        Else
            txtPassword.PasswordChar = "*"

        End If
    End Sub
#Region "telnet methods"
    'telnet part

    Private Sub cboTDSize_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboTDSize.SelectedIndexChanged
        If cboTDSize.SelectedIndex = 4 Then
            If cboTParity.Items.Count = 6 Then
                cboTParity.Items.RemoveAt(3)
            End If
        Else
            If Not cboTParity.Items.Count = 6 Then
                cboTParity.Items.Insert(3, 3)
            End If
        End If
    End Sub

    Private Sub tsBtnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsBtnExit.Click
        If sckTelnet.Connected Then
            Dim b As DialogResult = MessageBox.Show("Telnet is connected with remote board!" & vbCrLf & "Are you sure to exit?", "Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Information)
            If b = Windows.Forms.DialogResult.Yes Then
                sckTelnet.BeginDisconnect(False, New AsyncCallback(AddressOf DisconnectCallback), sckTelnet)

                'sckTelnet.Disconnect(True)
                'sckTelnet.Close()
                End
            Else
                tabCtrl.SelectTab(3)
            End If
        Else
            End
        End If


    End Sub
    Private Sub btnLogin_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLogin.Click
        Dim s As String = txtPassword.Text.Trim
        Debug.Print(s)

        Dim i As Int16 = 0
        Dim b() As Byte
        b = Encoding.Default.GetBytes(s)
        Send(sckTelnet, b)

    End Sub

    Private Sub btnWill_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnWill.Click
        Send(sckTelnet, Build_Send_Nego(WILL))
    End Sub

    Private Sub btnSetBaud_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSetBaud.Click

        Send(sckTelnet, Build_Set_Baud(Convert.ToUInt32(cboTBaud.Text)))
        'Debug.Print(cboBaud.Text)

    End Sub
    Private Sub btnDataSize_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDataSize.Click
        Send(sckTelnet, Build_Set_DataSize(Convert.ToByte(cboTDSize.Text.Trim)))
    End Sub

    Private Sub btnParity_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnParity.Click
        Send(sckTelnet, Build_Set_Parity(cboTParity.SelectedIndex))

    End Sub

    Private Sub btnStopBit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnStopBit.Click
        Send(sckTelnet, Build_Set_StopSize(cboTStopbit.SelectedIndex))
    End Sub

    Private Sub btnControl_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnControl.Click
        Send(sckTelnet, Build_Set_Control(cboTControl.SelectedIndex))
        Select Case cboTControl.SelectedIndex
            Case 0
                isConRequestSent = True
                isRtsRequestSent = False
                isCtsRequestSent = False
            Case 10
                isConRequestSent = False
                isRtsRequestSent = True
                isCtsRequestSent = False
            Case 20
                isConRequestSent = False
                isRtsRequestSent = False
                isCtsRequestSent = True

        End Select
    End Sub

    Private Sub btnLnStMask_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLnStMask.Click
        'send
    End Sub

    Private Sub btnMoStMask_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnMoStMask.Click
        'send
    End Sub

    Private Sub btnPurge_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPurge.Click
        'send
    End Sub
    Private Sub btnWont_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnWont.Click
        Send(sckTelnet, Build_Send_Nego(WONT))

        btnConnect.Text = "Connect"
        gbLogin.Enabled = False
        gbCommand.Enabled = False

        MsgBox("The Module is rebooted. Please try to reconnect.")
        sckTelnet.BeginDisconnect(True, New AsyncCallback(AddressOf DisconnectCallback), sckTelnet)
    End Sub

#End Region

    
End Class


