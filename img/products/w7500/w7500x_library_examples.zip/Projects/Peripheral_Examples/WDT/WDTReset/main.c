/**
  ******************************************************************************
  * @file    WDT/WDTReset/main.c 
  * @author  IOP Team
  * @version V1.0.0
  * @date    01-May-2015
  * @brief   Main program body
  ******************************************************************************
  * @attention
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, WIZnet SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2015 WIZnet Co.,Ltd.</center></h2>
  ******************************************************************************
  */ 

/* Includes ------------------------------------------------------------------*/
#include "W7500x.h"

/* Private typedef -----------------------------------------------------------*/
typedef struct
{
  __IO   uint32_t  REMAP;          /*!< Offset: 0x000 Remap Control Register (R/W) */
  __IO   uint32_t  PMUCTRL;        /*!< Offset: 0x004 PMU Control Register (R/W) */
  __IO   uint32_t  RESETOP;        /*!< Offset: 0x008 Reset Option Register  (R/W) */
  __IO   uint32_t  EMICTRL;        /*!< Offset: 0x00C EMI Control Register  (R/W) */
  __IO   uint32_t  RSTINFO;        /*!< Offset: 0x010 Reset Information Register (R/W) */
} W7500x_SYSCON_TypeDef;

/* Private define ------------------------------------------------------------*/
#define W7500x_SYSCON            ((W7500x_SYSCON_TypeDef *) W7500x_SYSCTRL_BASE)
#define W7500x_SYSCTRL_BASE      (0x4001F000)
#define SYSRESETREQ_Msk 0x1
#define WDTRESETREQ_Msk 0x2

/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
WDT_InitTypeDef WDT_InitStructure;
int reset_test = 0;
int rst_info = 0;


/* Private function prototypes -----------------------------------------------*/
void GPIO_Configuration(void);
void NVIC_Configuration(void);

/* Private functions ---------------------------------------------------------*/

/**
  * @brief   Main program
  * @param  None
  * @retval None
  */
int main()
{
    /*System clock configuration*/
    SystemInit();

    /* CPIO configuration */
    GPIO_Configuration();
    
    /* NVIC Configuration */
    NVIC_Configuration();

    rst_info = W7500x_SYSCON->RSTINFO;
    // 0 : SYSRESETREQ
    // 1 : Watchdog reset
    // 2 : Processor LOCKUP reset
    
    if((rst_info & WDTRESETREQ_Msk) != 0) //Reset request is caused by WDT
    {
        WDT_IntClear();

        GPIO_SetBits(GPIOC, GPIO_Pin_8);
        GPIO_ResetBits(GPIOC, GPIO_Pin_9);
        while(1);
    }
    else if((rst_info & SYSRESETREQ_Msk) != 0) //Reset request is caused by SYSTEM
    {
        WDT_InitStructure.WDTLoad = 0xFF0000;
        WDT_InitStructure.WDTControl_RstEn = WDTControl_RstEnable;
        WDT_Init(&WDT_InitStructure);

        WDT_Start();
    }
    
    while(1)
    {

        if(WDT_GetWDTValue() < 0x1000)
        {
            WDT_SetWDTLoad(0xFF0000);
            // LED red is toggled /
            if(GPIO_ReadOutputDataBit(GPIOC,GPIO_Pin_8) != (uint32_t)Bit_RESET)
                GPIO_ResetBits(GPIOC, GPIO_Pin_8);
            else
                GPIO_SetBits(GPIOC, GPIO_Pin_8);
        }
    }
}

/**
  * @brief  Configure the GPIO Pins.
  * @param  None
  * @retval None
  */
void GPIO_Configuration(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    EXTI_InitTypeDef EXTI_InitStructure;

    
     /* GPIO Configuration for red LED */
    GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_8; ///< Connecting GPIO_Pin_8(LED(R))
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT; ///< Set to GPIO Mode to Output Port
    GPIO_Init(GPIOC, &GPIO_InitStructure);
    PAD_AFConfig(PAD_PC, GPIO_Pin_8, PAD_AF1); ///< PAD Config - LED used 2nd Function
 
    /* GPIO Configuration for green LED */
    GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_9; ///< Connecting GPIO_Pin_9(LED(G))
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT; ///< Set to GPIO Mode to Output Port
    GPIO_Init(GPIOC, &GPIO_InitStructure);
    PAD_AFConfig(PAD_PC, GPIO_Pin_9, PAD_AF1); ///< PAD Config - LED used 2nd Function
    
    /* Set to GPIO_Pin_0 to Input Port */
    GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_0; 
    GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_IN;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    /* Set to GPIO_Pin_0 to External Interrupt Port */
    EXTI_InitStructure.EXTI_Line = GPIO_Pin_0;
    EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising; ///< Set to Trigger to Rising
    EXTI_Init(PAD_PA, &EXTI_InitStructure);

    GPIO_SetBits(GPIOC, GPIO_Pin_8);
    GPIO_SetBits(GPIOC, GPIO_Pin_9);
}

/**
  * @brief  Configure the nested vectored interrupt controller.
  * @param  None
  * @retval None
  */
void NVIC_Configuration(void)
{
    NVIC_EnableIRQ(EXTI_IRQn);
}
