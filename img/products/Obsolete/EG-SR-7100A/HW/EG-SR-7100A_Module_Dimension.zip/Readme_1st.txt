Hello Partner,
 
Recently we received the report from some of WIZnet customers who purchased the IIM7100(A).
It was about the flash memory corruption of Atmel MCU in IIM7100(A) which led to failure of search or download function of the module.
During troubleshooting, we found out that their system board has an unstable power supply but have no power-on-reset circuit on board to protect the system. 
This caused malfunction in Atmel MCU and corrupted inside Flash or externel memory.
It is very rare case but would be likely to happen with any other customer's system where power input condition is not tolarable to Atmel MCU with Flash memory inside and there is no protection circuit such as power-on-reset.
Wiznet IIM7100(A) does not have this power-on-reset either because it was designed to run based on normal power supply condition.
So it is recommended to use the power-on-reset chip in the customer's system board for stable operation even in unsteady or unstable power supply condition.
More information on this  is available from Atmel website,  
http://www.atmel.com/dyn/resources/prod_documents/doc4183.pdf
For the system which uses IIM7100(A) module as drop-in part and didn't apply power-on-reset circuit, Wiznet will provide the reference schematic and recommend parts to use to make it stable by way of adding power-on-reset chip to existing system board or IIM7100(A) itself on customer's choice. 
(Please refer to attached schematic.)
For making sure that IIM7100(A) works fine even in unstable power environment, Wiznet will supply the revised new module adopting power-on-reset from now on. 
 
Thanks.
