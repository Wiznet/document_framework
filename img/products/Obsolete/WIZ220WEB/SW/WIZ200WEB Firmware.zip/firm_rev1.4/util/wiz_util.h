/**
 @file		wiznet.h
 @brief 		
 */

#ifndef _WIZNET_H
#define _WIZNET_H

#include "util.h"
#include "sockutil.h"
#endif
