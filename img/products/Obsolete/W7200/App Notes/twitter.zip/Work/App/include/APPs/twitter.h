#ifndef	_TWITTER_H_
#define	_TWITTER_H_

#define LIB_DOMAIN "arduino-tweet.appspot.com"
#define token "373763803-rfMUaR3oPmUZdhVXwpK3xSqBON6BBMVNWgsoqUaD"

u8 Twitter_Post(u8 s, u8 * msg, u8 *pSip);


#endif
