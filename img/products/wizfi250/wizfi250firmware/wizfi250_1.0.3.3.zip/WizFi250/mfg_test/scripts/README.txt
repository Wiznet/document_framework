The scripts in this directory are designed to run in a windows command shell.
Don't forget to change the UART COM port to match your WICED board!  