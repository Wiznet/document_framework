#include "stm32f10x.h"
#include "stdio.h"
#include "string.h"
#include "uart.h"
#include "time.h"

volatile uint8_t  RecvBuff[RECV_LEN]={0x00};    //Receive buffer for the USART
volatile uint16_t RX2_Point = 0;          /* buffer pointer*/  

/****************************************************
Function name: 	USART1_Config
Parameter��			null
Return value:		null
Function:			  config USART1
****************************************************/
void USART1_Config(void)
{
    GPIO_InitTypeDef  GPIO_InitStruct;
    USART_InitTypeDef USART_InitStruct;

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1 | RCC_APB2Periph_GPIOA, ENABLE);  //USART1--CLOCK--CORRESPONDING--GPIO--CLOCK START
 
 //USART1 Tx---GPIO----PA.09----alternate function push pull output
    GPIO_InitStruct.GPIO_Pin = GPIO_Pin_9;
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &GPIO_InitStruct);

 //USART1 Rx---GPIO----PA.10----input floating
    GPIO_InitStruct.GPIO_Pin = GPIO_Pin_10;
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_Init(GPIOA, &GPIO_InitStruct);

 //USART1 mode configuration
    USART_InitStruct.USART_BaudRate = 115200;  //baud rate
    USART_InitStruct.USART_WordLength = USART_WordLength_8b;  //length
    USART_InitStruct.USART_StopBits = USART_StopBits_1;//stop bit
    USART_InitStruct.USART_Parity = USART_Parity_No ;//parity bit
    USART_InitStruct.USART_HardwareFlowControl = USART_HardwareFlowControl_None;//Hardware Flow Control
    USART_InitStruct.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;//USART MODE---Receive---Send 
    USART_Init(USART1, &USART_InitStruct); 
    USART_Cmd(USART1, ENABLE);//Enable USART1
}

/****************************************************
Function name: 	USART2_Config
Parameter��			null
Return value:		null
Function:			  config USART2
****************************************************/
void USART2_Config(void)
{
    GPIO_InitTypeDef  GPIO_InitStruct;
    USART_InitTypeDef USART_InitStruct;
	  NVIC_InitTypeDef	NVIC_InitStructure; 

    RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2 | RCC_APB2Periph_GPIOA, ENABLE);  //USART2--CLOCK
 //USART2 Tx---GPIO----PA2----alternate function push pull output
    GPIO_InitStruct.GPIO_Pin = GPIO_Pin_2;
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &GPIO_InitStruct);

 //USART2 Rx---GPIO----PA3----input floating
    GPIO_InitStruct.GPIO_Pin = GPIO_Pin_3;
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_Init(GPIOA, &GPIO_InitStruct);

//Priority config
	  NVIC_InitStructure.NVIC_IRQChannel = USART2_IRQn; 
  	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0; 
	  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
	  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE; 
	  NVIC_Init(&NVIC_InitStructure); 
	
 //USART2 mode config
    USART_InitStruct.USART_BaudRate = 115200;  //baud rate
    USART_InitStruct.USART_WordLength = USART_WordLength_8b;  //length
    USART_InitStruct.USART_StopBits = USART_StopBits_1;//Stop bit
    USART_InitStruct.USART_Parity = USART_Parity_No ;//Parity bit 
    USART_InitStruct.USART_HardwareFlowControl = USART_HardwareFlowControl_None;//Hardware Flow Control
    USART_InitStruct.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;//USART MODE---Receive---Send
    USART_Init(USART2, &USART_InitStruct);
    USART_ClearFlag(USART2, USART_FLAG_RXNE); 		
    USART_ClearFlag(USART2,USART_FLAG_TC);  //clear USART2 send interrupt flage otherwise the first byte will not occur

    USART_ITConfig(USART2, USART_IT_RXNE, ENABLE); //enable interrupt----normally save the receive data into array for using
    USART_Cmd(USART2, ENABLE);//enable USART2
			                  
    RX2_Point=0;               //clear
    TIM_Cmd(TIM3,DISABLE);     //close timer 3 
		
}

/****************************************************
Function name:	USARTX_Init
Parameter��			null
Return value:		null
Function:    		initialize port
****************************************************/
void USARTX_Init(void)
{
  USART1_Config();  				//printf
	USART2_Config();					//config S2E

}

/****************************************************
Function name:	USART2_IRQHandler
Parameter��			null
Return value:		null
Function:  			USART2 interrupt handler
****************************************************/
void USART2_IRQHandler(void) 
 {
	  char temp = 0;  
    if(USART_GetITStatus(USART2, USART_IT_RXNE) == SET)  
    {             
        temp = USART_ReceiveData( USART2 );         // read the USART2 data, clear flag RXNE  
        if((RX2_Point & FRAME_LEN) == 0)                //receive data from S2E
        {  
            if(RX2_Point<RECV_LEN)              //have space to receive more data 
            {                     
                TIM_SetCounter(TIM3,0);        	//clear timer   
                if(RX2_Point==0)              
                {  
                    TIM_Cmd(TIM3,ENABLE);    		//enable timer 3
                }  
                RecvBuff[RX2_Point++]=temp; 		//Save the receive value      
            }  
            else  
            {  
                RX2_Point |= FRAME_LEN;         //the length is out of limitation  
            }  
        }  
    }  

 }


/****************************************************
Function name:	fputc
Parameter��			null
Return value:		Value USART1 need to print
Function:  			printf Redirect
****************************************************/
int fputc(int ch, FILE *f)
{
    USART_SendData(USART1, (uint8_t)ch); 												 //Send one byte data to USART1 
    while (USART_GetFlagStatus(USART1, USART_FLAG_TC) == RESET); //Wait for sendding finish 
    return (ch);
}

/****************************************************
Function name:	fgetc
Parameter��			null
Return value:		Value USART1 receive
Function:  			scanf function Redirect
****************************************************/
int fgetc(FILE *f)
{
    while (USART_GetFlagStatus(USART1, USART_FLAG_RXNE) == RESET); //Wait for USART1 input data
    return (int)USART_ReceiveData(USART1);
}













