#include "stm32f10x.h"
#include "stdio.h"
#include "string.h"
#include "ATCommand.H"
#include "sys_tick.h"
#include "uart.h"

extern uint8_t RecvBuff[RECV_LEN];  //receive the data from USART PORT
extern uint16_t RX2_Point; 
extern uint8_t Config_OK;
/****************************************************
Function name: 	Usart_Send
Parameter:			USARTx  --port number    ch  --value to send
								size    --value size
Return value:		null
Function:				Send data to S2E via USART2
****************************************************/
void Usart_Send(USART_TypeDef* USARTx,char *ch)
{
	printf("Send:%s",ch);
  while(*ch)
	{
	  USART_SendData(USARTx,(uint8_t) *ch++);  //Send 1 byte to USART2
    while (USART_GetFlagStatus(USARTx, USART_FLAG_TC) == RESET); //Wait for sending finish 
	}	
}

/****************************************************
Function name: 	TCP_Server_Mode
Parameter��			null
Return value:		null
Function:				Send AT-command to configure S2E module via UART
****************************************************/
volatile uint8_t SendFlag=0;

void TCP_Server_Mode(void)
{ 
  uint8_t RecvFlag=1;
	char *state;
	
  switch(SendFlag)
	{
	  case 0:
		{
			Usart_Send(USART2,"AT\r\n");//Terminal check
		  while(RecvFlag)
	    { 
			  if(RX2_Point & FRAME_LEN)     //If receive data 
        {
					 state=strstr((char *)RecvBuff,"OK"); //check is there 'OK' in receive buffer
           if(state!=NULL)      //true 
					 {
              RX2_Point=0;       //clear receive flag 
				      RecvFlag=0;        //clear receive state flage
						  SendFlag=1;					//se send state flag 
					    printf("Recv:%s\r\n",RecvBuff);
			        memset(RecvBuff,0,RECV_LEN);  //clear receive buffer
					 }
					 else{  //false
						 SendFlag=100;		//Failed to configure
						 RecvFlag=0;
					 } 
	      }	
	    }
	  }break;
	 case 1:
		{
			Usart_Send(USART2,"AT+ECHO=0\r\n");//(open --1/ close --0)  echo command 
      RecvFlag=1;			
		  while(RecvFlag)
	    { 
			  if(RX2_Point & FRAME_LEN) //If receive data 
        {   
					 state=strstr((char *)RecvBuff,"OK");
           if(state!=NULL)
					 {
              RX2_Point=0;
				      RecvFlag=0;			//clear receive state flage
						  SendFlag=2;
					    printf("Recv:%s\r\n",RecvBuff);
			        memset(RecvBuff,0,RECV_LEN);   
					 }	
           else{  
						 SendFlag=100;
						 RecvFlag=0;
					 }					 
	      }	
	    }
	  }break;
	 case 2:
		{
			Usart_Send(USART2,"AT+C1_OP=0\r\n");//Set into TCP Server mode
		  RecvFlag=1;		
		  while(RecvFlag)
	    { 
			  if(RX2_Point & FRAME_LEN) //If receive data 
        {
					state=strstr((char *)RecvBuff,"OK");
					if(state!=NULL)
					{
             RX2_Point=0;
				     RecvFlag=0;		//clear receive state flage
					   SendFlag=3;     
					   printf("Recv:%s\r\n",RecvBuff);
			       memset(RecvBuff,0,RECV_LEN);			
	        }
				  else{  
						 SendFlag=100;
						 RecvFlag=0;
					 }
				 }
	    }
	  }break;
	 case 3:
		{
			Usart_Send(USART2,"AT+IP_MODE=0\r\n");//set into static IP mode
			RecvFlag=1;		
		  while(RecvFlag)
	    { 
			  if(RX2_Point & FRAME_LEN)//If receive data 
        {
					state=strstr((char *)RecvBuff,"OK");
					if(state!=NULL)
					{
             RX2_Point=0;
				     RecvFlag=0;			//clear receive state flage
					   SendFlag=4;     
					   printf("Recv:%s\r\n",RecvBuff);
			       memset(RecvBuff,0,RECV_LEN);				     		
	        }
				  else{  
						 SendFlag=100;
						 RecvFlag=0;
					 }
				 }
	    }
	  }break;
	 case 4:
		{
			Usart_Send(USART2,"AT+IP=192.168.1.88\r\n");  //configure locak IP address
			RecvFlag=1;		
		  while(RecvFlag)
	    { 
			  if(RX2_Point & FRAME_LEN)//If receive data 
        {
					state=strstr((char *)RecvBuff,"OK");
					if(state!=NULL)
					{
             RX2_Point=0;
				     RecvFlag=0;				//clear receive state flage
					   SendFlag=5;     
					   printf("Recv:%s\r\n",RecvBuff);
			       memset(RecvBuff,0,RECV_LEN);	 					
	        }
				  else{  
						 SendFlag=100;
						 RecvFlag=0;
					 }
				 }
	    }
	  }break;
		case 5:
		{
			Usart_Send(USART2,"AT+MARK=255.255.255.0\r\n");  //configure locak IP address
			RecvFlag=1;		
		  while(RecvFlag)
	    { 
			  if(RX2_Point & FRAME_LEN)//If receive data 
        {
					state=strstr((char *)RecvBuff,"OK");
					if(state!=NULL)
					{
             RX2_Point=0;
				     RecvFlag=0;			//clear receive state flage
					   SendFlag=6;     
					   printf("Recv:%s\r\n",RecvBuff);
			       memset(RecvBuff,0,RECV_LEN);	 					
	        }
				  else{  
						 SendFlag=100;
						 RecvFlag=0;
					 }
				 }
	    }
	  }break;
		case 6:
		{
			Usart_Send(USART2,"AT+GATEWAY=192.168.1.1\r\n");  //configure locak IP address
			RecvFlag=1;		
		  while(RecvFlag)
	    { 
			  if(RX2_Point & FRAME_LEN)//If receive data 
        {
					state=strstr((char *)RecvBuff,"OK");
					if(state!=NULL)
					{
             RX2_Point=0;
				     RecvFlag=0;			//clear receive state flage
					   SendFlag=7;    
					   printf("Recv:%s\r\n",RecvBuff);
			       memset(RecvBuff,0,RECV_LEN);	 					
	        }
				  else{  
						 SendFlag=100;
						 RecvFlag=0;
					 }
				 }
	    }
	  }break;
	 case 7:
		{
			Usart_Send(USART2,"AT+C1_PORT=5000\r\n");//configure locak port number
			RecvFlag=1;		
		  while(RecvFlag)
	    { 
			  if(RX2_Point & FRAME_LEN)//If receive data 
        {
					state=strstr((char *)RecvBuff,"OK");
					if(state!=NULL)
					{
             RX2_Point=0;
				     RecvFlag=0;			//clear receive state flage
					   SendFlag=8;     
					   printf("Recv:%s\r\n",RecvBuff);
			       memset(RecvBuff,0,RECV_LEN);		
	        }
				  else{  
						 SendFlag=100;
						 RecvFlag=0;
					 }
				 }
	    }
	  }break; 
	 case 8:
		{
			Usart_Send(USART2,"AT+START_MODE=0\r\n"); //configure start mode (0--AT mode ��1--data mode)
			RecvFlag=1;		
		  while(RecvFlag)
	    { 
			  if(RX2_Point & FRAME_LEN)//If receive data 
        {
					state=strstr((char *)RecvBuff,"OK");
					if(state!=NULL)
					{
             RX2_Point=0;
				     RecvFlag=0;			//clear receive state flage
					   SendFlag=9;     
					   printf("Recv:%s\r\n",RecvBuff);
			       memset(RecvBuff,0,RECV_LEN);
	        }
				else{  
						 SendFlag=100;
					   RecvFlag=0;
					 }
				 }				
	    }
	  }break;	
	 case 9:
		{
			Usart_Send(USART2,"AT+EXIT\r\n");  //Save the configuration and set into data mode
		    RecvFlag=1;		
		  while(RecvFlag)
	    { 
			  if(RX2_Point & FRAME_LEN)//If receive data 
        {
					state=strstr((char *)RecvBuff,"OK");
					if(state!=NULL)
					{
             RX2_Point=0;
				     RecvFlag=0;			//clear receive state flage
					   SendFlag=99;    
					   printf("Recv:%s\r\n",RecvBuff);
			       memset(RecvBuff,0,RECV_LEN);
					}	
          else{  
						 SendFlag=100;
             RecvFlag=0;						
					 }
				 }					
	      }      
	    }break;
	 case 99:
	  {
			printf("TCP Server Config Success!\r\n");
			Config_OK=1;
	  }
		default:
			RecvFlag=100;break;
	 case 100:
		{
		   printf("TCP Server Config Fail!\r\n");
			 Config_OK=1;
		}break;
	 }	
 }




