#include "common/common.h"
#include "appmod/loopback/loopback.h"


//loopback_tcps

wiz_NetInfo gWIZNETINFO;

int main(void)
{
	printf("adsf");
	uint8_t set[6] = {0,};

	if(platform_init(NULL) != RET_OK)
		goto FAIL_TRAP;

/*	if(network_init(0, NULL, NULL) != RET_OK) {
		ERR("Network_init fail");
		goto FAIL_TRAP;
	}
*/
	LOG("---------------------------------------\r\n");
	LOG("---------------------------------------");
	LOG("Current Network Configuration          ");

	LOG("---------------------------------------");
	getSHAR(set);
	LOGA("MAC : %02X:%02X:%02X:%02X:%02X:%02X", set[0],set[1],set[2],set[3],set[4],set[5]);
	getSIPR(set);
	LOGA("IP  : %d.%d.%d.%d", set[0],set[1],set[2],set[3]);
	getSUBR(set);
	LOGA("SN  : %d.%d.%d.%d", set[0],set[1],set[2],set[3]);
	getGAR(set);
	LOGA("GW  : %d.%d.%d.%d", set[0],set[1],set[2],set[3]);
	LOG("-----------------------------------");
	LOG(" WIZlib Project - Title            ");
	LOG("-----------------------------------");
    printf("SysCtlHClockGet: %d\r\n",xSysCtlClockGet());

   while(1) {
	   loopback_tcps(0,5000);
	   loopback_udp(1,3000);
      
    }
	FAIL_TRAP:
	   wizpf_led_trap(1);
	return -1;
}
