var annotated =
[
    [ "__WIZCHIP", "struct_____w_i_z_c_h_i_p.html", "struct_____w_i_z_c_h_i_p" ]
];