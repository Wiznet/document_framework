var searchData=
[
  ['id',['id',['../struct_____w_i_z_c_h_i_p.html#a4b13df261e52fc02dc773a1eb70572b4',1,'__WIZCHIP']]],
  ['if',['IF',['../struct_____w_i_z_c_h_i_p.html#a21eb19d5a7b7833ab9496cc74daa08a5',1,'__WIZCHIP']]],
  ['if_5fmode',['if_mode',['../struct_____w_i_z_c_h_i_p.html#a32fec318d5bfa58b3ebd8493959a1b31',1,'__WIZCHIP']]]
];
