var searchData=
[
  ['socket_20register_20access_20functions',['Socket register access functions',['../group___socket__register__access__function.html',1,'']]],
  ['socket_20register',['Socket register',['../group___socket__register__group.html',1,'']]]
];
