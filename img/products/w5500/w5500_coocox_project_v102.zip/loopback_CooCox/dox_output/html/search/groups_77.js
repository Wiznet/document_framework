var searchData=
[
  ['wizchip_20i_2fo_20functions',['WIZCHIP I/O functions',['../group___w_i_z_c_h_i_p___i_o___functions.html',1,'']]],
  ['wizchip_20register',['WIZCHIP register',['../group___w_i_z_c_h_i_p__register.html',1,'']]]
];
