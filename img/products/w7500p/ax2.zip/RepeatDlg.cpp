// RepeatDlg.cpp : implementation file
//

#include "stdafx.h"
#include "ax1.h"
#include "RepeatDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CRepeatDlg dialog


CRepeatDlg::CRepeatDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CRepeatDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CRepeatDlg)
	m_nTestCnt = 5;
	//}}AFX_DATA_INIT
}


void CRepeatDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRepeatDlg)
	DDX_Text(pDX, IDC_TESTCNT, m_nTestCnt);
	DDV_MinMaxUInt(pDX, m_nTestCnt, 1, 65536);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CRepeatDlg, CDialog)
	//{{AFX_MSG_MAP(CRepeatDlg)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRepeatDlg message handlers
