#if !defined(AFX_CONFIGDLG_H__D272834E_3894_4BFA_AB46_2A28FFB43F99__INCLUDED_)
#define AFX_CONFIGDLG_H__D272834E_3894_4BFA_AB46_2A28FFB43F99__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ConfigDlg.h : header file
//
#define UDP_SEC_UNIT	0.0001 //100us
class CAX1View;
/////////////////////////////////////////////////////////////////////////////
// CConfigDlg dialog

class CConfigDlg : public CDialog
{
// Construction
public:
	CAX1View* m_pView;
	void SaveConfigToFile(char* filename);
	void LoadConfigFromFile(char* filename);
	CConfigDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CConfigDlg)
	enum { IDD = IDD_DLGCFG };
	CStatic	m_ctrlSizeStatic;
	CStatic	m_ctrlDataFormatStatic;
	CComboBox	m_ctrlDataFormat;
	CEdit	m_ctrlCompFileName;
	CButton	m_ctrlCompFile;
	CButton	m_ctrlLogOnErr;
	CEdit	m_ctrlFromData;
	CEdit	m_ctrlDataSize;
	CButton	m_ctrlBrowse;
	CEdit	m_ctrlLogCount;
	CIPAddressCtrl	m_ctrlServerIP;
	CIPAddressCtrl	m_ctrlPeerIP;
	CButton	m_ctrlNodelayAck;
	CEdit	m_ctrlLogFileName;
	CButton	m_ctrlActive;
	BOOL	m_bActive;
	UINT	m_nLocalPort;
	UINT	m_nLogCount;
	BOOL	m_bLogEnable;
	CString	m_strLogFileName;
	int		m_nTestMode;
	BOOL	m_bNoDelayAck;
	UINT	m_nPeerPort;
	UINT	m_nRBuff;
	UINT	m_nSBuff;
	UINT	m_nServerPort;
	UINT	m_nListenPort;
	int		m_nCompMode;
	CString	m_strCompFileName;
	UINT	m_nErrCnt;
	UINT	m_nDataSize;
	BOOL	m_bErrorExit;
	UINT	m_nFromData;
	BOOL	m_bLogOnErr;
	BOOL	m_bDataInvalid;
	UINT	m_nRepeatTime;
	UINT	m_nUDPPacketSize;
	BOOL	m_bOnLogMsg;
	BOOL	m_bPromptDlg;
	float	m_nExpectedUDPBandWidth;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CConfigDlg)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CConfigDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnLoopbackRadio();
	afx_msg void OnSendonlyRadio();
	afx_msg void OnRecvonlyRadio();
	afx_msg void OnLogenableCheck();
	afx_msg void OnLoadBut();
	afx_msg void OnSaveBut();
	afx_msg void OnActiveCheck();
	afx_msg void OnComfileRadio();
	afx_msg void OnCompdataRadio();
	afx_msg void OnExiterrorCheck();
	afx_msg void OnSelchangeDataformatCombo();
	afx_msg void OnApplyBut();
	afx_msg void OnBrowseBut();
	afx_msg void OnProgmsgCheck();
	afx_msg void OnNodlgCheck();
	//}}AFX_MSG
public:
	CString m_strCompPathName;
	CString m_strLoadFileName;
	afx_msg void OnDefaultBut();

	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CONFIGDLG_H__D272834E_3894_4BFA_AB46_2A28FFB43F99__INCLUDED_)
