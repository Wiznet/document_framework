// ConfigDlg.cpp : implementation file
//

#include "stdafx.h"
#include "ax1.h"
#include "AX1Doc.h"
#include "AX1View.h"
#include "ConfigDlg.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CConfigDlg dialog


CConfigDlg::CConfigDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CConfigDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CConfigDlg)
	m_bActive = FALSE;
	m_nLocalPort = 0;
	m_nLogCount = 0;
	m_bLogEnable = FALSE;
	m_strLogFileName = _T("");
	m_nTestMode = -1;
	m_bNoDelayAck = FALSE;
	m_nPeerPort = 0;
	m_nRBuff = 0;
	m_nSBuff = 0;
	m_nServerPort = 0;
	m_nListenPort = 0;
	m_nCompMode = 0;
	m_strCompFileName = _T("");
	m_nErrCnt = 0;
	m_nDataSize = 0;
	m_bErrorExit = FALSE;
	m_nFromData = 0;
	m_bLogOnErr = FALSE;
	m_bDataInvalid = TRUE;
	m_nRepeatTime = 1000;
	m_nUDPPacketSize = 1472;
	m_bOnLogMsg = FALSE;
	m_bPromptDlg = FALSE;
	m_strCompPathName = _T("");
	m_pView = NULL;
	m_nExpectedUDPBandWidth = 100.0f;
	//}}AFX_DATA_INIT
}


void CConfigDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CConfigDlg)
	DDX_Control(pDX, IDC_SIZE_STATIC, m_ctrlSizeStatic);
	DDX_Control(pDX, IDC_DATAFORMAT_STATIC, m_ctrlDataFormatStatic);
	DDX_Control(pDX, IDC_DATAFORMAT_COMBO, m_ctrlDataFormat);
	DDX_Control(pDX, IDC_COMPFILE_EDIT, m_ctrlCompFileName);
	DDX_Control(pDX, IDC_COMFILE_RADIO, m_ctrlCompFile);
	DDX_Control(pDX, IDC_LOGERR_CHECK, m_ctrlLogOnErr);
	DDX_Control(pDX, IDC_FROMDATA_EDIT, m_ctrlFromData);
	DDX_Control(pDX, IDC_DATASIZE_EDIT, m_ctrlDataSize);
	DDX_Control(pDX, IDC_BROWSE_BUT, m_ctrlBrowse);
	DDX_Control(pDX, IDC_LOGCOUNT_EDIT, m_ctrlLogCount);
	DDX_Control(pDX, IDC_SERVER_IPADDRESS, m_ctrlServerIP);
	DDX_Control(pDX, IDC_PEER_IPADDRESS, m_ctrlPeerIP);
	DDX_Control(pDX, IDC_NODELAY_CHECK, m_ctrlNodelayAck);
	DDX_Control(pDX, IDC_LOGFILENALE_EDIT, m_ctrlLogFileName);
	DDX_Control(pDX, IDC_ACTIVE_CHECK, m_ctrlActive);
	DDX_Check(pDX, IDC_ACTIVE_CHECK, m_bActive);
	DDX_Text(pDX, IDC_LOCALPORT_EDIT, m_nLocalPort);
	DDX_Text(pDX, IDC_LOGCOUNT_EDIT, m_nLogCount);
	DDX_Check(pDX, IDC_LOGENABLE_CHECK, m_bLogEnable);
	DDX_Text(pDX, IDC_LOGFILENALE_EDIT, m_strLogFileName);
	DDX_Radio(pDX, IDC_LOOPBACK_RADIO, m_nTestMode);
	DDX_Check(pDX, IDC_NODELAY_CHECK, m_bNoDelayAck);
	DDX_Text(pDX, IDC_PEERPORT_EDIT, m_nPeerPort);
	DDX_Text(pDX, IDC_RBUFF_EDIT, m_nRBuff);
	DDX_Text(pDX, IDC_SBUFF_EDIT, m_nSBuff);
	DDX_Text(pDX, IDC_SERVERPORT_EDIT, m_nServerPort);
	DDX_Text(pDX, IDC_LISTENPORT_EDIT, m_nListenPort);
	DDX_Radio(pDX, IDC_COMFILE_RADIO, m_nCompMode);
	DDX_Text(pDX, IDC_COMPFILE_EDIT, m_strCompFileName);
	DDX_Text(pDX, IDC_DATASIZE_EDIT, m_nDataSize);
	DDX_Check(pDX, IDC_EXITERROR_CHECK, m_bErrorExit);
	DDX_Text(pDX, IDC_FROMDATA_EDIT, m_nFromData);
	DDV_MinMaxUInt(pDX, m_nFromData, 0, 255);
	DDX_Check(pDX, IDC_LOGERR_CHECK, m_bLogOnErr);
	DDX_Check(pDX, IDC_INVALID_CHECK, m_bDataInvalid);
	DDX_Text(pDX, IDC_REPEATTIME_EDIT, m_nRepeatTime);
	DDX_Text(pDX, IDC_UDPPACKET_EDIT, m_nUDPPacketSize);
	DDV_MinMaxUInt(pDX, m_nUDPPacketSize, 1, 1472);
	DDX_Check(pDX, IDC_PROGMSG_CHECK, m_bOnLogMsg);
	DDX_Check(pDX, IDC_NODLG_CHECK, m_bPromptDlg);
	DDX_Text(pDX, IDC_UDPBANDWIDTH_EDIT, m_nExpectedUDPBandWidth);
	DDV_MinMaxFloat(pDX, m_nExpectedUDPBandWidth, 1.e-003f, 100.f);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CConfigDlg, CDialog)
	//{{AFX_MSG_MAP(CConfigDlg)
	ON_BN_CLICKED(IDC_LOOPBACK_RADIO, OnLoopbackRadio)
	ON_BN_CLICKED(IDC_SENDONLY_RADIO, OnSendonlyRadio)
	ON_BN_CLICKED(IDC_RECVONLY_RADIO, OnRecvonlyRadio)
	ON_BN_CLICKED(IDC_LOGENABLE_CHECK, OnLogenableCheck)
	ON_BN_CLICKED(IDC_LOAD_BUT, OnLoadBut)
	ON_BN_CLICKED(IDC_SAVE_BUT, OnSaveBut)
	ON_BN_CLICKED(IDC_ACTIVE_CHECK, OnActiveCheck)
	ON_BN_CLICKED(IDC_COMFILE_RADIO, OnComfileRadio)
	ON_BN_CLICKED(IDC_COMPDATA_RADIO, OnCompdataRadio)
	ON_BN_CLICKED(IDC_EXITERROR_CHECK, OnExiterrorCheck)
	ON_CBN_SELCHANGE(IDC_DATAFORMAT_COMBO, OnSelchangeDataformatCombo)
	ON_BN_CLICKED(IDC_APPLY_BUT, OnApplyBut)
	ON_BN_CLICKED(IDC_BROWSE_BUT, OnBrowseBut)
	ON_BN_CLICKED(IDC_DEFALUT_BUT, OnDefaultBut)
	ON_BN_CLICKED(IDC_PROGMSG_CHECK, OnProgmsgCheck)
	ON_BN_CLICKED(IDC_NODLG_CHECK, OnNodlgCheck)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CConfigDlg message handlers

BOOL CConfigDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
//	OnDefalutBut();
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CConfigDlg::OnLoopbackRadio() 
{
	// TODO: Add your control notification handler code here
	m_ctrlActive.EnableWindow();
	OnActiveCheck();
}

void CConfigDlg::OnSendonlyRadio() 
{
	// TODO: Add your control notification handler code here
	m_ctrlActive.EnableWindow(FALSE);
	//CWnd* pWnd = GetDlgItem(IDC_COMPDATA_RADIO);
	//pWnd->EnableWindow(FALSE);
	//m_ctrlDataSize.EnableWindow(FALSE);
	//m_ctrlSizeStatic.EnableWindow(FALSE);
	//m_ctrlDataFormat.EnableWindow(FALSE);
	//m_ctrlDataFormatStatic.EnableWindow(FALSE);
	//m_ctrlFromData.EnableWindow(FALSE);
}

void CConfigDlg::OnRecvonlyRadio() 
{
	// TODO: Add your control notification handler code here
	UpdateData();
	m_ctrlActive.EnableWindow(FALSE);
/*	//m_ctrlCompFile.EnableWindow();
	m_ctrlCompFileName.EnableWindow(!m_nCompMode);
	m_ctrlBrowse.EnableWindow(!m_nCompMode);
	CWnd* pWnd = GetDlgItem(IDC_COMPDATA_RADIO);
	pWnd->EnableWindow();
	m_ctrlDataSize.EnableWindow(m_nCompMode);
	m_ctrlSizeStatic.EnableWindow(m_nCompMode);
	m_ctrlDataFormat.EnableWindow(m_nCompMode);
	m_ctrlDataFormatStatic.EnableWindow(m_nCompMode);
	m_ctrlFromData.EnableWindow(m_ctrlDataFormat.GetCurSel()==1 && m_nCompMode);*/
}

void CConfigDlg::OnLogenableCheck() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	m_ctrlLogFileName.EnableWindow(m_bLogEnable);
	m_ctrlLogCount.EnableWindow(m_bLogEnable);
	m_ctrlLogOnErr.EnableWindow(m_bLogEnable);
}

void CConfigDlg::OnDefaultBut() 
{
	// TODO: Add your control notification handler code here
	m_nListenPort = 3000;
	m_ctrlServerIP.SetWindowText("192.168.1.100");
	m_nServerPort = 5000;
	m_nSBuff = 8;
	m_nRBuff = 8;
	m_bNoDelayAck = FALSE;


	m_nLocalPort = 0;
	m_ctrlPeerIP.SetWindowText("192.168.1.100");
	m_nPeerPort = 3000;
	m_nUDPPacketSize = 1472;
	m_nExpectedUDPBandWidth = 10.0;

	m_nTestMode = 0;
	m_bActive = TRUE;
	m_ctrlActive.EnableWindow();
	m_nCompMode = 0;
	m_strCompFileName = "AX2.bin";
	m_strCompPathName = ".\\AX2.bin";
	m_nDataSize = 8*1024;
//	m_bSeqData = FALSE;

	m_ctrlDataFormat.SetCurSel(0);
	m_nFromData = 0;
//	m_ctrlDataFormatStatic.EnableWindow(m_nCompMode);
	m_nRepeatTime = 2000;


/*
	m_ctrlCompFile.EnableWindow(FALSE);
	m_ctrlCompFileName.EnableWindow(FALSE);
	m_ctrlBrowse.EnableWindow(FALSE);
	CWnd* pWnd = GetDlgItem(IDC_COMPDATA_RADIO);
	pWnd->EnableWindow(FALSE);
	m_ctrlDataSize.EnableWindow(FALSE);
	m_ctrlSizeStatic.EnableWindow(FALSE);
	m_ctrlDataFormat.EnableWindow(FALSE);
	m_ctrlFromData.EnableWindow(FALSE);
*/

	m_bDataInvalid = TRUE;
	m_bOnLogMsg = TRUE;
	m_bPromptDlg = TRUE;
	m_bLogEnable = FALSE;
	m_bErrorExit = TRUE;
	m_bLogOnErr = TRUE;
	m_ctrlLogFileName.EnableWindow(FALSE);
	m_strLogFileName = ".\\AX2Log.txt";
	m_nLogCount = 1000;
	m_ctrlLogOnErr.EnableWindow(FALSE);
	m_ctrlLogCount.EnableWindow(FALSE);	

	SetWindowText("Configuration - Default");
	UpdateData(FALSE);
}

void CConfigDlg::OnLoadBut() 
{
	// TODO: Add your control notification handler code here
	CFileDialog FDlg(TRUE,"ax2",".\\*.ax2",OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,"*.ax2");
	if(FDlg.DoModal()==IDOK)
		LoadConfigFromFile(FDlg.GetPathName().GetBuffer(256));
}

void CConfigDlg::LoadConfigFromFile(char *filename)
{
	FILE* loadfile;
	loadfile = fopen(filename,"r");
	char tmpbuf[256];

	if(loadfile)
	{
		fscanf(loadfile,"LISTEN PORT = %d\n",&m_nListenPort);
		fscanf(loadfile, "SERVER IP = %s\n",tmpbuf);
		m_ctrlServerIP.SetWindowText(tmpbuf);

		fscanf(loadfile, "SERVER PORT = %d\n",&m_nServerPort);
		fscanf(loadfile, "SEND BUF = %d\n",&m_nSBuff);
		fscanf(loadfile, "RECV BUF = %d\n",&m_nRBuff);
		fscanf(loadfile, "NODELAYACK = %d\n",&m_bNoDelayAck);

		fscanf(loadfile, "SOURCE PORT = %d\n",&m_nLocalPort);
		fscanf(loadfile, "PEER IP = %s\n",tmpbuf);
		m_ctrlPeerIP.SetWindowText(tmpbuf);
		fscanf(loadfile, "PEER PORT = %d\n",&m_nPeerPort);
		fscanf(loadfile, "PACKET SIZE = %d\n",&m_nUDPPacketSize);
		fscanf(loadfile, "BANDWIDTH = %f\n", &m_nExpectedUDPBandWidth); 

		fscanf(loadfile, "TEST MODE = %d\n",&m_nTestMode);
		fscanf(loadfile, "ACTIVE = %d\n",&m_bActive);
		fscanf(loadfile, "COMP MODE = %d\n", &m_nCompMode);
		fscanf(loadfile, "COMP FILE = %s\n", tmpbuf);
		if(strcmp(tmpbuf,"\"\"")) m_strCompFileName= _T(tmpbuf);
		else m_strCompFileName= _T("");
		fscanf(loadfile, "COMP PATH = %s\n", tmpbuf);
		if(strcmp(tmpbuf,".\\")) m_strCompPathName= _T(tmpbuf);
		else m_strCompPathName= _T(".\\");

		fscanf(loadfile, "DATA SIZE = %d\n",&m_nDataSize);
		UINT dform;
		fscanf(loadfile, "DATA FORMAT = %d\n",&dform);
		fscanf(loadfile, "FROM DATA = %d\n", &m_nFromData);
		m_ctrlDataFormat.SetCurSel(dform);
		fscanf(loadfile, "DATA INVALID = %d\n",&m_bDataInvalid);
		fscanf(loadfile, "REPEAT TIME = %d\n", &m_nRepeatTime);

		
		fscanf(loadfile, "DISPLAY LOG = %d\n", &m_bOnLogMsg);
		fscanf(loadfile, "PROMPT DIALOG = %d\n", &m_bPromptDlg);
		fscanf(loadfile, "LOGENABLE = %d\n",&m_bLogEnable);
		fscanf(loadfile, "EXIT ERROR = %d\n",&m_bErrorExit);

		fscanf(loadfile, "LOGFILE = %s\n",tmpbuf);
		if(strcmp(tmpbuf,"\"\""))
			m_strLogFileName = CString(tmpbuf);
		else
			m_strLogFileName = "";
		fscanf(loadfile, "LOGCNT = %d\n",&m_nLogCount);
		fscanf(loadfile, "LOG ON ERROR = %d\n",&m_bLogOnErr);

		fclose(loadfile);

		m_strLoadFileName = _T(strrchr(filename,'\\')+1);
		SetWindowText("Configuration - " + m_strLoadFileName);
		UpdateData(FALSE);
		switch(m_nTestMode)
		{
		case 0: OnLoopbackRadio();
				break;
		case 1: OnSendonlyRadio();
				break;
		default: OnRecvonlyRadio();
				break;
		}
		OnLogenableCheck();
	}
}

void CConfigDlg::OnSaveBut() 
{
	// TODO: Add your control notification handler code here
	CString strfilename;
	if(m_strLoadFileName == "")
		strfilename = _T(".\\AX2Conf.ax2");
	else
		strfilename = _T(".\\") + m_strLoadFileName;
	CFileDialog FDlg(FALSE,"ax2",strfilename,OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,"*.ax2");
	if(FDlg.DoModal()==IDOK)
	{
		SaveConfigToFile(FDlg.GetFileName().GetBuffer(100));
		SetWindowText("Configuration - " + FDlg.GetFileName());
		FILE* conffile;
		conffile = fopen(".\\AX2Conf.conf","w");
		if(conffile)
		{
			fprintf(conffile,"%s",FDlg.GetPathName().GetBuffer(256));
			fclose(conffile);
		}
		((CAX1App*)AfxGetApp())->SetTitle(FDlg.GetFileName().GetBuffer(100));
	}
}

void CConfigDlg::SaveConfigToFile(char *filename)
{
	FILE* savefile;
	savefile = fopen(filename,"w");
	char tmpbuf[256];
	if(savefile)
	{
		UpdateData(TRUE);
		fprintf(savefile,"LISTEN PORT = %d\n",m_nListenPort);
		m_ctrlServerIP.GetWindowText(tmpbuf,100);
		fprintf(savefile, "SERVER IP = %s\n",tmpbuf);
		fprintf(savefile, "SERVER PORT = %d\n",m_nServerPort);
		fprintf(savefile, "SEND BUF = %d\n", m_nSBuff);
		fprintf(savefile, "RECV BUF = %d\n", m_nRBuff);
		fprintf(savefile, "NODELAYACK = %d\n", (UINT)m_bNoDelayAck);

		fprintf(savefile, "SOURCE PORT = %d\n",m_nLocalPort);
		m_ctrlPeerIP.GetWindowText(tmpbuf,256);
		fprintf(savefile, "PEER IP = %s\n", tmpbuf);
		fprintf(savefile, "PEER PORT = %d\n",m_nPeerPort);
		fprintf(savefile, "PACKET SIZE = %d\n", m_nUDPPacketSize);
		fprintf(savefile, "BANDWIDTH = %f\n", m_nExpectedUDPBandWidth);

		fprintf(savefile, "TEST MODE = %d\n", m_nTestMode);
		fprintf(savefile, "ACTIVE = %d\n", (UINT)m_bActive);
		fprintf(savefile, "COMP MODE = %d\n", (UINT)m_nCompMode);
		if(m_strCompFileName != "")
		{
			fprintf(savefile, "COMP FILE = %s\n", m_strCompFileName.GetBuffer(256));
			fprintf(savefile, "COMP PATH = %s\n", m_strCompPathName.GetBuffer(256));
		}
		else 
		{
			fprintf(savefile, "COMP FILE = %s\n", "\"\"");
			fprintf(savefile, "COMP PATH = %s\n", ".\\");
		}

		fprintf(savefile, "DATA SIZE = %d\n",m_nDataSize);
		fprintf(savefile, "DATA FORMAT = %d\n", m_ctrlDataFormat.GetCurSel());
		fprintf(savefile, "FROM DATA = %d\n", m_nFromData);
		fprintf(savefile, "DATA INVALID = %d\n",m_bDataInvalid);
		fprintf(savefile, "REPEAT TIME = %d\n", m_nRepeatTime);

		fprintf(savefile, "DISPLAY LOG = %d\n", m_bOnLogMsg);
		fprintf(savefile, "PROMPT DIALOG = %d\n", m_bPromptDlg);
		fprintf(savefile, "LOGENABLE = %d\n", (UINT)m_bLogEnable);
		fprintf(savefile, "EXIT ERROR = %d\n",(UINT)m_bErrorExit);

		if(m_strLogFileName != "")
			fprintf(savefile, "LOGFILE = %s\n",m_strLogFileName.GetBuffer(256));
		else
			fprintf(savefile, "LOGFILE = %s\n","\"\"");
		fprintf(savefile, "LOGCNT = %d\n", m_nLogCount);
		fprintf(savefile, "LOG ON ERROR = %d\n",m_bLogOnErr);


		fclose(savefile);
	}
}

void CConfigDlg::OnActiveCheck() 
{
	// TODO: Add your control notification handler code here
	UpdateData();
/*
	if(m_bActive)
	{
		m_ctrlCompFile.EnableWindow(FALSE);
		m_ctrlCompFileName.EnableWindow(FALSE);
		m_ctrlBrowse.EnableWindow(FALSE);
		CWnd* pWnd = GetDlgItem(IDC_COMPDATA_RADIO);
		pWnd->EnableWindow(FALSE);
		m_ctrlDataSize.EnableWindow(FALSE);
		m_ctrlSizeStatic.EnableWindow(FALSE);
		m_ctrlDataFormat.EnableWindow(FALSE);
		m_ctrlDataFormatStatic.EnableWindow(FALSE);
	//	m_ctrlFromData.EnableWindow(FALSE);
	}
	else
	{
		m_ctrlCompFile.EnableWindow();
		m_ctrlCompFileName.EnableWindow(!m_nCompMode);
		m_ctrlBrowse.EnableWindow(!m_nCompMode);
		CWnd* pWnd = GetDlgItem(IDC_COMPDATA_RADIO);
		pWnd->EnableWindow();
		m_ctrlDataSize.EnableWindow(m_nCompMode);
		m_ctrlSizeStatic.EnableWindow(m_nCompMode);
		m_ctrlDataFormat.EnableWindow(m_nCompMode);
		m_ctrlDataFormatStatic.EnableWindow(m_nCompMode);
	//	m_ctrlFromData.EnableWindow((m_bSeqData && m_nCompMode == 1));
	}
	m_ctrlFromData.EnableWindow(m_ctrlDataFormat.GetCurSel()==1 && m_nCompMode && (m_nTestMode == 2 || (!m_nTestMode && !m_bActive)));
*/
}

void CConfigDlg::OnComfileRadio() 
{
	// TODO: Add your control notification handler code here
	UpdateData();
/*	m_ctrlCompFileName.EnableWindow();
	m_ctrlBrowse.EnableWindow();
	m_ctrlDataSize.EnableWindow(FALSE);
	m_ctrlSizeStatic.EnableWindow(FALSE);
	m_ctrlDataFormat.EnableWindow(FALSE);
	m_ctrlDataFormatStatic.EnableWindow(FALSE);
	m_ctrlFromData.EnableWindow(FALSE);
*/
}

void CConfigDlg::OnCompdataRadio() 
{
	// TODO: Add your control notification handler code here
	UpdateData();
/*	m_ctrlCompFileName.EnableWindow(FALSE);
	m_ctrlBrowse.EnableWindow(FALSE);
	m_ctrlDataSize.EnableWindow();
	m_ctrlSizeStatic.EnableWindow();
	m_ctrlDataFormat.EnableWindow();
	m_ctrlDataFormatStatic.EnableWindow(m_nCompMode);
	m_ctrlFromData.EnableWindow(m_ctrlDataFormat.GetCurSel()==1 && m_nCompMode && (m_nTestMode == 2 || (!m_nTestMode && !m_bActive)));
	*/
}



void CConfigDlg::OnExiterrorCheck() 
{
	// TODO: Add your control notification handler code here
	UpdateData();
}

BOOL CConfigDlg::PreTranslateMessage(MSG* pMsg) 
{
	// TODO: Add your specialized code here and/or call the base class
	if (pMsg->message == WM_KEYDOWN)
    {
        switch (pMsg->wParam)
        {
        case VK_RETURN:
        case VK_ESCAPE:
			return TRUE;
	        break;
		}
    }
	return CDialog::PreTranslateMessage(pMsg);
}



void CConfigDlg::OnSelchangeDataformatCombo() 
{
	// TODO: Add your control notification handler code here
	if(m_ctrlDataFormat.GetCurSel() == 1) 
		m_ctrlFromData.EnableWindow();
	else
		m_ctrlFromData.EnableWindow(FALSE);	
}

void CConfigDlg::OnApplyBut() 
{
	// TODO: Add your control notification handler code here
	UpdateData();
	int pos;
	if(m_strCompPathName.Find(m_strCompFileName) == -1)
	{
		m_strCompPathName = m_strCompFileName;
		if((pos=m_strCompPathName.ReverseFind('\\')) == -1)
		{
			m_strCompPathName = ".\\" + m_strCompFileName;
		}
		else
		{
			m_strCompFileName = m_strCompPathName.Mid(pos+1);
		}
	}
}

void CConfigDlg::OnBrowseBut() 
{
	// TODO: Add your control notification handler code here
	CFileDialog FDlg(TRUE,NULL,".\\*.*",OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,"*.*");
	if(FDlg.DoModal()==IDOK)
	{
		m_strCompFileName = FDlg.GetFileName();
		m_strCompPathName = FDlg.GetPathName();
		UpdateData(FALSE);
	}
	
}


void CConfigDlg::OnProgmsgCheck() 
{
	// TODO: Add your control notification handler code here
	m_bOnLogMsg = ((CButton*)GetDlgItem(IDC_PROGMSG_CHECK))->GetCheck();
	if(!m_pView->m_bUserTest )
	{
		if(m_bOnLogMsg && m_pView->m_bAlive)
			m_pView->m_pProgDlg->ShowWindow(SW_SHOW);
		else
			m_pView->m_pProgDlg->ShowWindow(SW_HIDE);
	}
}

void CConfigDlg::OnNodlgCheck() 
{
	// TODO: Add your control notification handler code here
	m_bPromptDlg = ((CButton*)GetDlgItem(IDC_NODLG_CHECK))->GetCheck();
}

