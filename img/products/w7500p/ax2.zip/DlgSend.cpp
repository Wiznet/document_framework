// DlgSend.cpp : implementation file
//

#include "stdafx.h"
#include "AX1.h"
#include "DlgSend.h"
#include "AX1Doc.h"
#include "AX1View.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgSend dialog


CDlgSend::CDlgSend(CWnd* pParent /*=NULL*/,BOOL IsTCP, BOOL IsSend)
	: CDialog(CDlgSend::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgSend)
	m_iCnt = 100;
	m_cVal = 97;
	m_bIsTCP = IsTCP;
	m_bIsSend = IsSend;
	m_RemoteIP = _T("");
	m_nPeerPort = 0;
	m_nFormat = 0;
	//}}AFX_DATA_INIT
}


void CDlgSend::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgSend)
	DDX_Control(pDX, IDC_FOMAT_COMBO, m_ctrlFormat);
	DDX_Control(pDX, IDC_PEERPORT_STATIC, m_PeerPortStatic);
	DDX_Control(pDX, IDC_PEERPORT, m_PeerPortEdit);
	DDX_Text(pDX, IDC_EDT_CNT, m_iCnt);
	DDX_Text(pDX, IDC_EDT_VAL, m_cVal);
	DDV_MinMaxByte(pDX, m_cVal, 0, 255);
	DDX_Text(pDX, IDC_REMOTEIP, m_RemoteIP);
	DDV_MaxChars(pDX, m_RemoteIP, 15);
	DDX_Text(pDX, IDC_PEERPORT, m_nPeerPort);
	DDX_CBIndex(pDX, IDC_FOMAT_COMBO, m_nFormat);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgSend, CDialog)
	//{{AFX_MSG_MAP(CDlgSend)
	ON_CBN_SELCHANGE(IDC_FOMAT_COMBO, OnSelchangeFomatCombo)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgSend message handlers

BOOL CDlgSend::OnInitDialog() 
{
	CDialog::OnInitDialog();

	m_nFormat = m_pView->m_pConfigDlg->m_ctrlDataFormat.GetCurSel();	
	// TODO: Add extra initialization here
	if(m_bIsTCP)
	{
		m_RemoteIP = m_pView->m_clntSocket.GetRemoteHostIP();
		GetDlgItem(IDC_REMOTEIP)->EnableWindow(FALSE);
		m_nPeerPort = m_pView->m_clntSocket.GetRemotePort();
		m_PeerPortEdit.EnableWindow(FALSE);
		m_ctrlFormat.SetCurSel(m_nFormat);
		OnSelchangeFomatCombo();
		if(m_bIsSend) SetWindowText("TCP : Send Data");
		else SetWindowText("TCP : Receive Data");
	}
	else
	{
		m_ctrlFormat.SetCurSel(m_nFormat);
		OnSelchangeFomatCombo();
		if(m_bIsSend)
		{
			SetWindowText("UDP : Send Data");
			m_pView->m_pConfigDlg->m_ctrlPeerIP.GetWindowText(m_RemoteIP);
			m_nPeerPort = m_pView->m_pConfigDlg->m_nPeerPort;
		}
		else
		{
			m_RemoteIP = "Any";
			m_nPeerPort = 0;
			GetDlgItem(IDC_REMOTEIP)->EnableWindow(FALSE);
			GetDlgItem(IDC_PEERPORT)->EnableWindow(FALSE);
			SetWindowText("UDP : Receive Data");
		}

	}
	m_iCnt = m_pView->m_pConfigDlg->m_nDataSize;
	m_cVal = m_pView->m_pConfigDlg->m_nFromData;


	UpdateData(FALSE);
	if(!m_pView->m_pConfigDlg->m_bPromptDlg) OnOK();
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CDlgSend::OnOK() 
{
	// TODO: Add extra validation here
	UpdateData();
	if(m_iCnt < 1) 
	{
		AfxMessageBox("'Size' is great than 0");
		return;
	}
	CDialog::OnOK();
}

void CDlgSend::OnSelchangeFomatCombo() 
{
	// TODO: Add your control notification handler code here
	if(m_ctrlFormat.GetCurSel() == 1)
		GetDlgItem(IDC_EDT_VAL)->EnableWindow();
	else
		GetDlgItem(IDC_EDT_VAL)->EnableWindow(FALSE);
}
