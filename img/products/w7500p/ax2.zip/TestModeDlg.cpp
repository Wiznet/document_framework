// TestModeDlg.cpp : implementation file
//

#include "stdafx.h"
#include "ax1.h"
#include "TestModeDlg.h"

#include "AX1Doc.h"
#include "AX1View.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTestModeDlg dialog


CTestModeDlg::CTestModeDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CTestModeDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CTestModeDlg)
	m_bActive = FALSE;
	m_nTestMode = -1;
	//}}AFX_DATA_INIT
}


void CTestModeDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTestModeDlg)
	DDX_Control(pDX, IDC_LOOPBACK_RADIO, m_ctrlTestMode);
	DDX_Check(pDX, IDC_ACTIVE_CHECK, m_bActive);
	DDX_Radio(pDX, IDC_LOOPBACK_RADIO, m_nTestMode);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CTestModeDlg, CDialog)
	//{{AFX_MSG_MAP(CTestModeDlg)
	ON_BN_CLICKED(IDC_LOOPBACK_RADIO, OnLoopbackRadio)
	ON_BN_CLICKED(IDC_SEND_RADIO, OnSendRadio)
	ON_BN_CLICKED(IDC_RECV_RADIO, OnRecvRadio)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTestModeDlg message handlers

BOOL CTestModeDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();

	// TODO: Add extra initialization here
	m_nTestMode = m_pView->m_pConfigDlg->m_nTestMode;
	m_bActive = m_pView->m_pConfigDlg->m_bActive;

	UpdateData(FALSE);
	switch(m_nTestMode)
	{
	case 0:
		OnLoopbackRadio();
		break;
	case 1:
		OnSendRadio();
		break;
	default:
		OnRecvRadio();
		break;
	}
	if(!m_pView->m_pConfigDlg->m_bPromptDlg) OnOK();
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CTestModeDlg::OnLoopbackRadio() 
{
	// TODO: Add your control notification handler code here
	GetDlgItem(IDC_ACTIVE_CHECK)->EnableWindow();
}

void CTestModeDlg::OnSendRadio() 
{
	// TODO: Add your control notification handler code here
	GetDlgItem(IDC_ACTIVE_CHECK)->EnableWindow(FALSE);
	
}

void CTestModeDlg::OnRecvRadio() 
{
	// TODO: Add your control notification handler code here
	GetDlgItem(IDC_ACTIVE_CHECK)->EnableWindow(FALSE);
	
}



void CTestModeDlg::OnOK() 
{
	// TODO: Add extra validation here
	UpdateData();
	CDialog::OnOK();
}
