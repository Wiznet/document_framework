// DlgIPPort.cpp : implementation file
//

#include "stdafx.h"
#include "AX1.h"
#include "DlgIPPort.h"
#include "AX1Doc.h"
#include "AX1View.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgIPPort dialog


CDlgIPPort::CDlgIPPort(CWnd* pParent /*=NULL*/,BOOL bTCP)
	: CDialog(CDlgIPPort::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgIPPort)
	m_strIP = _T("192.168.0.2");
	m_bTCP = bTCP;
	if(m_bTCP)	m_uPort = 5000;
	else	 m_uPort = 3000;

	//}}AFX_DATA_INIT
}


void CDlgIPPort::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgIPPort)
	DDX_Text(pDX, IDC_EDTIP, m_strIP);
	DDX_Text(pDX, IDC_EDTPORT, m_uPort);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgIPPort, CDialog)
	//{{AFX_MSG_MAP(CDlgIPPort)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgIPPort message handlers

void CDlgIPPort::OnOK() 
{
	// TODO: Add extra validation here
	UpdateData();
/*
	CAX1App* pApp = (CAX1App*) AfxGetApp();
	if(m_bTCP)
	{
		pApp->WriteProfileString("AX1","TCP_DEST_IP",m_strIP);
		pApp->WriteProfileInt("AX1","TCP_DEST_Port",m_uPort);
	}
	else 
	{
		pApp->WriteProfileString("AX1","UDP_DEST_IP",m_strIP);
		pApp->WriteProfileInt("AX1","UDP_DEST_Port",m_uPort);
	}
*/
	CDialog::OnOK();
}

BOOL CDlgIPPort::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
//	CAX1App* pApp = (CAX1App*) AfxGetApp();
	if(m_bTCP)
	{
//		m_strIP = pApp->GetProfileString("AX1","TCP_DEST_IP","192.168.0.2");
//		m_uPort = pApp->GetProfileInt("AX1","TCP_DEST_Port",5000);	
		m_pView->m_pConfigDlg->m_ctrlServerIP.GetWindowText(m_strIP);
		m_uPort = m_pView->m_pConfigDlg->m_nServerPort;
		SetWindowText("TCP : Peer IP & Port Setting");
	}
	else
	{
//		m_strIP = pApp->GetProfileString("AX1","UDP_DEST_IP","192.168.0.2");
//		m_uPort = pApp->GetProfileInt("AX1","UDP_DEST_Port",3000);	
		m_pView->m_pConfigDlg->m_ctrlPeerIP.GetWindowText(m_strIP);
		m_uPort = m_pView->m_pConfigDlg->m_nPeerPort;
		SetWindowText("UDP : Peer IP & Port Setting");
	}
	UpdateData(FALSE);
	if(!m_pView->m_pConfigDlg->m_bPromptDlg) OnOK();
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
