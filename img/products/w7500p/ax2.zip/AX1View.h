// AX1View.h : interface of the CAX1View class
//
/////////////////////////////////////////////////////////////////////////////
//{{AFX_INCLUDES()
#include "mswinsockcontrol.h"
//}}AFX_INCLUDES

#if !defined(AFX_AX1VIEW_H__A699C6ED_FC2D_11D3_A689_005004C3B715__INCLUDED_)
#define AFX_AX1VIEW_H__A699C6ED_FC2D_11D3_A689_005004C3B715__INCLUDED_

#include "mswinsockcontrol.h"	// Added by ClassView
#include "ProgDlg.h"	// Added by ClassView
#include "ConfigDlg.h"
#include "MyEdit.h"

#include <afxdb.h>

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define UDP_TIMER		999
#define REPEAT_TIMER	888

class CAX1View : public CFormView
{
protected: // create from serialization only
	CAX1View();
	DECLARE_DYNCREATE(CAX1View)

public:
	//{{AFX_DATA(CAX1View)
	enum { IDD = IDD_AX1_FORM };
	CComboBox	m_ctrlSpeed;
	CMSWinsockControl	m_ctrlUDPSock;
	CMSWinsockControl m_clntSocket;
	CMSWinsockControl m_srvSocket;
	CString	m_strRepeatCnt;
	CString	m_strRSpeed;
	CString	m_strRSec;
	CString	m_strRTSec;
	CString	m_strRTSpeed;
	CString	m_strSSec;
	CString	m_strSSpeed;
	CString	m_strData;
	CString	m_strStatus;
	CString	m_strTestMode;
	//}}AFX_DATA

// Attributes
public:
	CAX1Doc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAX1View)
	public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual void OnInitialUpdate(); // called first time after construct
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnPrint(CDC* pDC, CPrintInfo* pInfo);
	//}}AFX_VIRTUAL

// Implementation
public:

	UINT m_nTotalInvalidCnt;
	UINT m_nInvalidCnt;

	UINT m_nUDPPeerPacketSize;
	void UDPRecvCompleted(void);
	UINT m_nUDPTimerWait;
	CString m_strUDPLoss;
	float m_fUDPLossRate;
	UINT m_nUDPLossSize;
	
	void SendCompleted(BOOL bTCP);
	BOOL m_bUDP;
	UINT m_nBit;
	UINT m_nSpeed;
	CString m_strSpeed;
	CString m_strCompPathName;
	CString m_strCompFileName;
	UINT m_nFormat;

	BOOL m_bActive;
	UINT m_nTestMode;
	BOOL GenerateTestData(BOOL bTCP, BOOL bSend);
	CString m_strConfFileName;
	BOOL m_bUDPPeer;
	BOOL m_bTCP;
	BOOL m_bFileOpen;
	BOOL m_bUserTest;
	BOOL m_bListen;
	ULONG m_nUserDataSize;
	ULONG m_nFileSize;
	ULONG m_nUserRecvSize;
	ULONG m_nUserSentSize;

	ULONG m_nUDPSize;
	UINT m_nRepeat;
	UINT m_iCnt;
	BOOL m_bAlive;
	BOOL m_bInfinite;
	BOOL m_FirstRecv;
	CProgDlg *m_pProgDlg;
	UINT m_nTestCnt;

	CString m_FileName;
	ULONG m_len;

	CMyEdit m_Edit;
	CFont m_NormFont;

	double           m_unitFreq;
	unsigned __int64 m_SStartTick;
	unsigned __int64 m_SEndTick;
	unsigned __int64 m_RStartTick;
	unsigned __int64 m_REndTick;

	double	m_secTick;

	double	m_secTX;
	double	m_secRX;
	double  m_secRTT;

//	unsigned __int64 m_starttick;
//	unsigned __int64 m_endtick;
//	BOOL	m_bTicking;




	HGLOBAL m_hUserDataBuf;
	HGLOBAL m_hFileBuf;
	CLongBinary m_DataBinary;
	COleVariant m_DataVariant;


	
	BOOL m_bConnect;
	CString m_UDPPeerIP;
	UINT m_nUDPPeerPort;

	CConfigDlg*	m_pConfigDlg;

	void Log(CString log, BOOL bBOLD=FALSE);

	void SendUDPData(VARIANT* pVar);

	virtual ~CAX1View();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CAX1View)
	afx_msg void OnConnectionRequestWinsock1(long requestID);
	afx_msg void OnMenuStartserver();
	afx_msg void OnDataArrivalWinsock2(long bytesTotal);
	afx_msg void OnFileOpen();
	afx_msg void OnSendCompleteWinsock2();
	afx_msg void OnSendProgressWinsock2(long bytesSent, long bytesRemaining);
	afx_msg void OnMenuConnect();
	afx_msg void OnErrorWinsock2(short Number, BSTR FAR* Description, long Scode, LPCTSTR Source, LPCTSTR HelpFile, long HelpContext, BOOL FAR* CancelDisplay);
	afx_msg void OnMenuInfinite();
	afx_msg void OnMenuFinite();
	afx_msg void OnConnectWinsock2();
	afx_msg void OnDataArrivalWinsock3(long bytesTotal);
	afx_msg void OnUdpopen();
	afx_msg void OnUdpsend();
	afx_msg void OnCputick();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnErrorWinsock3(short Number, BSTR FAR* Description, long Scode, LPCTSTR Source, LPCTSTR HelpFile, long HelpContext, BOOL FAR* CancelDisplay);
	afx_msg void OnTcpclose();
	afx_msg void OnDestroy();
	afx_msg void OnMenuSend2();
	afx_msg void OnSend();
	afx_msg void OnUdpFileSend();
	afx_msg void OnMenuUdpRepeat();
	afx_msg void OnMenuTcpRepeat();
	afx_msg void OnUpdateMenuUdpRepeat(CCmdUI* pCmdUI);
	afx_msg void OnUpdateUdpsend(CCmdUI* pCmdUI);
	afx_msg void OnUpdateUdpclose(CCmdUI* pCmdUI);
	afx_msg void OnUpdateUdpopen(CCmdUI* pCmdUI);
	afx_msg void OnUpdateUdpSend(CCmdUI* pCmdUI);
	afx_msg void OnUpdateMenuInfinite(CCmdUI* pCmdUI);
	afx_msg void OnUpdateMenuConnect(CCmdUI* pCmdUI);
	afx_msg void OnUpdateMenuSend2(CCmdUI* pCmdUI);
	afx_msg void OnUpdateMenuStartserver(CCmdUI* pCmdUI);
	afx_msg void OnUpdateMenuTcpRepeat(CCmdUI* pCmdUI);
	afx_msg void OnUpdateSend(CCmdUI* pCmdUI);
	afx_msg void OnUpdateTcpclose(CCmdUI* pCmdUI);
	afx_msg void OnUpdateFileOpen(CCmdUI* pCmdUI);
	afx_msg void OnUpdateCputick(CCmdUI* pCmdUI);
	afx_msg void OnUpdateMenuFinite(CCmdUI* pCmdUI);
	afx_msg void OnMenuConfig();
	afx_msg void OnUpdateUdprecv(CCmdUI* pCmdUI);
	afx_msg void OnUpdateRecv(CCmdUI* pCmdUI);
	afx_msg void OnRecv();
	afx_msg void OnCloseWinsock2();
	afx_msg void OnSelchangeSpeedCombo();
	afx_msg void OnUdprecv();
	afx_msg void OnUdpclose();
	DECLARE_EVENTSINK_MAP()
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	CHAR m_strLogFile[512];
	FILE* m_hLogFile;
	void OnMenuRepeat();
	void OnMenuRepeat1() ;
	void GetPeerInfo();
};

#ifndef _DEBUG  // debug version in AX1View.cpp
inline CAX1Doc* CAX1View::GetDocument()
   { return (CAX1Doc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_AX1VIEW_H__A699C6ED_FC2D_11D3_A689_005004C3B715__INCLUDED_)
