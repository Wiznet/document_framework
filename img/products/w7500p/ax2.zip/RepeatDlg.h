#if !defined(AFX_REPEATDLG_H__558FCA1E_EB89_4CC1_BCB8_7DEB7B39339B__INCLUDED_)
#define AFX_REPEATDLG_H__558FCA1E_EB89_4CC1_BCB8_7DEB7B39339B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// RepeatDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CRepeatDlg dialog

class CRepeatDlg : public CDialog
{
// Construction
public:
	CRepeatDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CRepeatDlg)
	enum { IDD = IDD_DLGREPEAT };
	UINT	m_nTestCnt;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRepeatDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CRepeatDlg)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_REPEATDLG_H__558FCA1E_EB89_4CC1_BCB8_7DEB7B39339B__INCLUDED_)
