#if !defined(AFX_DLGSEND_H__16A4C5A4_EDE4_11D3_A6C7_005004BFA35B__INCLUDED_)
#define AFX_DLGSEND_H__16A4C5A4_EDE4_11D3_A6C7_005004BFA35B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgSend.h : header file
//
class CAX1View;

/////////////////////////////////////////////////////////////////////////////
// CDlgSend dialog

class CDlgSend : public CDialog
{
// Construction
public:
	BOOL m_bIsSend;
	CAX1View* m_pView;
//	CDlgSend(CWnd* pParent = NULL);   // standard constructor
	CDlgSend(CWnd* pParent = NULL,BOOL IsTCP=FALSE, BOOL IsSend=FALSE);

// Dialog Data
	//{{AFX_DATA(CDlgSend)
	enum { IDD = IDD_DLGSEND };
	CComboBox	m_ctrlFormat;
	CStatic	m_PeerPortStatic;
	CEdit	m_PeerPortEdit;
	UINT	m_iCnt;
	BYTE	m_cVal;
	BOOL    m_bIsTCP;
	CString	m_RemoteIP;
	UINT	m_nPeerPort;
	int		m_nFormat;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgSend)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDlgSend)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	afx_msg void OnSelchangeFomatCombo();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGSEND_H__16A4C5A4_EDE4_11D3_A6C7_005004BFA35B__INCLUDED_)
