// PortDlg.cpp : implementation file
//

#include "stdafx.h"
#include "AX1.h"
#include "PortDlg.h"

#include "AX1Doc.h"
#include "AX1View.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPortDlg dialog


CPortDlg::CPortDlg(CWnd* pParent /*=NULL*/,BOOL IsTCP)
	: CDialog(CPortDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CPortDlg)
	m_bTCP= IsTCP;
	//}}AFX_DATA_INIT
	m_Port = 0;
	if(m_bTCP)	m_Port = 3000;
	m_pView = (CAX1View*) pParent;

}


void CPortDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPortDlg)
	DDX_Text(pDX, IDC_EDIT1, m_Port);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPortDlg, CDialog)
	//{{AFX_MSG_MAP(CPortDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPortDlg message handlers

BOOL CPortDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();

	if(m_bTCP)
	{
		SetWindowText("TCP : Listen Port Number Set");
		m_Port = m_pView->m_pConfigDlg->m_nListenPort;
	}
	else
	{
		SetWindowText("UDP : Source Port Number Set");	
		m_Port = m_pView->m_pConfigDlg->m_nLocalPort;
	}

	// TODO: Add extra initialization here

	UpdateData(FALSE);
	if(!m_pView->m_pConfigDlg->m_bPromptDlg) OnOK();
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
