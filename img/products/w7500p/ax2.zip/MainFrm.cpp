// MainFrm.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "AX1.h"

#include "MainFrm.h"
#include "AX1Doc.h"
#include "AX1View.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNCREATE(CMainFrame, CFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_CREATE()
	ON_WM_CLOSE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
	ID_INVALID_PANE,
	ID_LOSS_PANE,
};

static enum indicator_pos
{
	INDICATOR_SEPARATOR,
	INDICATOR_INVALID_PANE,
	INDICATOR_LOSS_PANE,
};



/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
	// TODO: add member initialization code here
}

CMainFrame::~CMainFrame()
{
	TRACE("MAIN FRAME DESTROY\r\n");
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	if (!m_wndToolBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP
		| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC) ||
		!m_wndToolBar.LoadToolBar(IDR_MAINFRAME))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}

	if (!m_wndStatusBar.Create(this) || !m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)))
	{
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}

	CString strTemp;
	int cxWidth =0;
	UINT uiID = 0;
	UINT uiStyle = 0;

//	m_wndStatusBar.GetPaneInfo(INDICATOR_SEPARATOR, uiID, uiStyle , cxWidth);
	strTemp.LoadString(IDM_UDPRECV);
	cxWidth = CalculateWidthForText(strTemp);
	m_wndStatusBar.SetPaneInfo(INDICATOR_SEPARATOR, uiID, uiStyle,  cxWidth);

	// TODO: Delete these three lines if you don't want the toolbar to
	//  be dockable
	m_wndToolBar.EnableDocking(CBRS_ALIGN_ANY);
	EnableDocking(CBRS_ALIGN_ANY);
	DockControlBar(&m_wndToolBar);
	SetInvalidCnt(0);
	SetUDPLossRate(0);

	return 0;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if( !CFrameWnd::PreCreateWindow(cs) )
		return FALSE;
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CFrameWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers



int CMainFrame::CalculateWidthForText(CString strText)
{
	// Adjust the width of the status bar pane to ensure the text is visible
	int			nI = 0;
	CString		str;
	CSize		sz;
	TEXTMETRIC	tm;
	int			dx=0;
	CDC*		pDC = GetDC();
	CFont*		pFont = GetFont();

	// Select the listbox font, save the old font
	CFont* pOldFont = pDC->SelectObject(pFont);

	// Get the text metrics for avg char width
	pDC->GetTextMetrics(&tm);

	sz = pDC->GetTextExtent(strText);

	// Add the avg width to prevent clipping
	sz.cx += tm.tmAveCharWidth;

	dx = max(sz.cx, dx);

	// Select the old font back into the DC
	pDC->SelectObject(pOldFont);

	ReleaseDC(pDC);

	return dx;
}

void CMainFrame::SetInvalidCnt(UINT cnt)
{
	CString str;
	str.Format("Invalid : %d",cnt);
	m_wndStatusBar.SetPaneText(1,str);
}

void CMainFrame::SetUDPLossRate(float rate)
{
	CString str;
	str.Format("Loss Rate : %3.3f%%",rate);
	m_wndStatusBar.SetPaneText(2,str);
}

void CMainFrame::OnClose() 
{
	// TODO: Add your message handler code here and/or call default
	CAX1View* pView = (CAX1View*)GetActiveView();
	if(pView)
	{
		if(pView->m_bUDP && pView->m_bAlive && ((pView->m_nTestMode==0 && pView->m_bActive)|| pView->m_nTestMode==1))
		{
			AfxMessageBox("To Terminate AX2 program, Please STOP UDP sending...");
			return;
		}
	}
	CFrameWnd::OnClose();
}
