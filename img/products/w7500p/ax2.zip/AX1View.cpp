// AX1View.cpp : implementation of the CAX1View class
//

#include "stdafx.h"
#include <comdef.h>
#include "AX1.h"
#include <stdlib.h>

#include "MainFrm.h"
#include "AX1Doc.h"
#include "AX1View.h"

#include <afxmt.h>
#include "portdlg.h"
#include "DlgIPPort.h"
#include "DlgSend.h"
#include "RepeatDlg.h"
#include "ConfigDlg.h"
#include "TestModeDlg.h"

#include <winsock2.h>


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define DIVIDE_UNIT	1


typedef struct __UDPTHREADPARM
{
	CAX1View* pView;
	VARIANT*  pVar;
}UDPTHREADPARM;

CWinThread * gblThread = NULL;
UDPTHREADPARM* gblParam = NULL;


//	AfxBeginThread(GetSystemClock, this, THREAD_PRIORITY_TIME_CRITICAL);
UINT SendUDPThread(LPVOID lp)
{
	UDPTHREADPARM* pParm = (UDPTHREADPARM*) lp;
	gblParam = pParm;
	pParm->pView->SendUDPData(pParm->pVar);
	delete pParm;
	gblThread = NULL;
	gblParam = NULL;
	return 1;
}


/*
unsigned __int64 snapshot_rdtsc()
{
    static unsigned __int64 tick;
   static unsigned __int32 lo, hi;

	_asm push eax;
	_asm push edx;
    _asm _emit 0x0f
    _asm _emit 0x31
    _asm mov lo, eax
    _asm mov hi, edx

    tick = hi;
    tick <<= 32;
    tick |= lo;

	_asm pop edx;
	_asm pop eax;

    return tick;
}
*/
/*
UINT GetSystemClock(LPVOID lp)
{
	CAX1View* pView = (CAX1View*) lp;
	pView->m_bTicking = TRUE;
	pView->m_starttick = snapshot_rdtsc();
	Sleep(5000);
	pView->m_endtick = snapshot_rdtsc();
	pView->m_freq = (pView->m_endtick - pView->m_starttick) / 5;
	pView->m_unitFreq = (double)(__int64)((pView->m_endtick - pView->m_starttick)/(5*DIVIDE_UNIT));
	pView->m_bTicking = FALSE;
	TRACE("m_freq=%I64u, m_unitFreq=%6.3fHz/10ns\r\n",pView->m_freq,pView->m_unitFreq);
	return 1;
}
*/

unsigned __int64 snapshot_rdtsc()
{
	LARGE_INTEGER	 lpCount;
	QueryPerformanceCounter(&lpCount);
	return lpCount.QuadPart;
}


/////////////////////////////////////////////////////////////////////////////
// CAX1View

IMPLEMENT_DYNCREATE(CAX1View, CFormView)

BEGIN_MESSAGE_MAP(CAX1View, CFormView)
	//{{AFX_MSG_MAP(CAX1View)
	ON_COMMAND(ID_MENU_STARTSERVER, OnMenuStartserver)
	ON_COMMAND(ID_FILE_OPEN, OnFileOpen)
	ON_COMMAND(ID_MENU_CONNECT, OnMenuConnect)
	ON_COMMAND(ID_MENU_INFINITE, OnMenuInfinite)
	ON_COMMAND(ID_MENU_FINITE, OnMenuFinite)
	ON_COMMAND(IDM_UDPOPEN, OnUdpopen)
	ON_COMMAND(IDM_UDPSEND, OnUdpsend)
	ON_COMMAND(IDM_CPUTICK, OnCputick)
	ON_WM_TIMER()
	ON_COMMAND(IDM_TCPCLOSE, OnTcpclose)
	ON_WM_DESTROY()
	ON_COMMAND(ID_MENU_SEND2,OnMenuSend2)
	ON_COMMAND(IDM_SEND,OnSend)
	ON_COMMAND(ID_UDP_SEND,OnUdpFileSend)
	ON_COMMAND(IDC_MENU_UDP_REPEAT, OnMenuUdpRepeat)
	ON_COMMAND(ID_MENU_TCP_REPEAT, OnMenuTcpRepeat)
	ON_UPDATE_COMMAND_UI(IDC_MENU_UDP_REPEAT, OnUpdateMenuUdpRepeat)
	ON_UPDATE_COMMAND_UI(IDM_UDPSEND, OnUpdateUdpsend)
	ON_UPDATE_COMMAND_UI(IDM_UDPCLOSE, OnUpdateUdpclose)
	ON_UPDATE_COMMAND_UI(IDM_UDPOPEN, OnUpdateUdpopen)
	ON_UPDATE_COMMAND_UI(ID_UDP_SEND, OnUpdateUdpSend)
	ON_UPDATE_COMMAND_UI(ID_MENU_INFINITE, OnUpdateMenuInfinite)
	ON_UPDATE_COMMAND_UI(ID_MENU_CONNECT, OnUpdateMenuConnect)
	ON_UPDATE_COMMAND_UI(ID_MENU_SEND2, OnUpdateMenuSend2)
	ON_UPDATE_COMMAND_UI(ID_MENU_STARTSERVER, OnUpdateMenuStartserver)
	ON_UPDATE_COMMAND_UI(ID_MENU_TCP_REPEAT, OnUpdateMenuTcpRepeat)
	ON_UPDATE_COMMAND_UI(IDM_SEND, OnUpdateSend)
	ON_UPDATE_COMMAND_UI(IDM_TCPCLOSE, OnUpdateTcpclose)
	ON_UPDATE_COMMAND_UI(ID_FILE_OPEN, OnUpdateFileOpen)
	ON_UPDATE_COMMAND_UI(IDM_CPUTICK, OnUpdateCputick)
	ON_UPDATE_COMMAND_UI(ID_MENU_FINITE, OnUpdateMenuFinite)
	ON_COMMAND(ID_MENU_CONFIG, OnMenuConfig)
	ON_UPDATE_COMMAND_UI(IDM_UDPRECV, OnUpdateUdprecv)
	ON_UPDATE_COMMAND_UI(IDM_RECV, OnUpdateRecv)
	ON_COMMAND(IDM_RECV, OnRecv)
	ON_CBN_SELCHANGE(IDC_SPEED_COMBO, OnSelchangeSpeedCombo)
	ON_COMMAND(IDM_UDPRECV, OnUdprecv)
	ON_COMMAND(IDM_UDPCLOSE, OnUdpclose)
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CFormView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CFormView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CFormView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAX1View construction/destruction

CAX1View::CAX1View()
	: CFormView(CAX1View::IDD)
{
	//{{AFX_DATA_INIT(CAX1View)
	m_strRepeatCnt = _T("0");
	m_strRSpeed = _T("0");
	m_strRSec = _T("0");
	m_strRTSec = _T("0");
	m_strRTSpeed = _T("0");
	m_strSSec = _T("0");
	m_strSSpeed = _T("0");
	m_strData = _T("No Data");
	m_strStatus = _T("CLOSED");
	m_strTestMode = _T("-");
	//}}AFX_DATA_INIT
	// TODO: add construction code here
	
	m_bUserTest = FALSE;
	m_nUserDataSize = 0;
	m_nUserSentSize = 0;
	m_FirstRecv = TRUE;
	m_bFileOpen = FALSE;
	m_nTestCnt = 0;
	m_bInfinite = FALSE;
	m_bAlive = FALSE;

	m_iCnt = 1;
	m_secTX = 0;
	m_secRX = 0;
	m_secRTT = 0;

	m_nUDPTimerWait = 0;
	m_strUDPLoss = "";
	m_fUDPLossRate = 0;
	m_nUDPLossSize = 0;
	
	m_nTotalInvalidCnt = 0;
	m_nInvalidCnt = 0;


	m_pProgDlg = NULL;
	m_bFileOpen = FALSE;
	m_bConnect = FALSE;
	m_bUDPPeer = FALSE;
	m_bTCP = FALSE;
	m_bListen = FALSE;
	if(m_hUserDataBuf)	GlobalFree(m_hUserDataBuf);//GlobalUnlock(m_hDataBuf);
	if(m_hFileBuf)	GlobalFree(m_hFileBuf);//GlobalUnlock(m_hDataBuf);
	m_hUserDataBuf = NULL;
	m_nFileSize = 0;
	m_hFileBuf = NULL;

	m_strCompFileName = _T("");
	m_strCompPathName = _T("");
	
	m_bUDP = FALSE;
	m_pConfigDlg = NULL;

	m_hLogFile = NULL;
}

CAX1View::~CAX1View()
{
	TRACE("AX1 DESTROY\r\n");
}

void CAX1View::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAX1View)
	DDX_Control(pDX, IDC_SPEED_COMBO, m_ctrlSpeed);
	DDX_Control(pDX, IDC_WINSOCK3, m_ctrlUDPSock);
	DDX_Control(pDX, IDC_WINSOCK2, m_clntSocket);
	DDX_Control(pDX, IDC_WINSOCK1, m_srvSocket);
	DDX_Text(pDX, IDC_CNT_STATIC, m_strRepeatCnt);
	DDX_Text(pDX, IDC_RSPEED_STATIC, m_strRSpeed);
	DDX_Text(pDX, IDC_RSEC_STATIC, m_strRSec);
	DDX_Text(pDX, IDC_RTSEC_STATIC, m_strRTSec);
	DDX_Text(pDX, IDC_RTSPEED_STATIC, m_strRTSpeed);
	DDX_Text(pDX, IDC_SSEC_STATIC, m_strSSec);
	DDX_Text(pDX, IDC_SSPEED_STATIC, m_strSSpeed);
	DDX_Text(pDX, IDC_DATA_STATIC, m_strData);
	DDX_Text(pDX, IDC_STATUS_STATIC, m_strStatus);
	DDX_Text(pDX, IDC_TESTMODE_STATIC, m_strTestMode);
	//}}AFX_DATA_MAP
	DDX_Control(pDX, IDC_EDIT1, m_Edit);
//	DDX_Control(pDX, IDC_PROGRESS1, m_Progress);
}

BOOL CAX1View::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CFormView::PreCreateWindow(cs);
}

void CAX1View::OnInitialUpdate()
{
	CFormView::OnInitialUpdate();
	GetParentFrame()->RecalcLayout();
	ResizeParentToFit();

	LARGE_INTEGER lpFreq;
	QueryPerformanceFrequency(&lpFreq);
	m_unitFreq = (lpFreq.QuadPart) / (double)DIVIDE_UNIT;


	m_NormFont.CreateFont( 15, 0, 0, 0, FW_NORMAL, 0, 0, 0, ANSI_CHARSET, OUT_DEFAULT_PRECIS,
							CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_SWISS,_T("Verdana") ) ;

	m_Edit.LimitText();
	m_Edit.SetFont( &m_NormFont, FALSE );


	m_Edit.SetWindowText("");


	m_ctrlSpeed.SetCurSel(0);

	OnSelchangeSpeedCombo();


	m_SStartTick  = 0;
	m_SEndTick = 0 ;
	m_RStartTick = 0;
	m_REndTick = 0;
	m_pProgDlg = new CProgDlg;
	m_pProgDlg->Create(IDD_PROGRESS,this);

	m_pConfigDlg = new CConfigDlg;
	m_pConfigDlg->Create(IDD_DLGCFG,this);
	m_pConfigDlg->m_pView = this;

	CString strConf;
	FILE* conffile;
	conffile = fopen(".\\AX2Conf.conf", "r");
	if(conffile)
	{
		char confname[256];
		memset(confname,0,sizeof(confname));
		int filesize = fread(confname,sizeof(char),256,conffile);//fscanf(conffile,"%s",confname);
		fclose(conffile);
		if(!strcmp(confname,"\"\""))
		{
			m_pConfigDlg->OnDefaultBut();
			m_strConfFileName = "Default";
			m_nFormat = 1;
		}
		else 
		{
			m_pConfigDlg->LoadConfigFromFile(confname);
			m_strConfFileName.Format("%s",strrchr(confname,'\\')+1);
			m_nFormat = m_pConfigDlg->m_ctrlDataFormat.GetCurSel();
		}
	}
	else
	{
		m_pConfigDlg->OnDefaultBut();
		m_strConfFileName = "Default";
	}
	m_secTick = 1/m_unitFreq;

	CHAR* pName=m_pConfigDlg->m_strLogFileName.GetBuffer(256);
	CHAR* pExt=strrchr(pName,'.');
	*pExt = 0;
	CTime CurTime = CTime::GetCurrentTime();
	CString strtime = CurTime.Format("%c");
	strtime.Replace("/", "-");
	strtime.Replace(":", " ");
	sprintf(m_strLogFile,"%s(%s).%s",pName,strtime.GetBuffer(256),pExt+1);
	
	m_hLogFile = fopen(m_strLogFile,"w");
	if(!m_hLogFile)
		AfxMessageBox("Can't create the log file");

#if 0	
	FILE* tfile;
	tfile = fopen("C:\\Tog.bin","wb+");
	UINT i = 0;
	UCHAR start=0;
	UCHAR cur = 0;
	// for iperf
	#if 0
	fwrite("\0",1,1,tfile);
	fwrite("\0",1,1,tfile);
	fwrite("\0",1,1,tfile);
	fwrite("\0",1,1,tfile);
	fwrite("\0",1,1,tfile);
	fwrite("\0",1,1,tfile);
	fwrite("\0",1,1,tfile);
	fwrite("\x01",1,1,tfile);
	fwrite("\0",1,1,tfile);
	fwrite("\0",1,1,tfile);
	fwrite("\x13",1,1,tfile);
	fwrite("\x88",1,1,tfile);
	fwrite("\0",1,1,tfile);
	fwrite("\0",1,1,tfile);
	fwrite("\0",1,1,tfile);
	fwrite("\0",1,1,tfile);
	fwrite("\0",1,1,tfile);
	fwrite("\0",1,1,tfile);
	fwrite("\0",1,1,tfile);
	fwrite("\0",1,1,tfile);
	fwrite("\0",1,1,tfile);
	fwrite("\0",1,1,tfile);
	fwrite("\xC8",1,1,tfile);		// 50K
	fwrite("\00",1,1,tfile);
	#endif
	cur = 0xAA;
	for(i = 0 ; i < 1024*10/*35401728*/; i++)
	{
/*		if(!(i % 1024))
		{
			fwrite(&start,1,1,tfile);
			start++;
		}
		else*/
		{
			fwrite(&cur,1,1,tfile);
		}
		cur = ~cur;
	}
	fclose(tfile);
#endif

}

/////////////////////////////////////////////////////////////////////////////
// CAX1View printing

BOOL CAX1View::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CAX1View::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CAX1View::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

void CAX1View::OnPrint(CDC* pDC, CPrintInfo* /*pInfo*/)
{
	// TODO: add customized printing code here
}

/////////////////////////////////////////////////////////////////////////////
// CAX1View diagnostics

#ifdef _DEBUG
void CAX1View::AssertValid() const
{
	CFormView::AssertValid();
}

void CAX1View::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}

CAX1Doc* CAX1View::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CAX1Doc)));
	return (CAX1Doc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CAX1View message handlers

BEGIN_EVENTSINK_MAP(CAX1View, CFormView)
    //{{AFX_EVENTSINK_MAP(CAX1View)
	ON_EVENT(CAX1View, IDC_WINSOCK1, 2 /* ConnectionRequest */, OnConnectionRequestWinsock1, VTS_I4)
	ON_EVENT(CAX1View, IDC_WINSOCK2, 0 /* DataArrival */, OnDataArrivalWinsock2, VTS_I4)
	ON_EVENT(CAX1View, IDC_WINSOCK2, 4 /* SendComplete */, OnSendCompleteWinsock2, VTS_NONE)
	ON_EVENT(CAX1View, IDC_WINSOCK2, 3 /* SendProgress */, OnSendProgressWinsock2, VTS_I4 VTS_I4)
	ON_EVENT(CAX1View, IDC_WINSOCK2, 6 /* Error */, OnErrorWinsock2, VTS_I2 VTS_PBSTR VTS_I4 VTS_BSTR VTS_BSTR VTS_I4 VTS_PBOOL)
	ON_EVENT(CAX1View, IDC_WINSOCK2, 1 /* Connect */, OnConnectWinsock2, VTS_NONE)
	ON_EVENT(CAX1View, IDC_WINSOCK3, 0 /* DataArrival */, OnDataArrivalWinsock3, VTS_I4)
	ON_EVENT(CAX1View, IDC_WINSOCK3, 6 /* Error */, OnErrorWinsock3, VTS_I2 VTS_PBSTR VTS_I4 VTS_BSTR VTS_BSTR VTS_I4 VTS_PBOOL)
	ON_EVENT(CAX1View, IDC_WINSOCK2, 5 /* Close */, OnCloseWinsock2, VTS_NONE)
	//}}AFX_EVENTSINK_MAP
END_EVENTSINK_MAP()

void CAX1View::OnConnectionRequestWinsock1(long requestID) 
{
	// TODO: Add your control notification handler code here
//	OnUdpclose();
	m_clntSocket.SetLocalPort(0);
	m_clntSocket.Accept(requestID);

	AfxMessageBox(_T("Connected"));

	SOCKET s = (SOCKET)(m_clntSocket.GetSocketHandle());
	BOOL bErr = TRUE;
	UINT BufSize = m_pConfigDlg->m_nRBuff*1024;
	if(!setsockopt(s,IPPROTO_TCP,TCP_NODELAY,(char*)&m_pConfigDlg->m_bNoDelayAck,sizeof(m_pConfigDlg->m_bNoDelayAck)))
	{
		if(!setsockopt(s,SOL_SOCKET,SO_RCVBUF,(char*)&BufSize,sizeof(BufSize)))
		{
			BufSize = m_pConfigDlg->m_nSBuff*1024;
			if(!setsockopt(s,SOL_SOCKET,SO_SNDBUF,(char*)&BufSize,sizeof(BufSize)))
				bErr = FALSE;
		}
	}
	if(bErr)
	{
		AfxMessageBox("TCP : Fail to set SOCKET options");
		if(m_pConfigDlg->m_bLogEnable && m_pConfigDlg->m_bLogOnErr && m_hLogFile)
			fprintf(m_hLogFile,"TCP : Fail to set SOCKET options\r\n");
	}

	if(m_nTestMode == 2 ||  (m_nTestMode == 0 && !m_bActive))
	{
		if(!(m_bFileOpen || m_bUserTest))
		{
			if(!m_pConfigDlg->m_nCompMode && !m_bFileOpen)
			{
				OnMenuSend2();
			}
			else if(m_pConfigDlg->m_nCompMode && !m_bUserTest)
			{
				OnRecv();
			}
		}
		else if(m_bFileOpen)
		{
			OnMenuSend2();
		}
		else if(m_bUserTest)
		{
			m_DataBinary.m_hData = m_hUserDataBuf;
			m_DataBinary.m_dwDataLength = m_nUserDataSize;
			m_DataVariant = m_DataBinary;
			m_FirstRecv = TRUE;
			m_nUserRecvSize = 0;
			m_iCnt = 1;
			m_nTotalInvalidCnt = 0;
			m_nInvalidCnt = 0;

			m_secTX = m_secRX = m_secRTT = 0;
			UCHAR* lpData = (UCHAR*)GlobalLock(m_hUserDataBuf);
			GlobalUnlock(lpData);
 			CString str;

			str.Format("[TCP : READY TO RECEIVE DATA : 0x%02X~0x%02X (%d Bytes)]", lpData[0],lpData[m_nUserDataSize-1],m_nUserDataSize);
 			Log(str);
			Log("");
			m_strData.Format("DATA : %s(0x%02X~0x%02X),  %d Bytes", 
				(m_nFormat == 0) ? "NONE" : (m_nFormat==1) ? "SEQ" : "TOG", lpData[0],lpData[m_nUserDataSize-1], m_nUserDataSize);
			OnSelchangeSpeedCombo();
			UpdateData(FALSE);

		}
	}
	m_bTCP = TRUE;
	m_bConnect = TRUE;
	m_nUDPLossSize = 0;
	m_fUDPLossRate = 0;

	m_strStatus = "CONNECTED S";
	UpdateData(FALSE);
}

void CAX1View::OnMenuStartserver() 
{
	// TODO: Add your command handler code here
	CPortDlg dlg(this,TRUE);
	
	if (dlg.DoModal() == IDOK) 
	{
		CTestModeDlg testdlg;
		testdlg.m_pView = this;
		if(testdlg.DoModal() == IDOK)
		{
			m_srvSocket.SetLocalPort(dlg.m_Port);
			m_nTestMode = testdlg.m_nTestMode;
			m_bActive = testdlg.m_bActive;
			m_bTCP = TRUE;
			m_bListen = TRUE;
//			OnUdpclose();
			m_srvSocket.Listen();
			m_strStatus.Format("%s[%d]","LISTEN",dlg.m_Port);
			m_strTestMode.Format("%s",(m_nTestMode==2) ? "R.O" : (m_nTestMode==1) ? "S.O" : (m_bActive) ? "LBA" : "LBP");
			m_nTotalInvalidCnt = 0;
			m_nInvalidCnt = 0;
			UpdateData(FALSE);
		}
	}
}


void CAX1View::OnDataArrivalWinsock2(long bytesTotal) 
{
	// TODO: Add your control notification handler code here
	VARIANT type;
	VARIANT maxLen;
	CString str;

	double seconds;
	double Mbps;
	HGLOBAL tDataBuf;

	COleVariant data;
	data.Clear();
	type.vt = VT_I4;
	type.lVal = VT_UI1|VT_ARRAY;
	maxLen.vt = VT_I4;
	maxLen.lVal = bytesTotal;
	UCHAR * pDest=0;
	UCHAR * pData=0;

	try
	{
		if(m_nTestMode == 1) 
		{
			OnTcpclose();
			str = "[TCP : ERROR - Receive a undefined data from the peer!!!]"; /*- Ingnored]"; */
			Log(str);
			/*m_clntSocket.GetData(&data, type, maxLen);*/
			return;
		}
		tDataBuf = (m_bUserTest) ? m_hUserDataBuf : m_hFileBuf;

		pData = (UCHAR*)GlobalLock(tDataBuf);
		if(!pData) 
		{
			OnTcpclose();
			str = _T("[TCP : ERROR - Not Ready to the file to be received]");
			Log(str);
			return;
		}

		TRACE("START-\r\nbytesTotal=%d\r\n",bytesTotal);
		if(m_FirstRecv)
		{
			m_RStartTick = snapshot_rdtsc();
			m_nUserRecvSize = 0;
			m_nInvalidCnt = 0;
			if(m_bUserTest)
			{
				str.Format("[%d] [TCP : RECEIVE START]", m_iCnt);
				Log(str);
			}
			if((m_nTestMode==0 && !m_bActive) || m_nTestMode==2)
			{
				m_bAlive = TRUE;
				if(!m_bUserTest && m_pConfigDlg->m_bOnLogMsg)
				{
					m_pProgDlg->m_Progress.SetPos(0);
					str.Format(" %s [%d] : TCP Receiving...",m_clntSocket.GetRemoteHostIP(),m_clntSocket.GetRemotePort());
					m_pProgDlg->SetWindowText(str);
 					m_pProgDlg->ShowWindow(SW_SHOW);
				}
			}
		}
		m_clntSocket.GetData(&data, type, maxLen);
		m_REndTick = snapshot_rdtsc();

		if(m_nTestMode == 0 && !m_bActive)
		{
			if(m_FirstRecv) 
			{
				if(m_bUserTest)
				{
					str.Format("[%d] [TCP : SEND START]",m_iCnt);
					Log(str);
				}
				m_nUserSentSize = 0;
				m_SStartTick = snapshot_rdtsc();
			}
			m_clntSocket.SendData(data);
		}
	}
	catch(CException * e)
	{
		OnTcpclose();
		e->ReportError();
		e->Delete();
		return;
	}

	if(m_bUserTest)
	{
		if(m_pConfigDlg->m_bOnLogMsg)
		{
			str.Format("       {Received : %d, Total Received : %d}",bytesTotal,m_nUserRecvSize+bytesTotal);
			Log(str);
		}
	}
	else if(m_pConfigDlg->m_bOnLogMsg)
	{
		if((m_nTestMode==0 && !m_bActive) || m_nTestMode==2)
		{
			seconds = (__int64)(m_REndTick - m_RStartTick)/m_unitFreq;
			Mbps = (((m_nUserRecvSize+bytesTotal) * m_nBit)/seconds) / m_nSpeed ;
			str.Format("%.3f %s (%d Bytes)", Mbps, m_strSpeed, m_nUserRecvSize+bytesTotal);
			m_pProgDlg->m_Progress.SetPos((UINT)((unsigned __int64)100*(m_nUserRecvSize+bytesTotal)/m_nUserDataSize));
			m_pProgDlg->m_Speed.SetWindowText(str);
		}
	}

	pDest = (UCHAR*)data.parray->pvData;
	pData = pData + m_nUserRecvSize;

	if(m_pConfigDlg->m_bDataInvalid && m_nFormat>0)
	{
		if (memcmp(pDest,pData, bytesTotal) != 0) 
		{
			m_nInvalidCnt++;
			for(long i=0; i < bytesTotal; i++)
			{
				if(pDest[i] != pData[i])
				{
					str.Format("[%d-%d] DATA INVALID, At %d(0x%X) : %02X) != %02X]",
						m_iCnt,m_nInvalidCnt, m_nUserRecvSize+i,m_nUserRecvSize+i,pData[i],pDest[i]);
					Log(str);
				}
			}
			if(m_pConfigDlg->m_bErrorExit)
			{
				GlobalUnlock(tDataBuf);
				m_nTotalInvalidCnt += m_nInvalidCnt;
				OnSelchangeSpeedCombo();
				str.Format("[%d][UDP : CLOSED]",m_iCnt);
				Log(str);
				OnTcpclose();
				return;
			}
		}	
	}
	GlobalUnlock(tDataBuf);
	
	m_nUserRecvSize += bytesTotal;
	m_FirstRecv = FALSE;

	if(m_nUserRecvSize > m_nUserDataSize)
	{
		str.Format("[%d] [TCP : SIZE MISMATCHED - DataSize=%d, Received Size=%d]",m_iCnt,m_nUserDataSize,m_nUserRecvSize);
		Log(str);
	}

	if(m_nUserRecvSize >= m_nUserDataSize)
	{
		seconds =(__int64)(m_REndTick - m_RStartTick)/m_unitFreq;
		Mbps = (m_nUserRecvSize * m_nBit / seconds)/m_nSpeed;
		if(m_nTestMode !=1)
		{
			if(m_bUserTest)
				str.Format("[%d] [TCP : RECEIVE COMPLETED - %.3f %s (%d bytes, %.6f sec)]", m_iCnt,Mbps, m_strSpeed, m_nUserRecvSize, seconds);
			else 
				str.Format("[%d] RECV : %.3f %s (%d bytes, %.6f sec)",	m_iCnt, Mbps, m_strSpeed, m_nUserRecvSize, seconds);
			Log(str);
			if(m_iCnt == 1)	m_secRX = seconds;
			else m_secRX = (m_secRX + seconds)/2;
		}
		if(m_nTestMode==0 && m_bActive)
		{
			seconds = (__int64)(m_REndTick - m_SStartTick) / m_unitFreq;
			Mbps = (m_nUserRecvSize * m_nBit / seconds)/m_nSpeed;
			if(m_bUserTest)
				str.Format("[%d] [TCP : ROUND TRIP - %.3f %s (%d bytes, %.6f sec)", m_iCnt, Mbps, m_strSpeed, m_nUserRecvSize, seconds);
			else
				str.Format("[%d] ROUND TRIP : %.3f %s (%d bytes, %.6f sec)", m_iCnt, Mbps, m_strSpeed, m_nUserRecvSize, seconds);
			Log(str);
			if(m_iCnt == 1)	m_secRTT = seconds;
			else m_secRTT = (m_secRTT + seconds)/2;
		}
		if(m_nTestMode==2 || (m_nTestMode==0 && m_bActive))
		{
			Log("");
			m_bAlive = FALSE;
			m_nTotalInvalidCnt += m_nInvalidCnt;
			if(m_iCnt++ == 0) m_iCnt=1;
			OnSelchangeSpeedCombo();
		}
		m_nUserRecvSize = 0;
		m_FirstRecv = TRUE;
		if((m_nTestMode==0 && !m_bActive) || m_nTestMode==2)
		{
			m_pProgDlg->ShowWindow(SW_HIDE);
		}
		if (m_nTestMode==0 && m_bActive && (m_bInfinite || m_nTestCnt != 0))
		{
			SetTimer(REPEAT_TIMER,m_pConfigDlg->m_nRepeatTime,NULL);
		}
	}
}

void CAX1View::OnFileOpen() 
{
	CString str;
	CFileDialog Dlg(TRUE, NULL, m_pConfigDlg->m_strCompPathName, OFN_HIDEREADONLY, _T("All files(*.*)|*.*|Text Document(*.txt)|*.txt"), this);
	CFile file;
	CFileStatus fStatus;

	if(m_bFileOpen)
	{
		GlobalFree(m_hFileBuf);
		m_hFileBuf = NULL;
	}
	m_bFileOpen = FALSE;
	
	if(m_pConfigDlg->m_bPromptDlg)
	{
		if(Dlg.DoModal()== IDOK)
		{
			m_strCompFileName = Dlg.GetFileName();
			m_strCompPathName = Dlg.GetPathName();
		}
		else return;
	}
	else
	{
		m_strCompFileName = m_pConfigDlg->m_strCompFileName;
		m_strCompPathName = m_pConfigDlg->m_strCompPathName;
	}
	if(file.Open(m_strCompPathName, CFile::modeRead | CFile::typeBinary))
	{
		file.GetStatus(fStatus);

		m_nFileSize = fStatus.m_size;
		m_hFileBuf = GlobalAlloc(GHND, m_nFileSize);
		if(!m_hFileBuf) 
		{
			AfxMessageBox("Fail to allocate memory");
			file.Close();
			if(m_pConfigDlg->m_bLogEnable && m_pConfigDlg->m_bLogOnErr && m_hLogFile)
				fprintf(m_hLogFile,"Fail to allocate memory\r\n");
			m_bFileOpen = FALSE;
			return;
		}
		LPVOID lpData = GlobalLock(m_hFileBuf);
		file.Read(lpData, m_nFileSize);
		GlobalUnlock(m_hFileBuf);
		m_bFileOpen = TRUE;
		m_bUserTest = FALSE;
		file.Close();
		m_bFileOpen = TRUE;
	}
	else
	{
		str.Format("There is no file - %s",m_strCompPathName);
		if(m_pConfigDlg->m_bLogEnable && m_pConfigDlg->m_bLogOnErr && m_hLogFile) 
			fprintf(m_hLogFile, "%s\r\n" , str.GetBuffer(256));
		AfxMessageBox(str);
	}
}


void CAX1View::OnSendCompleteWinsock2() 
{
	if(m_nUserSentSize >= m_nUserDataSize)
		SendCompleted(TRUE);
}

void CAX1View::OnSendProgressWinsock2(long bytesSent, long bytesRemaining) 
{
	// TODO: Add your control notification handler code here

	CString str;
	double seconds;
	double Mbps; 


	m_SEndTick = snapshot_rdtsc();
	m_nUserSentSize += bytesSent;

	if(m_bUserTest)
	{
		if(m_pConfigDlg->m_bOnLogMsg)
		{
			if((m_nTestMode == 0 && m_bActive) || m_nTestMode==1)
				str.Format("       {Sent : %d, Remained : %d}",bytesSent,bytesRemaining);
			else if(m_nTestMode == 0 && !m_bActive)
				str.Format("       {Sent : %d, Remained : %d}",bytesSent,m_nUserDataSize - m_nUserSentSize);
			Log(str);
		}
	}
	else if(m_pConfigDlg->m_bOnLogMsg)
	{
		if((m_nTestMode == 0 && m_bActive) || m_nTestMode==1)
		{
			seconds = (__int64)(m_SEndTick - m_SStartTick)/m_unitFreq;
			Mbps = (m_nUserSentSize * m_nBit /seconds) / m_nSpeed;
			str.Format("%.3f %s (%d Bytes)", Mbps, m_strSpeed, m_nUserSentSize);
			m_pProgDlg->m_Progress.SetPos((UINT)((unsigned __int64)100*m_nUserSentSize/m_nUserDataSize));
			m_pProgDlg->m_Speed.SetWindowText(str);
		}
	}
}


void CAX1View::OnMenuConnect() 
{
	// TODO: Add your command handler code here
	CDlgIPPort dlg;
	dlg.m_bTCP=TRUE;
	dlg.m_pView = this;
	
	if (dlg.DoModal() == IDOK) 
	{
		CTestModeDlg testdlg;
		testdlg.m_pView = this;
		if(testdlg.DoModal() == IDOK)
		{
			m_nTestMode = testdlg.m_nTestMode;
			m_bActive = testdlg.m_bActive;

			VARIANT maxLen;
			maxLen.vt = VT_I4;
			maxLen.lVal = dlg.m_uPort;

			_bstr_t	str;
			str = dlg.m_strIP;
			_variant_t	data;
			data = str;

			m_clntSocket.Connect(data, maxLen);
			m_strStatus.Format("%s[%d]", "CONNECT",m_clntSocket.GetLocalPort());
			m_strTestMode.Format("%s",(m_nTestMode==2) ? "R.O" : (m_nTestMode==1) ? "S.O" : (m_bActive) ? "LBA" : "LBP");

			m_nTotalInvalidCnt = 0;
			m_nInvalidCnt = 0;
			UpdateData(FALSE);
		}
	}
}

void CAX1View::OnErrorWinsock2(short Number, BSTR FAR* Description, long Scode, LPCTSTR Source, LPCTSTR HelpFile, long HelpContext, BOOL FAR* CancelDisplay) 
{
	// TODO: Add your control notification handler code here
/*	CString err;
	err.Format("%s",Description);
	AfxMessageBox(err);*/

	LPVOID lpMsgBuf;
	FormatMessage( 
		FORMAT_MESSAGE_ALLOCATE_BUFFER | 
		FORMAT_MESSAGE_FROM_SYSTEM | 
		FORMAT_MESSAGE_IGNORE_INSERTS,
		NULL,
		Number,
		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), // Default language
		(LPTSTR) &lpMsgBuf,
		0,
		NULL 
	);
	// Process any inserts in lpMsgBuf.
	// ...
	// Display the string.
	AfxMessageBox((LPCTSTR)lpMsgBuf, MB_OK | MB_ICONINFORMATION );
	if(m_pConfigDlg->m_bLogEnable && m_pConfigDlg->m_bLogOnErr && m_hLogFile) 
		fprintf(m_hLogFile, "%s\r\n",lpMsgBuf);

	// Free the buffer.
	LocalFree( lpMsgBuf );

	OnTcpclose();
}


void CAX1View::OnMenuSend2() 
{
	CString strprog;

	if(!m_bFileOpen)
	{
		OnFileOpen();
	}
	if(!m_bFileOpen) return;

	m_bUserTest = FALSE;
 	m_nUserSentSize = 0;
 	m_nUserRecvSize = 0;
 	m_iCnt = 1;
	m_nTotalInvalidCnt = 0;
	m_nInvalidCnt = 0;

	m_secTX = m_secRX = m_secRTT = 0;
	m_fUDPLossRate = 0;
	m_nUDPLossSize = 0;

 	m_FirstRecv = TRUE;
	m_bInfinite = FALSE;

	OnSelchangeSpeedCombo();

 	m_Edit.SetWindowText("");
	strprog.Format("[TCP : READY TO FILE - %s %d Bytes]\r\n",m_strCompFileName, m_nFileSize);
	Log(strprog);
	m_strData.Format("FILE : %s,  %d Bytes", m_strCompFileName, m_nFileSize);
	UpdateData(FALSE);

	m_nUserDataSize = m_nFileSize;
	m_DataBinary.m_hData = m_hFileBuf;
	m_DataBinary.m_dwDataLength = m_nFileSize;
	m_DataVariant = m_DataBinary;

	if((m_nTestMode == 0 && m_bActive) || m_nTestMode == 1)
	{
		if(m_pConfigDlg->m_bOnLogMsg)
		{
 			m_pProgDlg->m_Progress.SetPos(0);
			strprog.Format(" %s [%d] : TCP Sending...",m_clntSocket.GetRemoteHostIP(),m_clntSocket.GetRemotePort());
			m_pProgDlg->SetWindowText(strprog);
 			m_pProgDlg->ShowWindow(SW_SHOW);
		}
		m_bAlive = TRUE;
		m_SStartTick = snapshot_rdtsc();
		m_clntSocket.SendData(m_DataVariant);
	}
}

void CAX1View::OnUdprecv() 
{
	// TODO: Add your command handler code here
	m_Edit.SetWindowText("");
	if(GenerateTestData(FALSE, FALSE))
	{
		m_DataBinary.m_hData = m_hUserDataBuf;
		m_DataBinary.m_dwDataLength = m_nUserDataSize;
		m_DataVariant = m_DataBinary;
		m_FirstRecv = TRUE;
		m_nUserRecvSize = 0;
		m_nUserSentSize = 0;
		m_iCnt = 1;
		m_nTotalInvalidCnt = 0;
		m_nInvalidCnt = 0;

		m_secTX = m_secRX = m_secRTT = 0;
		m_nUDPLossSize = 0;
		m_fUDPLossRate = 0;
		OnSelchangeSpeedCombo();
 	}	
}


void CAX1View::OnUdpFileSend() 
{
//	OnUdpclose();
//	if(m_bTCP) OnTcpclose();
	if(((m_nTestMode==0 && m_bActive) || m_nTestMode==1) && !m_bUDPPeer) 
	{
		GetPeerInfo();
		if(!m_bUDPPeer)	return;
		m_ctrlUDPSock.SetRemoteHost(m_UDPPeerIP);
		m_ctrlUDPSock.SetRemotePort(m_nUDPPeerPort);
	}
	if(!m_bFileOpen)
	{
		OnFileOpen();
	}
	if(!m_bFileOpen) return;

 	m_bUserTest = FALSE;
 	m_nUserSentSize = 0;
 	m_nUserRecvSize = 0;
	m_nUDPLossSize = 0;
	m_fUDPLossRate = 0;
 	m_iCnt = 1;
	m_nTotalInvalidCnt = 0;
	m_nInvalidCnt = 0;
	m_secTX = m_secRX = m_secRTT = 0;
	
	OnSelchangeSpeedCombo();
 	
	m_FirstRecv = TRUE;
	m_bInfinite = FALSE;

 	m_Edit.SetWindowText("");
	CString str;
	str.Format("[TCP : READY TO FILE - %s %d Bytes]\r\n",m_strCompFileName, m_nFileSize);
	Log(str);
	m_strData.Format("FILE : %s,  %d Bytes", m_strCompFileName, m_nFileSize);
	UpdateData(FALSE);


	m_nUserDataSize = m_nFileSize;
	m_DataBinary.m_hData = m_hFileBuf;
	m_DataBinary.m_dwDataLength = m_nFileSize;
	m_DataVariant = m_DataBinary;

	if((m_nTestMode==0 && m_bActive) || m_nTestMode==1)
	{
		UDPTHREADPARM* pParm = new UDPTHREADPARM;
		pParm->pVar = (VARIANT*)&m_DataVariant;
		pParm->pView = this;
		m_ctrlUDPSock.SetRemoteHost(m_UDPPeerIP);
		m_ctrlUDPSock.SetRemotePort(m_nUDPPeerPort);
		gblThread = AfxBeginThread(SendUDPThread, pParm, THREAD_PRIORITY_TIME_CRITICAL);
	}	
}

void CAX1View::OnMenuRepeat()
{
	if(m_bUserTest)
	{
		if(!m_hUserDataBuf)
		{
			if(m_bTCP)	OnSend();
			else if(m_bUDP) OnUdpsend();
		}
	}
	else
	{
		if(m_bUDP)
		{
			if(!m_bUDPPeer)	GetPeerInfo();
			if(!m_bUDPPeer)	return;
		}
		if(!m_bFileOpen)	OnFileOpen();
		if(!m_bFileOpen) return;
	}
	CRepeatDlg dlg;
	if(dlg.DoModal()==IDOK)
	{
		m_nTestCnt = dlg.m_nTestCnt-1;
		OnMenuRepeat1();
	}
}

void CAX1View::OnMenuRepeat1() 
{
	// TODO: Add your command handler code here
	CString str;
	if(m_bUserTest)
	{
		if(m_bTCP)
		{
			m_bAlive = TRUE;
			m_nUserSentSize = 0;
			m_SStartTick = snapshot_rdtsc();
 			m_clntSocket.SendData(m_DataVariant);
			str.Format("[%d] [TCP : SEND STARTED]",m_iCnt);
			Log(str);
		}
		else if(m_bUDP)
		{
			m_bAlive = TRUE;
			m_bUDPPeer = TRUE;
			m_nUserSentSize = 0;
			UDPTHREADPARM* pParm = new UDPTHREADPARM;
			pParm->pVar = (VARIANT*)&m_DataVariant;
			pParm->pView = this;
			m_ctrlUDPSock.SetRemoteHost(m_UDPPeerIP);
			m_ctrlUDPSock.SetRemotePort(m_nUDPPeerPort);
			gblThread = AfxBeginThread(SendUDPThread, pParm, THREAD_PRIORITY_TIME_CRITICAL);
		}
	}
	else
	{
		m_nUserSentSize = 0;
		m_nUserRecvSize = 0;
		m_strUDPLoss = "";
		m_nUDPLossSize = 0;
		m_FirstRecv = TRUE;
		if(m_pConfigDlg->m_bOnLogMsg)
		{
			m_pProgDlg->m_Progress.SetRange(0, 100);
			m_pProgDlg->m_Progress.SetPos(0);
			m_pProgDlg->ShowWindow(SW_SHOW);
		}
		m_bAlive = TRUE;

		m_SStartTick = snapshot_rdtsc();
		if(m_bTCP)	m_clntSocket.SendData(m_DataVariant);
		else if(m_bUDP)
		{
			UDPTHREADPARM* pParm = new UDPTHREADPARM;
			pParm->pVar = (VARIANT*)&m_DataVariant;
			pParm->pView = this;
			m_ctrlUDPSock.SetRemoteHost(m_UDPPeerIP);
			m_ctrlUDPSock.SetRemotePort(m_nUDPPeerPort);
			gblThread = AfxBeginThread(SendUDPThread, pParm, THREAD_PRIORITY_TIME_CRITICAL);
		}
	}
}

void CAX1View::OnMenuInfinite() 
{
	// TODO: Add your command handler code here
/*	if(m_bTCP)
	{
		if(!m_bConnect) 
		{
			AfxMessageBox("Not Connected");
			return;
		}
	}
	else
	{
		if(m_bUserTest && !m_bConnect)	OnUdpclose();
		if(!m_bUDPPeer) GetPeerInfo();
		if(!m_bUDPPeer)	return;
		m_bTCP = FALSE;
		m_ctrlUDPSock.SetRemoteHost(m_UDPPeerIP);
		m_ctrlUDPSock.SetRemotePort(m_nUDPPeerPort);
	}
	if(!m_bFileOpen)
	{
		OnFileOpen();
	}

	if(!m_bFileOpen) return;
	m_bInfinite = TRUE;
	OnMenuRepeat1();
*/
	if(m_bUserTest)
	{
		if(!m_hUserDataBuf)
		{
			if(m_bTCP)
			{
				if(GenerateTestData(m_bTCP, TRUE))
				{
					m_DataBinary.m_hData = m_hUserDataBuf;
					m_DataBinary.m_dwDataLength = m_nUserDataSize;
					m_DataVariant = m_DataBinary;
					m_nUserSentSize = 0;
					CString str;
					m_DataBinary.m_hData = m_hUserDataBuf;
					m_DataBinary.m_dwDataLength = m_nUserDataSize;
					m_DataVariant = m_DataBinary;
				}
				else return;
			}
			else if(m_bUDP)
			{
				if(GenerateTestData(m_bUDP, TRUE))
				{
					m_DataBinary.m_hData = m_hUserDataBuf;
					m_DataBinary.m_dwDataLength = m_nUserDataSize;
					m_DataVariant = m_DataBinary;
					m_nUserSentSize = 0;
					CString str;
					m_DataBinary.m_hData = m_hUserDataBuf;
					m_DataBinary.m_dwDataLength = m_nUserDataSize;
					m_DataVariant = m_DataBinary;
				}
				else return;
			}
		}
	}
	else
	{
		if(!m_bFileOpen)	OnFileOpen();
		if(!m_bFileOpen) return;
		if(m_bUDP)
		{
			if(!m_bUDPPeer)	GetPeerInfo();
			if(!m_bUDPPeer)	return;

			m_bTCP = FALSE;
			m_ctrlUDPSock.SetRemoteHost(m_UDPPeerIP);
			m_ctrlUDPSock.SetRemotePort(m_nUDPPeerPort);
		}
	}
	m_bInfinite = TRUE;
	OnMenuRepeat1();

}

void CAX1View::OnMenuFinite() 
{
	// TODO: Add your command handler code here
	m_bInfinite = FALSE;
	m_nTestCnt = 0;
}


void CAX1View::OnConnectWinsock2() 
{
//	OnUdpclose();
//	AfxMessageBox(_T("Connected"));	


	SOCKET s = (SOCKET) m_clntSocket.GetSocketHandle();

	UINT BufSize = m_pConfigDlg->m_nRBuff*1024;
	BOOL bErr = TRUE;
	if(!setsockopt(s,IPPROTO_TCP,TCP_NODELAY,(char*)&m_pConfigDlg->m_bNoDelayAck,sizeof(m_pConfigDlg->m_bNoDelayAck)))
	{
		if(!setsockopt(s,SOL_SOCKET,SO_RCVBUF,(char*)&BufSize,sizeof(BufSize)))
		{
			BufSize = m_pConfigDlg->m_nSBuff*1024;
			if(!setsockopt(s,SOL_SOCKET,SO_SNDBUF,(char*)&BufSize,sizeof(BufSize)))
				bErr = FALSE;
		}
	}
	if(bErr)
	{
		AfxMessageBox("TCP : Fail to set SOCKET options");
		if(m_pConfigDlg->m_bLogEnable && m_pConfigDlg->m_bLogOnErr && m_hLogFile)
			fprintf(m_hLogFile,"TCP : Fail to set SOCKET options\r\n");
	}

	if(m_nTestMode == 2 ||  (m_nTestMode == 0 && !m_bActive))
	{
		if(!(m_bFileOpen || m_bUserTest))
		{
			if(!m_pConfigDlg->m_nCompMode && !m_bFileOpen)
			{
				OnMenuSend2();
			}
			else if(m_pConfigDlg->m_nCompMode && !m_bUserTest)
			{
				OnRecv();
			}
		}
		else if(m_bFileOpen)
		{
			OnMenuSend2();
		}
		else if(m_bUserTest)
		{
			m_DataBinary.m_hData = m_hUserDataBuf;
			m_DataBinary.m_dwDataLength = m_nUserDataSize;
			m_DataVariant = m_DataBinary;
			m_FirstRecv = TRUE;
			m_nUserRecvSize = 0;
			m_iCnt = 1;
			m_secTX = m_secRX = m_secRTT = 0;
			m_nInvalidCnt = 0;
			m_nTotalInvalidCnt = 0;
			UCHAR* lpData = (UCHAR*)GlobalLock(m_hUserDataBuf);
			GlobalUnlock(lpData);
			
			OnSelchangeSpeedCombo();

			CString str;
			str.Format("[TCP : READY TO RECEIVE DATA : 0x%02X~0x%02X (%d Bytes)]", lpData[0],lpData[m_nUserDataSize-1],m_nUserDataSize);
 			Log(str);
			m_strData.Format("DATA : %s(0x%02X~0x%02X),  %d Bytes", 
				(m_nFormat == 0) ? "NONE" : (m_nFormat==1) ? "SEQ" : "TOG", lpData[0],lpData[m_nUserDataSize-1], m_nUserDataSize);
			UpdateData(FALSE);
		}
	}
	m_bConnect = TRUE;
	m_bTCP = TRUE;
	m_bUDP = FALSE;
	m_strStatus = "CONNECTED C";
	m_nUDPLossSize = 0;
	m_fUDPLossRate = 0;
	UpdateData(FALSE);
}


BOOL bUDPRecv = FALSE;
CString recvstrlog;


void CAX1View::OnDataArrivalWinsock3(long bytesTotal) 
{
	// TODO: Add your control notification handler code here
	VARIANT type;
	VARIANT maxLen;
	CString str, str1;

	double seconds;
	double Mbps;

	HGLOBAL tDataBuf;
	COleVariant data;
	type.vt = VT_I4;
	type.lVal = VT_UI1|VT_ARRAY;
	maxLen.vt = VT_I4;
	maxLen.lVal = bytesTotal;
	UCHAR * pDest=0;
	UCHAR * pData=0;
	UINT nUDPLossSize = 0;

	KillTimer(UDP_TIMER);

	tDataBuf = (m_bUserTest) ? m_hUserDataBuf : m_hFileBuf;

	pData = (UCHAR*)GlobalLock(tDataBuf);
	if(!pData) 
	{
		OnUdpclose();
		str.Format("[%d] [UDP : ERROR - Not Ready to DATA to be received]",m_iCnt);
		Log(str);
		return;
	}
	try
	{
		if(m_nTestMode == 1) 
		{
				m_ctrlUDPSock.GetData(&data, type, maxLen);
				str = "[UDP : ERROR - Receive a undefined data from the peer!!!]";
				Log(str);
				OnUdpclose();
				return;
		}

		if(m_FirstRecv)
		{
			m_RStartTick = snapshot_rdtsc();
			m_nUserRecvSize = 0;
			m_nUDPLossSize = 0;
			m_strUDPLoss = "";
			m_nUDPTimerWait = 0;
			m_nInvalidCnt = 0;

			if(m_bUserTest)
			{
				str.Format("[%d] [UDP : RECEIVE START]", m_iCnt);
				Log(str);
			}
			if((m_nTestMode==0 && !m_bActive) || m_nTestMode==2)
			{
				m_bAlive = TRUE;
				if(!m_bUserTest) 
				{
					m_pProgDlg->m_Progress.SetPos(0);
					if(m_pConfigDlg->m_bOnLogMsg)
 						m_pProgDlg->ShowWindow(SW_SHOW);
				}
			}
		}

		m_ctrlUDPSock.GetData(&data, type, maxLen);
		if(m_FirstRecv && ((m_nTestMode==0 && !m_bActive) || m_nTestMode==2))
		{
			str.Format(" %s [%d] : UDP Receiving...",m_ctrlUDPSock.GetRemoteHostIP(),m_ctrlUDPSock.GetRemotePort());
			m_pProgDlg->SetWindowText(str);
		}

//		TRACE("bytesTotal = %d, cElements=%d\r\n",bytesTotal, data.parray->rgsabound[0].cElements);

		bytesTotal =  data.parray->rgsabound[0].cElements;	
		if(m_FirstRecv) m_nUDPPeerPacketSize = bytesTotal;
		m_REndTick = snapshot_rdtsc();

		seconds = (__int64)(m_REndTick - m_RStartTick)/m_unitFreq;

		if(!m_FirstRecv && m_nUDPTimerWait == 0)
		{
			m_nUDPTimerWait = (UINT)(((seconds*1000) * m_nUserRecvSize)/(m_pConfigDlg->m_nUDPPacketSize)) + 1000;
			TRACE("m_nUDPTimerWait=%dms\r\n",m_nUDPTimerWait);
		}

		if(m_nTestMode == 0 && !m_bActive)
		{
			if(m_FirstRecv)
			{
				//if(m_bUserTest)
				//{
				//	str.Format("[%d] [UDP : SEND START]",m_iCnt);
				//	Log(str);
				//}
				m_nUserSentSize = 0;
				//m_SStartTick = snapshot_rdtsc();
			}
			SendUDPData(data);
		}
	}
	catch(CException * e)
	{
		OnUdpclose();
		e->ReportError();
		e->Delete();
		return;
	}

	if(m_bUserTest)
	{
		if(m_pConfigDlg->m_bOnLogMsg)
		{
			str.Format("       {Received : %d, Total Received : %d}",bytesTotal,m_nUserRecvSize+bytesTotal);
			Log(str);
		}
	}
	else if(m_pConfigDlg->m_bOnLogMsg)
	{
		if((m_nTestMode==0 && !m_bActive) || m_nTestMode==2)
		{
			//seconds = (__int64)(m_REndTick - m_RStartTick)/m_unitFreq;
			Mbps = (((m_nUserRecvSize+bytesTotal - m_nUDPLossSize) * m_nBit)/seconds) / m_nSpeed ;
			str.Format("%.3f %s\r\n(%d - %d = %d Bytes)", Mbps, m_strSpeed, m_nUserRecvSize+bytesTotal,m_nUDPLossSize, m_nUserRecvSize+bytesTotal - m_nUDPLossSize);
			m_pProgDlg->m_Progress.SetPos((UINT)((unsigned __int64)100*(m_nUserRecvSize+bytesTotal)/m_nUserDataSize));
			m_pProgDlg->m_Speed.SetWindowText(str);
		}
	}


	pDest = (UCHAR*)data.parray->pvData;
	pData = pData + m_nUserRecvSize;


	if(m_pConfigDlg->m_bDataInvalid && m_nFormat>0)
	{
		while(1)
		{
			if((m_nUserRecvSize + nUDPLossSize) >= m_nUserDataSize)
			{
				m_nInvalidCnt++;
				pData -= m_nUDPPeerPacketSize;
				for(long i=0; i < bytesTotal; i++)
				{
					if(pDest[i] != pData[i])
					{
						str.Format("[%d-%d] : DATA INVALID, At %d(0x%X) : %02X != %02X]",
							m_iCnt,m_nInvalidCnt, m_nUserRecvSize+i,m_nUserRecvSize+i,pData[i],pDest[i]);
						Log(str);
					}
				}
				if(m_pConfigDlg->m_bErrorExit)
				{
					str.Format("[%d][UDP : CLOSED]",m_iCnt);
					Log(str);
					OnUdpclose();
				}
				break;
			}
			else if (memcmp(pDest,pData, bytesTotal)== 0)
			{
				if(nUDPLossSize > 0)
				{
					str1.Format("       {At %d, %d bytes}\r\n", m_nUserRecvSize, nUDPLossSize);
					m_strUDPLoss += str1;
					m_nUserRecvSize += nUDPLossSize;
					m_nUDPLossSize  += nUDPLossSize;
					if(m_nTestMode == 0 && !m_bActive) m_nUserSentSize += nUDPLossSize;
				}
				break;
			}
			else
			{
				nUDPLossSize += m_nUDPPeerPacketSize;
				pData += m_nUDPPeerPacketSize;
			}
		}
	}
	GlobalUnlock(tDataBuf);

	m_nUserRecvSize += bytesTotal;

	m_FirstRecv = FALSE;
	
	if(m_nUserRecvSize >= m_nUserDataSize)
	{
		TRACE("CALL UDPRecvCompleted()\r\n");
		if(!m_bUserTest && m_nTestMode == 0 && m_bActive)
			SendCompleted(FALSE);
		UDPRecvCompleted();
		if (m_nTestMode == 0 && !m_bActive) SendCompleted(FALSE);
	}
	else SetTimer(UDP_TIMER, m_nUDPTimerWait,NULL);
/*
	if(m_nUserRecvSize >= m_nUserDataSize)
	{
		seconds =(__int64)(m_REndTick - m_RStartTick)/m_unitFreq;
		Mbps = ((m_nUserRecvSize-m_nUDPLossSize) * m_nBit / seconds)/m_nSpeed;
		if(m_nTestMode !=1)
		{
			if(m_bUserTest)
				str.Format("[%d] [UDP : RECEIVE COMPLETED - %.3f %s (%d-%d=%d bytes, %.6f sec)]", 
					m_iCnt,Mbps, m_strSpeed, m_nUserRecvSize, m_nUDPLossSize, m_nUserRecvSize-m_nUDPLossSize,seconds);
			else
				str.Format("[%d] RECV : %.3f %s (%d-%d=%d bytes, %.6f sec)",
					m_iCnt,Mbps, m_strSpeed, m_nUserRecvSize, m_nUDPLossSize, m_nUserRecvSize-m_nUDPLossSize,seconds);
			Log(str);
			if(m_iCnt == 1)	m_secRX = seconds;
			else m_secRX = (m_secRX + seconds)/2;
		}
		if(m_nTestMode==0 && m_bActive)
		{
			seconds = (__int64)(m_REndTick - m_SStartTick) / m_unitFreq;
			Mbps = ((m_nUserRecvSize-m_nUDPLossSize) * m_nBit / seconds)/m_nSpeed;
			if(m_bUserTest)
				str.Format("[%d] [UDP : ROUND TRIP - %.3f %s (%d-%d=%d bytes, %.6f sec)]",
					m_iCnt,Mbps, m_strSpeed, m_nUserRecvSize, m_nUDPLossSize, m_nUserRecvSize-m_nUDPLossSize,seconds);
			else
				str.Format("[%d] ROUND TRIP : %.3f %s (%d-%d=%d bytes, %.6f sec)]",
					m_iCnt,Mbps, m_strSpeed, m_nUserRecvSize, m_nUDPLossSize, m_nUserRecvSize-m_nUDPLossSize,seconds);
			if(m_iCnt == 1)	m_secRTT = seconds;
			else m_secRTT = (m_secRTT + seconds)/2;
			Log(str);
		}
		if(m_nUDPLossSize!=0)
		{
			m_strUDPLoss.SetAt(m_strUDPLoss.GetLength()-2,'\0');
			Log(m_strUDPLoss);
			str.Format("[%d] [UDP : LOSS DATA - %d (%3.3f%%)]",m_iCnt,m_nUDPLossSize,m_nUDPLossSize/(double)m_nUserDataSize * 100);
			Log(str);
		}
		if((m_nTestMode==0 && m_bActive) || m_nTestMode==2)
		{
			Log("");
			m_bAlive = FALSE;
			if(m_iCnt++ == 0) m_iCnt=1;
			OnSelchangeSpeedCombo();
		}
		m_FirstRecv = TRUE;
		m_nUserRecvSize = 0;
		m_nUDPLossSize = 0;
		m_strUDPLoss = "";
		if((m_nTestMode==0 && !m_bActive) || m_nTestMode==2)
		{
			m_pProgDlg->ShowWindow(SW_HIDE);
		}
		if (m_nTestMode==0 && m_bActive && (m_bInfinite || m_nTestCnt != 0))
		{
			SetTimer(REPEAT_TIMER,m_pConfigDlg->m_nRepeatTime,NULL);
		}
	}*/
}

void CAX1View::OnUdpopen() 
{
	CPortDlg dlg(this,FALSE);
	
	if (dlg.DoModal() == IDOK) 
	{
		CTestModeDlg testdlg;
		testdlg.m_pView = this;
		if(testdlg.DoModal() == IDOK)
		{
			m_nTestMode = testdlg.m_nTestMode;
			m_bActive = testdlg.m_bActive;

			if(m_nTestMode == 2 ||  (m_nTestMode == 0 && !m_bActive))
			{
				if(!(m_bFileOpen || m_bUserTest))
				{
					if(!m_pConfigDlg->m_nCompMode && !m_bFileOpen)
					{
						OnUdpFileSend();
					}
					else if(m_pConfigDlg->m_nCompMode && !m_bUserTest)
					{
						OnUdprecv();
					}
				}
				else if(m_bFileOpen)
				{
 					OnUdpFileSend();
				}
				else if(m_bUserTest)
				{
					m_DataBinary.m_hData = m_hUserDataBuf;
					m_DataBinary.m_dwDataLength = m_nUserDataSize;
					m_DataVariant = m_DataBinary;
					UCHAR* lpData = (UCHAR*)GlobalLock(m_hUserDataBuf);
					GlobalUnlock(lpData);
 					CString str;

					str.Format("[UDP : READY TO RECEIVE DATA : 0x%02X~0x%02X (%d Bytes)]", lpData[0],lpData[m_nUserDataSize-1],m_nUserDataSize);
 					Log(str);
					Log("");
					m_strData.Format("DATA : %s(0x%02X~0x%02X),  %d Bytes", 
						(m_nFormat == 0) ? "NONE" : (m_nFormat==1) ? "SEQ" : "TOG", lpData[0],lpData[m_nUserDataSize-1], m_nUserDataSize);
				}
			}
			m_ctrlUDPSock.SetLocalPort(dlg.m_Port);
			m_ctrlUDPSock.SendData(COleVariant(""));
			SOCKET s = (SOCKET)(m_ctrlUDPSock.GetSocketHandle());
			
			UINT nUDPRBufSize = 64*1024;
			if(setsockopt(s,SOL_SOCKET,SO_RCVBUF,(char*)&nUDPRBufSize,sizeof(nUDPRBufSize)))
			{
				nUDPRBufSize = GetLastError();
				AfxMessageBox("UDP : Fail to set SOCKET options");
				if(m_pConfigDlg->m_bLogEnable && m_pConfigDlg->m_bLogOnErr && m_hLogFile)
					fprintf(m_hLogFile,"UDP : Fail to set SOCKET options\r\n");
			}


/*			SOCKADDR_IN addr;
			addr.sin_family=AF_INET;
			addr.sin_addr.s_addr = htonl(INADDR_ANY);
			addr.sin_port=dlg.m_Port;
//			SOCKET s = m_ctrlUDPSock.GetSocketHandle();
//			bind(s,(LPSOCKADDR)&addr, sizeof(addr));
			COleVariant port;
			port.vt = VT_I4;
			port.iVal = dlg.m_Port;
			COleVariant localip = COleVariant(m_ctrlUDPSock.GetLocalIP());
			m_ctrlUDPSock.Bind(port,localip ); 
*/
			m_strStatus.Format("UDP[%d]",m_ctrlUDPSock.GetLocalPort());
			m_strTestMode.Format("%s",(m_nTestMode==2) ? "R.O" : (m_nTestMode==1) ? "S.O" : (m_bActive) ? "LBA" : "LBP"); 
			m_FirstRecv = TRUE;
			m_nUserRecvSize = 0;
			m_nUDPLossSize = 0;
			m_fUDPLossRate = 0;
			m_nTotalInvalidCnt = 0;
			m_nInvalidCnt = 0;
			m_iCnt = 1;
			m_nRepeat = 1;
			m_secTX = m_secRX = m_secRTT = 0;
			m_bUDP = TRUE;
			OnSelchangeSpeedCombo();

			UpdateData(FALSE);
		}
	}
}

void CAX1View::OnUdpsend() 
{
	CString str;

	m_bUDPPeer = FALSE;
	m_Edit.SetWindowText("");
	if (GenerateTestData(FALSE,TRUE))
	{
		m_DataBinary.m_hData = m_hUserDataBuf;
		m_DataBinary.m_dwDataLength = m_nUserDataSize;
		m_DataVariant = m_DataBinary;

		m_bUDPPeer = TRUE;
		m_iCnt = 1;
		m_nTotalInvalidCnt = 0;
		m_nInvalidCnt = 0;

		m_secTX = m_secRX = m_secRTT = 0;
		m_nUserSentSize = 0;
		m_nUserRecvSize = 0;
		m_nUDPLossSize = 0;
		m_fUDPLossRate = 0;
		OnSelchangeSpeedCombo();

		UDPTHREADPARM* pParm = new UDPTHREADPARM;
		pParm->pVar = (VARIANT*)&m_DataVariant;
		pParm->pView = this;
			
		m_ctrlUDPSock.SetRemoteHost(m_UDPPeerIP);
		m_ctrlUDPSock.SetRemotePort(m_nUDPPeerPort);
		gblThread = AfxBeginThread(SendUDPThread, pParm, THREAD_PRIORITY_TIME_CRITICAL);
	}
}

void CAX1View::OnSend() 
{
	CString str;
	m_Edit.SetWindowText("");
	if(GenerateTestData(TRUE, TRUE))
	{
		m_DataBinary.m_hData = m_hUserDataBuf;
		m_DataBinary.m_dwDataLength = m_nUserDataSize;
		m_DataVariant = m_DataBinary;
		m_nUserSentSize = 0;
		m_iCnt = 1;
		m_nTotalInvalidCnt = 0;
		m_nInvalidCnt = 0;

		m_secTX = m_secRX = m_secRTT = 0;
		m_nUDPLossSize = 0;
		m_fUDPLossRate = 0;

		OnSelchangeSpeedCombo();
		str.Format("[%d] [TCP : SEND STARTED]",m_iCnt);
		Log(str);
		m_SStartTick = snapshot_rdtsc();
 		m_clntSocket.SendData(m_DataVariant);
 	}
}


void CAX1View::OnCputick() 
{
	// TODO: Add your command handler code here

	CString freq = _T("");
	CString dig = _T("");

	unsigned __int64 tfreq = (unsigned __int64)m_unitFreq;
	if(tfreq / 1000000000000)
	{
		dig.Format("%dT ",tfreq / 1000000000000);
		freq = freq + dig;
		tfreq = tfreq % 1000000000000;
	}
	if(tfreq / 1000000000)
	{
		dig.Format("%dG ",tfreq / 1000000000);
		freq = freq + dig;
		tfreq = tfreq % 1000000000;
	}
	if(tfreq / 1000000)
	{
		dig.Format("%dM ",tfreq / 1000000);
		freq = freq + dig;
		tfreq = tfreq % 1000000;
	}
	if(tfreq)
		dig.Format("%06d",tfreq);
	freq = _T("SYSTEM CLOCK = ") + freq + dig + _T(" Hz");
	dig.Format("\r\n\r\n 1 TICK = %.15f sec", m_secTick);

	AfxMessageBox(freq + dig);
}

void CAX1View::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
	CString str;
	CFormView::OnTimer(nIDEvent);
	static bCheck = FALSE;
	if(nIDEvent == UDP_TIMER)
	{
		KillTimer(UDP_TIMER);
		TRACE("UDP TIMEOUT OCCUR\r\n");
		if(m_nUserRecvSize < m_nUserDataSize)
		{
			ULONG size = 0;
			ioctlsocket(m_ctrlUDPSock.GetSocketHandle(),FIONREAD , &size);
			if(size > 0)
			{
				TRACE("RECV BUF NOT EMPTY=%d\r\n",size);
				OnDataArrivalWinsock3(size);
				return;
			}
			str.Format("       {At %d, %d bytes - The Remained Data Lossed}", m_nUserRecvSize, m_nUserDataSize - m_nUserRecvSize);
			m_strUDPLoss += str;  
			m_nUDPLossSize += m_nUserDataSize - m_nUserRecvSize;
			m_nUserRecvSize = m_nUserDataSize;
			if(m_nTestMode == 0 && m_bActive)
			{
				if(gblThread)
				{
					TRACE("ERRRO : REMAINED SEND DATA\r\n");
				}
				m_nUserSentSize = m_nUserDataSize;
				SendCompleted(FALSE);
			}
			TRACE("UDP TIMEOUT : UDPRecvCompleted()\r\n");
			UDPRecvCompleted();
			if(m_nTestMode == 0 && !m_bActive) 
			{
				m_nUserSentSize = m_nUserDataSize;
				SendCompleted(m_bTCP);
			}
		}
		else
		{
			TRACE("WHY UDP TIMEOUT?\r\n");
		}
	}
	else if(nIDEvent == REPEAT_TIMER)
	{
		KillTimer(REPEAT_TIMER);
		if(m_bInfinite)
			OnMenuRepeat1();
		else if(m_nTestCnt !=0)
		{
			OnMenuRepeat1();
			m_nTestCnt--;
		}
	}
}

void CAX1View::OnErrorWinsock3(short Number, BSTR FAR* Description, long Scode, LPCTSTR Source, LPCTSTR HelpFile, long HelpContext, BOOL FAR* CancelDisplay) 
{
	// TODO: Add your control notification handler code here
	LPVOID lpMsgBuf;
	FormatMessage( 
		FORMAT_MESSAGE_ALLOCATE_BUFFER | 
		FORMAT_MESSAGE_FROM_SYSTEM | 
		FORMAT_MESSAGE_IGNORE_INSERTS,
		NULL,
		Number,
		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), // Default language
		(LPTSTR) &lpMsgBuf,
		0,
		NULL 
	);
	// Process any inserts in lpMsgBuf.
	// ...
	// Display the string.
	AfxMessageBox((LPCTSTR)lpMsgBuf, MB_OK | MB_ICONINFORMATION );
	if(m_pConfigDlg->m_bLogEnable && m_pConfigDlg->m_bLogOnErr && m_hLogFile) fprintf(m_hLogFile, "%s\r\n",lpMsgBuf);

	// Free the buffer.
	LocalFree( lpMsgBuf );
}

void CAX1View::OnTcpclose() 
{
	// TODO: Add your command handler code here
	KillTimer(REPEAT_TIMER);
	m_srvSocket.Close();
	m_clntSocket.Close();
	m_bAlive = FALSE;
	m_bUserTest = FALSE;
	m_bConnect = FALSE;
	m_bTCP = FALSE;
	m_bListen = FALSE;
	m_nTestCnt = 0;
	m_bInfinite = FALSE;
	m_strStatus = "CLOSED";
	UpdateData(FALSE);
	m_pProgDlg->ShowWindow(SW_HIDE);
}

void CAX1View::OnUdpclose() 
{
	// TODO: Add your command handler code here
	m_bUDP = FALSE;
	KillTimer(REPEAT_TIMER);
	m_bAlive = FALSE;
	KillTimer(UDP_TIMER);
	m_ctrlUDPSock.Close();
	m_bUDPPeer = FALSE;
	m_bUserTest = FALSE;
	m_nTestCnt = 0;
	m_bInfinite = FALSE;
	bUDPRecv = FALSE;
	m_strStatus = "CLOSED";
	UpdateData(FALSE);
	m_pProgDlg->ShowWindow(SW_HIDE);
}

void CAX1View::OnDestroy() 
{
	TRACE("CAX1View::OnDestroy()\r\n");
	CFormView::OnDestroy();

	m_bUDP = FALSE;
	if(gblThread)
	{
		gblThread->SuspendThread();
		TerminateThread(gblThread->m_hThread,-1);
	}

	if(gblParam) delete gblParam;

	if(m_pProgDlg)
	{
		delete m_pProgDlg;
		m_pProgDlg = NULL;
	}
	if(m_pConfigDlg)
	{
		delete m_pConfigDlg;
		m_pConfigDlg = NULL;
	}

	if(m_hLogFile)
	{
		int filesize = ftell(m_hLogFile);
		
		fclose(m_hLogFile);
		if(filesize == 0)
		{
			remove(m_strLogFile);
		}
	}

	GlobalFree(m_hUserDataBuf);
	GlobalFree(m_hFileBuf);
	Sleep(1000);
}



void CAX1View::Log(CString log, BOOL bBOLD)
{
	UINT cnt = m_Edit.GetLineCount();
/*	if(cnt > 24)
	{
		m_Edit.Clear();
		m_Edit.SetWindowText("");
	}
	CString str;

	m_Edit.GetWindowText(str);
	m_Edit.SetWindowText(str+log+"\r\n");*/
	if(cnt > m_pConfigDlg->m_nLogCount)
	{
		m_Edit.Clear();
		m_Edit.SetWindowText("");
	}
	CString str;
	m_Edit.GetWindowText(str);

	m_Edit.SetSel(str.GetLength(), -1);
	m_Edit.ReplaceSel(log+"\r\n");
	if(m_pConfigDlg->m_bLogEnable && m_hLogFile)
	{
		fprintf(m_hLogFile,"%s\r\n",(LPCSTR)log);
	}
//	m_Edit.LineScroll(1);
}


void CAX1View::GetPeerInfo()
{
	CDlgIPPort dlg;
	dlg.m_bTCP = m_bTCP;
	dlg.m_pView = this;
	
	if (dlg.DoModal() == IDOK) 
	{
		m_nUDPPeerPort = dlg.m_uPort;

		m_UDPPeerIP = dlg.m_strIP;
		if(!m_bTCP) m_bUDPPeer = TRUE;
		else m_bUDPPeer = FALSE;
	}
}

void CAX1View::SendUDPData(VARIANT* pVar)
{
//#define USE_MSWINSOCK
	UINT sentsize=0,sendingsize=0;
	CString str;
	UINT packetcnt = 0;
	double seconds;
	double Mbps;
	unsigned __int64 stick, etick, wait_tick_cnt;
	BOOL bSendWait = ((m_nTestMode == 0 && m_bActive) || m_nTestMode == 1);

#ifdef USE_MSWINSOCK
	VARIANT tData;
	tData.vt = pVar->vt;
	tData.wReserved1=pVar->wReserved1;
	tData.wReserved2=pVar->wReserved2;
	tData.wReserved3=pVar->wReserved3;
	tData.parray = NULL;
#endif

	CHAR * pArray = (CHAR*)pVar->parray->pvData;
	sendingsize = pVar->parray->rgsabound[0].cElements;

#ifndef USE_MSWINSOCK
	SOCKET s = m_ctrlUDPSock.GetSocketHandle();
	sockaddr_in addr;
	addr.sin_family = AF_INET;
	if(m_nTestMode==0 && !m_bActive)
	{
		addr.sin_port = htons((unsigned short)m_ctrlUDPSock.GetRemotePort());
		addr.sin_addr.s_addr = inet_addr(m_ctrlUDPSock.GetRemoteHostIP().GetBuffer(30)); 
	}
	else
	{
		addr.sin_port = htons((unsigned short)m_nUDPPeerPort);
		addr.sin_addr.s_addr = inet_addr(m_UDPPeerIP.GetBuffer(30)); 
	}
#endif

	if(bSendWait)
	{
		wait_tick_cnt = (unsigned __int64) (
						((m_pConfigDlg->m_nUDPPacketSize * 8) / (m_pConfigDlg->m_nExpectedUDPBandWidth*1024*1024))
						/ m_secTick  		);
		TRACE("WAIT TICK CNT = %I64u, TICK TIME=%.12fms\r\n", wait_tick_cnt, m_secTick);
	}

	if(m_nUserSentSize == 0)
	{
		if(m_bUserTest)
		{
			str.Format("[%d] [UDP : SEND START]",m_iCnt);
			Log(str);
		}
		else if((m_nTestMode == 0 && m_bActive) || m_nTestMode == 1)
		{
 			m_pProgDlg->m_Progress.SetPos(0);
			CString strprog;
			strprog.Format("%s[%d] : UDP Send Progressing...",m_UDPPeerIP,m_nUDPPeerPort);
			m_pProgDlg->SetWindowText(strprog);
 			if(m_pConfigDlg->m_bOnLogMsg && ((m_nTestMode==0 && m_bActive) || m_nTestMode==1))
				m_pProgDlg->ShowWindow(SW_SHOW);
		}
		if((m_nTestMode==0 && m_bActive) || m_nTestMode==1)	m_bAlive = TRUE;
		m_SStartTick = snapshot_rdtsc();
	}

	while(sendingsize > 0 && m_bUDP && this)
	{
		stick = snapshot_rdtsc();
#ifdef USE_MSWINSOCK
		tData.parray = new SAFEARRAY;
		tData.parray->cbElements = 1;//pVar->parray->cbElements;
		tData.parray->cDims = 1;//pVar->parray->cDims;
		tData.parray->cLocks = 0; //pVar->parray->cLocks;
		tData.parray->fFeatures = 128; //pVar->parray->fFeatures;
#endif

		if(sendingsize > m_pConfigDlg->m_nUDPPacketSize) sentsize =  m_pConfigDlg->m_nUDPPacketSize;
		else sentsize = sendingsize;

#ifdef USE_MSWINSOCK
		tData.parray->rgsabound[0].lLbound = 0;
		tData.parray->rgsabound[0].cElements = sentsize;
		tData.parray->pvData = pArray;
#endif


#ifdef USE_MSWINSOCK
		m_ctrlUDPSock.SendData(tData);
#else
		if(SOCKET_ERROR == sendto(s, pArray, sentsize, 0, (sockaddr*)&addr,sizeof(addr)))
		{
			LPVOID lpMsgBuf;
			FormatMessage( 
				FORMAT_MESSAGE_ALLOCATE_BUFFER | 
				FORMAT_MESSAGE_FROM_SYSTEM | 
				FORMAT_MESSAGE_IGNORE_INSERTS,
				NULL,
				GetLastError(),
				MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), // Default language
				(LPTSTR) &lpMsgBuf,
				0,
				NULL 
			);
			// Process any inserts in lpMsgBuf.
			// ...
			// Display the string.
			AfxMessageBox((LPCTSTR)lpMsgBuf, MB_OK | MB_ICONINFORMATION );
			// Free the buffer.
			LocalFree( lpMsgBuf );
 

			return;
		}
#endif
		
		TRACE("UDP : SEND OK %d\r\n", sentsize);
		sendingsize -= sentsize;
		pArray += sentsize;
		m_nUserSentSize += sentsize;

		if(m_bUserTest)
		{
			if(m_pConfigDlg->m_bOnLogMsg)
			{
				if((m_nTestMode == 0 && m_bActive) || m_nTestMode==1)
				{
					str.Format("       {Sent : %d, Remained : %d}",sentsize,sendingsize);
				}
				else if(m_nTestMode == 0 && !m_bActive)
				{
					str.Format("       {Sent : %d, Remained : %d}",sentsize,m_nUserDataSize - m_nUserSentSize);
				}
				Log(str);
			}
		}
		else if (m_pConfigDlg->m_bOnLogMsg)
		{
			if((m_nTestMode == 0 && m_bActive) || m_nTestMode==1)
			{
				seconds = (__int64)(m_SEndTick - m_SStartTick)/m_unitFreq;
				Mbps = (m_nUserSentSize * m_nBit /seconds) / m_nSpeed;
				str.Format("%.3f %s (%d Bytes)", Mbps, m_strSpeed, m_nUserSentSize);
				if(m_pProgDlg)
				{
					m_pProgDlg->m_Progress.SetPos((UINT)((unsigned __int64)100*m_nUserSentSize/m_nUserDataSize));
					m_pProgDlg->m_Speed.SetWindowText(str);
				}
			}
		}

#ifdef USE_MSWINSOCK
		delete tData.parray;
		tData.parray = NULL;
#endif

		m_SEndTick = snapshot_rdtsc();
		etick = m_SEndTick;
		while( bSendWait && m_bUDP && sendingsize && ((etick - stick) < wait_tick_cnt - 100))
		{
//			TRACE("etick - stick = %d, ", etick - stick);
//			TRACE("wait_tick_cnt = %d\r\n",wait_tick_cnt);
			etick = snapshot_rdtsc();
		}
	}
	if(this)
	{
		if(!m_bUDP)
		{
#ifdef USE_MSWINSOCK
			if(tData.parray) delete tData.parray;
#endif
			str.Format("[%d][UDP : CLOSED - SEND FAIL]",m_iCnt);
			Log(str);
		}
		if((m_nUserSentSize >= m_nUserDataSize) &&  m_nTestMode==1)
			SendCompleted(FALSE);
	}	
}



void CAX1View::OnMenuUdpRepeat() 
{
	// TODO: Add your command handler code here
//	OnTcpclose();
	OnMenuRepeat();
}

void CAX1View::OnMenuTcpRepeat() 
{
	// TODO: Add your command handler code here
//	OnUdpclose();
	m_bTCP = TRUE;
	OnMenuRepeat();
}

void CAX1View::OnMenuConfig() 
{
	// TODO: Add your command handler code here
	m_pConfigDlg->ShowWindow(SW_SHOW);
}



BOOL CAX1View::GenerateTestData(BOOL bTCP, BOOL bSend)
{
 	CDlgSend dlg(NULL,bTCP,bSend);
	dlg.m_pView = this;


 	if (dlg.DoModal() == IDOK)
 	{
 		m_nUserDataSize = dlg.m_iCnt;
 		BYTE data = dlg.m_cVal;
		m_nFormat = dlg.m_nFormat;

 		if(m_hUserDataBuf) GlobalFree(m_hUserDataBuf);
 		m_hUserDataBuf = GlobalAlloc(GHND, m_nUserDataSize);
		if(!m_hUserDataBuf)
		{
			AfxMessageBox("Fail to allocate memory");
			if(m_pConfigDlg->m_bLogEnable && m_pConfigDlg->m_bLogOnErr && m_hLogFile)
				fprintf(m_hLogFile,"Fail to allocate memory\r\n");
			return FALSE;
		}
 		m_bUserTest = TRUE;
 		m_FirstRecv = TRUE;
 		m_nUserRecvSize = 0;


 		UCHAR* lpData = (UCHAR*)GlobalLock(m_hUserDataBuf);
		if(m_nFormat)
		{
			for(UINT i=0; i < m_nUserDataSize; i++)
			{
				if(m_nFormat == 1)
					lpData[i] = (UCHAR)(data+i);
				else
					lpData[i] = (i%2==0) ? 0xAA:0x55;
			}
		}
		else memset(lpData,0xFF,m_nUserDataSize);

		GlobalUnlock(lpData);
 		CString str;
		str.Format("[%s : READY TO %s DATA : 0x%02X~0x%02X (%d Bytes)]",(bTCP)?"TCP":"UDP", (bSend)?"SEND":"RECEIVE", lpData[0],lpData[m_nUserDataSize-1],m_nUserDataSize);
 		Log(str);
		Log("");
		m_strData.Format("DATA : %s(0x%02X~0x%02X),  %d Bytes", 
			(m_nFormat == 0) ? "NONE" : (m_nFormat==1) ? "SEQ" : "TOG", lpData[0],lpData[m_nUserDataSize-1], m_nUserDataSize);
		UpdateData(FALSE);
		if(!m_bTCP)
		{
			m_UDPPeerIP = dlg.m_RemoteIP;
			m_nUDPPeerPort = dlg.m_nPeerPort;
		}

	}
	else return FALSE;

	return TRUE;
}
void CAX1View::OnRecv() 
{
	// TODO: Add your command handler code here
	m_Edit.SetWindowText("");
	if(GenerateTestData(TRUE, FALSE))
	{
		m_DataBinary.m_hData = m_hUserDataBuf;
		m_DataBinary.m_dwDataLength = m_nUserDataSize;
		m_DataVariant = m_DataBinary;
		m_FirstRecv = TRUE;
		m_nUserRecvSize = 0;
		m_iCnt = 1;
		m_nTotalInvalidCnt = 0;
		m_nInvalidCnt = 0;

		m_nUDPLossSize = 0;
		m_fUDPLossRate = 0;
		m_secTX = m_secRX = m_secRTT = 0;
		OnSelchangeSpeedCombo();
 	}	
}


void CAX1View::OnCloseWinsock2() 
{
	// TODO: Add your control notification handler code here
	KillTimer(REPEAT_TIMER);
	AfxMessageBox("The Peer requests to close the socket");
	OnTcpclose();
}

void CAX1View::OnSelchangeSpeedCombo() 
{
	// TODO: Add your control notification handler code here
	UINT nAvgLossSize;

	m_nBit = 8;
	switch(m_ctrlSpeed.GetCurSel())
	{
	case 0:
		m_nSpeed = 1024*1024;
		m_strSpeed = "Mbps";
		break;
	case 1:
		m_nSpeed = 1024;
		m_strSpeed = "Kbps";
		break;
	case 2:
		m_nSpeed = 1;
		m_strSpeed = "bps";
		break;
	case 3:
		m_nBit = 1;
		m_nSpeed = 1024*1024;
		m_strSpeed = "MBps";
		break;
	case 4:
		m_nBit = 1;
		m_nSpeed = 1024;
		m_strSpeed = "KBps";
		break;
	case 5:
		m_nBit = 1;
		m_nSpeed = 1;
		m_strSpeed = "Bps";
		break;
	}

	m_strRepeatCnt.Format("%d",m_iCnt-1);

	m_strSSec.Format("%.6f",m_secTX);
	m_strRSec.Format("%.6f",m_secRX);
	m_strRTSec.Format("%.6f",m_secRTT);

	nAvgLossSize = (UINT)(m_nUserDataSize*(m_fUDPLossRate/100));

	if(m_secTX)
	{
		if(m_nTestMode == 0 && !m_bActive)
			m_strSSpeed.Format("%.3f", (m_nUserDataSize - nAvgLossSize)*m_nBit / m_secTX / m_nSpeed);
		else
			m_strSSpeed.Format("%.3f", (m_nUserDataSize)*m_nBit / m_secTX / m_nSpeed);
	}
	else m_strSSpeed.Format("%.3f", 0);

	if(m_secRX) m_strRSpeed.Format("%.3f", (m_nUserDataSize - nAvgLossSize)*m_nBit / m_secRX / m_nSpeed);
	else m_strRSpeed.Format("%.3f", 0);

	if(m_secRTT) m_strRTSpeed.Format("%.3f", (m_nUserDataSize - nAvgLossSize)*m_nBit / m_secRTT / m_nSpeed);
	else m_strRTSpeed.Format("%.3f", 0);

	GetDlgItem(IDC_CNT_STATIC)->SetWindowText(m_strRepeatCnt);
	GetDlgItem(IDC_SSEC_STATIC)->SetWindowText(m_strSSec);
	GetDlgItem(IDC_RSEC_STATIC)->SetWindowText(m_strRSec);
	GetDlgItem(IDC_RTSEC_STATIC)->SetWindowText(m_strRTSec);
	GetDlgItem(IDC_SSPEED_STATIC)->SetWindowText(m_strSSpeed);
	GetDlgItem(IDC_RSPEED_STATIC)->SetWindowText(m_strRSpeed);
	GetDlgItem(IDC_RTSPEED_STATIC)->SetWindowText(m_strRTSpeed);
	
	if(m_nTestMode != 1)
		((CMainFrame*)GetParentFrame())->SetUDPLossRate(m_fUDPLossRate);
	if(m_nTestMode == 2 || m_nTestMode == 0)
		((CMainFrame*)GetParentFrame())->SetInvalidCnt(m_nTotalInvalidCnt);

	
//	UpdateData(FALSE);

}



void CAX1View::OnUpdateRecv(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->Enable((m_bListen || m_bConnect) && !m_bAlive && ((m_nTestMode==0 && !m_bActive) || m_nTestMode==2));
}

void CAX1View::OnUpdateUdprecv(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->Enable(m_bUDP && !m_bAlive && ((m_nTestMode==0 && !m_bActive) || m_nTestMode==2));
}

void CAX1View::OnUpdateMenuUdpRepeat(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
//	pCmdUI->Enable(!m_bTCP && m_bUDP && !m_bAlive);
	pCmdUI->Enable(m_bUDP && ((m_nTestMode==0 && m_bActive) || m_nTestMode == 1) && !m_bAlive && !(m_bInfinite || m_nTestCnt>0));

}

void CAX1View::OnUpdateUdpsend(CCmdUI* pCmdUI) // Menu
{
	// TODO: Add your command update UI handler code here
//	pCmdUI->Enable(!m_bTCP && m_bUDP && !m_bAlive);
	pCmdUI->Enable(m_bUDP && !m_bAlive && ((m_nTestMode==0 && m_bActive) || m_nTestMode==1));
}

void CAX1View::OnUpdateUdpSend(CCmdUI* pCmdUI) // U1
{
	// TODO: Add your command update UI handler code here
	pCmdUI->Enable(m_bUDP && !m_bAlive);
}

void CAX1View::OnUpdateUdpclose(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->Enable(!m_bTCP && m_bUDP);	
}

void CAX1View::OnUpdateUdpopen(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->Enable(!m_bTCP && !m_bUDP && !m_bAlive);
}


void CAX1View::OnUpdateMenuInfinite(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
//	pCmdUI->Enable(!( (m_nTestMode==0 && !m_bActive) || m_nTestMode == 2 || m_bAlive || m_bInfinite || m_nTestCnt || (m_bTCP && m_bListen)));		
	pCmdUI->Enable(((m_nTestMode==0 && m_bActive) || m_nTestMode == 1) && (m_bConnect || m_bUDP) && !m_bAlive && (m_nTestCnt == 0) && !m_bInfinite);
}

void CAX1View::OnUpdateMenuConnect(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->Enable(!m_bUDP && !(m_bListen || m_bConnect|| m_bAlive));
}

void CAX1View::OnUpdateMenuSend2(CCmdUI* pCmdUI) //T1
{
	// TODO: Add your command update UI handler code here
//	if(m_bAlive || !m_bConnect)  pCmdUI->Enable(FALSE);
//	else pCmdUI->Enable();
	pCmdUI->Enable(!m_bUDP && (m_bConnect  || (m_bListen && ((m_nTestMode==0 && !m_bActive) || m_nTestMode==2)))
		&& !m_bAlive && !(m_bInfinite || m_nTestCnt>0));

}

void CAX1View::OnUpdateMenuStartserver(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	if(m_bUDP || m_bConnect || m_bAlive || m_bListen) pCmdUI->Enable(FALSE);
	else pCmdUI->Enable();

}

void CAX1View::OnUpdateMenuTcpRepeat(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
//	if(m_bAlive && m_bTCP || !m_bConnect) pCmdUI->Enable(FALSE);
//	else pCmdUI->Enable();
	pCmdUI->Enable(m_bConnect && ((m_nTestMode==0 && m_bActive) || m_nTestMode==1) && !m_bAlive && !(m_bInfinite || m_nTestCnt>0) );
	
}

void CAX1View::OnUpdateSend(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(m_bConnect && !m_bAlive && ((m_nTestMode==0 && m_bActive) || m_nTestMode==1));
}

void CAX1View::OnUpdateTcpclose(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	
	pCmdUI->Enable(m_bTCP && (m_bConnect || m_bListen));
}

void CAX1View::OnUpdateFileOpen(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->Enable(!m_bAlive);
}

void CAX1View::OnUpdateCputick(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->Enable(!m_bAlive);
}

void CAX1View::OnUpdateMenuFinite(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->Enable(m_bInfinite || m_nTestCnt > 0);
}



void CAX1View::SendCompleted(BOOL bTCP)
{
	double seconds;
	double Mbps;
	CString str, pro;
	if(bTCP) pro = "TCP";
	else pro = "UDP";

	if(m_nUserSentSize > m_nUserDataSize)
	{
		str.Format("[%d] [%s : SIZE MISMATCHED - DataSize=%d, Sent Size=%d]",m_iCnt,pro,m_nUserDataSize,m_nUserSentSize);
		Log(str);
	}

	
	if(m_bUserTest)
	{
		if((m_nTestMode == 0 && m_bActive) || m_nTestMode == 1)
		{
			seconds = (__int64)(m_SEndTick - m_SStartTick) / m_unitFreq;
			Mbps = (m_nUserSentSize * m_nBit / seconds)/m_nSpeed;
			str.Format("[%d] [%s : SEND COMPLETED - %.3f %s (%d bytes, %.6f sec)]", m_iCnt,pro,Mbps, m_strSpeed, m_nUserSentSize, seconds);
			Log(str);
			if(m_iCnt == 1)	m_secTX = seconds;
			else m_secTX = (m_secTX + seconds)/2;
		}
		else if(m_nTestMode==0 && !m_bActive)
		{
			if(m_bUDP)
			{
				seconds = (__int64)(m_SEndTick - m_SStartTick) / m_unitFreq;
				Mbps = ((m_nUserSentSize-m_nUDPLossSize) * m_nBit / seconds)/m_nSpeed;
				str.Format("[%d] [%s : SEND COMPLETED - %.3f %s (%d - %d = %d bytes, %.6f sec)]", m_iCnt,pro,Mbps, m_strSpeed, m_nUserSentSize,m_nUDPLossSize, m_nUserSentSize-m_nUDPLossSize, seconds);
				Log(str);
				if(m_iCnt == 1)	m_secTX = seconds;
				else m_secTX = (m_secTX + seconds)/2;

				seconds = (__int64)(m_SEndTick - m_RStartTick) / m_unitFreq;
				Mbps = ((m_nUserSentSize-m_nUDPLossSize) * m_nBit / seconds)/m_nSpeed;
				str.Format("[%d] [%s : ROUND TRIP - %.3f %s (%d - %d = %d bytes, %.6f sec)]", m_iCnt,pro, Mbps, m_strSpeed, m_nUserSentSize,m_nUDPLossSize, m_nUserSentSize-m_nUDPLossSize, seconds);
				if(m_iCnt == 1)	m_secRTT = seconds;
				else m_secRTT = (m_secRTT + seconds)/2;
				Log(str);
			}
			else if (m_bTCP)
			{
				seconds = (__int64)(m_SEndTick - m_SStartTick) / m_unitFreq;
				Mbps = ((m_nUserSentSize) * m_nBit / seconds)/m_nSpeed;
				str.Format("[%d] [%s : SEND COMPLETED - %.3f %s (%d bytes, %.6f sec)]", m_iCnt,pro,Mbps, m_strSpeed, m_nUserSentSize, seconds);
				Log(str);
				if(m_iCnt == 1)	m_secTX = seconds;
				else m_secTX = (m_secTX + seconds)/2;

				seconds = (__int64)(m_SEndTick - m_RStartTick) / m_unitFreq;
				Mbps = ((m_nUserSentSize) * m_nBit / seconds)/m_nSpeed;
				str.Format("[%d] [%s : ROUND TRIP - %.3f %s (%d bytes, %.6f sec)]", m_iCnt,pro, Mbps, m_strSpeed, m_nUserSentSize, seconds);
				if(m_iCnt == 1)	m_secRTT = seconds;
				else m_secRTT = (m_secRTT + seconds)/2;
				Log(str);
			}
			Log("");
		}
	}
	else
	{
		if((m_nTestMode==0 && m_bActive) || m_nTestMode==1)
		{
			m_pProgDlg->ShowWindow(SW_HIDE);
			seconds = (__int64)(m_SEndTick - m_SStartTick) / m_unitFreq;
			Mbps = (m_nUserSentSize * m_nBit / seconds) / m_nSpeed;
			str.Format("[%d] SEND : %.3f %s (%d bytes, %.6f sec)",m_iCnt, Mbps, m_strSpeed, m_nUserSentSize, seconds);
			Log(str);
			if(m_iCnt == 1)	m_secTX = seconds;
			else m_secTX = (m_secTX + seconds)/2;
			if(m_nTestMode == 1) Log("");
		}
		else if(m_nTestMode==0 && !m_bActive)
		{
			if(m_bUDP)
			{
				seconds = (__int64)(m_SEndTick - m_SStartTick) / m_unitFreq;
				Mbps = ((m_nUserSentSize) * m_nBit / seconds ) / m_nSpeed;
				str.Format("[%d] SEND : %.3f %s (%d bytes, %.6f sec)",m_iCnt,Mbps,m_strSpeed,m_nUserSentSize,seconds);
				Log(str);
				if(m_iCnt == 1) 	m_secTX = seconds;
				else m_secTX = (m_secTX + seconds)/2;

				seconds = (__int64)(m_SEndTick - m_RStartTick) / m_unitFreq;
				Mbps = ((m_nUserSentSize) * m_nBit / seconds) / m_nSpeed;
				str.Format("[%d] ROUND TRIP : %.3f %s (%d bytes, %.6f sec)",m_iCnt, Mbps, m_strSpeed, m_nUserSentSize, seconds);
				Log(str);
				if(m_iCnt == 1) m_secRTT = seconds;
				else m_secTX = (m_secRTT + seconds)/2;
			}
			else if(m_bTCP)
			{
				seconds = (__int64)(m_SEndTick - m_SStartTick) / m_unitFreq;
				Mbps = ((m_nUserSentSize-m_nUDPLossSize) * m_nBit / seconds ) / m_nSpeed;
				str.Format("[%d] SEND : %.3f %s (%d - %d = %d bytes, %.6f sec)",m_iCnt,Mbps,m_strSpeed,m_nUserSentSize,m_nUDPLossSize, m_nUserSentSize-m_nUDPLossSize, seconds);
				Log(str);
				if(m_iCnt == 1) 	m_secTX = seconds;
				else m_secTX = (m_secTX + seconds)/2;

				seconds = (__int64)(m_SEndTick - m_RStartTick) / m_unitFreq;
				Mbps = ((m_nUserSentSize-m_nUDPLossSize) * m_nBit / seconds) / m_nSpeed;
				str.Format("[%d] ROUND TRIP : %.3f %s (%d - %d = %d bytes, %.6f sec)",m_iCnt, Mbps, m_strSpeed, m_nUserSentSize,m_nUDPLossSize, m_nUserSentSize-m_nUDPLossSize, seconds);
				Log(str);
				if(m_iCnt == 1) m_secRTT = seconds;
				else m_secTX = (m_secRTT + seconds)/2;
			}
			Log("");
		}
	}
	m_nUserSentSize = 0;
	if(m_nTestMode==1 || (m_nTestMode==0 && !m_bActive))
	{
		m_bAlive = FALSE;
		m_nTotalInvalidCnt += m_nInvalidCnt;
		if(m_iCnt++ == 0) m_iCnt=1;
		OnSelchangeSpeedCombo();
	}
	if(m_nTestMode==1 && (m_bInfinite || m_nTestCnt != 0))
	{
		SetTimer(REPEAT_TIMER,m_pConfigDlg->m_nRepeatTime,NULL);
	}
}



void CAX1View::UDPRecvCompleted()
{
	double seconds;
	double Mbps;
	CString str;

	KillTimer(UDP_TIMER);
	if(m_nUserRecvSize > m_nUserDataSize)
	{
		str.Format("[%d] [UDP : SIZE MISMATCHED - DataSize=%d, Received Size=%d]",m_iCnt,m_nUserDataSize,m_nUserRecvSize);
		Log(str);
	}

	if(m_nUserRecvSize >= m_nUserDataSize)
	{
		seconds =(__int64)(m_REndTick - m_RStartTick)/m_unitFreq;
		Mbps = ((m_nUserRecvSize-m_nUDPLossSize) * m_nBit / seconds)/m_nSpeed;
		if(m_nTestMode !=1)
		{
			if(m_bUserTest)
				str.Format("[%d] [UDP : RECEIVE COMPLETED - %.3f %s (%d-%d=%d bytes, %.6f sec)]", 
					m_iCnt,Mbps, m_strSpeed, m_nUserRecvSize, m_nUDPLossSize, m_nUserRecvSize-m_nUDPLossSize,seconds);
			else
				str.Format("[%d] RECV : %.3f %s (%d-%d=%d bytes, %.6f sec)",
					m_iCnt,Mbps, m_strSpeed, m_nUserRecvSize, m_nUDPLossSize, m_nUserRecvSize-m_nUDPLossSize,seconds);
			Log(str);
			if(m_iCnt == 1)	m_secRX = seconds;
			else m_secRX = (m_secRX + seconds)/2;
		}
		if(m_nUDPLossSize!=0)
		{
			//m_strUDPLoss.SetAt(m_strUDPLoss.GetLength()-2,'\0');
			//Log(m_strUDPLoss);
			CHAR * pTok = m_strUDPLoss.GetBuffer(m_strUDPLoss.GetLength());
			pTok = strtok(pTok,"\r\n");
			while(pTok)
			{
				str.Format("%s",pTok);
				Log(str);
				pTok = strtok(NULL,"|");
			}
			str.Format("[%d] [UDP : LOSS DATA - %d (%3.3f%%)]",m_iCnt,m_nUDPLossSize,m_nUDPLossSize/(double)m_nUserDataSize * 100);
			Log(str);
			if(m_iCnt == 1) m_fUDPLossRate = (float)(m_nUDPLossSize/(double)m_nUserDataSize * 100);
			else m_fUDPLossRate = (float)((m_fUDPLossRate + (m_nUDPLossSize/(double)m_nUserDataSize * 100))/2);
		}
		if(m_nTestMode==0 && m_bActive)
		{
			seconds = (__int64)(m_REndTick - m_SStartTick) / m_unitFreq;
			Mbps = ((m_nUserRecvSize-m_nUDPLossSize) * m_nBit / seconds)/m_nSpeed;
			if(m_bUserTest)
				str.Format("[%d] [UDP : ROUND TRIP - %.3f %s (%d-%d=%d bytes, %.6f sec)]",
					m_iCnt,Mbps, m_strSpeed, m_nUserRecvSize, m_nUDPLossSize, m_nUserRecvSize-m_nUDPLossSize,seconds);
			else
				str.Format("[%d] ROUND TRIP : %.3f %s (%d-%d=%d bytes, %.6f sec)]",
					m_iCnt,Mbps, m_strSpeed, m_nUserRecvSize, m_nUDPLossSize, m_nUserRecvSize-m_nUDPLossSize,seconds);
			if(m_iCnt == 1)	m_secRTT = seconds;
			else m_secRTT = (m_secRTT + seconds)/2;
			Log(str);
		}

		m_FirstRecv = TRUE;
		m_nUserRecvSize = 0;

		if((m_nTestMode==0 && m_bActive) || m_nTestMode==2)
		{
			Log("");
			m_nTotalInvalidCnt += m_nInvalidCnt;
			m_bAlive = FALSE;
			if(m_iCnt++ == 0) m_iCnt=1;
			OnSelchangeSpeedCombo();
		}
		if((m_nTestMode==0 && !m_bActive) || m_nTestMode==2)
		{
			if(!m_bUserTest) m_pProgDlg->ShowWindow(SW_HIDE);
		}
		if (m_nTestMode==0 && m_bActive && (m_bInfinite || m_nTestCnt != 0))
		{
			SetTimer(REPEAT_TIMER,m_pConfigDlg->m_nRepeatTime,NULL);
		}
	}
}

