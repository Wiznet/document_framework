#if !defined(AFX_TESTMODEDLG_H__0BCF23AC_EA01_4C3B_937A_602D2B880EC4__INCLUDED_)
#define AFX_TESTMODEDLG_H__0BCF23AC_EA01_4C3B_937A_602D2B880EC4__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// TestModeDlg.h : header file
//

class CAX1View;
/////////////////////////////////////////////////////////////////////////////
// CTestModeDlg dialog

class CTestModeDlg : public CDialog
{
// Construction
public:
	CAX1View* m_pView;
	CTestModeDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CTestModeDlg)
	enum { IDD = IDD_TESTMODE_DIALOG };
	CButton	m_ctrlTestMode;
	CButton	m_ctrlRecv;
	BOOL	m_bActive;
	int		m_nTestMode;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTestModeDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CTestModeDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnLoopbackRadio();
	afx_msg void OnSendRadio();
	afx_msg void OnRecvRadio();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TESTMODEDLG_H__0BCF23AC_EA01_4C3B_937A_602D2B880EC4__INCLUDED_)
