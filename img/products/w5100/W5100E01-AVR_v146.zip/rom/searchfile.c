/**
 @file		searchfile.c
*/

#include <string.h>

#include "../mcu/types.h"
#include "../iinchip/w5100.h"
#include "../rom/romfs.h"

#include "../rom/searchfile.h"

extern ROMFILE* romfl_list;


/**
 @brief 	Search a file from ROM FILE 
 */
u_char search_file(
	u_char * name, 		/**< file name */
	prog_char ** buf, 		/**< file contents to be return */
	u_int * len			/**< file length to be return */
	) 
{
	int i;
    	ROMFILE *romfs;
    
	i = 0;

    	for (romfs = romfl_list; romfs; romfs = romfs->romfl_next)
    	{
		if (!strcmp((char*)name, (char*)romfs->romfl_name))
		{
			*len = romfs->romfl_size;
			*buf = romfs->romfl_data;
			return ++i;
		}
	}

	return 0;
}
