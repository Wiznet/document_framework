/**
 @file		searchfile.h
*/

#ifndef __ROMFILE_SEARCH
#define __ROMFILE_SEARCH


extern u_char search_file(u_char * name, prog_char ** buf, u_int * len);	// Search a file from ROM FILE 

#endif
