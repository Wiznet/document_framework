 /*
 * (c)COPYRIGHT
 * ALL RIGHT RESERVED
 *
 * FileName : main.c
 * Brief : source codes for W5100E01-AVR
 * This code is optimized at AVR-GCC 4.3.2(20081118).
 
 * Revision History :
 * ----------	-------		------------------------------------------------
 * 	Date		version	  	Description
 * ----------	-------  	------------------------------------------------
 * 03/28/2007	1.0.0.0		Release version
 * ----------	-------		------------------------------------------------
 * 01/08/2008	1.1.0.0		Check if W5100 register and EEPROM are the same value 
 *											before displaying network information.
 							Changed W5100 Driver(v1.2).
 							Removed WinAVR-20050214 codes(UART).
 							Changed check_leaseIP() function in DHCP.C.
 * ----------	-------		------------------------------------------------
 * 11/21/2008	1.2.0.0		optimized at Compiler WinAVR 20081118rc2 version
 *							Changed wait_1us() function delay.c
 *							Changed lcd_ready() function in lcd.c
 * ----------	-------		------------------------------------------------
 * 03/13/2012	1.3.0.0		Modified for the ARP errata of W5100 							
 * ----------	-------		------------------------------------------------
 * 01/14/2013	1.4.0.0		Correct the driver files for W5100 							
 * ----------	-------		------------------------------------------------ 
 * 02/14/2013	1.4.1.0		Added the setSn_IR() function for Connect() function
 							in w5100.c 							
 * ----------	-------		------------------------------------------------
 * 10/11/2013	1.4.2.0		Anyport value changed from 1000 to 10000
 *							Added the applySUBR(),clearSUBR() function in socket.c 
 *							and w5100.c
 * ----------	-------		------------------------------------------------
 * 10/11/2013	1.4.3.0		modified the get_netconf()fuction in config.c 
 *							(revision of v1.4.1.0)
 *			
 * ----------	-------		------------------------------------------------
 * 10/11/2013	1.4.4.0		 modified the get_netconf()fuction in config.c 
 *							(revision of v1.4.2.0)
 *							
 * ----------	-------		------------------------------------------------
 * 10/28/2013	1.4.5.0		modify clearSUBR()functions because of the ARP errata.
 *							but it was only solved the Erratum3.
 *											
 * ----------	-------		------------------------------------------------
 * 08/12/2015	1.4.6.0		modify setSUBR() fuctions
 *							when setSUBR use, it dosen't save the subnetmask value.
 *							(w5100.c)
 * ----------	-------		------------------------------------------------
 */
#include <string.h>
#include "../util/myprintf.h"
#include "../mcu/types.h"
#include "../mcu/timer.h"
#include "../mcu/delay.h"
#include "../mcu/serial.h"
#include "../iinchip/socket.h"
#include "../iinchip/w5100.h"		//for debug 2008.02.20
#include "../evb/lcd.h"
#include "../evb/evb.h"
#include "../evb/manage.h"
#include "../evb/channel.h"
#include "../evb/config.h"
#include "../inet/dhcp.h"
#include "../app/webserver.h"
#include "../app/loopback.h"
#include "../app/ping_app.h"

extern CHANNELHANDLER ChannelHandler[MAX_SOCK_NUM];
extern NETCONF	NetConf;
extern CHCONF	ChConf;

extern u_char SRC_MAC_ADDR[6];		/**< Source MAC Address */
extern u_char GET_SN_MASK[4];		/**< Subnet mask received from the DHCP server */
extern u_char GET_GW_IP[4];		/**< Gateway IP address received from the DHCP server */
extern u_char GET_DNS_IP[4];		/**< DNS server IP address received from the DHCP server */
extern u_char GET_SIP[4];		/**< Leased source IP address received from the DHCP server */

extern char uart0_getchar(FILE *f);
/**
	@mainpage	W5100 Firmware Source
	@section intro	Introduction
	- Introduction : 
	@section CREATEINFO	Author
	- author : wiznet co. 
	- Released date : 2006.12.20
	- Last Updated date : 2013. 2. 14
*/

int main(void)
{
	u_char key;
	SOCKET i;
	evb_init();
	check_manage();	/* administration mode check */
	init_timer();

	for (i = 0; i < MAX_SOCK_NUM; i++)
	{
		switch(ChConf.ch[i].type)
		{
		case NOTUSE: unregister_channel_handler(i);
			break;

		case DHCP_CLIENT: PRINTLN1("%d : DHCP Client Start.",i);
			evb_set_lcd_text(0,(u_char*)"< DHCP  CLIENT >");
			evb_set_lcd_text(1,(u_char*)" Wait a minute ");
			get_netconf(&NetConf);
			memcpy(SRC_MAC_ADDR,NetConf.mac,6);
			init_dhcp_client(i, evb_soft_reset,evb_soft_reset);
			if(!getIP_DHCPS())
			{
				evb_set_lcd_text(1,(u_char*)" Fail to get IP ");
				PRINTLN("Fail to get a IP adress from DHCP server");
				PRINTLN("Apply the default network information!!!");
				ChConf.ch[i].type =  NOTUSE;	// Disable DHCPC;
				unregister_channel_handler(i);
				wait_10ms(100);
			}
			else
			{
				NetConf.sip  = *((u_long*)GET_SIP);
				NetConf.gwip = *((u_long*)GET_GW_IP);
				NetConf.sn   = *((u_long*)GET_SN_MASK);
				NetConf.dns  = *((u_long*)GET_DNS_IP);
				
				PRINTLN("Get network information from DHCP Server...");	
				register_channel_handler(i,check_DHCP_state);
			}
			set_netconf(&NetConf);
			break;
		case LB_TCPS:
			register_channel_handler(i,loopback_tcps);
			break;
		case LB_TCPC:
			register_channel_handler(i,loopback_tcpc);
			break;
		case LB_UDP:
			register_channel_handler(i,loopback_udp);
			break;
		case WEB_SERVER:
			register_channel_handler(i,web_server);
			break;
		}
	}
	
	net_init();
	evb_logo();
		
	while (1)
	{
			for (i = 0 ; i < MAX_SOCK_NUM ; i++ )
			if(ChannelHandler[i].Handler) (*ChannelHandler[i].Handler)(i);

			//for ISR test
			if(uart_keyhit(0))
			{		

				key = uart0_getchar(NULL);
				if(key ==  'c')
				{
					for(i=0;i<4;i++)	IINCHIP_WRITE(Sn_IR(i), 0xFF);
					IINCHIP_WRITE(IR, 0xFF);
					PRINTLN("all interrupt register cleared!!!!");
				}

			}
	}		
}
