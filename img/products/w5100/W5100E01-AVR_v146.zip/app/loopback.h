/*
@file		loopback.h
*/

#ifndef _LOOPBACK_H
#define _LOOPBACK_H

extern void loopback_tcps(u_char ch);
extern void loopback_tcpc(u_char ch);
extern void loopback_udp(u_char ch);
extern void loopback_udp_ARPtest(u_char ch);

#endif
