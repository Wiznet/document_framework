/*
*
@file		loopback.c
@brief	loopback test functions
*/

#include "../mcu/types.h"
#include "../iinchip/w5100.h"

#include "../iinchip/socket.h"
#include "../util/sockutil.h"
#include "../util/myprintf.h"
#include "../evb/config.h"
#include "../evb/channel.h"
#include "../evb/evb.h"

#include "../app/loopback.h"

extern u_char bchannel_start[MAX_SOCK_NUM];
extern CHCONF	ChConf;

/**
 @brief	loopback test using TCP(server mode)
 */
void loopback_tcps(
	u_char ch	/**< channel(socket) index */
	)
{
	int len;							
	//u_char * data_buf = (u_char*) TX_BUF; // 0x1100, RX_BUF = TX_BUF+TX_RX_MAX_BUF_SIZE
uint8 data_buf[1500];
uint16 max_bufsize = sizeof(data_buf);

	switch (getSn_SR(ch))
	{
	case SOCK_ESTABLISHED:						/* if connection is established */
		if(bchannel_start[ch]==1)
		{
			PRINTLN3("%d : Connected by %s(%u)",ch,inet_ntoa(GetDestAddr(ch)),GetDestPort(ch));
			bchannel_start[ch] = 2;
		}
		if ((len = getSn_RX_RSR(ch)) > 0) 			/* check Rx data */
		{
			if (len > max_bufsize) len = max_bufsize;	/* if Rx data size is lager than TX_RX_MAX_BUF_SIZE */
									/* the data size to read is MAX_BUF_SIZE. */
			len = recv(ch, data_buf, len);			/* read the received data */
			send(ch, data_buf, len);				/* send the received data */
		}
		break;
	case SOCK_CLOSE_WAIT:                           		/* If the client request to close */
		DPRINTLN1("%d : CLOSE_WAIT", ch);
		disconnect(ch);
		bchannel_start[ch] = 0;
		break;
	case SOCK_CLOSED:                                               /* if a socket is closed */
		if(!bchannel_start[ch]) 
		{
			PRINTLN1("%d : Loop-Back TCP Server Started.",ch);
			bchannel_start[ch] = 1;
		}
		if(socket(ch,Sn_MR_TCP,ChConf.ch[ch].port,0x00) == 0)    /* reinitialize the socket */
		{
			PRINTLN1("\a%d : Fail to create socket.",ch);
			bchannel_start[ch] = 0;
		}
		else
			listen(ch);
		
		break;
	}
}

/**
 @brief	loopback test using TCP(client mode)
 */
void loopback_tcpc(
	u_char ch	/**< channel(socket) index */
	)
{
	int len;							
	u_char * data_buf = (u_char*) TX_BUF;
	uint8 destip[4] = {192, 168, 1, 226};
	switch (getSn_SR(ch))
	{
	case SOCK_ESTABLISHED:						/* if connection is established */
		if(bchannel_start[ch]==1)
		{
			PRINTLN3("%d : Connected by %s(%u)",ch,inet_ntoa(GetDestAddr(ch)),GetDestPort(ch));			
			bchannel_start[ch] = 2;
		}
		if ((len = getSn_RX_RSR(ch)) > 0) 			/* check Rx data */
		{
			if (len > TX_RX_MAX_BUF_SIZE) len = TX_RX_MAX_BUF_SIZE;	/* if Rx data size is lager than TX_RX_MAX_BUF_SIZE */
									/* the data size to read is MAX_BUF_SIZE. */
			len = recv(ch, data_buf, len);			/* read the received data */
			send(ch, data_buf, len);				/* send the received data */
		}
		break;
	case SOCK_CLOSE_WAIT:                           		/* If the client request to close */
		DPRINTLN1("%d : CLOSE_WAIT", ch);
		disconnect(ch);
		bchannel_start[ch] = 0;
		break;
	case SOCK_CLOSED:                                               /* if a socket is closed */
		if(!bchannel_start[ch])
		{
			PRINTLN1("%d : Loop-Back TCP Client Started.",ch);
			bchannel_start[ch] = 1;
		}
		if(socket(ch,Sn_MR_TCP,get_system_any_port(),0x00) == 0)    /* reinitialize the socket */
		{
			PRINTLN1("\a%d : Fail to create socket.",ch);
			bchannel_start[ch] = 0;
		}
		else
		{
		    printf("Coonecting to...\r\n");
			connect(ch,(u_char*)&ChConf.ch[ch].destip,ChConf.ch[ch].port);
		
		}
		break;
	}
}

/**
 @brief	loopback test using UDP
 */
void loopback_udp(
	u_char ch	/**< channel(socket) index */
	)
{
	int len;
	u_char * data_buf = (u_char*) TX_BUF;
	uint8 destip[4];
	uint16 destport;

	switch (getSn_SR(ch))
	{
	case SOCK_UDP:
		if ((len = getSn_RX_RSR(ch)) > 0) 			/* check Rx data */
		{
			if (len > TX_RX_MAX_BUF_SIZE) len = TX_RX_MAX_BUF_SIZE;	/* if Rx data size is lager than TX_RX_MAX_BUF_SIZE */
		
			len = recvfrom(ch, data_buf, len,&destip,&destport);			/* read the received data */
			if(sendto(ch, data_buf, len,&destip,destport) == 0)	/* send the received data */
			{
				PRINTLN("\a\a\a%d : System Fatal Error.");
				evb_soft_reset();
			}
		}
		break;
	case SOCK_CLOSED:      
	    /* if a socket is closed */
		PRINTLN1("%d : Loop-Back UDP Started.",ch);
		if(socket(ch,Sn_MR_UDP,ChConf.ch[ch].port,0x00)== 0)    /* reinitialize the socket */
			PRINTLN1("\a%d : Fail to create socket.",ch);
		break;
	}
}




