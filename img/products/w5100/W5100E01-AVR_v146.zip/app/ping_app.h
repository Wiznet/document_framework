/**
 @file		ping_app.h
*/
#ifndef __PING_APP_H
#define __PING_APP_H

extern void ping_request(void);
extern void ping_usage(void);	// Display the usage of ping command

#endif
