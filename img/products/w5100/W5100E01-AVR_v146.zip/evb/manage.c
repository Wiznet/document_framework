/**
 @file		manage.c
 @brief 		administration menu
 */

/* #include <stdio.h> */
#include <string.h>
#include "../mcu/types.h"
#include "../mcu/serial.h"
#include "../mcu/delay.h"
#include "../util/myprintf.h"
#include "../util/sockutil.h"
#include "../util/util.h"
#include "../iinchip/socket.h"
#include "../evb/config.h"
#include "../evb/lcd.h"
#include "../evb/led.h"
#include "../evb/evb.h"
#include "../app/ping_app.h"
#include "../evb/manage.h"

static u_char manage_network(void);
static u_char manage_channel(void);
static void select_ch_app(CHCONF* pChConf, u_char ch);

extern NETCONF	NetConf;
extern CHCONF	ChConf;

extern char uart0_getchar(FILE *f);
extern void uart0_putchar(char c, FILE *f);

/**
 @brief		Check to enter administrator mode
 */ 
void check_manage(void)
{
	int i,j;
	char key;

	if(get_reset_flag()== SYSTEM_AUTO_RESET)
	{
		set_reset_flag(SYSTEM_MANUAL_RESET);
		return;
	}
	
	PRINT("\r\nPress 'M' to enter the manager mode");

	lcd_clrscr();
	lcd_gotoxy(0,0);
	lcd_puts("< MANAGE  MODE >");
	lcd_gotoxy(0,1);
	led_on(0);
	led_off(1);
	for (i = 0; i < 16; i++)
	{
		for ( j = 0 ; j < 40 ; j++)
		{
			if(uart_keyhit(0))
			{		

				key = uart0_getchar(NULL);
				if(key == 'M' || key == 'm')
				{
					manage_config();
					return;
				}
				else if(key == 0x1B) return;					
			}
			wait_1ms(5);
		}
		PRINT("\a.");	
		lcd_putch(0xFF);
		led_toggle(0);
		led_toggle(1);
	}
	PRINTLN("");
	led_on(0);
	led_on(1);
	
}


/**
 @brief		manage mode main menu.
 */ 
void manage_config(void)
{
	u_char sel = 0;
	u_char bmodify=0;
	
	get_chconf(&ChConf);
	while(sel != 'e' && sel != 'E')
	{	
		PRINT(	"\r\n==================="
			    	"\r\nEVB B/D MANAGE MODE"
				"\r\n==================="
				"\r\n1 : Network Config"
				"\r\n2 : Channel Config"
				"\r\n3 : Ping App Test"
				"\r\nF : Factory Reset"
				"\r\nE : Exit"
				"\r\n==================="
				"\r\nSelect ? ");
		
		evb_set_lcd_text(1,(u_char*)"  Select Menu?  ");

		sel = uart0_getchar(NULL);
		uart0_putchar(sel,NULL);
		uart_puts(0,"\r\n");
		
		switch(sel)
		{
		case '1' : evb_set_lcd_text(1,(u_char*)" Network Config ");
			bmodify |= manage_network();
			break;
		case '2' : evb_set_lcd_text(1,(u_char*)" Channel Config ");
			bmodify |= manage_channel();
			break;

		case '3' : evb_set_lcd_text(1,(u_char*)"  Ping Request  ");
			net_init();
			ping_request();
			bmodify = 1;
			break;

		case 'F' :
		case 'f' : PRINTLN("Factory Reset");
			load_factory_netconf();
			load_factory_chconf();
			bmodify = 1;
			break;
		case 'E' : 
		case 'e' : PRINTLN("Exit Network Config");
			break;
		default : PRINTLN("\aInvalid Selectiton");
			break;
		}
	}
	if(bmodify) evb_soft_reset();
}


/**
 @brief		manage mode network config menu
 */ 
static u_char manage_network(void)
{
	u_char sel = 0;
	u_char ret = 0;
	u_char addrstr[30];
	u_char * tok;
	u_int i,tnum;
	u_char tmac[6];
	
	get_netconf(&NetConf);

	while(sel != 'e' && sel != 'E')
	{
		PRINT(	"\r\n------------------"
				"\r\nNETWORK CONFIG"
				"\r\n------------------"
				"\r\nD : Display config"
				"\r\n1 : Source IP"
				"\r\n2 : Gateway IP"
				"\r\n3 : Subnet Mask"
				"\r\n4 : DNS Server IP"
				"\r\nM : MAC address"
				"\r\nA : Memory Allocation"
				"\r\nF : Factory reset"
				"\r\nE : Exit"
				"\r\n------------------"
				"\r\nSelect ? ");	

		sel = uart0_getchar(NULL);
		uart0_putchar(sel,NULL);
		uart_puts(0,"\r\n");

		switch(sel)
		{
		case 'd' :
		case 'D' : display_netconf(&NetConf);
			break;
		case '1' : PRINT("Source IP ? ");
			uart_gets(0,(char*)addrstr,0,30);
			if(!VerifyIPAddress((char*)addrstr))
			{
				PRINTLN("\aInvalid.");
				continue;
			}
			NetConf.sip = htonl(inet_addr(addrstr));
			ret = 1;
			break;
		case '2' : PRINT("Gateway IP ? ");
			uart_gets(0,(char*)addrstr,0,30);
			if(!VerifyIPAddress((char*)addrstr))
			{
				PRINTLN("\aInvalid.");
				continue;
			}
			NetConf.gwip = htonl(inet_addr(addrstr));
			ret = 1;		
			break;
		case '3' : PRINT("Subnet Mask ? ");
			uart_gets(0,(char*)addrstr,0,30);
			if(!VerifyIPAddress((char*)addrstr))
			{
				PRINTLN("\aInvalid.");
				continue;
			}
			NetConf.sn = htonl(inet_addr(addrstr));
			ret = 1;
			break;
		case '4' :PRINT("DNS Server IP ? ");
			uart_gets(0,(char*)addrstr,0,30);
			if(!VerifyIPAddress((char*)addrstr))
			{
				PRINTLN("\aInvalid.");
				continue;
			}
			NetConf.dns = htonl(inet_addr(addrstr));
			ret = 1;
			break;
		case 'M' :
		case 'm' : PRINT("MAC Address ? ");
			uart_gets(0,(char*)addrstr,0,30);
			tok = addrstr;
			for(i = 0; i < 6; i++)
			{
				tok = (u_char*)strtok((char*)tok,".");
				if (tok == 0 && i != 5) break;
				if(!ValidATOI((char*)tok,0x10,(int*)&tnum)) break;
				if(tnum < 0 || tnum > 255) break;
				tmac[i] = tnum & 0xFF;
				PRINT1("%.2x", tmac[i]);
				/* printf("%.2x", tmac[i]); */
				tok = NULL;
			}		
			if( i != 6)
			{
				PRINTLN("\aInvalid.");
				//continue;
			}
			else
			{
				memcpy(NetConf.mac,tmac,6);
				ret = 1;
			}
			break;
		case 'A' :
		case 'a' : PRINT("Memory Alloc ? ");
			uart_gets(0,(char*)addrstr,0,3);
			NetConf.Mem_alloc = ATOI((char*)addrstr,0x10);
			PRINTLN1("%.2x", NetConf.Mem_alloc);
			break;
		case 'F' :
		case 'f' : PRINTLN("Factory Reset");
			load_factory_netconf();
			ret = 1;
			break;
		case 'E' : 
		case 'e' : set_netconf(&NetConf);
			PRINTLN("Exit Network Config");
			break;
		case 0x1B: PRINTLN("User canceled.");
			break;
		default : PRINTLN("\aInvalid Selectiton");
			break;
		}
	}
	return ret;
}


/**
 @brief		manage mode channel config menu
 */ 
static u_char manage_channel(void)
{
	u_char sel = 0;
	u_char ret = 0;
	u_char ii = 0;
	
	get_chconf(&ChConf);

	while(sel != 'e' && sel != 'E')
	{
		PRINT(	"\r\n------------------"
				"\r\nCHANNEL CONFIG"
				"\r\n------------------"
				"\r\nD : Display Config");

		for (ii = 0; ii < MAX_SOCK_NUM; ii++) PRINT2("\r\n%d : %dth Channel", ii, ii);

		PRINT(	"\r\nF : Factory Reset"
				"\r\nE : Exit"
				"\r\n------------------"
				"\r\nSelect ? ");	

		sel = uart0_getchar(NULL);
		uart0_putchar(sel,NULL);
		uart_puts(0,"\r\n");

		switch(sel)
		{
		case '0' : 
		case '1' : 
		case '2' : 
		case '3' :  select_ch_app(&ChConf,sel-'0');
			break;
		case 'D' :
		case 'd' : display_chconf(&ChConf);
			break;
		case 'F' :
		case 'f' : PRINTLN("Factory Reset");
			load_factory_chconf();
			ret = 1;
			break;
		case 'E' : 
		case 'e' : set_chconf(&ChConf);
			PRINTLN("Exit Channel Config");
			break;
		case 0x1B: PRINTLN("User canceled.");
			break;
		default : PRINTLN("\aInvalid Selectiton");
			break;
		}
	}
	return ret;
}


/**
 @brief		channel mode setting.
 */ 
static void select_ch_app(CHCONF* pChConf, u_char ch)
{
	u_long test_port;
	u_long test_result;

	u_char sel,i,bloop;
	u_int port;
	u_char addrstr[16];
	u_long addr;
	bloop = 1;
	while(bloop)
	{
		PRINTLN1("Select the followed APPs type for %d channel.",ch);
		PRINTLN("\t0 : No Use"); 		
		if(!ch) PRINT("\t1 : DHCP Client");

		PRINT(	"\r\n\t2 : Loop-Back TCP Server"
				"\r\n\t3 : Loop-Back TCP Client"
				"\r\n\t4 : Loop-Back UDP"
				"\r\n\t5 : Web Server"
				"\r\nSelect ? ");
		
		sel = uart0_getchar(NULL);
		uart0_putchar(sel,NULL);
		uart_puts(0,"\r\n");
		switch(sel)
		{

		case '0': pChConf->ch[ch].type = NOTUSE;
			bloop = 0;
			break;
		case '1': 
			if(!ch)
			{ 
				pChConf->ch[0].type = DHCP_CLIENT;
				bloop = 0;
			}
			else 
			{
				PRINTLN("\aInvalid.");
				bloop = 1;
			}
			break;
		case '2': 
			while(1)
			{
				PRINT("Listen Port Num (1~65535) ? ");
				uart_gets(0,(char*)addrstr,0,8);
				if(addrstr[0] == 0) 
				{
					port = DEFAULT_LISTEN_PORT;
					PRINTLN1("Default Applied. %d",port);
					break;
				}
				if(addrstr[0] == '0' && addrstr[1] == 'x')
				{
					if(ValidATOI((char*)addrstr+2,0x10,(int*)&port)) break;
				}
				else if(ValidATOI((char*)addrstr,10,(int*)&port)) break;
				PRINTLN("\aInvalid Range.");
			}
			if(!port)
			{
				port = DEFAULT_LISTEN_PORT;
				PRINTLN1("Default Applied. %d",port);
			}
			pChConf->ch[ch].type = LB_TCPS;
			pChConf->ch[ch].port = port;
			bloop = 0;
			break;
		case '3':
			while(1)
			{
				PRINT("Server IP Address ? ");
				uart_gets(0,(char*)addrstr,0,16);
				if(addrstr[0] == 0) 
				{
				/*  +2008.01 [hw] : bug fix(Swap DESTIP) */ 
					addr = htonl(DEFAULT_CH_DESTIP);
				/* --- */
					PRINTLN1("Default Applied. %s",inet_ntoa(ntohl(addr)));
					break;
				}
				
				if(VerifyIPAddress((char*)addrstr))
				{
					addr = htonl(inet_addr(addrstr));
					break;
				}
				PRINTLN("\aInvalid Range.");
			}
			pChConf->ch[ch].destip = addr;
			while(1)
			{
				PRINT("Server Port Num (1~65535) ? ");
				uart_gets(0,(char*)addrstr,0,8);
				if(addrstr[0] == 0) 
				{
					port = DEFAULT_CONNECT_PORT;
					PRINTLN1("Default Applied. %d",port);
					break;
				}
				if(addrstr[0] == '0' && addrstr[1] == 'x')
				{
					if(ValidATOI((char*)(addrstr+2),0x10,(int*)&port)) break;
				}
				else if(ValidATOI((char*)addrstr,10,(int*)&port)) break;
				PRINTLN("\aInvalid Range.");
			}
			if(!port)
			{
				port = DEFAULT_CONNECT_PORT;
				PRINTLN1("Default Applied. %d",port);
			}
			pChConf->ch[ch].port = port;
			pChConf->ch[ch].type = LB_TCPC;
			bloop = 0;
			break;
		case '4':
			while(1)
			{
				while(1)
				{
					PRINT("Source Port Num (1~65535) ? ");
					uart_gets(0,(char*)addrstr,0,8);
					if(addrstr[0] == 0) 
					{
						port = DEFAULT_SOURCE_PORT;
						PRINTLN1("Default Applied. %d",port);
						break;
					}
					if(addrstr[0] == '0' && addrstr[1] == 'x')
					{
						if(ValidATOI((char*)(addrstr+2),0x10,(int*)&port)) break;
					}
					else if(ValidATOI((char*)addrstr,10,(int*)&port)) break;
					PRINTLN("\aInvalid Range.");
				}
				if(!port)
				{
					port = DEFAULT_SOURCE_PORT;
					PRINTLN1("Default Applied. %d",port);
				}
				for(i=0; i < MAX_SOCK_NUM; i++)
				{
					if(ch!=i && pChConf->ch[i].type == LB_UDP && pChConf->ch[i].port == port)
					{
						i+=10;
						break;
					}
				}
				if(i==MAX_SOCK_NUM) break;
				PRINTLN1("\aYou can't use the same port number in UDP. The %d channel is same.",i-10);
			}
			pChConf->ch[ch].port = port;
			pChConf->ch[ch].type = LB_UDP;
			bloop = 0;
			break;
		case '5':
			while(1)
			{
				PRINT("HTTP Port Num (1~65535) ? ");
				uart_gets(0,(char*)addrstr,0,8);
				if(addrstr[0] == 0) 
				{
					port = DEFAULT_HTTP_PORT;
					PRINTLN1("Default Applied. %d",port);
					break;
				}
				if(addrstr[0] == '0' && addrstr[1] == 'x')
				{
					if(ValidATOI((char*)(addrstr+2),0x10,(int*)&port)) break;
				}
				else if(ValidATOI((char*)addrstr,10,(int*)&port)) break;
				PRINTLN("\aInvalid Range.");
			}
			if(!port)
			{
				port = DEFAULT_HTTP_PORT;
				PRINTLN1("Default Applied. %d",port);
			}
			pChConf->ch[ch].port = port;
			pChConf->ch[ch].type = WEB_SERVER;
			bloop = 0;
			break;


		case 0x1b: PRINTLN("User canceled.");
			break;
		default: PRINTLN("\aInvalid.");
			break;
		}
	}
}

