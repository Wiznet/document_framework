/**
 @file		evb.h
 @brief 		
 */

#ifndef _EVB_H
#define _EVB_H


extern void mcu_init(void);
extern void evb_init(void);
extern void net_init(void);

extern void evb_soft_reset(void);

extern void evb_logo(void);
extern void evb_lcd_logo(void);

extern u_char* evb_get_lcd_text(u_char row);
extern void evb_set_lcd_text(u_char row, u_char* lcd);

#endif
