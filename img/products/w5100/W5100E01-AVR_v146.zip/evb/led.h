/*
*
@file		led.h
*/

#ifndef _LED_H
#define _LED_H

#define LED_AVR_PORT_VAL	PORTG
#define LED_AVR_PORT_DIR	DDRG

#define LED_PIN_0		3
#define LED_PIN_1		4

#define LED_ON			1
#define LED_OFF			0	

extern void led_init(void);
extern void led_toggle(u_char led);
extern void led_off(u_char led);
extern void led_on(u_char led);

extern u_char led_state(u_char led);

#endif
