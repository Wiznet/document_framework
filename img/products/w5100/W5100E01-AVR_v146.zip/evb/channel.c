/**
 * @file		channel.c
 * @brief 		interrupt handler
 */

#include "../mcu/types.h"
#include "../iinchip/socket.h"

#include "../util/myprintf.h"
#include "../evb/channel.h"


CHANNELHANDLER ChannelHandler[MAX_SOCK_NUM];
u_char bchannel_start[MAX_SOCK_NUM] = { 0, 0, 0, 0};	/** 0:close, 1:ready, 2:connect */


/**
* @brief	Initialize the channel handler
*
*/
void init_channel_handler(void)
{
	u_int i;
	for(i = 0; i < MAX_SOCK_NUM; i++)
	{
		ChannelHandler[i].Handler = 0;
		bchannel_start[i] = 0;
	}
}


/**
* @brief	Register the channel handler
*
*/
void register_channel_handler(
	u_char ch, 	/**< channel(socket) index */
	void (*handler)(u_char)	/**< channel handler */
	)
{
	ChannelHandler[ch].Handler = handler;
	DPRINTLN1("Register %d channel handler",ch);
}


/**
* @brief	Unregister the channel handler
*
*/
void unregister_channel_handler(
	u_char ch	/**< channel(socket) index */
	)
{
	ChannelHandler[ch].Handler = 0;
	bchannel_start[ch] = 0;
	DPRINTLN1("Unregister %d channel handler",ch);
}

