/*
*
@file		led.c
@brief	LED Basic Function Implement File
*/

#include <avr/io.h>

#include "../mcu/types.h"
#include "../mcu/delay.h"

#include "../evb/led.h"

/**
 @brief	Initialize LED.
 *
*/
void led_init(void)
{
	u_int i;
	LED_AVR_PORT_DIR |= (1<<LED_PIN_0) | (1<<LED_PIN_1);
	for(i = 0; i < 3; i++)
	{
		led_on(0);
		led_on(1);
		wait_10ms(30);
		led_off(0);
		led_off(1);
		wait_10ms(30);
	}
}

void led_toggle(u_char led)
{
	if(led_state(led)==LED_ON)
		LED_AVR_PORT_VAL &= ~(1 << (LED_PIN_0+led));
	else 	LED_AVR_PORT_VAL |= (1 << (LED_PIN_0+led));
}

void led_off(u_char led)
{
	LED_AVR_PORT_VAL &= ~(1 << (LED_PIN_0+led));
}

void led_on(u_char led)
{
	LED_AVR_PORT_VAL |= (1 << (LED_PIN_0+led));
}

u_char led_state(u_char led)
{
	return ( ( (LED_AVR_PORT_VAL & (1 << (LED_PIN_0+led)))) ? LED_ON : LED_OFF);
}
