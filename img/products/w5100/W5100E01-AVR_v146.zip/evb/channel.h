/**
 * @file		channel.h
 * @brief 		channel handler header file
 */

#ifndef _CHANNEL_H
#define _CHANNEL_H

/**
 @brief		channel hander structure
 */
typedef struct _CHANNELHANDLE
{
	void (*Handler)(u_char);	/**< channel handler's function pointer */
}CHANNELHANDLER;


extern void init_channel_handler(void);
extern void register_channel_handler(u_char ch, void (*handler)(u_char));
extern void unregister_channel_handler(u_char ch);

#endif
