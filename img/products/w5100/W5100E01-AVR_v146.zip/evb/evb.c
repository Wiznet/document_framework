/**
 @file		evb.c
 @brief 		functions to initialize EVB prepheral equipments
 */

#include <avr/io.h>
#include <avr/interrupt.h>
#include <string.h>

#include "../mcu/types.h"
#include "../mcu/serial.h"
#include "../iinchip/socket.h"
#include "../iinchip/w5100.h"
#include "../util/util.h"
#include "../util/sockutil.h"
#include "../util/myprintf.h"
#include "../evb/lcd.h"
#include "../evb/led.h"
#include "../evb/config.h"

#include "../evb/evb.h"


#define	ATMEGA128_0WAIT		0
#define	ATMEGA128_1WAIT		1
#define	ATMEGA128_2WAIT		2
#define	ATMEGA128_3WAIT		3
#define 	ATMEGA128_NUM_WAIT	ATMEGA128_0WAIT

extern SYSINFO	SysInfo;
extern NETCONF	NetConf;

static u_char evb_lcd_text[LCD_MAX_ROW][LCD_MAX_COL+1];


/**
 * @brief	Initialize EVB prepheral equipments( MCU, LCD, UART,... )
 */ 
void evb_init(void)
{
	u_int i;
	
	mcu_init();
	lcd_init();
	for(i = 0; i < LCD_MAX_ROW;i++) 
		memset(evb_lcd_text[i],' ',LCD_MAX_COL+1);
	uart_init(0, 7);		// Serial Port Initialize
	led_init();
	init_conf_variables();	
}

void evb_soft_reset(void)
{
	PRINTLN("System Reset.");
	set_reset_flag(SYSTEM_AUTO_RESET);
	asm volatile("jmp 0x0000");	
}


void evb_logo(void)
{
	NETCONF	net_conf_reg;
	u_char status;

	PRINTLN("\r\n###########################################");
	PRINT("W5100E01-AVR  Test in ");
#if (__DEF_IINCHIP_BUS__ == __DEF_IINCHIP_DIRECT_MODE__)
	PRINTLN("Direct Mode");
#elif (__DEF_IINCHIP_BUS__ == __DEF_IINCHIP_INDIRECT_MODE__)
	PRINTLN("Indirect Mode");
#elif (__DEF_IINCHIP_BUS__ == __DEF_IINCHIP_SPI_MODE__)
	PRINTLN("SPI Mode");
#else
	#error "unknown bus type"
#endif

	PRINT("###########################################\r\n"
		"Copyright : WIZnet, Inc. 2013\r\n" 
		"Homepage  : http://www.wiznet.co.kr\r\n"
		"Support   : support@wiznet.co.kr\r\n"
		"Sales     : sales@wiznet.co.kr\r\n"
		"-------------------------------------------\r\n" );
	PRINTLN4("F/W Version   : %d.%d.%d.%d",(u_char)(SysInfo.ver>>24),(u_char)(SysInfo.ver>>16),
					(u_char)(SysInfo.ver>>8),(u_char)(SysInfo.ver));

	PRINTLN4("H/W Version   : %d.%d.%d.%d",(u_char)(HW_VERSION>>24),(u_char)(HW_VERSION>>16),
					(u_char)(HW_VERSION>>8),(u_char)(HW_VERSION));
	

	//net config + 2007.12.13 [jhpark]
	//read from iinchip reg
	get_netconf_reg(&net_conf_reg);

	//compare conf value
	status = comp_net_conf(&NetConf, &net_conf_reg);
	
	if(status)
	{
		display_netconf(&net_conf_reg);

		//					0123456789abcdef
		evb_set_lcd_text(1,(u_char*)"Reg Access Error");

		PRINTLN1("IInChip Reg access error! - %d", status);
	}
	else
	{
		display_netconf(&NetConf);
	 	evb_lcd_logo();
	}
	PRINTLN("###########################################\r\n");

}

void evb_lcd_logo(void)
{
	u_char logo[17];
	lcd_clrscr();
	lcd_gotoxy(0,0);
	sprintf((char*)logo, "<W5100E01 v%d.%d>",(u_char)(SysInfo.ver>>24),(u_char)(SysInfo.ver>>16));
	evb_set_lcd_text(0,logo);
	evb_set_lcd_text(1,(u_char*)inet_ntoa_pad(ntohl(NetConf.sip)));
}

u_char* evb_get_lcd_text(u_char row)
{
	if(row < LCD_MAX_ROW)
		return evb_lcd_text[row];
	return 0;
	
}

void evb_set_lcd_text(u_char row, u_char* lcd)
{
	if(row < LCD_MAX_ROW && strlen((char*)lcd) <= LCD_MAX_COL)
	{
		memset(evb_lcd_text[row],' ',LCD_MAX_COL);
		evb_lcd_text[row][LCD_MAX_COL] = 0;
		memcpy(evb_lcd_text[row],lcd,strlen((char*)lcd));
		lcd_gotoxy(0,row);
		lcd_puts((char*)evb_lcd_text[row]);
	}
}

void mcu_init(void) 
{
	cli();
		
#ifndef __DEF_IINCHIP_INT__	
	EICRA=0x00;
	EICRB=0x00;
	EIMSK=0x00;
	EIFR=0x00;
#else
	EICRA = 0x00;			// External Interrupt Control Register A clear
	EICRB = 0x02;			// External Interrupt Control Register B clear // edge 
	EIMSK = (1 << INT4);		// External Interrupt Mask Register : 0x10
	EIFR = 0xFF;			// External Interrupt Flag Register all clear
	DDRE &= ~(1 << INT4);		// Set PE Direction 
	PORTE |= (1 << INT4);		// Set PE Default value
#endif


#if (ATMEGA128_NUM_WAIT == ATMEGA128_0WAIT)
	MCUCR = 0x80;		
	XMCRA=0x40;
#elif (ATMEGA128_NUM_WAIT == ATMEGA128_1WAIT)
	MCUCR = 0xc0;		// MCU control regiseter : enable external ram
	XMCRA=0x40;		// External Memory Control Register A : 
						// Low sector   : 0x1100 ~ 0x7FFF
						// Upper sector : 0x8000 ~ 0xFFFF
#elif (ATMEGA128_NUM_WAIT == ATMEGA128_2WAIT )
	MCUCR = 0x80;
	XMCRA=0x42;
#elif ((ATMEGA128_NUM_WAIT == ATMEGA128_3WAIT)
	MCUCR = 0xc0;
	XMCRA=0x42;
#else
#error "unknown atmega128 number wait type"
#endif	

	sei();				// enable interrupts
}

void net_init(void)
{
	iinchip_init();
	get_netconf(&NetConf);
	setSIPR((u_char*)&NetConf.sip);
	setGAR((u_char*)&NetConf.gwip);
	setSUBR((u_char*)&NetConf.sn);
	setSHAR(NetConf.mac);
#ifdef __DEF_IINCHIP_INT__
	setIMR(0xEF);
#endif	
	sysinit(NetConf.Mem_alloc,NetConf.Mem_alloc);
}
