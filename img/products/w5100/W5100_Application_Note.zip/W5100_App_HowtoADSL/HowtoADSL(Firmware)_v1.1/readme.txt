+ How to compile

   Execute the make in the ~/compile folder, then the source code is compiled.


+ How to Change the interface mode
  Change the value of the __DEF_IINCHIP_BUS__ in the types.h file.