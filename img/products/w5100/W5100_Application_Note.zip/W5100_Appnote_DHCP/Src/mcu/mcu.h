/**
 @file		mcu.h
 @brief 		
 */

#ifndef _MCU_H
#define _MCU_H

extern void mcu_init(void);
extern void mcu_soft_reset(void);

#endif
